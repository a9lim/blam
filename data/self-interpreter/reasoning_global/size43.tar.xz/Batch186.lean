import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2384864524718 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2384864524718 : Closed e2384864524718 ∧ code e2384864524718 = 11180957546926 := by decide
theorem cert_e2384864524718 : check e2384864524718 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2384864524730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2384864524730 : Closed e2384864524730 ∧ code e2384864524730 = 11180957546938 := by decide
theorem cert_e2384864524730 : check e2384864524730 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2384864524778 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2384864524778 : Closed e2384864524778 ∧ code e2384864524778 = 11180957546986 := by decide
theorem cert_e2384864524778 : check e2384864524778 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2384864524910 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2384864524910 : Closed e2384864524910 ∧ code e2384864524910 = 11180957547118 := by decide
theorem cert_e2384864524910 : checkPay e2384864524910 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2384864524922 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2384864524922 : Closed e2384864524922 ∧ code e2384864524922 = 11180957547130 := by decide
theorem cert_e2384864524922 : checkPay e2384864524922 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2384864525210 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2384864525210 : Closed e2384864525210 ∧ code e2384864525210 = 11180957547418 := by decide
theorem cert_e2384864525210 : checkPay e2384864525210 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2384864525526 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2384864525526 : Closed e2384864525526 ∧ code e2384864525526 = 11180957547734 := by decide
theorem cert_e2384864525526 : check e2384864525526 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2384864525530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2384864525530 : Closed e2384864525530 ∧ code e2384864525530 = 11180957547738 := by decide
theorem cert_e2384864525530 : check e2384864525530 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2384864525546 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2384864525546 : Closed e2384864525546 ∧ code e2384864525546 = 11180957547754 := by decide
theorem cert_e2384864525546 : check e2384864525546 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2384864525622 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2384864525622 : Closed e2384864525622 ∧ code e2384864525622 = 11180957547830 := by decide
theorem cert_e2384864525622 : check e2384864525622 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2384864525626 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2384864525626 : Closed e2384864525626 ∧ code e2384864525626 = 11180957547834 := by decide
theorem cert_e2384864525626 : check e2384864525626 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2384864525722 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2384864525722 : Closed e2384864525722 ∧ code e2384864525722 = 11180957547930 := by decide
theorem cert_e2384864525722 : check e2384864525722 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2384864529262 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384864529262 : Closed e2384864529262 ∧ code e2384864529262 = 11180957551470 := by decide
theorem cert_e2384864529262 : check e2384864529262 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2384864529270 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384864529270 : Closed e2384864529270 ∧ code e2384864529270 = 11180957551478 := by decide
theorem cert_e2384864529270 : check e2384864529270 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2384864529326 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384864529326 : Closed e2384864529326 ∧ code e2384864529326 = 11180957551534 := by decide
theorem cert_e2384864529326 : check e2384864529326 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384864529338 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384864529338 : Closed e2384864529338 ∧ code e2384864529338 = 11180957551546 := by decide
theorem cert_e2384864529338 : check e2384864529338 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384864529366 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384864529366 : Closed e2384864529366 ∧ code e2384864529366 = 11180957551574 := by decide
theorem cert_e2384864529366 : check e2384864529366 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2384864529370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384864529370 : Closed e2384864529370 ∧ code e2384864529370 = 11180957551578 := by decide
theorem cert_e2384864529370 : check e2384864529370 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2384864529646 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384864529646 : Closed e2384864529646 ∧ code e2384864529646 = 11180957551854 := by decide
theorem cert_e2384864529646 : check e2384864529646 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2384864529654 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384864529654 : Closed e2384864529654 ∧ code e2384864529654 = 11180957551862 := by decide
theorem cert_e2384864529654 : check e2384864529654 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2384864530030 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384864530030 : Closed e2384864530030 ∧ code e2384864530030 = 11180957552238 := by decide
theorem cert_e2384864530030 : check e2384864530030 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384864530042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384864530042 : Closed e2384864530042 ∧ code e2384864530042 = 11180957552250 := by decide
theorem cert_e2384864530042 : check e2384864530042 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384864530230 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384864530230 : Closed e2384864530230 ∧ code e2384864530230 = 11180957552438 := by decide
theorem cert_e2384864530230 : check e2384864530230 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2384864530234 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384864530234 : Closed e2384864530234 ∧ code e2384864530234 = 11180957552442 := by decide
theorem cert_e2384864530234 : check e2384864530234 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2384864535982 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2384864535982 : Closed e2384864535982 ∧ code e2384864535982 = 11180957558190 := by decide
theorem cert_e2384864535982 : check e2384864535982 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384864535994 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2384864535994 : Closed e2384864535994 ∧ code e2384864535994 = 11180957558202 := by decide
theorem cert_e2384864535994 : check e2384864535994 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384864536042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2384864536042 : Closed e2384864536042 ∧ code e2384864536042 = 11180957558250 := by decide
theorem cert_e2384864536042 : check e2384864536042 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384864536174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2384864536174 : Closed e2384864536174 ∧ code e2384864536174 = 11180957558382 := by decide
theorem cert_e2384864536174 : check e2384864536174 [[],[.left,.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2384864536186 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2384864536186 : Closed e2384864536186 ∧ code e2384864536186 = 11180957558394 := by decide
theorem cert_e2384864536186 : check e2384864536186 [[],[.left,.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2384864536474 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2384864536474 : Closed e2384864536474 ∧ code e2384864536474 = 11180957558682 := by decide
theorem cert_e2384864536474 : check e2384864536474 [[],[.left,.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2384864539350 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2384864539350 : Closed e2384864539350 ∧ code e2384864539350 = 11180957561558 := by decide
theorem cert_e2384864539350 : check e2384864539350 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2384864539354 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2384864539354 : Closed e2384864539354 ∧ code e2384864539354 = 11180957561562 := by decide
theorem cert_e2384864539354 : check e2384864539354 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2384864539370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2384864539370 : Closed e2384864539370 ∧ code e2384864539370 = 11180957561578 := by decide
theorem cert_e2384864539370 : check e2384864539370 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2384864539446 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2384864539446 : Closed e2384864539446 ∧ code e2384864539446 = 11180957561654 := by decide
theorem cert_e2384864539446 : check e2384864539446 [[],[.left,.left],[.left],[],[],[.under,.under,.left]] .chain = true := by decide
def e2384864539450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2384864539450 : Closed e2384864539450 ∧ code e2384864539450 = 11180957561658 := by decide
theorem cert_e2384864539450 : check e2384864539450 [[],[.left,.left],[.left],[],[],[.under,.under,.left]] .chain = true := by decide
def e2384864539546 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2384864539546 : Closed e2384864539546 ∧ code e2384864539546 = 11180957561754 := by decide
theorem cert_e2384864539546 : check e2384864539546 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2384864676718 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384864676718 : Closed e2384864676718 ∧ code e2384864676718 = 11180957698926 := by decide
theorem cert_e2384864676718 : check e2384864676718 [[],[.left,.left],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e2384864676726 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384864676726 : Closed e2384864676726 ∧ code e2384864676726 = 11180957698934 := by decide
theorem cert_e2384864676726 : check e2384864676726 [[],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2384864676782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384864676782 : Closed e2384864676782 ∧ code e2384864676782 = 11180957698990 := by decide
theorem cert_e2384864676782 : check e2384864676782 [[],[.left,.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e2384864676794 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384864676794 : Closed e2384864676794 ∧ code e2384864676794 = 11180957699002 := by decide
theorem cert_e2384864676794 : check e2384864676794 [[],[.left,.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e2384864676822 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384864676822 : Closed e2384864676822 ∧ code e2384864676822 = 11180957699030 := by decide
theorem cert_e2384864676822 : check e2384864676822 [[],[.left,.left],[.left],[.left],[],[.left]] .chain = true := by decide
def e2384864676826 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384864676826 : Closed e2384864676826 ∧ code e2384864676826 = 11180957699034 := by decide
theorem cert_e2384864676826 : check e2384864676826 [[],[.left,.left],[.left],[.left],[],[.left],[],[]] .chain = true := by decide
def e2384864677102 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384864677102 : Closed e2384864677102 ∧ code e2384864677102 = 11180957699310 := by decide
theorem cert_e2384864677102 : check e2384864677102 [[],[.left,.left],[.left],[.left],[],[]] .chain = true := by decide
def e2384864677110 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384864677110 : Closed e2384864677110 ∧ code e2384864677110 = 11180957699318 := by decide
theorem cert_e2384864677110 : check e2384864677110 [[],[.left,.left],[.left],[.left],[],[]] .chain = true := by decide
def e2384864677486 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384864677486 : Closed e2384864677486 ∧ code e2384864677486 = 11180957699694 := by decide
theorem cert_e2384864677486 : check e2384864677486 [[],[.left,.left],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2384864677498 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384864677498 : Closed e2384864677498 ∧ code e2384864677498 = 11180957699706 := by decide
theorem cert_e2384864677498 : check e2384864677498 [[],[.left,.left],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2384864677686 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384864677686 : Closed e2384864677686 ∧ code e2384864677686 = 11180957699894 := by decide
theorem cert_e2384864677686 : check e2384864677686 [[],[.left,.left],[.left],[.left],[],[]] .chain = true := by decide
def e2384864677690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384864677690 : Closed e2384864677690 ∧ code e2384864677690 = 11180957699898 := by decide
theorem cert_e2384864677690 : check e2384864677690 [[],[.left,.left],[.left],[.left],[],[]] .chain = true := by decide
def e2384865266542 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384865266542 : Closed e2384865266542 ∧ code e2384865266542 = 11180958288750 := by decide
def e2384865266550 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384865266550 : Closed e2384865266550 ∧ code e2384865266550 = 11180958288758 := by decide
def e2384865266606 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384865266606 : Closed e2384865266606 ∧ code e2384865266606 = 11180958288814 := by decide
def e2384865266618 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384865266618 : Closed e2384865266618 ∧ code e2384865266618 = 11180958288826 := by decide
private def t_e2384865266618 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2384865266618 : ¬ IsSelfInterpreter e2384865266618 :=
  wSource (t := t_e2384865266618) (replay_sound (ps := []) (t := e2384865266618) (by decide)) (by decide)
def e2384865266646 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384865266646 : Closed e2384865266646 ∧ code e2384865266646 = 11180958288854 := by decide
theorem cert_e2384865266646 : check e2384865266646 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2384865266650 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384865266650 : Closed e2384865266650 ∧ code e2384865266650 = 11180958288858 := by decide
private def t_e2384865266650 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2384865266650 : ¬ IsSelfInterpreter e2384865266650 :=
  wSource (t := t_e2384865266650) (replay_sound (ps := []) (t := e2384865266650) (by decide)) (by decide)
def e2384865266926 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384865266926 : Closed e2384865266926 ∧ code e2384865266926 = 11180958289134 := by decide
theorem cert_e2384865266926 : check e2384865266926 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384865266934 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384865266934 : Closed e2384865266934 ∧ code e2384865266934 = 11180958289142 := by decide
theorem cert_e2384865266934 : check e2384865266934 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2384865267310 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384865267310 : Closed e2384865267310 ∧ code e2384865267310 = 11180958289518 := by decide
theorem cert_e2384865267310 : check e2384865267310 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2384865267322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384865267322 : Closed e2384865267322 ∧ code e2384865267322 = 11180958289530 := by decide
theorem cert_e2384865267322 : check e2384865267322 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2384865267510 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384865267510 : Closed e2384865267510 ∧ code e2384865267510 = 11180958289718 := by decide
theorem cert_e2384865267510 : check e2384865267510 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2384865267514 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384865267514 : Closed e2384865267514 ∧ code e2384865267514 = 11180958289722 := by decide
def e2385049775642 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049775642 : Closed e2385049775642 ∧ code e2385049775642 = 11181142797850 := by decide
private def t_e2385049775642 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049775642 : ¬ IsSelfInterpreter e2385049775642 :=
  wSource (t := t_e2385049775642) (replay_sound (ps := []) (t := e2385049775642) (by decide)) (by decide)
def e2385049777690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049777690 : Closed e2385049777690 ∧ code e2385049777690 = 11181142799898 := by decide
private def t_e2385049777690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049777690 : ¬ IsSelfInterpreter e2385049777690 :=
  wSource (t := t_e2385049777690) (replay_sound (ps := []) (t := e2385049777690) (by decide)) (by decide)
def e2385049792026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049792026 : Closed e2385049792026 ∧ code e2385049792026 = 11181142814234 := by decide
private def t_e2385049792026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049792026 : ¬ IsSelfInterpreter e2385049792026 :=
  wSource (t := t_e2385049792026) (replay_sound (ps := []) (t := e2385049792026) (by decide)) (by decide)
def e2385049795098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049795098 : Closed e2385049795098 ∧ code e2385049795098 = 11181142817306 := by decide
private def t_e2385049795098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049795098 : ¬ IsSelfInterpreter e2385049795098 :=
  wSource (t := t_e2385049795098) (replay_sound (ps := []) (t := e2385049795098) (by decide)) (by decide)
def e2385049802266 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049802266 : Closed e2385049802266 ∧ code e2385049802266 = 11181142824474 := by decide
private def t_e2385049802266 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049802266 : ¬ IsSelfInterpreter e2385049802266 :=
  wSource (t := t_e2385049802266) (replay_sound (ps := []) (t := e2385049802266) (by decide)) (by decide)
def e2385049803290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049803290 : Closed e2385049803290 ∧ code e2385049803290 = 11181142825498 := by decide
private def t_e2385049803290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049803290 : ¬ IsSelfInterpreter e2385049803290 :=
  wSource (t := t_e2385049803290) (replay_sound (ps := []) (t := e2385049803290) (by decide)) (by decide)
def e2385049873946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049873946 : Closed e2385049873946 ∧ code e2385049873946 = 11181142896154 := by decide
private def t_e2385049873946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049873946 : ¬ IsSelfInterpreter e2385049873946 :=
  wSource (t := t_e2385049873946) (replay_sound (ps := []) (t := e2385049873946) (by decide)) (by decide)
def e2385049875994 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049875994 : Closed e2385049875994 ∧ code e2385049875994 = 11181142898202 := by decide
private def t_e2385049875994 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049875994 : ¬ IsSelfInterpreter e2385049875994 :=
  wSource (t := t_e2385049875994) (replay_sound (ps := []) (t := e2385049875994) (by decide)) (by decide)
def e2385049972250 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049972250 : Closed e2385049972250 ∧ code e2385049972250 = 11181142994458 := by decide
private def t_e2385049972250 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049972250 : ¬ IsSelfInterpreter e2385049972250 :=
  wSource (t := t_e2385049972250) (replay_sound (ps := []) (t := e2385049972250) (by decide)) (by decide)
def e2385049975322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385049975322 : Closed e2385049975322 ∧ code e2385049975322 = 11181142997530 := by decide
private def t_e2385049975322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385049975322 : ¬ IsSelfInterpreter e2385049975322 :=
  wSource (t := t_e2385049975322) (replay_sound (ps := []) (t := e2385049975322) (by decide)) (by decide)
def e2385050023450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385050023450 : Closed e2385050023450 ∧ code e2385050023450 = 11181143045658 := by decide
private def t_e2385050023450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385050023450 : ¬ IsSelfInterpreter e2385050023450 :=
  wSource (t := t_e2385050023450) (replay_sound (ps := []) (t := e2385050023450) (by decide)) (by decide)
def e2385050024474 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2385050024474 : Closed e2385050024474 ∧ code e2385050024474 = 11181143046682 := by decide
private def t_e2385050024474 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2385050024474 : ¬ IsSelfInterpreter e2385050024474 :=
  wSource (t := t_e2385050024474) (replay_sound (ps := []) (t := e2385050024474) (by decide)) (by decide)
def e2385052022810 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052022810 : Closed e2385052022810 ∧ code e2385052022810 = 11181145045018 := by decide
theorem cert_e2385052022810 : check e2385052022810 [[]] .width = true := by decide
def e2385052031002 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052031002 : Closed e2385052031002 ∧ code e2385052031002 = 11181145053210 := by decide
theorem cert_e2385052031002 : check e2385052031002 [[]] .width = true := by decide
def e2385052088346 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052088346 : Closed e2385052088346 ∧ code e2385052088346 = 11181145110554 := by decide
theorem cert_e2385052088346 : check e2385052088346 [[]] .width = true := by decide
def e2385052100634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052100634 : Closed e2385052100634 ∧ code e2385052100634 = 11181145122842 := by decide
theorem cert_e2385052100634 : check e2385052100634 [[]] .width = true := by decide
def e2385052129306 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052129306 : Closed e2385052129306 ∧ code e2385052129306 = 11181145151514 := by decide
theorem cert_e2385052129306 : check e2385052129306 [[]] .width = true := by decide
def e2385052133402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052133402 : Closed e2385052133402 ∧ code e2385052133402 = 11181145155610 := by decide
theorem cert_e2385052133402 : check e2385052133402 [[]] .width = true := by decide
def e2385052416026 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052416026 : Closed e2385052416026 ∧ code e2385052416026 = 11181145438234 := by decide
theorem cert_e2385052416026 : check e2385052416026 [[]] .width = true := by decide
def e2385052424218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052424218 : Closed e2385052424218 ∧ code e2385052424218 = 11181145446426 := by decide
theorem cert_e2385052424218 : check e2385052424218 [[]] .width = true := by decide
def e2385052809242 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052809242 : Closed e2385052809242 ∧ code e2385052809242 = 11181145831450 := by decide
theorem cert_e2385052809242 : check e2385052809242 [[]] .width = true := by decide
def e2385052821530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385052821530 : Closed e2385052821530 ∧ code e2385052821530 = 11181145843738 := by decide
theorem cert_e2385052821530 : check e2385052821530 [[]] .width = true := by decide
def e2385053014042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385053014042 : Closed e2385053014042 ∧ code e2385053014042 = 11181146036250 := by decide
theorem cert_e2385053014042 : check e2385053014042 [[]] .width = true := by decide
def e2385053018138 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2385053018138 : Closed e2385053018138 ∧ code e2385053018138 = 11181146040346 := by decide
theorem cert_e2385053018138 : check e2385053018138 [[]] .width = true := by decide
def e2385065848174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2385065848174 : Closed e2385065848174 ∧ code e2385065848174 = 11181158870382 := by decide
theorem cert_e2385065848174 : check e2385065848174 [[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2385065848182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2385065848182 : Closed e2385065848182 ∧ code e2385065848182 = 11181158870390 := by decide
theorem cert_e2385065848182 : check e2385065848182 [[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2385065848238 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2385065848238 : Closed e2385065848238 ∧ code e2385065848238 = 11181158870446 := by decide
theorem cert_e2385065848238 : check e2385065848238 [[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2385065848250 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2385065848250 : Closed e2385065848250 ∧ code e2385065848250 = 11181158870458 := by decide
theorem cert_e2385065848250 : check e2385065848250 [[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2385065848278 : Closed e2385065848278 ∧ code e2385065848278 = 11181158870486 := by decide
theorem cert_e2385065848278 : check e2385065848278 [[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2385065848282 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2385065848282 : Closed e2385065848282 ∧ code e2385065848282 = 11181158870490 := by decide
theorem cert_e2385065848282 : check e2385065848282 [[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2385065848494 : Closed e2385065848494 ∧ code e2385065848494 = 11181158870702 := by decide
theorem cert_e2385065848494 : check e2385065848494 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848506 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2385065848506 : Closed e2385065848506 ∧ code e2385065848506 = 11181158870714 := by decide
theorem cert_e2385065848506 : check e2385065848506 [[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848554 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2385065848554 : Closed e2385065848554 ∧ code e2385065848554 = 11181158870762 := by decide
theorem cert_e2385065848554 : check e2385065848554 [[],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2385065848662 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2385065848662 : Closed e2385065848662 ∧ code e2385065848662 = 11181158870870 := by decide
theorem cert_e2385065848662 : check e2385065848662 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848666 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2385065848666 : Closed e2385065848666 ∧ code e2385065848666 = 11181158870874 := by decide
theorem cert_e2385065848666 : check e2385065848666 [[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2385065848682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2385065848682 : Closed e2385065848682 ∧ code e2385065848682 = 11181158870890 := by decide
theorem cert_e2385065848682 : check e2385065848682 [[],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2385065849710 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2385065849710 : Closed e2385065849710 ∧ code e2385065849710 = 11181158871918 := by decide
theorem cert_e2385065849710 : check e2385065849710 [[],[.left,.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2385065849718 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2385065849718 : Closed e2385065849718 ∧ code e2385065849718 = 11181158871926 := by decide
theorem cert_e2385065849718 : check e2385065849718 [[],[.left,.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2385065849774 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2385065849774 : Closed e2385065849774 ∧ code e2385065849774 = 11181158871982 := by decide
theorem cert_e2385065849774 : check e2385065849774 [[],[.left,.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2385065849786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2385065849786 : Closed e2385065849786 ∧ code e2385065849786 = 11181158871994 := by decide
theorem cert_e2385065849786 : check e2385065849786 [[],[.left,.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e2385065849814 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2385065849814 : Closed e2385065849814 ∧ code e2385065849814 = 11181158872022 := by decide
theorem cert_e2385065849814 : check e2385065849814 [[],[.left,.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2385065849818 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2385065849818 : Closed e2385065849818 ∧ code e2385065849818 = 11181158872026 := by decide
theorem cert_e2385065849818 : check e2385065849818 [[],[.left,.left],[.left],[],[.left],[.left]] .chain = true := by decide
def e2385065850094 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2385065850094 : Closed e2385065850094 ∧ code e2385065850094 = 11181158872302 := by decide
theorem cert_e2385065850094 : check e2385065850094 [[],[.left,.left],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2385065850102 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2385065850102 : Closed e2385065850102 ∧ code e2385065850102 = 11181158872310 := by decide
theorem cert_e2385065850102 : check e2385065850102 [[],[.left,.left],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2385065850478 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2385065850478 : Closed e2385065850478 ∧ code e2385065850478 = 11181158872686 := by decide
theorem cert_e2385065850478 : check e2385065850478 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065850490 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2385065850490 : Closed e2385065850490 ∧ code e2385065850490 = 11181158872698 := by decide
theorem cert_e2385065850490 : check e2385065850490 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065850678 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2385065850678 : Closed e2385065850678 ∧ code e2385065850678 = 11181158872886 := by decide
theorem cert_e2385065850678 : check e2385065850678 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065850682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2385065850682 : Closed e2385065850682 ∧ code e2385065850682 = 11181158872890 := by decide
theorem cert_e2385065850682 : check e2385065850682 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065851310 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2385065851310 : Closed e2385065851310 ∧ code e2385065851310 = 11181158873518 := by decide
theorem cert_e2385065851310 : check e2385065851310 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065851322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2385065851322 : Closed e2385065851322 ∧ code e2385065851322 = 11181158873530 := by decide
theorem cert_e2385065851322 : check e2385065851322 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065851370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2385065851370 : Closed e2385065851370 ∧ code e2385065851370 = 11181158873578 := by decide
theorem cert_e2385065851370 : check e2385065851370 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065851502 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2385065851502 : Closed e2385065851502 ∧ code e2385065851502 = 11181158873710 := by decide
theorem cert_e2385065851502 : check e2385065851502 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065851514 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2385065851514 : Closed e2385065851514 ∧ code e2385065851514 = 11181158873722 := by decide
theorem cert_e2385065851514 : check e2385065851514 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065851802 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2385065851802 : Closed e2385065851802 ∧ code e2385065851802 = 11181158874010 := by decide
theorem cert_e2385065851802 : check e2385065851802 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065852118 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2385065852118 : Closed e2385065852118 ∧ code e2385065852118 = 11181158874326 := by decide
theorem cert_e2385065852118 : check e2385065852118 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065852122 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2385065852122 : Closed e2385065852122 ∧ code e2385065852122 = 11181158874330 := by decide
theorem cert_e2385065852122 : check e2385065852122 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065852138 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2385065852138 : Closed e2385065852138 ∧ code e2385065852138 = 11181158874346 := by decide
theorem cert_e2385065852138 : check e2385065852138 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065852214 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2385065852214 : Closed e2385065852214 ∧ code e2385065852214 = 11181158874422 := by decide
theorem cert_e2385065852214 : check e2385065852214 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065852218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2385065852218 : Closed e2385065852218 ∧ code e2385065852218 = 11181158874426 := by decide
theorem cert_e2385065852218 : check e2385065852218 [[],[.left,.left],[.left],[],[.left],[]] .chain = true := by decide
def e2385065852314 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2385065852314 : Closed e2385065852314 ∧ code e2385065852314 = 11181158874522 := by decide
theorem cert_e2385065852314 : check e2385065852314 [[],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2385065855854 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2385065855854 : Closed e2385065855854 ∧ code e2385065855854 = 11181158878062 := by decide
theorem cert_e2385065855854 : check e2385065855854 [[],[.left,.left],[.left],[],[],[.left],[]] .smaller = true := by decide
def e2385065855862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2385065855862 : Closed e2385065855862 ∧ code e2385065855862 = 11181158878070 := by decide
theorem cert_e2385065855862 : check e2385065855862 [[],[.left,.left],[.left],[],[],[.left],[]] .smaller = true := by decide
def e2385065855918 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2385065855918 : Closed e2385065855918 ∧ code e2385065855918 = 11181158878126 := by decide
theorem cert_e2385065855918 : check e2385065855918 [[],[.left,.left],[.left],[],[],[.left],[]] .smaller = true := by decide
def e2385065855930 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2385065855930 : Closed e2385065855930 ∧ code e2385065855930 = 11181158878138 := by decide
theorem cert_e2385065855930 : check e2385065855930 [[],[.left,.left],[.left],[],[],[.left]] .chain = true := by decide
def e2385065855958 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2385065855958 : Closed e2385065855958 ∧ code e2385065855958 = 11181158878166 := by decide
theorem cert_e2385065855958 : check e2385065855958 [[],[.left,.left],[.left],[],[],[.left],[]] .smaller = true := by decide
def e2385065855962 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2385065855962 : Closed e2385065855962 ∧ code e2385065855962 = 11181158878170 := by decide
theorem cert_e2385065855962 : check e2385065855962 [[],[.left,.left],[.left],[],[],[.left]] .chain = true := by decide
def e2385065856238 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2385065856238 : Closed e2385065856238 ∧ code e2385065856238 = 11181158878446 := by decide
theorem cert_e2385065856238 : check e2385065856238 [[],[.left,.left],[.left],[],[],[],[]] .smaller = true := by decide
def e2385065856246 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2385065856246 : Closed e2385065856246 ∧ code e2385065856246 = 11181158878454 := by decide
theorem cert_e2385065856246 : check e2385065856246 [[],[.left,.left],[.left],[],[],[],[]] .smaller = true := by decide
def e2385065856622 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2385065856622 : Closed e2385065856622 ∧ code e2385065856622 = 11181158878830 := by decide
theorem cert_e2385065856622 : check e2385065856622 [[],[.left,.left],[.left],[],[],[]] .chain = true := by decide
def e2385065856634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2385065856634 : Closed e2385065856634 ∧ code e2385065856634 = 11181158878842 := by decide
theorem cert_e2385065856634 : check e2385065856634 [[],[.left,.left],[.left],[],[],[]] .chain = true := by decide
def e2385065856822 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2385065856822 : Closed e2385065856822 ∧ code e2385065856822 = 11181158879030 := by decide
theorem cert_e2385065856822 : check e2385065856822 [[],[.left,.left],[.left],[],[],[]] .chain = true := by decide
def e2385065856826 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2385065856826 : Closed e2385065856826 ∧ code e2385065856826 = 11181158879034 := by decide
theorem cert_e2385065856826 : check e2385065856826 [[],[.left,.left],[.left],[],[],[]] .chain = true := by decide
def e2385065862574 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2385065862574 : Closed e2385065862574 ∧ code e2385065862574 = 11181158884782 := by decide
theorem cert_e2385065862574 : check e2385065862574 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065862586 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2385065862586 : Closed e2385065862586 ∧ code e2385065862586 = 11181158884794 := by decide
theorem cert_e2385065862586 : check e2385065862586 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065862634 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2385065862634 : Closed e2385065862634 ∧ code e2385065862634 = 11181158884842 := by decide
theorem cert_e2385065862634 : check e2385065862634 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065862766 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2385065862766 : Closed e2385065862766 ∧ code e2385065862766 = 11181158884974 := by decide
theorem cert_e2385065862766 : check e2385065862766 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065862778 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2385065862778 : Closed e2385065862778 ∧ code e2385065862778 = 11181158884986 := by decide
theorem cert_e2385065862778 : check e2385065862778 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065863066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2385065863066 : Closed e2385065863066 ∧ code e2385065863066 = 11181158885274 := by decide
theorem cert_e2385065863066 : check e2385065863066 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065865942 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2385065865942 : Closed e2385065865942 ∧ code e2385065865942 = 11181158888150 := by decide
theorem cert_e2385065865942 : check e2385065865942 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065865946 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2385065865946 : Closed e2385065865946 ∧ code e2385065865946 = 11181158888154 := by decide
theorem cert_e2385065865946 : check e2385065865946 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065865962 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2385065865962 : Closed e2385065865962 ∧ code e2385065865962 = 11181158888170 := by decide
theorem cert_e2385065865962 : check e2385065865962 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065866038 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2385065866038 : Closed e2385065866038 ∧ code e2385065866038 = 11181158888246 := by decide
theorem cert_e2385065866038 : check e2385065866038 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065866042 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2385065866042 : Closed e2385065866042 ∧ code e2385065866042 = 11181158888250 := by decide
theorem cert_e2385065866042 : check e2385065866042 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385065866138 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2385065866138 : Closed e2385065866138 ∧ code e2385065866138 = 11181158888346 := by decide
theorem cert_e2385065866138 : check e2385065866138 [[],[.left,.left],[.left],[],[]] .chain = true := by decide
def e2385066003310 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2385066003310 : Closed e2385066003310 ∧ code e2385066003310 = 11181159025518 := by decide
theorem cert_e2385066003310 : check e2385066003310 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2385066003318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2385066003318 : Closed e2385066003318 ∧ code e2385066003318 = 11181159025526 := by decide
theorem cert_e2385066003318 : check e2385066003318 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2385066003374 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2385066003374 : Closed e2385066003374 ∧ code e2385066003374 = 11181159025582 := by decide
theorem cert_e2385066003374 : check e2385066003374 [[],[.left,.left],[.left],[.left],[],[],[.under,.left]] .sourceHead = true := by decide
def e2385066003386 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2385066003386 : Closed e2385066003386 ∧ code e2385066003386 = 11181159025594 := by decide
theorem cert_e2385066003386 : check e2385066003386 [[],[.left,.left],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2385066003414 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2385066003414 : Closed e2385066003414 ∧ code e2385066003414 = 11181159025622 := by decide
theorem cert_e2385066003414 : check e2385066003414 [[],[.left,.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e2385066003418 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2385066003418 : Closed e2385066003418 ∧ code e2385066003418 = 11181159025626 := by decide
theorem cert_e2385066003418 : check e2385066003418 [[],[.left,.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2385066003694 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2385066003694 : Closed e2385066003694 ∧ code e2385066003694 = 11181159025902 := by decide
theorem cert_e2385066003694 : check e2385066003694 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2385066003702 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2385066003702 : Closed e2385066003702 ∧ code e2385066003702 = 11181159025910 := by decide
theorem cert_e2385066003702 : check e2385066003702 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2385066004078 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2385066004078 : Closed e2385066004078 ∧ code e2385066004078 = 11181159026286 := by decide
theorem cert_e2385066004078 : check e2385066004078 [[],[.left,.left],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2385066004090 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2385066004090 : Closed e2385066004090 ∧ code e2385066004090 = 11181159026298 := by decide
theorem cert_e2385066004090 : check e2385066004090 [[],[.left,.left],[.left],[.left],[],[],[.under],[.under],[.under]] .chain = true := by decide
def e2385066004278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2385066004278 : Closed e2385066004278 ∧ code e2385066004278 = 11181159026486 := by decide
theorem cert_e2385066004278 : check e2385066004278 [[],[.left,.left],[.left],[.left],[],[],[.under],[.under]] .chain = true := by decide
def e2385066004282 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2385066004282 : Closed e2385066004282 ∧ code e2385066004282 = 11181159026490 := by decide
theorem cert_e2385066004282 : check e2385066004282 [[],[.left,.left],[.left],[.left],[],[],[.under],[.under]] .chain = true := by decide
def e2385066593134 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2385066593134 : Closed e2385066593134 ∧ code e2385066593134 = 11181159615342 := by decide
def e2385066593142 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2385066593142 : Closed e2385066593142 ∧ code e2385066593142 = 11181159615350 := by decide
def e2385066593198 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2385066593198 : Closed e2385066593198 ∧ code e2385066593198 = 11181159615406 := by decide
def e2385066593210 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2385066593210 : Closed e2385066593210 ∧ code e2385066593210 = 11181159615418 := by decide
private def t_e2385066593210 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2385066593210 : ¬ IsSelfInterpreter e2385066593210 :=
  wSource (t := t_e2385066593210) (replay_sound (ps := []) (t := e2385066593210) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2384865266618
#print axioms Blc.Floor43.cert_e2384865266650
#print axioms Blc.Floor43.cert_e2385049775642
#print axioms Blc.Floor43.cert_e2385049777690
#print axioms Blc.Floor43.cert_e2385049792026
#print axioms Blc.Floor43.cert_e2385049795098
#print axioms Blc.Floor43.cert_e2385049802266
#print axioms Blc.Floor43.cert_e2385049803290
#print axioms Blc.Floor43.cert_e2385049873946
#print axioms Blc.Floor43.cert_e2385049875994
#print axioms Blc.Floor43.cert_e2385049972250
#print axioms Blc.Floor43.cert_e2385049975322
#print axioms Blc.Floor43.cert_e2385050023450
#print axioms Blc.Floor43.cert_e2385050024474
#print axioms Blc.Floor43.cert_e2385066593210
