import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407061728874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2407061728874 : Closed e2407061728874 ∧ code e2407061728874 = 11203154751082 := by decide
theorem cert_e2407061728874 : check e2407061728874 [[],[]] .chain = true := by decide
def e2407061728910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2407061728910 : Closed e2407061728910 ∧ code e2407061728910 = 11203154751118 := by decide
theorem cert_e2407061728910 : check e2407061728910 [[],[]] .chain = true := by decide
def e2407061728922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061728922 : Closed e2407061728922 ∧ code e2407061728922 = 11203154751130 := by decide
theorem cert_e2407061728922 : check e2407061728922 [[],[]] .chain = true := by decide
def e2407061728966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2407061728966 : Closed e2407061728966 ∧ code e2407061728966 = 11203154751174 := by decide
theorem cert_e2407061728966 : check e2407061728966 [[],[]] .chain = true := by decide
def e2407061729518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2407061729518 : Closed e2407061729518 ∧ code e2407061729518 = 11203154751726 := by decide
theorem cert_e2407061729518 : check e2407061729518 [[],[]] .chain = true := by decide
def e2407061729526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2407061729526 : Closed e2407061729526 ∧ code e2407061729526 = 11203154751734 := by decide
theorem cert_e2407061729526 : check e2407061729526 [[],[]] .chain = true := by decide
def e2407061730006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2407061730006 : Closed e2407061730006 ∧ code e2407061730006 = 11203154752214 := by decide
theorem cert_e2407061730006 : check e2407061730006 [[],[]] .chain = true := by decide
def e2407061730010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2407061730010 : Closed e2407061730010 ∧ code e2407061730010 = 11203154752218 := by decide
theorem cert_e2407061730010 : check e2407061730010 [[],[]] .chain = true := by decide
def e2407061730026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2407061730026 : Closed e2407061730026 ∧ code e2407061730026 = 11203154752234 := by decide
theorem cert_e2407061730026 : check e2407061730026 [[],[]] .chain = true := by decide
def e2407061730102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407061730102 : Closed e2407061730102 ∧ code e2407061730102 = 11203154752310 := by decide
theorem cert_e2407061730102 : check e2407061730102 [[],[]] .chain = true := by decide
def e2407061730106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407061730106 : Closed e2407061730106 ∧ code e2407061730106 = 11203154752314 := by decide
theorem cert_e2407061730106 : check e2407061730106 [[],[]] .chain = true := by decide
def e2407061730190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2407061730190 : Closed e2407061730190 ∧ code e2407061730190 = 11203154752398 := by decide
theorem cert_e2407061730190 : check e2407061730190 [[],[]] .chain = true := by decide
def e2407061730202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061730202 : Closed e2407061730202 ∧ code e2407061730202 = 11203154752410 := by decide
theorem cert_e2407061730202 : check e2407061730202 [[],[]] .chain = true := by decide
def e2407061731446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2407061731446 : Closed e2407061731446 ∧ code e2407061731446 = 11203154753654 := by decide
theorem cert_e2407061731446 : check e2407061731446 [[],[]] .chain = true := by decide
def e2407061731690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2407061731690 : Closed e2407061731690 ∧ code e2407061731690 = 11203154753898 := by decide
theorem cert_e2407061731690 : check e2407061731690 [[],[]] .chain = true := by decide
def e2407061731726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2407061731726 : Closed e2407061731726 ∧ code e2407061731726 = 11203154753934 := by decide
theorem cert_e2407061731726 : check e2407061731726 [[],[]] .chain = true := by decide
def e2407061731738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061731738 : Closed e2407061731738 ∧ code e2407061731738 = 11203154753946 := by decide
theorem cert_e2407061731738 : check e2407061731738 [[],[]] .chain = true := by decide
def e2407061731782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2407061731782 : Closed e2407061731782 ∧ code e2407061731782 = 11203154753990 := by decide
theorem cert_e2407061731782 : check e2407061731782 [[],[]] .chain = true := by decide
def e2407063629242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e2407063629242 : Closed e2407063629242 ∧ code e2407063629242 = 11203156651450 := by decide
theorem cert_e2407063629242 : check e2407063629242 [[],[]] .chain = true := by decide
def e2407063629274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e2407063629274 : Closed e2407063629274 ∧ code e2407063629274 = 11203156651482 := by decide
theorem cert_e2407063629274 : check e2407063629274 [[],[]] .chain = true := by decide
def e2407063629498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e2407063629498 : Closed e2407063629498 ∧ code e2407063629498 = 11203156651706 := by decide
theorem cert_e2407063629498 : check e2407063629498 [[],[]] .chain = true := by decide
def e2407063629546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e2407063629546 : Closed e2407063629546 ∧ code e2407063629546 = 11203156651754 := by decide
theorem cert_e2407063629546 : check e2407063629546 [[],[]] .chain = true := by decide
def e2407063629658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e2407063629658 : Closed e2407063629658 ∧ code e2407063629658 = 11203156651866 := by decide
theorem cert_e2407063629658 : check e2407063629658 [[],[]] .chain = true := by decide
def e2407063629674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e2407063629674 : Closed e2407063629674 ∧ code e2407063629674 = 11203156651882 := by decide
theorem cert_e2407063629674 : check e2407063629674 [[],[]] .chain = true := by decide
def e2407063630778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e2407063630778 : Closed e2407063630778 ∧ code e2407063630778 = 11203156652986 := by decide
theorem cert_e2407063630778 : check e2407063630778 [[],[]] .chain = true := by decide
def e2407063630810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e2407063630810 : Closed e2407063630810 ∧ code e2407063630810 = 11203156653018 := by decide
theorem cert_e2407063630810 : check e2407063630810 [[],[]] .chain = true := by decide
def e2407063632314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e2407063632314 : Closed e2407063632314 ∧ code e2407063632314 = 11203156654522 := by decide
theorem cert_e2407063632314 : check e2407063632314 [[],[]] .chain = true := by decide
def e2407063632362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e2407063632362 : Closed e2407063632362 ∧ code e2407063632362 = 11203156654570 := by decide
theorem cert_e2407063632362 : check e2407063632362 [[],[]] .chain = true := by decide
def e2407063633114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e2407063633114 : Closed e2407063633114 ∧ code e2407063633114 = 11203156655322 := by decide
theorem cert_e2407063633114 : check e2407063633114 [[],[]] .chain = true := by decide
def e2407063633130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e2407063633130 : Closed e2407063633130 ∧ code e2407063633130 = 11203156655338 := by decide
theorem cert_e2407063633130 : check e2407063633130 [[],[]] .chain = true := by decide
def e2407063685998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2407063685998 : Closed e2407063685998 ∧ code e2407063685998 = 11203156708206 := by decide
theorem cert_e2407063685998 : check e2407063685998 [[],[]] .chain = true := by decide
def e2407063686006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2407063686006 : Closed e2407063686006 ∧ code e2407063686006 = 11203156708214 := by decide
theorem cert_e2407063686006 : check e2407063686006 [[],[]] .chain = true := by decide
def e2407063686062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2407063686062 : Closed e2407063686062 ∧ code e2407063686062 = 11203156708270 := by decide
theorem cert_e2407063686062 : check e2407063686062 [[],[]] .chain = true := by decide
def e2407063686074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2407063686074 : Closed e2407063686074 ∧ code e2407063686074 = 11203156708282 := by decide
theorem cert_e2407063686074 : check e2407063686074 [[],[]] .chain = true := by decide
def e2407063686102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2407063686102 : Closed e2407063686102 ∧ code e2407063686102 = 11203156708310 := by decide
theorem cert_e2407063686102 : check e2407063686102 [[],[]] .chain = true := by decide
def e2407063686106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2407063686106 : Closed e2407063686106 ∧ code e2407063686106 = 11203156708314 := by decide
theorem cert_e2407063686106 : check e2407063686106 [[],[]] .chain = true := by decide
def e2407063686382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2407063686382 : Closed e2407063686382 ∧ code e2407063686382 = 11203156708590 := by decide
theorem cert_e2407063686382 : check e2407063686382 [[],[]] .chain = true := by decide
def e2407063686390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2407063686390 : Closed e2407063686390 ∧ code e2407063686390 = 11203156708598 := by decide
theorem cert_e2407063686390 : check e2407063686390 [[],[]] .chain = true := by decide
def e2407063686766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2407063686766 : Closed e2407063686766 ∧ code e2407063686766 = 11203156708974 := by decide
theorem cert_e2407063686766 : check e2407063686766 [[],[]] .chain = true := by decide
def e2407063686778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2407063686778 : Closed e2407063686778 ∧ code e2407063686778 = 11203156708986 := by decide
theorem cert_e2407063686778 : check e2407063686778 [[],[]] .chain = true := by decide
def e2407063686966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2407063686966 : Closed e2407063686966 ∧ code e2407063686966 = 11203156709174 := by decide
theorem cert_e2407063686966 : check e2407063686966 [[],[]] .chain = true := by decide
def e2407063686970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2407063686970 : Closed e2407063686970 ∧ code e2407063686970 = 11203156709178 := by decide
theorem cert_e2407063686970 : check e2407063686970 [[],[]] .chain = true := by decide
def e2407063891422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2407063891422 : Closed e2407063891422 ∧ code e2407063891422 = 11203156913630 := by decide
theorem cert_e2407063891422 : check e2407063891422 [[],[]] .chain = true := by decide
def e2407063891438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2407063891438 : Closed e2407063891438 ∧ code e2407063891438 = 11203156913646 := by decide
theorem cert_e2407063891438 : check e2407063891438 [[],[]] .chain = true := by decide
def e2407063891806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2407063891806 : Closed e2407063891806 ∧ code e2407063891806 = 11203156914014 := by decide
theorem cert_e2407063891806 : check e2407063891806 [[],[]] .chain = true := by decide
def e2407063891834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2407063891834 : Closed e2407063891834 ∧ code e2407063891834 = 11203156914042 := by decide
theorem cert_e2407063891834 : check e2407063891834 [[],[]] .chain = true := by decide
def e2407063891886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2407063891886 : Closed e2407063891886 ∧ code e2407063891886 = 11203156914094 := by decide
theorem cert_e2407063891886 : check e2407063891886 [[],[]] .chain = true := by decide
def e2407063891898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2407063891898 : Closed e2407063891898 ∧ code e2407063891898 = 11203156914106 := by decide
theorem cert_e2407063891898 : check e2407063891898 [[],[]] .chain = true := by decide
def e2407063892958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2407063892958 : Closed e2407063892958 ∧ code e2407063892958 = 11203156915166 := by decide
theorem cert_e2407063892958 : check e2407063892958 [[],[]] .chain = true := by decide
def e2407063892974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2407063892974 : Closed e2407063892974 ∧ code e2407063892974 = 11203156915182 := by decide
theorem cert_e2407063892974 : check e2407063892974 [[],[]] .chain = true := by decide
def e2407063895262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407063895262 : Closed e2407063895262 ∧ code e2407063895262 = 11203156917470 := by decide
theorem cert_e2407063895262 : check e2407063895262 [[],[]] .chain = true := by decide
def e2407063895290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407063895290 : Closed e2407063895290 ∧ code e2407063895290 = 11203156917498 := by decide
theorem cert_e2407063895290 : check e2407063895290 [[],[]] .chain = true := by decide
def e2407063895662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407063895662 : Closed e2407063895662 ∧ code e2407063895662 = 11203156917870 := by decide
theorem cert_e2407063895662 : check e2407063895662 [[],[]] .chain = true := by decide
def e2407063895674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407063895674 : Closed e2407063895674 ∧ code e2407063895674 = 11203156917882 := by decide
theorem cert_e2407063895674 : check e2407063895674 [[],[]] .chain = true := by decide
def e2407063924078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2407063924078 : Closed e2407063924078 ∧ code e2407063924078 = 11203156946286 := by decide
theorem cert_e2407063924078 : check e2407063924078 [[],[]] .chain = true := by decide
def e2407063924086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2407063924086 : Closed e2407063924086 ∧ code e2407063924086 = 11203156946294 := by decide
theorem cert_e2407063924086 : check e2407063924086 [[],[]] .chain = true := by decide
def e2407063924142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2407063924142 : Closed e2407063924142 ∧ code e2407063924142 = 11203156946350 := by decide
theorem cert_e2407063924142 : check e2407063924142 [[],[]] .chain = true := by decide
def e2407063924154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2407063924154 : Closed e2407063924154 ∧ code e2407063924154 = 11203156946362 := by decide
theorem cert_e2407063924154 : check e2407063924154 [[],[]] .chain = true := by decide
def e2407063924182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2407063924182 : Closed e2407063924182 ∧ code e2407063924182 = 11203156946390 := by decide
theorem cert_e2407063924182 : check e2407063924182 [[],[]] .chain = true := by decide
def e2407063924186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2407063924186 : Closed e2407063924186 ∧ code e2407063924186 = 11203156946394 := by decide
theorem cert_e2407063924186 : check e2407063924186 [[],[]] .chain = true := by decide
def e2407063924398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2407063924398 : Closed e2407063924398 ∧ code e2407063924398 = 11203156946606 := by decide
theorem cert_e2407063924398 : check e2407063924398 [[],[]] .chain = true := by decide
def e2407063924410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2407063924410 : Closed e2407063924410 ∧ code e2407063924410 = 11203156946618 := by decide
theorem cert_e2407063924410 : check e2407063924410 [[],[]] .chain = true := by decide
def e2407063924458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2407063924458 : Closed e2407063924458 ∧ code e2407063924458 = 11203156946666 := by decide
theorem cert_e2407063924458 : check e2407063924458 [[],[]] .chain = true := by decide
def e2407063924566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2407063924566 : Closed e2407063924566 ∧ code e2407063924566 = 11203156946774 := by decide
theorem cert_e2407063924566 : check e2407063924566 [[],[]] .chain = true := by decide
def e2407063924570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2407063924570 : Closed e2407063924570 ∧ code e2407063924570 = 11203156946778 := by decide
theorem cert_e2407063924570 : check e2407063924570 [[],[]] .chain = true := by decide
def e2407063924586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2407063924586 : Closed e2407063924586 ∧ code e2407063924586 = 11203156946794 := by decide
theorem cert_e2407063924586 : check e2407063924586 [[],[]] .chain = true := by decide
def e2407063925614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2407063925614 : Closed e2407063925614 ∧ code e2407063925614 = 11203156947822 := by decide
theorem cert_e2407063925614 : check e2407063925614 [[],[]] .chain = true := by decide
def e2407063925622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2407063925622 : Closed e2407063925622 ∧ code e2407063925622 = 11203156947830 := by decide
theorem cert_e2407063925622 : check e2407063925622 [[],[]] .chain = true := by decide
def e2407063925678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2407063925678 : Closed e2407063925678 ∧ code e2407063925678 = 11203156947886 := by decide
theorem cert_e2407063925678 : check e2407063925678 [[],[]] .chain = true := by decide
def e2407063925690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2407063925690 : Closed e2407063925690 ∧ code e2407063925690 = 11203156947898 := by decide
theorem cert_e2407063925690 : check e2407063925690 [[],[]] .chain = true := by decide
def e2407063925718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2407063925718 : Closed e2407063925718 ∧ code e2407063925718 = 11203156947926 := by decide
theorem cert_e2407063925718 : check e2407063925718 [[],[]] .chain = true := by decide
def e2407063925722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2407063925722 : Closed e2407063925722 ∧ code e2407063925722 = 11203156947930 := by decide
theorem cert_e2407063925722 : check e2407063925722 [[],[]] .chain = true := by decide
def e2407063925998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2407063925998 : Closed e2407063925998 ∧ code e2407063925998 = 11203156948206 := by decide
theorem cert_e2407063925998 : check e2407063925998 [[],[]] .chain = true := by decide
def e2407063926006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2407063926006 : Closed e2407063926006 ∧ code e2407063926006 = 11203156948214 := by decide
theorem cert_e2407063926006 : check e2407063926006 [[],[]] .chain = true := by decide
def e2407063926382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407063926382 : Closed e2407063926382 ∧ code e2407063926382 = 11203156948590 := by decide
theorem cert_e2407063926382 : check e2407063926382 [[],[]] .chain = true := by decide
def e2407063926394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407063926394 : Closed e2407063926394 ∧ code e2407063926394 = 11203156948602 := by decide
theorem cert_e2407063926394 : check e2407063926394 [[],[]] .chain = true := by decide
def e2407063926582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407063926582 : Closed e2407063926582 ∧ code e2407063926582 = 11203156948790 := by decide
theorem cert_e2407063926582 : check e2407063926582 [[],[]] .chain = true := by decide
def e2407063926586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407063926586 : Closed e2407063926586 ∧ code e2407063926586 = 11203156948794 := by decide
theorem cert_e2407063926586 : check e2407063926586 [[],[]] .chain = true := by decide
def e2407063927214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2407063927214 : Closed e2407063927214 ∧ code e2407063927214 = 11203156949422 := by decide
theorem cert_e2407063927214 : check e2407063927214 [[],[]] .chain = true := by decide
def e2407063927226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2407063927226 : Closed e2407063927226 ∧ code e2407063927226 = 11203156949434 := by decide
theorem cert_e2407063927226 : check e2407063927226 [[],[]] .chain = true := by decide
def e2407063927274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2407063927274 : Closed e2407063927274 ∧ code e2407063927274 = 11203156949482 := by decide
theorem cert_e2407063927274 : check e2407063927274 [[],[]] .chain = true := by decide
def e2407063927406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407063927406 : Closed e2407063927406 ∧ code e2407063927406 = 11203156949614 := by decide
theorem cert_e2407063927406 : check e2407063927406 [[],[]] .chain = true := by decide
def e2407063927418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407063927418 : Closed e2407063927418 ∧ code e2407063927418 = 11203156949626 := by decide
theorem cert_e2407063927418 : check e2407063927418 [[],[]] .chain = true := by decide
def e2407063927706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407063927706 : Closed e2407063927706 ∧ code e2407063927706 = 11203156949914 := by decide
theorem cert_e2407063927706 : check e2407063927706 [[],[]] .chain = true := by decide
def e2407063928022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2407063928022 : Closed e2407063928022 ∧ code e2407063928022 = 11203156950230 := by decide
theorem cert_e2407063928022 : check e2407063928022 [[],[]] .chain = true := by decide
def e2407063928026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2407063928026 : Closed e2407063928026 ∧ code e2407063928026 = 11203156950234 := by decide
theorem cert_e2407063928026 : check e2407063928026 [[],[]] .chain = true := by decide
def e2407063928042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2407063928042 : Closed e2407063928042 ∧ code e2407063928042 = 11203156950250 := by decide
theorem cert_e2407063928042 : check e2407063928042 [[],[]] .chain = true := by decide
def e2407063928118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407063928118 : Closed e2407063928118 ∧ code e2407063928118 = 11203156950326 := by decide
theorem cert_e2407063928118 : check e2407063928118 [[],[]] .chain = true := by decide
def e2407063928122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407063928122 : Closed e2407063928122 ∧ code e2407063928122 = 11203156950330 := by decide
theorem cert_e2407063928122 : check e2407063928122 [[],[]] .chain = true := by decide
def e2407063928218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407063928218 : Closed e2407063928218 ∧ code e2407063928218 = 11203156950426 := by decide
theorem cert_e2407063928218 : check e2407063928218 [[],[]] .chain = true := by decide
def e2407063929822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2407063929822 : Closed e2407063929822 ∧ code e2407063929822 = 11203156952030 := by decide
theorem cert_e2407063929822 : check e2407063929822 [[],[]] .chain = true := by decide
def e2407063929838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2407063929838 : Closed e2407063929838 ∧ code e2407063929838 = 11203156952046 := by decide
theorem cert_e2407063929838 : check e2407063929838 [[],[]] .chain = true := by decide
def e2407063931758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407063931758 : Closed e2407063931758 ∧ code e2407063931758 = 11203156953966 := by decide
theorem cert_e2407063931758 : check e2407063931758 [[],[]] .chain = true := by decide
def e2407063931766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407063931766 : Closed e2407063931766 ∧ code e2407063931766 = 11203156953974 := by decide
theorem cert_e2407063931766 : check e2407063931766 [[],[]] .chain = true := by decide
def e2407063931822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407063931822 : Closed e2407063931822 ∧ code e2407063931822 = 11203156954030 := by decide
theorem cert_e2407063931822 : check e2407063931822 [[],[]] .chain = true := by decide
def e2407063931834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407063931834 : Closed e2407063931834 ∧ code e2407063931834 = 11203156954042 := by decide
theorem cert_e2407063931834 : check e2407063931834 [[],[]] .chain = true := by decide
def e2407063931862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407063931862 : Closed e2407063931862 ∧ code e2407063931862 = 11203156954070 := by decide
theorem cert_e2407063931862 : check e2407063931862 [[],[]] .chain = true := by decide
def e2407063931866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407063931866 : Closed e2407063931866 ∧ code e2407063931866 = 11203156954074 := by decide
theorem cert_e2407063931866 : check e2407063931866 [[],[]] .chain = true := by decide
def e2407063932142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407063932142 : Closed e2407063932142 ∧ code e2407063932142 = 11203156954350 := by decide
theorem cert_e2407063932142 : check e2407063932142 [[],[]] .chain = true := by decide
def e2407063932150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407063932150 : Closed e2407063932150 ∧ code e2407063932150 = 11203156954358 := by decide
theorem cert_e2407063932150 : check e2407063932150 [[],[]] .chain = true := by decide
def e2407063932526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407063932526 : Closed e2407063932526 ∧ code e2407063932526 = 11203156954734 := by decide
theorem cert_e2407063932526 : check e2407063932526 [[],[]] .chain = true := by decide
def e2407063932538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407063932538 : Closed e2407063932538 ∧ code e2407063932538 = 11203156954746 := by decide
theorem cert_e2407063932538 : check e2407063932538 [[],[]] .chain = true := by decide
def e2407063932726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407063932726 : Closed e2407063932726 ∧ code e2407063932726 = 11203156954934 := by decide
theorem cert_e2407063932726 : check e2407063932726 [[],[]] .chain = true := by decide
def e2407063932730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407063932730 : Closed e2407063932730 ∧ code e2407063932730 = 11203156954938 := by decide
theorem cert_e2407063932730 : check e2407063932730 [[],[]] .chain = true := by decide
def e2407063937502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2407063937502 : Closed e2407063937502 ∧ code e2407063937502 = 11203156959710 := by decide
theorem cert_e2407063937502 : check e2407063937502 [[],[]] .chain = true := by decide
def e2407063937526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2407063937526 : Closed e2407063937526 ∧ code e2407063937526 = 11203156959734 := by decide
theorem cert_e2407063937526 : check e2407063937526 [[],[]] .chain = true := by decide
def e2407063938478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2407063938478 : Closed e2407063938478 ∧ code e2407063938478 = 11203156960686 := by decide
theorem cert_e2407063938478 : check e2407063938478 [[],[]] .chain = true := by decide
def e2407063938490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2407063938490 : Closed e2407063938490 ∧ code e2407063938490 = 11203156960698 := by decide
theorem cert_e2407063938490 : check e2407063938490 [[],[]] .chain = true := by decide
def e2407063938538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2407063938538 : Closed e2407063938538 ∧ code e2407063938538 = 11203156960746 := by decide
theorem cert_e2407063938538 : check e2407063938538 [[],[]] .chain = true := by decide
def e2407063938670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407063938670 : Closed e2407063938670 ∧ code e2407063938670 = 11203156960878 := by decide
theorem cert_e2407063938670 : check e2407063938670 [[],[]] .chain = true := by decide
def e2407063938682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407063938682 : Closed e2407063938682 ∧ code e2407063938682 = 11203156960890 := by decide
theorem cert_e2407063938682 : check e2407063938682 [[],[]] .chain = true := by decide
def e2407063938970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407063938970 : Closed e2407063938970 ∧ code e2407063938970 = 11203156961178 := by decide
theorem cert_e2407063938970 : check e2407063938970 [[],[]] .chain = true := by decide
def e2407063941358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2407063941358 : Closed e2407063941358 ∧ code e2407063941358 = 11203156963566 := by decide
theorem cert_e2407063941358 : check e2407063941358 [[],[]] .chain = true := by decide
def e2407063941366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2407063941366 : Closed e2407063941366 ∧ code e2407063941366 = 11203156963574 := by decide
theorem cert_e2407063941366 : check e2407063941366 [[],[]] .chain = true := by decide
def e2407063941846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2407063941846 : Closed e2407063941846 ∧ code e2407063941846 = 11203156964054 := by decide
theorem cert_e2407063941846 : check e2407063941846 [[],[]] .chain = true := by decide
def e2407063941850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2407063941850 : Closed e2407063941850 ∧ code e2407063941850 = 11203156964058 := by decide
theorem cert_e2407063941850 : check e2407063941850 [[],[]] .chain = true := by decide
def e2407063941866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2407063941866 : Closed e2407063941866 ∧ code e2407063941866 = 11203156964074 := by decide
theorem cert_e2407063941866 : check e2407063941866 [[],[]] .chain = true := by decide
def e2407063941942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407063941942 : Closed e2407063941942 ∧ code e2407063941942 = 11203156964150 := by decide
theorem cert_e2407063941942 : check e2407063941942 [[],[]] .chain = true := by decide
def e2407063941946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407063941946 : Closed e2407063941946 ∧ code e2407063941946 = 11203156964154 := by decide
theorem cert_e2407063941946 : check e2407063941946 [[],[]] .chain = true := by decide
def e2407063942042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407063942042 : Closed e2407063942042 ∧ code e2407063942042 = 11203156964250 := by decide
theorem cert_e2407063942042 : check e2407063942042 [[],[]] .chain = true := by decide
def e2407064079214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407064079214 : Closed e2407064079214 ∧ code e2407064079214 = 11203157101422 := by decide
theorem cert_e2407064079214 : check e2407064079214 [[],[]] .chain = true := by decide
def e2407064079222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407064079222 : Closed e2407064079222 ∧ code e2407064079222 = 11203157101430 := by decide
theorem cert_e2407064079222 : check e2407064079222 [[],[]] .chain = true := by decide
def e2407064079278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407064079278 : Closed e2407064079278 ∧ code e2407064079278 = 11203157101486 := by decide
theorem cert_e2407064079278 : check e2407064079278 [[],[]] .chain = true := by decide
def e2407064079290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407064079290 : Closed e2407064079290 ∧ code e2407064079290 = 11203157101498 := by decide
theorem cert_e2407064079290 : check e2407064079290 [[],[]] .chain = true := by decide
def e2407064079318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407064079318 : Closed e2407064079318 ∧ code e2407064079318 = 11203157101526 := by decide
theorem cert_e2407064079318 : check e2407064079318 [[],[]] .chain = true := by decide
def e2407064079322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407064079322 : Closed e2407064079322 ∧ code e2407064079322 = 11203157101530 := by decide
theorem cert_e2407064079322 : check e2407064079322 [[],[]] .chain = true := by decide
def e2407064079598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407064079598 : Closed e2407064079598 ∧ code e2407064079598 = 11203157101806 := by decide
theorem cert_e2407064079598 : check e2407064079598 [[],[]] .chain = true := by decide
def e2407064079606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407064079606 : Closed e2407064079606 ∧ code e2407064079606 = 11203157101814 := by decide
theorem cert_e2407064079606 : check e2407064079606 [[],[]] .chain = true := by decide
def e2407064079982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407064079982 : Closed e2407064079982 ∧ code e2407064079982 = 11203157102190 := by decide
theorem cert_e2407064079982 : check e2407064079982 [[],[]] .chain = true := by decide
def e2407064079994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407064079994 : Closed e2407064079994 ∧ code e2407064079994 = 11203157102202 := by decide
theorem cert_e2407064079994 : check e2407064079994 [[],[]] .chain = true := by decide
def e2407064080182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407064080182 : Closed e2407064080182 ∧ code e2407064080182 = 11203157102390 := by decide
theorem cert_e2407064080182 : check e2407064080182 [[],[]] .chain = true := by decide
def e2407064080186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407064080186 : Closed e2407064080186 ∧ code e2407064080186 = 11203157102394 := by decide
theorem cert_e2407064080186 : check e2407064080186 [[],[]] .chain = true := by decide
def e2407064409822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2407064409822 : Closed e2407064409822 ∧ code e2407064409822 = 11203157432030 := by decide
theorem cert_e2407064409822 : check e2407064409822 [[],[],[.under]] .smaller = true := by decide
def e2407064409846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2407064409846 : Closed e2407064409846 ∧ code e2407064409846 = 11203157432054 := by decide
theorem cert_e2407064409846 : check e2407064409846 [[],[],[.under]] .smaller = true := by decide
def e2407064409950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2407064409950 : Closed e2407064409950 ∧ code e2407064409950 = 11203157432158 := by decide
theorem cert_e2407064409950 : check e2407064409950 [[],[],[.under]] .smaller = true := by decide
def e2407064409978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2407064409978 : Closed e2407064409978 ∧ code e2407064409978 = 11203157432186 := by decide
theorem cert_e2407064409978 : check e2407064409978 [[],[],[.under]] .smaller = true := by decide
def e2407064410070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2407064410070 : Closed e2407064410070 ∧ code e2407064410070 = 11203157432278 := by decide
theorem cert_e2407064410070 : check e2407064410070 [[],[],[.under]] .smaller = true := by decide
def e2407064410074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2407064410074 : Closed e2407064410074 ∧ code e2407064410074 = 11203157432282 := by decide
theorem cert_e2407064410074 : check e2407064410074 [[],[],[.under]] .smaller = true := by decide
def e2407064410590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2407064410590 : Closed e2407064410590 ∧ code e2407064410590 = 11203157432798 := by decide
theorem cert_e2407064410590 : check e2407064410590 [[],[],[.under]] .smaller = true := by decide
def e2407064410614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2407064410614 : Closed e2407064410614 ∧ code e2407064410614 = 11203157432822 := by decide
theorem cert_e2407064410614 : check e2407064410614 [[],[],[.under]] .smaller = true := by decide
def e2407064411358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407064411358 : Closed e2407064411358 ∧ code e2407064411358 = 11203157433566 := by decide
theorem cert_e2407064411358 : check e2407064411358 [[],[],[.under]] .smaller = true := by decide
def e2407064411386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407064411386 : Closed e2407064411386 ∧ code e2407064411386 = 11203157433594 := by decide
theorem cert_e2407064411386 : check e2407064411386 [[],[],[.under]] .smaller = true := by decide
def e2407064411958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407064411958 : Closed e2407064411958 ∧ code e2407064411958 = 11203157434166 := by decide
theorem cert_e2407064411958 : check e2407064411958 [[],[],[.under]] .smaller = true := by decide
def e2407064411962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407064411962 : Closed e2407064411962 ∧ code e2407064411962 = 11203157434170 := by decide
theorem cert_e2407064411962 : check e2407064411962 [[],[],[.under]] .smaller = true := by decide
def e2407064426734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2407064426734 : Closed e2407064426734 ∧ code e2407064426734 = 11203157448942 := by decide
theorem cert_e2407064426734 : check e2407064426734 [[],[],[.under]] .smaller = true := by decide
def e2407064426742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2407064426742 : Closed e2407064426742 ∧ code e2407064426742 = 11203157448950 := by decide
theorem cert_e2407064426742 : check e2407064426742 [[],[],[.under]] .smaller = true := by decide
def e2407064427294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2407064427294 : Closed e2407064427294 ∧ code e2407064427294 = 11203157449502 := by decide
theorem cert_e2407064427294 : check e2407064427294 [[],[],[.under]] .smaller = true := by decide
def e2407064427406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2407064427406 : Closed e2407064427406 ∧ code e2407064427406 = 11203157449614 := by decide
theorem cert_e2407064427406 : check e2407064427406 [[],[],[.under]] .smaller = true := by decide
def e2407064427630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2407064427630 : Closed e2407064427630 ∧ code e2407064427630 = 11203157449838 := by decide
theorem cert_e2407064427630 : check e2407064427630 [[],[],[.under]] .smaller = true := by decide
def e2407064427642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2407064427642 : Closed e2407064427642 ∧ code e2407064427642 = 11203157449850 := by decide
theorem cert_e2407064427642 : check e2407064427642 [[],[],[.under]] .smaller = true := by decide
def e2407064427806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2407064427806 : Closed e2407064427806 ∧ code e2407064427806 = 11203157450014 := by decide
theorem cert_e2407064427806 : check e2407064427806 [[],[],[.under]] .smaller = true := by decide
def e2407064427974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2407064427974 : Closed e2407064427974 ∧ code e2407064427974 = 11203157450182 := by decide
theorem cert_e2407064427974 : check e2407064427974 [[],[],[.under]] .smaller = true := by decide
def e2407064428086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2407064428086 : Closed e2407064428086 ∧ code e2407064428086 = 11203157450294 := by decide
theorem cert_e2407064428086 : check e2407064428086 [[],[],[.under]] .smaller = true := by decide
def e2407064428090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2407064428090 : Closed e2407064428090 ∧ code e2407064428090 = 11203157450298 := by decide
theorem cert_e2407064428090 : check e2407064428090 [[],[],[.under]] .smaller = true := by decide
def e2407064428174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2407064428174 : Closed e2407064428174 ∧ code e2407064428174 = 11203157450382 := by decide
theorem cert_e2407064428174 : check e2407064428174 [[],[],[.under]] .smaller = true := by decide
def e2407064428230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2407064428230 : Closed e2407064428230 ∧ code e2407064428230 = 11203157450438 := by decide
theorem cert_e2407064428230 : check e2407064428230 [[],[],[.under]] .smaller = true := by decide
def e2407064430366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2407064430366 : Closed e2407064430366 ∧ code e2407064430366 = 11203157452574 := by decide
theorem cert_e2407064430366 : check e2407064430366 [[],[],[.under]] .smaller = true := by decide
def e2407064430478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2407064430478 : Closed e2407064430478 ∧ code e2407064430478 = 11203157452686 := by decide
theorem cert_e2407064430478 : check e2407064430478 [[],[],[.under]] .smaller = true := by decide
def e2407064433438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2407064433438 : Closed e2407064433438 ∧ code e2407064433438 = 11203157455646 := by decide
theorem cert_e2407064433438 : check e2407064433438 [[],[],[.under]] .smaller = true := by decide
def e2407064433606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2407064433606 : Closed e2407064433606 ∧ code e2407064433606 = 11203157455814 := by decide
theorem cert_e2407064433606 : check e2407064433606 [[],[],[.under]] .smaller = true := by decide
end Blc.Floor43
