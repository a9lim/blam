import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422362312506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362312506 : Closed e2422362312506 ∧ code e2422362312506 = 11218455334714 := by decide
theorem cert_e2422362312506 : check e2422362312506 [[],[]] .smaller = true := by decide
def e2422362312602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362312602 : Closed e2422362312602 ∧ code e2422362312602 = 11218455334810 := by decide
theorem cert_e2422362312602 : check e2422362312602 [[],[]] .smaller = true := by decide
def e2422362314414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))))
theorem wire_e2422362314414 : Closed e2422362314414 ∧ code e2422362314414 = 11218455336622 := by decide
theorem cert_e2422362314414 : check e2422362314414 [[],[]] .smaller = true := by decide
def e2422362314426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))))
theorem wire_e2422362314426 : Closed e2422362314426 ∧ code e2422362314426 = 11218455336634 := by decide
theorem cert_e2422362314426 : check e2422362314426 [[],[]] .smaller = true := by decide
def e2422362314474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362314474 : Closed e2422362314474 ∧ code e2422362314474 = 11218455336682 := by decide
theorem cert_e2422362314474 : check e2422362314474 [[],[]] .smaller = true := by decide
def e2422362314666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362314666 : Closed e2422362314666 ∧ code e2422362314666 = 11218455336874 := by decide
theorem cert_e2422362314666 : check e2422362314666 [[],[]] .smaller = true := by decide
def e2422362314974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))))
theorem wire_e2422362314974 : Closed e2422362314974 ∧ code e2422362314974 = 11218455337182 := by decide
theorem cert_e2422362314974 : check e2422362314974 [[],[]] .smaller = true := by decide
def e2422362314990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))))
theorem wire_e2422362314990 : Closed e2422362314990 ∧ code e2422362314990 = 11218455337198 := by decide
theorem cert_e2422362314990 : check e2422362314990 [[],[]] .smaller = true := by decide
def e2422362314998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))))
theorem wire_e2422362314998 : Closed e2422362314998 ∧ code e2422362314998 = 11218455337206 := by decide
theorem cert_e2422362314998 : check e2422362314998 [[],[]] .smaller = true := by decide
def e2422362315002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))))
theorem wire_e2422362315002 : Closed e2422362315002 ∧ code e2422362315002 = 11218455337210 := by decide
theorem cert_e2422362315002 : check e2422362315002 [[],[]] .smaller = true := by decide
def e2422362315182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))))
theorem wire_e2422362315182 : Closed e2422362315182 ∧ code e2422362315182 = 11218455337390 := by decide
theorem cert_e2422362315182 : check e2422362315182 [[],[]] .smaller = true := by decide
def e2422362315194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))))
theorem wire_e2422362315194 : Closed e2422362315194 ∧ code e2422362315194 = 11218455337402 := by decide
theorem cert_e2422362315194 : check e2422362315194 [[],[]] .smaller = true := by decide
def e2422362315242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362315242 : Closed e2422362315242 ∧ code e2422362315242 = 11218455337450 := by decide
theorem cert_e2422362315242 : check e2422362315242 [[],[]] .smaller = true := by decide
def e2422362315326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))))
theorem wire_e2422362315326 : Closed e2422362315326 ∧ code e2422362315326 = 11218455337534 := by decide
theorem cert_e2422362315326 : check e2422362315326 [[],[]] .smaller = true := by decide
def e2422362315374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362315374 : Closed e2422362315374 ∧ code e2422362315374 = 11218455337582 := by decide
theorem cert_e2422362315374 : check e2422362315374 [[],[]] .smaller = true := by decide
def e2422362315386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362315386 : Closed e2422362315386 ∧ code e2422362315386 = 11218455337594 := by decide
theorem cert_e2422362315386 : check e2422362315386 [[],[]] .smaller = true := by decide
def e2422362315550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))))
theorem wire_e2422362315550 : Closed e2422362315550 ∧ code e2422362315550 = 11218455337758 := by decide
theorem cert_e2422362315550 : check e2422362315550 [[],[]] .smaller = true := by decide
def e2422362315646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 5)))))))))
theorem wire_e2422362315646 : Closed e2422362315646 ∧ code e2422362315646 = 11218455337854 := by decide
theorem cert_e2422362315646 : check e2422362315646 [[],[]] .three = true := by decide
def e2422362315662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))))
theorem wire_e2422362315662 : Closed e2422362315662 ∧ code e2422362315662 = 11218455337870 := by decide
theorem cert_e2422362315662 : check e2422362315662 [[],[]] .smaller = true := by decide
def e2422362315674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362315674 : Closed e2422362315674 ∧ code e2422362315674 = 11218455337882 := by decide
theorem cert_e2422362315674 : check e2422362315674 [[],[]] .smaller = true := by decide
def e2422362315718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))))
theorem wire_e2422362315718 : Closed e2422362315718 ∧ code e2422362315718 = 11218455337926 := by decide
theorem cert_e2422362315718 : check e2422362315718 [[],[]] .smaller = true := by decide
def e2422362315742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)))))))))
theorem wire_e2422362315742 : Closed e2422362315742 ∧ code e2422362315742 = 11218455337950 := by decide
theorem cert_e2422362315742 : check e2422362315742 [[],[]] .smaller = true := by decide
def e2422362315766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 5))) (.var 1)))))))))
theorem wire_e2422362315766 : Closed e2422362315766 ∧ code e2422362315766 = 11218455337974 := by decide
theorem cert_e2422362315766 : check e2422362315766 [[],[]] .three = true := by decide
def e2422362315886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))))
theorem wire_e2422362315886 : Closed e2422362315886 ∧ code e2422362315886 = 11218455338094 := by decide
theorem cert_e2422362315886 : check e2422362315886 [[],[]] .smaller = true := by decide
def e2422362315898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))))
theorem wire_e2422362315898 : Closed e2422362315898 ∧ code e2422362315898 = 11218455338106 := by decide
theorem cert_e2422362315898 : check e2422362315898 [[],[]] .smaller = true := by decide
def e2422362316062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))))
theorem wire_e2422362316062 : Closed e2422362316062 ∧ code e2422362316062 = 11218455338270 := by decide
theorem cert_e2422362316062 : check e2422362316062 [[],[]] .smaller = true := by decide
def e2422362316158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 5)))))))))
theorem wire_e2422362316158 : Closed e2422362316158 ∧ code e2422362316158 = 11218455338366 := by decide
theorem cert_e2422362316158 : check e2422362316158 [[],[]] .three = true := by decide
def e2422362316230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))))
theorem wire_e2422362316230 : Closed e2422362316230 ∧ code e2422362316230 = 11218455338438 := by decide
theorem cert_e2422362316230 : check e2422362316230 [[],[]] .smaller = true := by decide
def e2422362316254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)))))))))
theorem wire_e2422362316254 : Closed e2422362316254 ∧ code e2422362316254 = 11218455338462 := by decide
theorem cert_e2422362316254 : check e2422362316254 [[],[]] .smaller = true := by decide
def e2422362316270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)))))))))
theorem wire_e2422362316270 : Closed e2422362316270 ∧ code e2422362316270 = 11218455338478 := by decide
theorem cert_e2422362316270 : check e2422362316270 [[],[]] .smaller = true := by decide
def e2422362316282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 5))) (.var 0)))))))))
theorem wire_e2422362316282 : Closed e2422362316282 ∧ code e2422362316282 = 11218455338490 := by decide
theorem cert_e2422362316282 : check e2422362316282 [[],[]] .three = true := by decide
def e2422362316342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e2422362316342 : Closed e2422362316342 ∧ code e2422362316342 = 11218455338550 := by decide
theorem cert_e2422362316342 : check e2422362316342 [[],[]] .smaller = true := by decide
def e2422362316346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422362316346 : Closed e2422362316346 ∧ code e2422362316346 = 11218455338554 := by decide
theorem cert_e2422362316346 : check e2422362316346 [[],[]] .smaller = true := by decide
def e2422362316394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362316394 : Closed e2422362316394 ∧ code e2422362316394 = 11218455338602 := by decide
theorem cert_e2422362316394 : check e2422362316394 [[],[]] .smaller = true := by decide
def e2422362316430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e2422362316430 : Closed e2422362316430 ∧ code e2422362316430 = 11218455338638 := by decide
theorem cert_e2422362316430 : check e2422362316430 [[],[]] .smaller = true := by decide
def e2422362316442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362316442 : Closed e2422362316442 ∧ code e2422362316442 = 11218455338650 := by decide
theorem cert_e2422362316442 : check e2422362316442 [[],[]] .smaller = true := by decide
def e2422362316486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422362316486 : Closed e2422362316486 ∧ code e2422362316486 = 11218455338694 := by decide
theorem cert_e2422362316486 : check e2422362316486 [[],[]] .smaller = true := by decide
def e2422362316510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)))))))))
theorem wire_e2422362316510 : Closed e2422362316510 ∧ code e2422362316510 = 11218455338718 := by decide
theorem cert_e2422362316510 : check e2422362316510 [[],[]] .smaller = true := by decide
def e2422362316534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)))))))))
theorem wire_e2422362316534 : Closed e2422362316534 ∧ code e2422362316534 = 11218455338742 := by decide
theorem cert_e2422362316534 : check e2422362316534 [[],[]] .smaller = true := by decide
def e2422362316570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))))
theorem wire_e2422362316570 : Closed e2422362316570 ∧ code e2422362316570 = 11218455338778 := by decide
theorem cert_e2422362316570 : check e2422362316570 [[],[]] .smaller = true := by decide
def e2422362316614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))))
theorem wire_e2422362316614 : Closed e2422362316614 ∧ code e2422362316614 = 11218455338822 := by decide
theorem cert_e2422362316614 : check e2422362316614 [[],[]] .smaller = true := by decide
def e2422362316638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)))))))))
theorem wire_e2422362316638 : Closed e2422362316638 ∧ code e2422362316638 = 11218455338846 := by decide
theorem cert_e2422362316638 : check e2422362316638 [[],[]] .smaller = true := by decide
def e2422362316654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)))))))))
theorem wire_e2422362316654 : Closed e2422362316654 ∧ code e2422362316654 = 11218455338862 := by decide
theorem cert_e2422362316654 : check e2422362316654 [[],[]] .smaller = true := by decide
def e2422362316662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)))))))))
theorem wire_e2422362316662 : Closed e2422362316662 ∧ code e2422362316662 = 11218455338870 := by decide
theorem cert_e2422362316662 : check e2422362316662 [[],[]] .smaller = true := by decide
def e2422362316666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)))))))))
theorem wire_e2422362316666 : Closed e2422362316666 ∧ code e2422362316666 = 11218455338874 := by decide
theorem cert_e2422362316666 : check e2422362316666 [[],[]] .smaller = true := by decide
def e2422362316758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 5) (.var 0))) (.var 1)))))))))
theorem wire_e2422362316758 : Closed e2422362316758 ∧ code e2422362316758 = 11218455338966 := by decide
theorem cert_e2422362316758 : check e2422362316758 [[],[]] .three = true := by decide
def e2422362316762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 5) (.var 1))) (.var 0)))))))))
theorem wire_e2422362316762 : Closed e2422362316762 ∧ code e2422362316762 = 11218455338970 := by decide
theorem cert_e2422362316762 : check e2422362316762 [[],[]] .three = true := by decide
def e2422362317278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422362317278 : Closed e2422362317278 ∧ code e2422362317278 = 11218455339486 := by decide
theorem cert_e2422362317278 : check e2422362317278 [[],[]] .smaller = true := by decide
def e2422362317302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422362317302 : Closed e2422362317302 ∧ code e2422362317302 = 11218455339510 := by decide
theorem cert_e2422362317302 : check e2422362317302 [[],[]] .smaller = true := by decide
def e2422362318254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422362318254 : Closed e2422362318254 ∧ code e2422362318254 = 11218455340462 := by decide
theorem cert_e2422362318254 : check e2422362318254 [[],[]] .smaller = true := by decide
def e2422362318266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422362318266 : Closed e2422362318266 ∧ code e2422362318266 = 11218455340474 := by decide
theorem cert_e2422362318266 : check e2422362318266 [[],[]] .smaller = true := by decide
def e2422362318314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422362318314 : Closed e2422362318314 ∧ code e2422362318314 = 11218455340522 := by decide
theorem cert_e2422362318314 : check e2422362318314 [[],[]] .smaller = true := by decide
def e2422362318398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422362318398 : Closed e2422362318398 ∧ code e2422362318398 = 11218455340606 := by decide
theorem cert_e2422362318398 : check e2422362318398 [[],[]] .smaller = true := by decide
def e2422362318446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422362318446 : Closed e2422362318446 ∧ code e2422362318446 = 11218455340654 := by decide
theorem cert_e2422362318446 : check e2422362318446 [[],[]] .smaller = true := by decide
def e2422362318458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422362318458 : Closed e2422362318458 ∧ code e2422362318458 = 11218455340666 := by decide
theorem cert_e2422362318458 : check e2422362318458 [[],[]] .smaller = true := by decide
def e2422362318622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422362318622 : Closed e2422362318622 ∧ code e2422362318622 = 11218455340830 := by decide
theorem cert_e2422362318622 : check e2422362318622 [[],[]] .smaller = true := by decide
def e2422362318718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 5))))))))))
theorem wire_e2422362318718 : Closed e2422362318718 ∧ code e2422362318718 = 11218455340926 := by decide
theorem cert_e2422362318718 : check e2422362318718 [[],[]] .three = true := by decide
def e2422362318734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422362318734 : Closed e2422362318734 ∧ code e2422362318734 = 11218455340942 := by decide
theorem cert_e2422362318734 : check e2422362318734 [[],[]] .smaller = true := by decide
def e2422362318746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362318746 : Closed e2422362318746 ∧ code e2422362318746 = 11218455340954 := by decide
theorem cert_e2422362318746 : check e2422362318746 [[],[]] .smaller = true := by decide
def e2422362318790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422362318790 : Closed e2422362318790 ∧ code e2422362318790 = 11218455340998 := by decide
theorem cert_e2422362318790 : check e2422362318790 [[],[]] .smaller = true := by decide
def e2422362318814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422362318814 : Closed e2422362318814 ∧ code e2422362318814 = 11218455341022 := by decide
theorem cert_e2422362318814 : check e2422362318814 [[],[]] .smaller = true := by decide
def e2422362318838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 5) (.var 1))))))))))
theorem wire_e2422362318838 : Closed e2422362318838 ∧ code e2422362318838 = 11218455341046 := by decide
theorem cert_e2422362318838 : check e2422362318838 [[],[]] .three = true := by decide
def e2422362321694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422362321694 : Closed e2422362321694 ∧ code e2422362321694 = 11218455343902 := by decide
theorem cert_e2422362321694 : check e2422362321694 [[],[]] .smaller = true := by decide
def e2422362321790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 5))))))))))
theorem wire_e2422362321790 : Closed e2422362321790 ∧ code e2422362321790 = 11218455343998 := by decide
theorem cert_e2422362321790 : check e2422362321790 [[],[]] .three = true := by decide
def e2422362321862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422362321862 : Closed e2422362321862 ∧ code e2422362321862 = 11218455344070 := by decide
theorem cert_e2422362321862 : check e2422362321862 [[],[]] .smaller = true := by decide
def e2422362321886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422362321886 : Closed e2422362321886 ∧ code e2422362321886 = 11218455344094 := by decide
theorem cert_e2422362321886 : check e2422362321886 [[],[]] .smaller = true := by decide
def e2422362321902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422362321902 : Closed e2422362321902 ∧ code e2422362321902 = 11218455344110 := by decide
theorem cert_e2422362321902 : check e2422362321902 [[],[]] .smaller = true := by decide
def e2422362321914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 5) (.var 0))))))))))
theorem wire_e2422362321914 : Closed e2422362321914 ∧ code e2422362321914 = 11218455344122 := by decide
theorem cert_e2422362321914 : check e2422362321914 [[],[]] .three = true := by decide
def e2422362323062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362323062 : Closed e2422362323062 ∧ code e2422362323062 = 11218455345270 := by decide
theorem cert_e2422362323062 : check e2422362323062 [[],[]] .smaller = true := by decide
def e2422362323306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422362323306 : Closed e2422362323306 ∧ code e2422362323306 = 11218455345514 := by decide
theorem cert_e2422362323306 : check e2422362323306 [[],[]] .smaller = true := by decide
def e2422362323342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422362323342 : Closed e2422362323342 ∧ code e2422362323342 = 11218455345550 := by decide
theorem cert_e2422362323342 : check e2422362323342 [[],[]] .smaller = true := by decide
def e2422362323354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362323354 : Closed e2422362323354 ∧ code e2422362323354 = 11218455345562 := by decide
theorem cert_e2422362323354 : check e2422362323354 [[],[]] .smaller = true := by decide
def e2422362323398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422362323398 : Closed e2422362323398 ∧ code e2422362323398 = 11218455345606 := by decide
theorem cert_e2422362323398 : check e2422362323398 [[],[]] .smaller = true := by decide
def e2422362323422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422362323422 : Closed e2422362323422 ∧ code e2422362323422 = 11218455345630 := by decide
theorem cert_e2422362323422 : check e2422362323422 [[],[]] .smaller = true := by decide
def e2422362323446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422362323446 : Closed e2422362323446 ∧ code e2422362323446 = 11218455345654 := by decide
theorem cert_e2422362323446 : check e2422362323446 [[],[]] .smaller = true := by decide
def e2422362324166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422362324166 : Closed e2422362324166 ∧ code e2422362324166 = 11218455346374 := by decide
theorem cert_e2422362324166 : check e2422362324166 [[],[]] .smaller = true := by decide
def e2422362324190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362324190 : Closed e2422362324190 ∧ code e2422362324190 = 11218455346398 := by decide
theorem cert_e2422362324190 : check e2422362324190 [[],[]] .smaller = true := by decide
def e2422362324206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362324206 : Closed e2422362324206 ∧ code e2422362324206 = 11218455346414 := by decide
theorem cert_e2422362324206 : check e2422362324206 [[],[]] .smaller = true := by decide
def e2422362324214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362324214 : Closed e2422362324214 ∧ code e2422362324214 = 11218455346422 := by decide
theorem cert_e2422362324214 : check e2422362324214 [[],[]] .smaller = true := by decide
def e2422362324218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362324218 : Closed e2422362324218 ∧ code e2422362324218 = 11218455346426 := by decide
theorem cert_e2422362324218 : check e2422362324218 [[],[]] .smaller = true := by decide
def e2422362324790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 5)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362324790 : Closed e2422362324790 ∧ code e2422362324790 = 11218455346998 := by decide
theorem cert_e2422362324790 : check e2422362324790 [[],[]] .three = true := by decide
def e2422362324794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 5)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362324794 : Closed e2422362324794 ∧ code e2422362324794 = 11218455347002 := by decide
theorem cert_e2422362324794 : check e2422362324794 [[],[]] .three = true := by decide
def e2422362325942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))))
theorem wire_e2422362325942 : Closed e2422362325942 ∧ code e2422362325942 = 11218455348150 := by decide
theorem cert_e2422362325942 : check e2422362325942 [[],[]] .smaller = true := by decide
def e2422362325946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))))
theorem wire_e2422362325946 : Closed e2422362325946 ∧ code e2422362325946 = 11218455348154 := by decide
theorem cert_e2422362325946 : check e2422362325946 [[],[]] .smaller = true := by decide
def e2422362325978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))))
theorem wire_e2422362325978 : Closed e2422362325978 ∧ code e2422362325978 = 11218455348186 := by decide
theorem cert_e2422362325978 : check e2422362325978 [[],[]] .smaller = true := by decide
def e2422362326646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362326646 : Closed e2422362326646 ∧ code e2422362326646 = 11218455348854 := by decide
theorem cert_e2422362326646 : check e2422362326646 [[],[]] .smaller = true := by decide
def e2422362326838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362326838 : Closed e2422362326838 ∧ code e2422362326838 = 11218455349046 := by decide
theorem cert_e2422362326838 : check e2422362326838 [[],[]] .smaller = true := by decide
def e2422362326842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362326842 : Closed e2422362326842 ∧ code e2422362326842 = 11218455349050 := by decide
theorem cert_e2422362326842 : check e2422362326842 [[],[]] .smaller = true := by decide
def e2422362327894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))))
theorem wire_e2422362327894 : Closed e2422362327894 ∧ code e2422362327894 = 11218455350102 := by decide
theorem cert_e2422362327894 : check e2422362327894 [[],[]] .smaller = true := by decide
def e2422362327898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))))
theorem wire_e2422362327898 : Closed e2422362327898 ∧ code e2422362327898 = 11218455350106 := by decide
theorem cert_e2422362327898 : check e2422362327898 [[],[]] .smaller = true := by decide
def e2422362327914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362327914 : Closed e2422362327914 ∧ code e2422362327914 = 11218455350122 := by decide
theorem cert_e2422362327914 : check e2422362327914 [[],[]] .smaller = true := by decide
def e2422362327978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))))
theorem wire_e2422362327978 : Closed e2422362327978 ∧ code e2422362327978 = 11218455350186 := by decide
theorem cert_e2422362327978 : check e2422362327978 [[],[]] .smaller = true := by decide
def e2422362328182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))))
theorem wire_e2422362328182 : Closed e2422362328182 ∧ code e2422362328182 = 11218455350390 := by decide
theorem cert_e2422362328182 : check e2422362328182 [[],[]] .smaller = true := by decide
def e2422362328278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))))
theorem wire_e2422362328278 : Closed e2422362328278 ∧ code e2422362328278 = 11218455350486 := by decide
theorem cert_e2422362328278 : check e2422362328278 [[],[]] .smaller = true := by decide
def e2422362328282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))))
theorem wire_e2422362328282 : Closed e2422362328282 ∧ code e2422362328282 = 11218455350490 := by decide
theorem cert_e2422362328282 : check e2422362328282 [[],[]] .smaller = true := by decide
def e2422362328298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362328298 : Closed e2422362328298 ∧ code e2422362328298 = 11218455350506 := by decide
theorem cert_e2422362328298 : check e2422362328298 [[],[]] .smaller = true := by decide
def e2422362328374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362328374 : Closed e2422362328374 ∧ code e2422362328374 = 11218455350582 := by decide
theorem cert_e2422362328374 : check e2422362328374 [[],[]] .smaller = true := by decide
def e2422362328378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362328378 : Closed e2422362328378 ∧ code e2422362328378 = 11218455350586 := by decide
theorem cert_e2422362328378 : check e2422362328378 [[],[]] .smaller = true := by decide
def e2422362328446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 5)))))))))
theorem wire_e2422362328446 : Closed e2422362328446 ∧ code e2422362328446 = 11218455350654 := by decide
theorem cert_e2422362328446 : check e2422362328446 [[],[]] .three = true := by decide
def e2422362328462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))))
theorem wire_e2422362328462 : Closed e2422362328462 ∧ code e2422362328462 = 11218455350670 := by decide
theorem cert_e2422362328462 : check e2422362328462 [[],[]] .smaller = true := by decide
def e2422362328474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362328474 : Closed e2422362328474 ∧ code e2422362328474 = 11218455350682 := by decide
theorem cert_e2422362328474 : check e2422362328474 [[],[]] .smaller = true := by decide
def e2422362328542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)))))))))
theorem wire_e2422362328542 : Closed e2422362328542 ∧ code e2422362328542 = 11218455350750 := by decide
theorem cert_e2422362328542 : check e2422362328542 [[],[]] .smaller = true := by decide
def e2422362328558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)))))))))
theorem wire_e2422362328558 : Closed e2422362328558 ∧ code e2422362328558 = 11218455350766 := by decide
theorem cert_e2422362328558 : check e2422362328558 [[],[]] .smaller = true := by decide
def e2422362328570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 5))) (.var 0)))))))))
theorem wire_e2422362328570 : Closed e2422362328570 ∧ code e2422362328570 = 11218455350778 := by decide
theorem cert_e2422362328570 : check e2422362328570 [[],[]] .three = true := by decide
def e2422362328630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e2422362328630 : Closed e2422362328630 ∧ code e2422362328630 = 11218455350838 := by decide
theorem cert_e2422362328630 : check e2422362328630 [[],[]] .smaller = true := by decide
def e2422362328634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422362328634 : Closed e2422362328634 ∧ code e2422362328634 = 11218455350842 := by decide
theorem cert_e2422362328634 : check e2422362328634 [[],[]] .smaller = true := by decide
def e2422362328682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))))
theorem wire_e2422362328682 : Closed e2422362328682 ∧ code e2422362328682 = 11218455350890 := by decide
theorem cert_e2422362328682 : check e2422362328682 [[],[]] .smaller = true := by decide
def e2422362328718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e2422362328718 : Closed e2422362328718 ∧ code e2422362328718 = 11218455350926 := by decide
theorem cert_e2422362328718 : check e2422362328718 [[],[]] .smaller = true := by decide
def e2422362328730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362328730 : Closed e2422362328730 ∧ code e2422362328730 = 11218455350938 := by decide
theorem cert_e2422362328730 : check e2422362328730 [[],[]] .smaller = true := by decide
def e2422362328774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422362328774 : Closed e2422362328774 ∧ code e2422362328774 = 11218455350982 := by decide
theorem cert_e2422362328774 : check e2422362328774 [[],[]] .smaller = true := by decide
def e2422362328798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)))))))))
theorem wire_e2422362328798 : Closed e2422362328798 ∧ code e2422362328798 = 11218455351006 := by decide
theorem cert_e2422362328798 : check e2422362328798 [[],[]] .smaller = true := by decide
def e2422362328822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)))))))))
theorem wire_e2422362328822 : Closed e2422362328822 ∧ code e2422362328822 = 11218455351030 := by decide
theorem cert_e2422362328822 : check e2422362328822 [[],[]] .smaller = true := by decide
def e2422362328926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)))))))))
theorem wire_e2422362328926 : Closed e2422362328926 ∧ code e2422362328926 = 11218455351134 := by decide
theorem cert_e2422362328926 : check e2422362328926 [[],[]] .smaller = true := by decide
def e2422362328954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)))))))))
theorem wire_e2422362328954 : Closed e2422362328954 ∧ code e2422362328954 = 11218455351162 := by decide
theorem cert_e2422362328954 : check e2422362328954 [[],[]] .smaller = true := by decide
def e2422362329006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)))))))))
theorem wire_e2422362329006 : Closed e2422362329006 ∧ code e2422362329006 = 11218455351214 := by decide
theorem cert_e2422362329006 : check e2422362329006 [[],[]] .smaller = true := by decide
def e2422362329014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)))))))))
theorem wire_e2422362329014 : Closed e2422362329014 ∧ code e2422362329014 = 11218455351222 := by decide
theorem cert_e2422362329014 : check e2422362329014 [[],[]] .smaller = true := by decide
def e2422362329018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)))))))))
theorem wire_e2422362329018 : Closed e2422362329018 ∧ code e2422362329018 = 11218455351226 := by decide
theorem cert_e2422362329018 : check e2422362329018 [[],[]] .smaller = true := by decide
def e2422362329066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 5) (.var 0))) (.var 0)))))))))
theorem wire_e2422362329066 : Closed e2422362329066 ∧ code e2422362329066 = 11218455351274 := by decide
theorem cert_e2422362329066 : check e2422362329066 [[],[]] .three = true := by decide
def e2422362329326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422362329326 : Closed e2422362329326 ∧ code e2422362329326 = 11218455351534 := by decide
theorem cert_e2422362329326 : check e2422362329326 [[],[]] .smaller = true := by decide
def e2422362329334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422362329334 : Closed e2422362329334 ∧ code e2422362329334 = 11218455351542 := by decide
theorem cert_e2422362329334 : check e2422362329334 [[],[]] .smaller = true := by decide
def e2422362329814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422362329814 : Closed e2422362329814 ∧ code e2422362329814 = 11218455352022 := by decide
theorem cert_e2422362329814 : check e2422362329814 [[],[]] .smaller = true := by decide
def e2422362329818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422362329818 : Closed e2422362329818 ∧ code e2422362329818 = 11218455352026 := by decide
theorem cert_e2422362329818 : check e2422362329818 [[],[]] .smaller = true := by decide
def e2422362329834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422362329834 : Closed e2422362329834 ∧ code e2422362329834 = 11218455352042 := by decide
theorem cert_e2422362329834 : check e2422362329834 [[],[]] .smaller = true := by decide
def e2422362329910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422362329910 : Closed e2422362329910 ∧ code e2422362329910 = 11218455352118 := by decide
theorem cert_e2422362329910 : check e2422362329910 [[],[]] .smaller = true := by decide
def e2422362329914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422362329914 : Closed e2422362329914 ∧ code e2422362329914 = 11218455352122 := by decide
theorem cert_e2422362329914 : check e2422362329914 [[],[]] .smaller = true := by decide
def e2422362329982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 5))))))))))
theorem wire_e2422362329982 : Closed e2422362329982 ∧ code e2422362329982 = 11218455352190 := by decide
theorem cert_e2422362329982 : check e2422362329982 [[],[]] .three = true := by decide
def e2422362329998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422362329998 : Closed e2422362329998 ∧ code e2422362329998 = 11218455352206 := by decide
theorem cert_e2422362329998 : check e2422362329998 [[],[]] .smaller = true := by decide
def e2422362330010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362330010 : Closed e2422362330010 ∧ code e2422362330010 = 11218455352218 := by decide
theorem cert_e2422362330010 : check e2422362330010 [[],[]] .smaller = true := by decide
def e2422362330078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422362330078 : Closed e2422362330078 ∧ code e2422362330078 = 11218455352286 := by decide
theorem cert_e2422362330078 : check e2422362330078 [[],[]] .smaller = true := by decide
def e2422362330094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422362330094 : Closed e2422362330094 ∧ code e2422362330094 = 11218455352302 := by decide
theorem cert_e2422362330094 : check e2422362330094 [[],[]] .smaller = true := by decide
def e2422362330106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 5) (.var 0))))))))))
theorem wire_e2422362330106 : Closed e2422362330106 ∧ code e2422362330106 = 11218455352314 := by decide
theorem cert_e2422362330106 : check e2422362330106 [[],[]] .three = true := by decide
def e2422362331254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422362331254 : Closed e2422362331254 ∧ code e2422362331254 = 11218455353462 := by decide
theorem cert_e2422362331254 : check e2422362331254 [[],[]] .smaller = true := by decide
def e2422362331498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422362331498 : Closed e2422362331498 ∧ code e2422362331498 = 11218455353706 := by decide
theorem cert_e2422362331498 : check e2422362331498 [[],[]] .smaller = true := by decide
def e2422362331534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422362331534 : Closed e2422362331534 ∧ code e2422362331534 = 11218455353742 := by decide
theorem cert_e2422362331534 : check e2422362331534 [[],[]] .smaller = true := by decide
def e2422362331546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422362331546 : Closed e2422362331546 ∧ code e2422362331546 = 11218455353754 := by decide
theorem cert_e2422362331546 : check e2422362331546 [[],[]] .smaller = true := by decide
def e2422362331590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422362331590 : Closed e2422362331590 ∧ code e2422362331590 = 11218455353798 := by decide
theorem cert_e2422362331590 : check e2422362331590 [[],[]] .smaller = true := by decide
def e2422362331614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422362331614 : Closed e2422362331614 ∧ code e2422362331614 = 11218455353822 := by decide
theorem cert_e2422362331614 : check e2422362331614 [[],[]] .smaller = true := by decide
def e2422362331638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422362331638 : Closed e2422362331638 ∧ code e2422362331638 = 11218455353846 := by decide
theorem cert_e2422362331638 : check e2422362331638 [[],[]] .smaller = true := by decide
def e2422362332382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422362332382 : Closed e2422362332382 ∧ code e2422362332382 = 11218455354590 := by decide
theorem cert_e2422362332382 : check e2422362332382 [[],[]] .smaller = true := by decide
def e2422362332410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422362332410 : Closed e2422362332410 ∧ code e2422362332410 = 11218455354618 := by decide
theorem cert_e2422362332410 : check e2422362332410 [[],[]] .smaller = true := by decide
def e2422362332782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362332782 : Closed e2422362332782 ∧ code e2422362332782 = 11218455354990 := by decide
theorem cert_e2422362332782 : check e2422362332782 [[],[]] .smaller = true := by decide
def e2422362332790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422362332790 : Closed e2422362332790 ∧ code e2422362332790 = 11218455354998 := by decide
theorem cert_e2422362332790 : check e2422362332790 [[],[]] .smaller = true := by decide
def e2422362332794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362332794 : Closed e2422362332794 ∧ code e2422362332794 = 11218455355002 := by decide
theorem cert_e2422362332794 : check e2422362332794 [[],[]] .smaller = true := by decide
def e2422362333082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 5)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362333082 : Closed e2422362333082 ∧ code e2422362333082 = 11218455355290 := by decide
theorem cert_e2422362333082 : check e2422362333082 [[],[]] .three = true := by decide
def e2422362334006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362334006 : Closed e2422362334006 ∧ code e2422362334006 = 11218455356214 := by decide
theorem cert_e2422362334006 : check e2422362334006 [[],[]] .smaller = true := by decide
def e2422362334010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362334010 : Closed e2422362334010 ∧ code e2422362334010 = 11218455356218 := by decide
theorem cert_e2422362334010 : check e2422362334010 [[],[]] .smaller = true := by decide
def e2422362334106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422362334106 : Closed e2422362334106 ∧ code e2422362334106 = 11218455356314 := by decide
theorem cert_e2422362334106 : check e2422362334106 [[],[]] .smaller = true := by decide
def e2422362334774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))))
theorem wire_e2422362334774 : Closed e2422362334774 ∧ code e2422362334774 = 11218455356982 := by decide
theorem cert_e2422362334774 : check e2422362334774 [[],[]] .smaller = true := by decide
def e2422362334778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422362334778 : Closed e2422362334778 ∧ code e2422362334778 = 11218455356986 := by decide
theorem cert_e2422362334778 : check e2422362334778 [[],[]] .smaller = true := by decide
def e2422362334862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))))
theorem wire_e2422362334862 : Closed e2422362334862 ∧ code e2422362334862 = 11218455357070 := by decide
theorem cert_e2422362334862 : check e2422362334862 [[],[]] .smaller = true := by decide
def e2422362334910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 4)))))))))
theorem wire_e2422362334910 : Closed e2422362334910 ∧ code e2422362334910 = 11218455357118 := by decide
theorem cert_e2422362334910 : check e2422362334910 [[],[]] .smaller = true := by decide
def e2422362334918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422362334918 : Closed e2422362334918 ∧ code e2422362334918 = 11218455357126 := by decide
theorem cert_e2422362334918 : check e2422362334918 [[],[]] .smaller = true := by decide
def e2422362334942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2422362334942 : Closed e2422362334942 ∧ code e2422362334942 = 11218455357150 := by decide
theorem cert_e2422362334942 : check e2422362334942 [[],[]] .smaller = true := by decide
def e2422362334958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)))))))))
theorem wire_e2422362334958 : Closed e2422362334958 ∧ code e2422362334958 = 11218455357166 := by decide
theorem cert_e2422362334958 : check e2422362334958 [[],[]] .smaller = true := by decide
def e2422362334966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2422362334966 : Closed e2422362334966 ∧ code e2422362334966 = 11218455357174 := by decide
theorem cert_e2422362334966 : check e2422362334966 [[],[]] .smaller = true := by decide
def e2422362334970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 4))) (.var 0)))))))))
theorem wire_e2422362334970 : Closed e2422362334970 ∧ code e2422362334970 = 11218455357178 := by decide
theorem cert_e2422362334970 : check e2422362334970 [[],[]] .smaller = true := by decide
def e2422362335002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))))
theorem wire_e2422362335002 : Closed e2422362335002 ∧ code e2422362335002 = 11218455357210 := by decide
theorem cert_e2422362335002 : check e2422362335002 [[],[]] .smaller = true := by decide
def e2422362335046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))))
theorem wire_e2422362335046 : Closed e2422362335046 ∧ code e2422362335046 = 11218455357254 := by decide
theorem cert_e2422362335046 : check e2422362335046 [[],[]] .smaller = true := by decide
def e2422362335070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2422362335070 : Closed e2422362335070 ∧ code e2422362335070 = 11218455357278 := by decide
theorem cert_e2422362335070 : check e2422362335070 [[],[]] .smaller = true := by decide
def e2422362335086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e2422362335086 : Closed e2422362335086 ∧ code e2422362335086 = 11218455357294 := by decide
theorem cert_e2422362335086 : check e2422362335086 [[],[]] .smaller = true := by decide
end Blc.Floor43
