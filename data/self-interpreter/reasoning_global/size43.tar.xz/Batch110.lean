import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862486813982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e862486813982 : Closed e862486813982 ∧ code e862486813982 = 9658579836190 := by decide
theorem cert_e862486813982 : check e862486813982 [] .sourceHead = true := by decide
def e862486814150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e862486814150 : Closed e862486814150 ∧ code e862486814150 = 9658579836358 := by decide
theorem cert_e862486814150 : check e862486814150 [] .sourceHead = true := by decide
def e862486814262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e862486814262 : Closed e862486814262 ∧ code e862486814262 = 9658579836470 := by decide
theorem cert_e862486814262 : check e862486814262 [] .sourceHead = true := by decide
def e862486814266 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e862486814266 : Closed e862486814266 ∧ code e862486814266 = 9658579836474 := by decide
theorem cert_e862486814266 : check e862486814266 [] .sourceHead = true := by decide
def e862486814350 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e862486814350 : Closed e862486814350 ∧ code e862486814350 = 9658579836558 := by decide
theorem cert_e862486814350 : check e862486814350 [] .sourceHead = true := by decide
def e862486814406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e862486814406 : Closed e862486814406 ∧ code e862486814406 = 9658579836614 := by decide
theorem cert_e862486814406 : check e862486814406 [] .sourceHead = true := by decide
def e862486816542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e862486816542 : Closed e862486816542 ∧ code e862486816542 = 9658579838750 := by decide
theorem cert_e862486816542 : check e862486816542 [] .sourceHead = true := by decide
def e862486816654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e862486816654 : Closed e862486816654 ∧ code e862486816654 = 9658579838862 := by decide
theorem cert_e862486816654 : check e862486816654 [] .sourceHead = true := by decide
def e862486819614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e862486819614 : Closed e862486819614 ∧ code e862486819614 = 9658579841822 := by decide
theorem cert_e862486819614 : check e862486819614 [] .sourceHead = true := by decide
def e862486819782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e862486819782 : Closed e862486819782 ∧ code e862486819782 = 9658579841990 := by decide
theorem cert_e862486819782 : check e862486819782 [] .sourceHead = true := by decide
def e862486821262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e862486821262 : Closed e862486821262 ∧ code e862486821262 = 9658579843470 := by decide
theorem cert_e862486821262 : check e862486821262 [] .sourceHead = true := by decide
def e862486821318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e862486821318 : Closed e862486821318 ∧ code e862486821318 = 9658579843526 := by decide
theorem cert_e862486821318 : check e862486821318 [] .sourceHead = true := by decide
def e862494666170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e862494666170 : Closed e862494666170 ∧ code e862494666170 = 9658587688378 := by decide
theorem cert_e862494666170 : check e862494666170 [] .sourceHead = true := by decide
def e862494666202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e862494666202 : Closed e862494666202 ∧ code e862494666202 = 9658587688410 := by decide
theorem cert_e862494666202 : check e862494666202 [] .sourceHead = true := by decide
def e862494666426 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e862494666426 : Closed e862494666426 ∧ code e862494666426 = 9658587688634 := by decide
theorem cert_e862494666426 : check e862494666426 [] .sourceHead = true := by decide
def e862494666474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e862494666474 : Closed e862494666474 ∧ code e862494666474 = 9658587688682 := by decide
theorem cert_e862494666474 : check e862494666474 [] .sourceHead = true := by decide
def e862494666586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e862494666586 : Closed e862494666586 ∧ code e862494666586 = 9658587688794 := by decide
theorem cert_e862494666586 : check e862494666586 [] .sourceHead = true := by decide
def e862494666602 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e862494666602 : Closed e862494666602 ∧ code e862494666602 = 9658587688810 := by decide
theorem cert_e862494666602 : check e862494666602 [] .sourceHead = true := by decide
def e862494667706 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e862494667706 : Closed e862494667706 ∧ code e862494667706 = 9658587689914 := by decide
theorem cert_e862494667706 : check e862494667706 [] .sourceHead = true := by decide
def e862494667738 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e862494667738 : Closed e862494667738 ∧ code e862494667738 = 9658587689946 := by decide
theorem cert_e862494667738 : check e862494667738 [] .sourceHead = true := by decide
def e862494669242 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e862494669242 : Closed e862494669242 ∧ code e862494669242 = 9658587691450 := by decide
theorem cert_e862494669242 : check e862494669242 [] .sourceHead = true := by decide
def e862494669290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e862494669290 : Closed e862494669290 ∧ code e862494669290 = 9658587691498 := by decide
theorem cert_e862494669290 : check e862494669290 [] .sourceHead = true := by decide
def e862494670042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e862494670042 : Closed e862494670042 ∧ code e862494670042 = 9658587692250 := by decide
theorem cert_e862494670042 : check e862494670042 [] .sourceHead = true := by decide
def e862494670058 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e862494670058 : Closed e862494670058 ∧ code e862494670058 = 9658587692266 := by decide
theorem cert_e862494670058 : check e862494670058 [] .sourceHead = true := by decide
def e862494919534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862494919534 : Closed e862494919534 ∧ code e862494919534 = 9658587941742 := by decide
theorem cert_e862494919534 : check e862494919534 [] .sourceHead = true := by decide
def e862494919542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862494919542 : Closed e862494919542 ∧ code e862494919542 = 9658587941750 := by decide
theorem cert_e862494919542 : check e862494919542 [] .sourceHead = true := by decide
def e862494919598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862494919598 : Closed e862494919598 ∧ code e862494919598 = 9658587941806 := by decide
theorem cert_e862494919598 : check e862494919598 [] .sourceHead = true := by decide
def e862494919610 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862494919610 : Closed e862494919610 ∧ code e862494919610 = 9658587941818 := by decide
theorem cert_e862494919610 : check e862494919610 [] .sourceHead = true := by decide
def e862494919638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862494919638 : Closed e862494919638 ∧ code e862494919638 = 9658587941846 := by decide
theorem cert_e862494919638 : check e862494919638 [] .sourceHead = true := by decide
def e862494919642 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862494919642 : Closed e862494919642 ∧ code e862494919642 = 9658587941850 := by decide
theorem cert_e862494919642 : check e862494919642 [] .sourceHead = true := by decide
def e862494919918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862494919918 : Closed e862494919918 ∧ code e862494919918 = 9658587942126 := by decide
theorem cert_e862494919918 : check e862494919918 [] .sourceHead = true := by decide
def e862494919926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862494919926 : Closed e862494919926 ∧ code e862494919926 = 9658587942134 := by decide
theorem cert_e862494919926 : check e862494919926 [] .sourceHead = true := by decide
def e862494920302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862494920302 : Closed e862494920302 ∧ code e862494920302 = 9658587942510 := by decide
theorem cert_e862494920302 : check e862494920302 [] .sourceHead = true := by decide
def e862494920314 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862494920314 : Closed e862494920314 ∧ code e862494920314 = 9658587942522 := by decide
theorem cert_e862494920314 : check e862494920314 [] .sourceHead = true := by decide
def e862494920502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862494920502 : Closed e862494920502 ∧ code e862494920502 = 9658587942710 := by decide
theorem cert_e862494920502 : check e862494920502 [] .sourceHead = true := by decide
def e862494920506 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862494920506 : Closed e862494920506 ∧ code e862494920506 = 9658587942714 := by decide
theorem cert_e862494920506 : check e862494920506 [] .sourceHead = true := by decide
def e862495714782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e862495714782 : Closed e862495714782 ∧ code e862495714782 = 9658588736990 := by decide
theorem cert_e862495714782 : check e862495714782 [] .sourceHead = true := by decide
def e862495714798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e862495714798 : Closed e862495714798 ∧ code e862495714798 = 9658588737006 := by decide
theorem cert_e862495714798 : check e862495714798 [] .sourceHead = true := by decide
def e862495715166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e862495715166 : Closed e862495715166 ∧ code e862495715166 = 9658588737374 := by decide
theorem cert_e862495715166 : check e862495715166 [] .sourceHead = true := by decide
def e862495715194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e862495715194 : Closed e862495715194 ∧ code e862495715194 = 9658588737402 := by decide
theorem cert_e862495715194 : check e862495715194 [] .sourceHead = true := by decide
def e862495715246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e862495715246 : Closed e862495715246 ∧ code e862495715246 = 9658588737454 := by decide
theorem cert_e862495715246 : check e862495715246 [] .sourceHead = true := by decide
def e862495715258 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e862495715258 : Closed e862495715258 ∧ code e862495715258 = 9658588737466 := by decide
theorem cert_e862495715258 : check e862495715258 [] .sourceHead = true := by decide
def e862495716318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e862495716318 : Closed e862495716318 ∧ code e862495716318 = 9658588738526 := by decide
theorem cert_e862495716318 : check e862495716318 [] .sourceHead = true := by decide
def e862495716334 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e862495716334 : Closed e862495716334 ∧ code e862495716334 = 9658588738542 := by decide
theorem cert_e862495716334 : check e862495716334 [] .sourceHead = true := by decide
def e862495718622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862495718622 : Closed e862495718622 ∧ code e862495718622 = 9658588740830 := by decide
theorem cert_e862495718622 : check e862495718622 [] .sourceHead = true := by decide
def e862495718650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862495718650 : Closed e862495718650 ∧ code e862495718650 = 9658588740858 := by decide
theorem cert_e862495718650 : check e862495718650 [] .sourceHead = true := by decide
def e862495719022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862495719022 : Closed e862495719022 ∧ code e862495719022 = 9658588741230 := by decide
theorem cert_e862495719022 : check e862495719022 [] .sourceHead = true := by decide
def e862495719034 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862495719034 : Closed e862495719034 ∧ code e862495719034 = 9658588741242 := by decide
theorem cert_e862495719034 : check e862495719034 [] .sourceHead = true := by decide
def e862495747438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e862495747438 : Closed e862495747438 ∧ code e862495747438 = 9658588769646 := by decide
theorem cert_e862495747438 : check e862495747438 [] .sourceHead = true := by decide
def e862495747446 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e862495747446 : Closed e862495747446 ∧ code e862495747446 = 9658588769654 := by decide
theorem cert_e862495747446 : check e862495747446 [] .sourceHead = true := by decide
def e862495747502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e862495747502 : Closed e862495747502 ∧ code e862495747502 = 9658588769710 := by decide
theorem cert_e862495747502 : check e862495747502 [] .sourceHead = true := by decide
def e862495747514 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e862495747514 : Closed e862495747514 ∧ code e862495747514 = 9658588769722 := by decide
theorem cert_e862495747514 : check e862495747514 [] .sourceHead = true := by decide
def e862495747542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e862495747542 : Closed e862495747542 ∧ code e862495747542 = 9658588769750 := by decide
theorem cert_e862495747542 : check e862495747542 [] .sourceHead = true := by decide
def e862495747546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e862495747546 : Closed e862495747546 ∧ code e862495747546 = 9658588769754 := by decide
theorem cert_e862495747546 : check e862495747546 [] .sourceHead = true := by decide
def e862495747758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862495747758 : Closed e862495747758 ∧ code e862495747758 = 9658588769966 := by decide
theorem cert_e862495747758 : check e862495747758 [] .sourceHead = true := by decide
def e862495747770 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862495747770 : Closed e862495747770 ∧ code e862495747770 = 9658588769978 := by decide
theorem cert_e862495747770 : check e862495747770 [] .sourceHead = true := by decide
def e862495747818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862495747818 : Closed e862495747818 ∧ code e862495747818 = 9658588770026 := by decide
theorem cert_e862495747818 : check e862495747818 [] .sourceHead = true := by decide
def e862495747926 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e862495747926 : Closed e862495747926 ∧ code e862495747926 = 9658588770134 := by decide
theorem cert_e862495747926 : check e862495747926 [] .sourceHead = true := by decide
def e862495747930 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e862495747930 : Closed e862495747930 ∧ code e862495747930 = 9658588770138 := by decide
theorem cert_e862495747930 : check e862495747930 [] .sourceHead = true := by decide
def e862495747946 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e862495747946 : Closed e862495747946 ∧ code e862495747946 = 9658588770154 := by decide
theorem cert_e862495747946 : check e862495747946 [] .sourceHead = true := by decide
def e862495748974 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e862495748974 : Closed e862495748974 ∧ code e862495748974 = 9658588771182 := by decide
theorem cert_e862495748974 : check e862495748974 [] .sourceHead = true := by decide
def e862495748982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e862495748982 : Closed e862495748982 ∧ code e862495748982 = 9658588771190 := by decide
theorem cert_e862495748982 : check e862495748982 [] .sourceHead = true := by decide
def e862495749038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e862495749038 : Closed e862495749038 ∧ code e862495749038 = 9658588771246 := by decide
theorem cert_e862495749038 : check e862495749038 [] .sourceHead = true := by decide
def e862495749050 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e862495749050 : Closed e862495749050 ∧ code e862495749050 = 9658588771258 := by decide
theorem cert_e862495749050 : check e862495749050 [] .sourceHead = true := by decide
def e862495749078 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e862495749078 : Closed e862495749078 ∧ code e862495749078 = 9658588771286 := by decide
theorem cert_e862495749078 : check e862495749078 [] .sourceHead = true := by decide
def e862495749082 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e862495749082 : Closed e862495749082 ∧ code e862495749082 = 9658588771290 := by decide
theorem cert_e862495749082 : check e862495749082 [] .sourceHead = true := by decide
def e862495749358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862495749358 : Closed e862495749358 ∧ code e862495749358 = 9658588771566 := by decide
theorem cert_e862495749358 : check e862495749358 [] .sourceHead = true := by decide
def e862495749366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862495749366 : Closed e862495749366 ∧ code e862495749366 = 9658588771574 := by decide
theorem cert_e862495749366 : check e862495749366 [] .sourceHead = true := by decide
def e862495749742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862495749742 : Closed e862495749742 ∧ code e862495749742 = 9658588771950 := by decide
theorem cert_e862495749742 : check e862495749742 [] .sourceHead = true := by decide
def e862495749754 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862495749754 : Closed e862495749754 ∧ code e862495749754 = 9658588771962 := by decide
theorem cert_e862495749754 : check e862495749754 [] .sourceHead = true := by decide
def e862495749942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862495749942 : Closed e862495749942 ∧ code e862495749942 = 9658588772150 := by decide
theorem cert_e862495749942 : check e862495749942 [] .sourceHead = true := by decide
def e862495749946 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862495749946 : Closed e862495749946 ∧ code e862495749946 = 9658588772154 := by decide
theorem cert_e862495749946 : check e862495749946 [] .sourceHead = true := by decide
def e862495750574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862495750574 : Closed e862495750574 ∧ code e862495750574 = 9658588772782 := by decide
theorem cert_e862495750574 : check e862495750574 [] .sourceHead = true := by decide
def e862495750586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862495750586 : Closed e862495750586 ∧ code e862495750586 = 9658588772794 := by decide
theorem cert_e862495750586 : check e862495750586 [] .sourceHead = true := by decide
def e862495750634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862495750634 : Closed e862495750634 ∧ code e862495750634 = 9658588772842 := by decide
theorem cert_e862495750634 : check e862495750634 [] .sourceHead = true := by decide
def e862495750766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862495750766 : Closed e862495750766 ∧ code e862495750766 = 9658588772974 := by decide
theorem cert_e862495750766 : check e862495750766 [] .sourceHead = true := by decide
def e862495750778 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862495750778 : Closed e862495750778 ∧ code e862495750778 = 9658588772986 := by decide
theorem cert_e862495750778 : check e862495750778 [] .sourceHead = true := by decide
def e862495751066 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862495751066 : Closed e862495751066 ∧ code e862495751066 = 9658588773274 := by decide
theorem cert_e862495751066 : check e862495751066 [] .sourceHead = true := by decide
def e862495751382 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e862495751382 : Closed e862495751382 ∧ code e862495751382 = 9658588773590 := by decide
theorem cert_e862495751382 : check e862495751382 [] .sourceHead = true := by decide
def e862495751386 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e862495751386 : Closed e862495751386 ∧ code e862495751386 = 9658588773594 := by decide
theorem cert_e862495751386 : check e862495751386 [] .sourceHead = true := by decide
def e862495751402 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e862495751402 : Closed e862495751402 ∧ code e862495751402 = 9658588773610 := by decide
theorem cert_e862495751402 : check e862495751402 [] .sourceHead = true := by decide
def e862495751478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862495751478 : Closed e862495751478 ∧ code e862495751478 = 9658588773686 := by decide
theorem cert_e862495751478 : check e862495751478 [] .sourceHead = true := by decide
def e862495751482 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862495751482 : Closed e862495751482 ∧ code e862495751482 = 9658588773690 := by decide
theorem cert_e862495751482 : check e862495751482 [] .sourceHead = true := by decide
def e862495751578 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862495751578 : Closed e862495751578 ∧ code e862495751578 = 9658588773786 := by decide
theorem cert_e862495751578 : check e862495751578 [] .sourceHead = true := by decide
def e862495753182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e862495753182 : Closed e862495753182 ∧ code e862495753182 = 9658588775390 := by decide
theorem cert_e862495753182 : check e862495753182 [] .sourceHead = true := by decide
def e862495753198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e862495753198 : Closed e862495753198 ∧ code e862495753198 = 9658588775406 := by decide
theorem cert_e862495753198 : check e862495753198 [] .sourceHead = true := by decide
def e862495755118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862495755118 : Closed e862495755118 ∧ code e862495755118 = 9658588777326 := by decide
theorem cert_e862495755118 : check e862495755118 [] .sourceHead = true := by decide
def e862495755126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862495755126 : Closed e862495755126 ∧ code e862495755126 = 9658588777334 := by decide
theorem cert_e862495755126 : check e862495755126 [] .sourceHead = true := by decide
def e862495755182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862495755182 : Closed e862495755182 ∧ code e862495755182 = 9658588777390 := by decide
theorem cert_e862495755182 : check e862495755182 [] .sourceHead = true := by decide
def e862495755194 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862495755194 : Closed e862495755194 ∧ code e862495755194 = 9658588777402 := by decide
theorem cert_e862495755194 : check e862495755194 [] .sourceHead = true := by decide
def e862495755222 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862495755222 : Closed e862495755222 ∧ code e862495755222 = 9658588777430 := by decide
theorem cert_e862495755222 : check e862495755222 [] .sourceHead = true := by decide
def e862495755226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862495755226 : Closed e862495755226 ∧ code e862495755226 = 9658588777434 := by decide
theorem cert_e862495755226 : check e862495755226 [] .sourceHead = true := by decide
def e862495755502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862495755502 : Closed e862495755502 ∧ code e862495755502 = 9658588777710 := by decide
theorem cert_e862495755502 : check e862495755502 [] .sourceHead = true := by decide
def e862495755510 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862495755510 : Closed e862495755510 ∧ code e862495755510 = 9658588777718 := by decide
theorem cert_e862495755510 : check e862495755510 [] .sourceHead = true := by decide
def e862495755886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862495755886 : Closed e862495755886 ∧ code e862495755886 = 9658588778094 := by decide
theorem cert_e862495755886 : check e862495755886 [] .sourceHead = true := by decide
def e862495755898 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862495755898 : Closed e862495755898 ∧ code e862495755898 = 9658588778106 := by decide
theorem cert_e862495755898 : check e862495755898 [] .sourceHead = true := by decide
def e862495756086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862495756086 : Closed e862495756086 ∧ code e862495756086 = 9658588778294 := by decide
theorem cert_e862495756086 : check e862495756086 [] .sourceHead = true := by decide
def e862495756090 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862495756090 : Closed e862495756090 ∧ code e862495756090 = 9658588778298 := by decide
theorem cert_e862495756090 : check e862495756090 [] .sourceHead = true := by decide
def e862495760862 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e862495760862 : Closed e862495760862 ∧ code e862495760862 = 9658588783070 := by decide
theorem cert_e862495760862 : check e862495760862 [] .sourceHead = true := by decide
def e862495760886 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e862495760886 : Closed e862495760886 ∧ code e862495760886 = 9658588783094 := by decide
theorem cert_e862495760886 : check e862495760886 [] .sourceHead = true := by decide
def e862495761838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862495761838 : Closed e862495761838 ∧ code e862495761838 = 9658588784046 := by decide
theorem cert_e862495761838 : check e862495761838 [] .sourceHead = true := by decide
def e862495761850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862495761850 : Closed e862495761850 ∧ code e862495761850 = 9658588784058 := by decide
theorem cert_e862495761850 : check e862495761850 [] .sourceHead = true := by decide
def e862495761898 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862495761898 : Closed e862495761898 ∧ code e862495761898 = 9658588784106 := by decide
theorem cert_e862495761898 : check e862495761898 [] .sourceHead = true := by decide
def e862495762030 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862495762030 : Closed e862495762030 ∧ code e862495762030 = 9658588784238 := by decide
theorem cert_e862495762030 : check e862495762030 [] .sourceHead = true := by decide
def e862495762042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862495762042 : Closed e862495762042 ∧ code e862495762042 = 9658588784250 := by decide
theorem cert_e862495762042 : check e862495762042 [] .sourceHead = true := by decide
def e862495762330 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862495762330 : Closed e862495762330 ∧ code e862495762330 = 9658588784538 := by decide
theorem cert_e862495762330 : check e862495762330 [] .sourceHead = true := by decide
def e862495764718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e862495764718 : Closed e862495764718 ∧ code e862495764718 = 9658588786926 := by decide
theorem cert_e862495764718 : check e862495764718 [] .sourceHead = true := by decide
def e862495764726 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e862495764726 : Closed e862495764726 ∧ code e862495764726 = 9658588786934 := by decide
theorem cert_e862495764726 : check e862495764726 [] .sourceHead = true := by decide
def e862495765206 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e862495765206 : Closed e862495765206 ∧ code e862495765206 = 9658588787414 := by decide
theorem cert_e862495765206 : check e862495765206 [] .sourceHead = true := by decide
def e862495765210 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e862495765210 : Closed e862495765210 ∧ code e862495765210 = 9658588787418 := by decide
theorem cert_e862495765210 : check e862495765210 [] .sourceHead = true := by decide
def e862495765226 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e862495765226 : Closed e862495765226 ∧ code e862495765226 = 9658588787434 := by decide
theorem cert_e862495765226 : check e862495765226 [] .sourceHead = true := by decide
def e862495765302 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862495765302 : Closed e862495765302 ∧ code e862495765302 = 9658588787510 := by decide
theorem cert_e862495765302 : check e862495765302 [] .sourceHead = true := by decide
def e862495765306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862495765306 : Closed e862495765306 ∧ code e862495765306 = 9658588787514 := by decide
theorem cert_e862495765306 : check e862495765306 [] .sourceHead = true := by decide
def e862495765402 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862495765402 : Closed e862495765402 ∧ code e862495765402 = 9658588787610 := by decide
theorem cert_e862495765402 : check e862495765402 [] .sourceHead = true := by decide
def e862495902574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862495902574 : Closed e862495902574 ∧ code e862495902574 = 9658588924782 := by decide
theorem cert_e862495902574 : check e862495902574 [] .sourceHead = true := by decide
def e862495902582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862495902582 : Closed e862495902582 ∧ code e862495902582 = 9658588924790 := by decide
theorem cert_e862495902582 : check e862495902582 [] .sourceHead = true := by decide
def e862495902638 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862495902638 : Closed e862495902638 ∧ code e862495902638 = 9658588924846 := by decide
theorem cert_e862495902638 : check e862495902638 [] .sourceHead = true := by decide
def e862495902650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862495902650 : Closed e862495902650 ∧ code e862495902650 = 9658588924858 := by decide
theorem cert_e862495902650 : check e862495902650 [] .sourceHead = true := by decide
def e862495902678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862495902678 : Closed e862495902678 ∧ code e862495902678 = 9658588924886 := by decide
theorem cert_e862495902678 : check e862495902678 [] .sourceHead = true := by decide
def e862495902682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862495902682 : Closed e862495902682 ∧ code e862495902682 = 9658588924890 := by decide
theorem cert_e862495902682 : check e862495902682 [] .sourceHead = true := by decide
def e862495902958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862495902958 : Closed e862495902958 ∧ code e862495902958 = 9658588925166 := by decide
theorem cert_e862495902958 : check e862495902958 [] .sourceHead = true := by decide
def e862495902966 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862495902966 : Closed e862495902966 ∧ code e862495902966 = 9658588925174 := by decide
theorem cert_e862495902966 : check e862495902966 [] .sourceHead = true := by decide
def e862495903342 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862495903342 : Closed e862495903342 ∧ code e862495903342 = 9658588925550 := by decide
theorem cert_e862495903342 : check e862495903342 [] .sourceHead = true := by decide
def e862495903354 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862495903354 : Closed e862495903354 ∧ code e862495903354 = 9658588925562 := by decide
theorem cert_e862495903354 : check e862495903354 [] .sourceHead = true := by decide
def e862495903542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862495903542 : Closed e862495903542 ∧ code e862495903542 = 9658588925750 := by decide
theorem cert_e862495903542 : check e862495903542 [] .sourceHead = true := by decide
def e862495903546 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862495903546 : Closed e862495903546 ∧ code e862495903546 = 9658588925754 := by decide
theorem cert_e862495903546 : check e862495903546 [] .sourceHead = true := by decide
def e862496492398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862496492398 : Closed e862496492398 ∧ code e862496492398 = 9658589514606 := by decide
theorem cert_e862496492398 : check e862496492398 [] .sourceHead = true := by decide
def e862496492406 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862496492406 : Closed e862496492406 ∧ code e862496492406 = 9658589514614 := by decide
theorem cert_e862496492406 : check e862496492406 [] .sourceHead = true := by decide
def e862496492462 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862496492462 : Closed e862496492462 ∧ code e862496492462 = 9658589514670 := by decide
theorem cert_e862496492462 : check e862496492462 [] .sourceHead = true := by decide
def e862496492474 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862496492474 : Closed e862496492474 ∧ code e862496492474 = 9658589514682 := by decide
theorem cert_e862496492474 : check e862496492474 [] .sourceHead = true := by decide
def e862496492502 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862496492502 : Closed e862496492502 ∧ code e862496492502 = 9658589514710 := by decide
theorem cert_e862496492502 : check e862496492502 [] .sourceHead = true := by decide
def e862496492506 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862496492506 : Closed e862496492506 ∧ code e862496492506 = 9658589514714 := by decide
theorem cert_e862496492506 : check e862496492506 [] .sourceHead = true := by decide
def e862496492782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862496492782 : Closed e862496492782 ∧ code e862496492782 = 9658589514990 := by decide
theorem cert_e862496492782 : check e862496492782 [] .sourceHead = true := by decide
def e862496492790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862496492790 : Closed e862496492790 ∧ code e862496492790 = 9658589514998 := by decide
theorem cert_e862496492790 : check e862496492790 [] .sourceHead = true := by decide
def e862496493166 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862496493166 : Closed e862496493166 ∧ code e862496493166 = 9658589515374 := by decide
theorem cert_e862496493166 : check e862496493166 [] .sourceHead = true := by decide
def e862496493178 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862496493178 : Closed e862496493178 ∧ code e862496493178 = 9658589515386 := by decide
theorem cert_e862496493178 : check e862496493178 [] .sourceHead = true := by decide
def e862496493366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862496493366 : Closed e862496493366 ∧ code e862496493366 = 9658589515574 := by decide
theorem cert_e862496493366 : check e862496493366 [] .sourceHead = true := by decide
def e862496493370 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862496493370 : Closed e862496493370 ∧ code e862496493370 = 9658589515578 := by decide
theorem cert_e862496493370 : check e862496493370 [] .sourceHead = true := by decide
def e862533496174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e862533496174 : Closed e862533496174 ∧ code e862533496174 = 9658626518382 := by decide
theorem cert_e862533496174 : check e862533496174 [] .sourceHead = true := by decide
def e862533496182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e862533496182 : Closed e862533496182 ∧ code e862533496182 = 9658626518390 := by decide
theorem cert_e862533496182 : check e862533496182 [] .sourceHead = true := by decide
def e862533496238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e862533496238 : Closed e862533496238 ∧ code e862533496238 = 9658626518446 := by decide
theorem cert_e862533496238 : check e862533496238 [] .sourceHead = true := by decide
def e862533496250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e862533496250 : Closed e862533496250 ∧ code e862533496250 = 9658626518458 := by decide
theorem cert_e862533496250 : check e862533496250 [] .sourceHead = true := by decide
def e862533496278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e862533496278 : Closed e862533496278 ∧ code e862533496278 = 9658626518486 := by decide
theorem cert_e862533496278 : check e862533496278 [] .sourceHead = true := by decide
def e862533496282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e862533496282 : Closed e862533496282 ∧ code e862533496282 = 9658626518490 := by decide
theorem cert_e862533496282 : check e862533496282 [] .sourceHead = true := by decide
def e862533496494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862533496494 : Closed e862533496494 ∧ code e862533496494 = 9658626518702 := by decide
theorem cert_e862533496494 : check e862533496494 [] .sourceHead = true := by decide
def e862533496506 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862533496506 : Closed e862533496506 ∧ code e862533496506 = 9658626518714 := by decide
theorem cert_e862533496506 : check e862533496506 [] .sourceHead = true := by decide
def e862533496554 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862533496554 : Closed e862533496554 ∧ code e862533496554 = 9658626518762 := by decide
theorem cert_e862533496554 : check e862533496554 [] .sourceHead = true := by decide
def e862533496662 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e862533496662 : Closed e862533496662 ∧ code e862533496662 = 9658626518870 := by decide
theorem cert_e862533496662 : check e862533496662 [] .sourceHead = true := by decide
def e862533496666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e862533496666 : Closed e862533496666 ∧ code e862533496666 = 9658626518874 := by decide
theorem cert_e862533496666 : check e862533496666 [] .sourceHead = true := by decide
def e862533496682 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e862533496682 : Closed e862533496682 ∧ code e862533496682 = 9658626518890 := by decide
theorem cert_e862533496682 : check e862533496682 [] .sourceHead = true := by decide
def e862533497710 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e862533497710 : Closed e862533497710 ∧ code e862533497710 = 9658626519918 := by decide
theorem cert_e862533497710 : check e862533497710 [] .sourceHead = true := by decide
def e862533497718 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e862533497718 : Closed e862533497718 ∧ code e862533497718 = 9658626519926 := by decide
theorem cert_e862533497718 : check e862533497718 [] .sourceHead = true := by decide
def e862533497774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e862533497774 : Closed e862533497774 ∧ code e862533497774 = 9658626519982 := by decide
theorem cert_e862533497774 : check e862533497774 [] .sourceHead = true := by decide
def e862533497786 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e862533497786 : Closed e862533497786 ∧ code e862533497786 = 9658626519994 := by decide
theorem cert_e862533497786 : check e862533497786 [] .sourceHead = true := by decide
def e862533497814 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e862533497814 : Closed e862533497814 ∧ code e862533497814 = 9658626520022 := by decide
theorem cert_e862533497814 : check e862533497814 [] .sourceHead = true := by decide
def e862533497818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e862533497818 : Closed e862533497818 ∧ code e862533497818 = 9658626520026 := by decide
theorem cert_e862533497818 : check e862533497818 [] .sourceHead = true := by decide
def e862533498094 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862533498094 : Closed e862533498094 ∧ code e862533498094 = 9658626520302 := by decide
theorem cert_e862533498094 : check e862533498094 [] .sourceHead = true := by decide
def e862533498102 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862533498102 : Closed e862533498102 ∧ code e862533498102 = 9658626520310 := by decide
theorem cert_e862533498102 : check e862533498102 [] .sourceHead = true := by decide
def e862533498478 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862533498478 : Closed e862533498478 ∧ code e862533498478 = 9658626520686 := by decide
theorem cert_e862533498478 : check e862533498478 [] .sourceHead = true := by decide
def e862533498490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862533498490 : Closed e862533498490 ∧ code e862533498490 = 9658626520698 := by decide
theorem cert_e862533498490 : check e862533498490 [] .sourceHead = true := by decide
end Blc.Floor43
