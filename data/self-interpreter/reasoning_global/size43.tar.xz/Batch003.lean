import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598192426222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598192426222 : Closed e598192426222 ∧ code e598192426222 = 9394285448430 := by decide
theorem cert_e598192426222 : check e598192426222 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598192426230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598192426230 : Closed e598192426230 ∧ code e598192426230 = 9394285448438 := by decide
theorem cert_e598192426230 : check e598192426230 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598192426606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598192426606 : Closed e598192426606 ∧ code e598192426606 = 9394285448814 := by decide
theorem cert_e598192426606 : check e598192426606 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e598192426618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598192426618 : Closed e598192426618 ∧ code e598192426618 = 9394285448826 := by decide
theorem cert_e598192426618 : check e598192426618 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e598192426806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598192426806 : Closed e598192426806 ∧ code e598192426806 = 9394285449014 := by decide
theorem cert_e598192426806 : check e598192426806 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left]] .chain = true := by decide
def e598192426810 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598192426810 : Closed e598192426810 ∧ code e598192426810 = 9394285449018 := by decide
theorem cert_e598192426810 : check e598192426810 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598393007470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e598393007470 : Closed e598393007470 ∧ code e598393007470 = 9394486029678 := by decide
theorem cert_e598393007470 : check e598393007470 [[.under]] .sourceHead = true := by decide
def e598393007478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e598393007478 : Closed e598393007478 ∧ code e598393007478 = 9394486029686 := by decide
theorem cert_e598393007478 : check e598393007478 [[.under]] .sourceHead = true := by decide
def e598393007534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e598393007534 : Closed e598393007534 ∧ code e598393007534 = 9394486029742 := by decide
theorem cert_e598393007534 : check e598393007534 [[.under]] .sourceHead = true := by decide
def e598393007546 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e598393007546 : Closed e598393007546 ∧ code e598393007546 = 9394486029754 := by decide
theorem cert_e598393007546 : check e598393007546 [[.under]] .sourceHead = true := by decide
def e598393007574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e598393007574 : Closed e598393007574 ∧ code e598393007574 = 9394486029782 := by decide
theorem cert_e598393007574 : check e598393007574 [[.under]] .sourceHead = true := by decide
def e598393007578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e598393007578 : Closed e598393007578 ∧ code e598393007578 = 9394486029786 := by decide
theorem cert_e598393007578 : check e598393007578 [[.under]] .sourceHead = true := by decide
def e598393007790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e598393007790 : Closed e598393007790 ∧ code e598393007790 = 9394486029998 := by decide
theorem cert_e598393007790 : check e598393007790 [[.under]] .sourceHead = true := by decide
def e598393007802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e598393007802 : Closed e598393007802 ∧ code e598393007802 = 9394486030010 := by decide
theorem cert_e598393007802 : check e598393007802 [[.under]] .sourceHead = true := by decide
def e598393007850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e598393007850 : Closed e598393007850 ∧ code e598393007850 = 9394486030058 := by decide
theorem cert_e598393007850 : check e598393007850 [[.under]] .sourceHead = true := by decide
def e598393007958 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e598393007958 : Closed e598393007958 ∧ code e598393007958 = 9394486030166 := by decide
theorem cert_e598393007958 : check e598393007958 [[.under]] .sourceHead = true := by decide
def e598393007962 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e598393007962 : Closed e598393007962 ∧ code e598393007962 = 9394486030170 := by decide
theorem cert_e598393007962 : check e598393007962 [[.under]] .sourceHead = true := by decide
def e598393007978 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e598393007978 : Closed e598393007978 ∧ code e598393007978 = 9394486030186 := by decide
theorem cert_e598393007978 : check e598393007978 [[.under]] .sourceHead = true := by decide
def e598393009006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e598393009006 : Closed e598393009006 ∧ code e598393009006 = 9394486031214 := by decide
theorem cert_e598393009006 : check e598393009006 [[.under]] .sourceHead = true := by decide
def e598393009014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e598393009014 : Closed e598393009014 ∧ code e598393009014 = 9394486031222 := by decide
theorem cert_e598393009014 : check e598393009014 [[.under]] .sourceHead = true := by decide
def e598393009070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e598393009070 : Closed e598393009070 ∧ code e598393009070 = 9394486031278 := by decide
theorem cert_e598393009070 : check e598393009070 [[.under]] .sourceHead = true := by decide
def e598393009082 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e598393009082 : Closed e598393009082 ∧ code e598393009082 = 9394486031290 := by decide
theorem cert_e598393009082 : check e598393009082 [[.under]] .sourceHead = true := by decide
def e598393009110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e598393009110 : Closed e598393009110 ∧ code e598393009110 = 9394486031318 := by decide
theorem cert_e598393009110 : check e598393009110 [[.under]] .sourceHead = true := by decide
def e598393009114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e598393009114 : Closed e598393009114 ∧ code e598393009114 = 9394486031322 := by decide
theorem cert_e598393009114 : check e598393009114 [[.under]] .sourceHead = true := by decide
def e598393009390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598393009390 : Closed e598393009390 ∧ code e598393009390 = 9394486031598 := by decide
theorem cert_e598393009390 : check e598393009390 [[.under]] .sourceHead = true := by decide
def e598393009398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598393009398 : Closed e598393009398 ∧ code e598393009398 = 9394486031606 := by decide
theorem cert_e598393009398 : check e598393009398 [[.under]] .sourceHead = true := by decide
def e598393009774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598393009774 : Closed e598393009774 ∧ code e598393009774 = 9394486031982 := by decide
theorem cert_e598393009774 : check e598393009774 [[.under]] .sourceHead = true := by decide
def e598393009786 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598393009786 : Closed e598393009786 ∧ code e598393009786 = 9394486031994 := by decide
theorem cert_e598393009786 : check e598393009786 [[.under]] .sourceHead = true := by decide
def e598393009974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598393009974 : Closed e598393009974 ∧ code e598393009974 = 9394486032182 := by decide
theorem cert_e598393009974 : check e598393009974 [[.under]] .sourceHead = true := by decide
def e598393009978 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598393009978 : Closed e598393009978 ∧ code e598393009978 = 9394486032186 := by decide
theorem cert_e598393009978 : check e598393009978 [[.under]] .sourceHead = true := by decide
def e598393010606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e598393010606 : Closed e598393010606 ∧ code e598393010606 = 9394486032814 := by decide
theorem cert_e598393010606 : check e598393010606 [[.under]] .sourceHead = true := by decide
def e598393010618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e598393010618 : Closed e598393010618 ∧ code e598393010618 = 9394486032826 := by decide
theorem cert_e598393010618 : check e598393010618 [[.under]] .sourceHead = true := by decide
def e598393010666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e598393010666 : Closed e598393010666 ∧ code e598393010666 = 9394486032874 := by decide
theorem cert_e598393010666 : check e598393010666 [[.under]] .sourceHead = true := by decide
def e598393010798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598393010798 : Closed e598393010798 ∧ code e598393010798 = 9394486033006 := by decide
theorem cert_e598393010798 : check e598393010798 [[.under]] .sourceHead = true := by decide
def e598393010810 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598393010810 : Closed e598393010810 ∧ code e598393010810 = 9394486033018 := by decide
theorem cert_e598393010810 : check e598393010810 [[.under]] .sourceHead = true := by decide
def e598393011098 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598393011098 : Closed e598393011098 ∧ code e598393011098 = 9394486033306 := by decide
theorem cert_e598393011098 : check e598393011098 [[.under]] .sourceHead = true := by decide
def e598393011414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e598393011414 : Closed e598393011414 ∧ code e598393011414 = 9394486033622 := by decide
theorem cert_e598393011414 : check e598393011414 [[.under]] .sourceHead = true := by decide
def e598393011418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e598393011418 : Closed e598393011418 ∧ code e598393011418 = 9394486033626 := by decide
theorem cert_e598393011418 : check e598393011418 [[.under]] .sourceHead = true := by decide
def e598393011434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e598393011434 : Closed e598393011434 ∧ code e598393011434 = 9394486033642 := by decide
theorem cert_e598393011434 : check e598393011434 [[.under]] .sourceHead = true := by decide
def e598393011510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598393011510 : Closed e598393011510 ∧ code e598393011510 = 9394486033718 := by decide
theorem cert_e598393011510 : check e598393011510 [[.under]] .sourceHead = true := by decide
def e598393011514 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598393011514 : Closed e598393011514 ∧ code e598393011514 = 9394486033722 := by decide
theorem cert_e598393011514 : check e598393011514 [[.under]] .sourceHead = true := by decide
def e598393011610 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598393011610 : Closed e598393011610 ∧ code e598393011610 = 9394486033818 := by decide
theorem cert_e598393011610 : check e598393011610 [[.under]] .sourceHead = true := by decide
def e598393015150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598393015150 : Closed e598393015150 ∧ code e598393015150 = 9394486037358 := by decide
theorem cert_e598393015150 : check e598393015150 [[.under]] .sourceHead = true := by decide
def e598393015158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598393015158 : Closed e598393015158 ∧ code e598393015158 = 9394486037366 := by decide
theorem cert_e598393015158 : check e598393015158 [[.under]] .sourceHead = true := by decide
def e598393015214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598393015214 : Closed e598393015214 ∧ code e598393015214 = 9394486037422 := by decide
theorem cert_e598393015214 : check e598393015214 [[.under]] .sourceHead = true := by decide
def e598393015226 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598393015226 : Closed e598393015226 ∧ code e598393015226 = 9394486037434 := by decide
theorem cert_e598393015226 : check e598393015226 [[.under]] .sourceHead = true := by decide
def e598393015254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598393015254 : Closed e598393015254 ∧ code e598393015254 = 9394486037462 := by decide
theorem cert_e598393015254 : check e598393015254 [[.under]] .sourceHead = true := by decide
def e598393015258 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598393015258 : Closed e598393015258 ∧ code e598393015258 = 9394486037466 := by decide
theorem cert_e598393015258 : check e598393015258 [[.under]] .sourceHead = true := by decide
def e598393015534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598393015534 : Closed e598393015534 ∧ code e598393015534 = 9394486037742 := by decide
theorem cert_e598393015534 : check e598393015534 [[.under]] .sourceHead = true := by decide
def e598393015542 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598393015542 : Closed e598393015542 ∧ code e598393015542 = 9394486037750 := by decide
theorem cert_e598393015542 : check e598393015542 [[.under]] .sourceHead = true := by decide
def e598393015918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598393015918 : Closed e598393015918 ∧ code e598393015918 = 9394486038126 := by decide
theorem cert_e598393015918 : check e598393015918 [[.under]] .sourceHead = true := by decide
def e598393015930 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598393015930 : Closed e598393015930 ∧ code e598393015930 = 9394486038138 := by decide
theorem cert_e598393015930 : check e598393015930 [[.under]] .sourceHead = true := by decide
def e598393016118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598393016118 : Closed e598393016118 ∧ code e598393016118 = 9394486038326 := by decide
theorem cert_e598393016118 : check e598393016118 [[.under]] .sourceHead = true := by decide
def e598393016122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598393016122 : Closed e598393016122 ∧ code e598393016122 = 9394486038330 := by decide
theorem cert_e598393016122 : check e598393016122 [[.under]] .sourceHead = true := by decide
def e598393021870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e598393021870 : Closed e598393021870 ∧ code e598393021870 = 9394486044078 := by decide
theorem cert_e598393021870 : check e598393021870 [[.under]] .sourceHead = true := by decide
def e598393021882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e598393021882 : Closed e598393021882 ∧ code e598393021882 = 9394486044090 := by decide
theorem cert_e598393021882 : check e598393021882 [[.under]] .sourceHead = true := by decide
def e598393021930 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e598393021930 : Closed e598393021930 ∧ code e598393021930 = 9394486044138 := by decide
theorem cert_e598393021930 : check e598393021930 [[.under]] .sourceHead = true := by decide
def e598393022062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e598393022062 : Closed e598393022062 ∧ code e598393022062 = 9394486044270 := by decide
theorem cert_e598393022062 : check e598393022062 [[.under]] .sourceHead = true := by decide
def e598393022074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e598393022074 : Closed e598393022074 ∧ code e598393022074 = 9394486044282 := by decide
theorem cert_e598393022074 : check e598393022074 [[.under]] .sourceHead = true := by decide
def e598393022362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e598393022362 : Closed e598393022362 ∧ code e598393022362 = 9394486044570 := by decide
theorem cert_e598393022362 : check e598393022362 [[.under]] .sourceHead = true := by decide
def e598393025238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e598393025238 : Closed e598393025238 ∧ code e598393025238 = 9394486047446 := by decide
theorem cert_e598393025238 : check e598393025238 [[.under]] .sourceHead = true := by decide
def e598393025242 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e598393025242 : Closed e598393025242 ∧ code e598393025242 = 9394486047450 := by decide
theorem cert_e598393025242 : check e598393025242 [[.under]] .sourceHead = true := by decide
def e598393025258 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e598393025258 : Closed e598393025258 ∧ code e598393025258 = 9394486047466 := by decide
theorem cert_e598393025258 : check e598393025258 [[.under]] .sourceHead = true := by decide
def e598393025334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e598393025334 : Closed e598393025334 ∧ code e598393025334 = 9394486047542 := by decide
theorem cert_e598393025334 : check e598393025334 [[.under]] .sourceHead = true := by decide
def e598393025338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e598393025338 : Closed e598393025338 ∧ code e598393025338 = 9394486047546 := by decide
theorem cert_e598393025338 : check e598393025338 [[.under]] .sourceHead = true := by decide
def e598393025434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e598393025434 : Closed e598393025434 ∧ code e598393025434 = 9394486047642 := by decide
theorem cert_e598393025434 : check e598393025434 [[.under]] .sourceHead = true := by decide
def e598393162606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598393162606 : Closed e598393162606 ∧ code e598393162606 = 9394486184814 := by decide
theorem cert_e598393162606 : check e598393162606 [[.under]] .sourceHead = true := by decide
def e598393162614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598393162614 : Closed e598393162614 ∧ code e598393162614 = 9394486184822 := by decide
theorem cert_e598393162614 : check e598393162614 [[.under]] .sourceHead = true := by decide
def e598393162670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598393162670 : Closed e598393162670 ∧ code e598393162670 = 9394486184878 := by decide
theorem cert_e598393162670 : check e598393162670 [[.under]] .sourceHead = true := by decide
def e598393162682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598393162682 : Closed e598393162682 ∧ code e598393162682 = 9394486184890 := by decide
theorem cert_e598393162682 : check e598393162682 [[.under]] .sourceHead = true := by decide
def e598393162710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598393162710 : Closed e598393162710 ∧ code e598393162710 = 9394486184918 := by decide
theorem cert_e598393162710 : check e598393162710 [[.under]] .sourceHead = true := by decide
def e598393162714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598393162714 : Closed e598393162714 ∧ code e598393162714 = 9394486184922 := by decide
theorem cert_e598393162714 : check e598393162714 [[.under]] .sourceHead = true := by decide
def e598393162990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598393162990 : Closed e598393162990 ∧ code e598393162990 = 9394486185198 := by decide
theorem cert_e598393162990 : check e598393162990 [[.under]] .sourceHead = true := by decide
def e598393162998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598393162998 : Closed e598393162998 ∧ code e598393162998 = 9394486185206 := by decide
theorem cert_e598393162998 : check e598393162998 [[.under]] .sourceHead = true := by decide
def e598393163374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598393163374 : Closed e598393163374 ∧ code e598393163374 = 9394486185582 := by decide
theorem cert_e598393163374 : check e598393163374 [[.under]] .sourceHead = true := by decide
def e598393163386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598393163386 : Closed e598393163386 ∧ code e598393163386 = 9394486185594 := by decide
theorem cert_e598393163386 : check e598393163386 [[.under]] .sourceHead = true := by decide
def e598393163574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598393163574 : Closed e598393163574 ∧ code e598393163574 = 9394486185782 := by decide
theorem cert_e598393163574 : check e598393163574 [[.under]] .sourceHead = true := by decide
def e598393163578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598393163578 : Closed e598393163578 ∧ code e598393163578 = 9394486185786 := by decide
theorem cert_e598393163578 : check e598393163578 [[.under]] .sourceHead = true := by decide
def e598393752430 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598393752430 : Closed e598393752430 ∧ code e598393752430 = 9394486774638 := by decide
theorem cert_e598393752430 : check e598393752430 [[.under]] .sourceHead = true := by decide
def e598393752438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598393752438 : Closed e598393752438 ∧ code e598393752438 = 9394486774646 := by decide
theorem cert_e598393752438 : check e598393752438 [[.under]] .sourceHead = true := by decide
def e598393752494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598393752494 : Closed e598393752494 ∧ code e598393752494 = 9394486774702 := by decide
theorem cert_e598393752494 : check e598393752494 [[.under]] .sourceHead = true := by decide
def e598393752506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598393752506 : Closed e598393752506 ∧ code e598393752506 = 9394486774714 := by decide
theorem cert_e598393752506 : check e598393752506 [[.under]] .sourceHead = true := by decide
def e598393752534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598393752534 : Closed e598393752534 ∧ code e598393752534 = 9394486774742 := by decide
theorem cert_e598393752534 : check e598393752534 [[.under]] .sourceHead = true := by decide
def e598393752538 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598393752538 : Closed e598393752538 ∧ code e598393752538 = 9394486774746 := by decide
theorem cert_e598393752538 : check e598393752538 [[.under]] .sourceHead = true := by decide
def e598393752814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598393752814 : Closed e598393752814 ∧ code e598393752814 = 9394486775022 := by decide
theorem cert_e598393752814 : check e598393752814 [[.under]] .sourceHead = true := by decide
def e598393752822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598393752822 : Closed e598393752822 ∧ code e598393752822 = 9394486775030 := by decide
theorem cert_e598393752822 : check e598393752822 [[.under]] .sourceHead = true := by decide
def e598393753198 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598393753198 : Closed e598393753198 ∧ code e598393753198 = 9394486775406 := by decide
theorem cert_e598393753198 : check e598393753198 [[.under]] .sourceHead = true := by decide
def e598393753210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598393753210 : Closed e598393753210 ∧ code e598393753210 = 9394486775418 := by decide
theorem cert_e598393753210 : check e598393753210 [[.under]] .sourceHead = true := by decide
def e598393753398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598393753398 : Closed e598393753398 ∧ code e598393753398 = 9394486775606 := by decide
theorem cert_e598393753398 : check e598393753398 [[.under]] .sourceHead = true := by decide
def e598393753402 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598393753402 : Closed e598393753402 ∧ code e598393753402 = 9394486775610 := by decide
theorem cert_e598393753402 : check e598393753402 [[.under]] .sourceHead = true := by decide
def e598476937950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e598476937950 : Closed e598476937950 ∧ code e598476937950 = 9394569960158 := by decide
theorem cert_e598476937950 : check e598476937950 [[.under],[.under,.left]] .chain = true := by decide
def e598476937974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e598476937974 : Closed e598476937974 ∧ code e598476937974 = 9394569960182 := by decide
theorem cert_e598476937974 : check e598476937974 [[.under],[.under,.left]] .chain = true := by decide
def e598476938078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e598476938078 : Closed e598476938078 ∧ code e598476938078 = 9394569960286 := by decide
theorem cert_e598476938078 : check e598476938078 [[.under],[.under,.left]] .chain = true := by decide
def e598476938094 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e598476938094 : Closed e598476938094 ∧ code e598476938094 = 9394569960302 := by decide
theorem cert_e598476938094 : check e598476938094 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e598476938102 : Closed e598476938102 ∧ code e598476938102 = 9394569960310 := by decide
theorem cert_e598476938102 : check e598476938102 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938106 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e598476938106 : Closed e598476938106 ∧ code e598476938106 = 9394569960314 := by decide
theorem cert_e598476938106 : check e598476938106 [[.under],[.under,.left]] .chain = true := by decide
def e598476938166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e598476938166 : Closed e598476938166 ∧ code e598476938166 = 9394569960374 := by decide
theorem cert_e598476938166 : check e598476938166 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938198 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e598476938198 : Closed e598476938198 ∧ code e598476938198 = 9394569960406 := by decide
theorem cert_e598476938198 : check e598476938198 [[.under],[.under,.left]] .chain = true := by decide
def e598476938202 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e598476938202 : Closed e598476938202 ∧ code e598476938202 = 9394569960410 := by decide
theorem cert_e598476938202 : check e598476938202 [[.under],[.under,.left]] .chain = true := by decide
def e598476938590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e598476938590 : Closed e598476938590 ∧ code e598476938590 = 9394569960798 := by decide
theorem cert_e598476938590 : check e598476938590 [[.under],[.under,.left]] .chain = true := by decide
def e598476938606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e598476938606 : Closed e598476938606 ∧ code e598476938606 = 9394569960814 := by decide
theorem cert_e598476938606 : check e598476938606 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e598476938614 : Closed e598476938614 ∧ code e598476938614 = 9394569960822 := by decide
theorem cert_e598476938614 : check e598476938614 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e598476938618 : Closed e598476938618 ∧ code e598476938618 = 9394569960826 := by decide
theorem cert_e598476938618 : check e598476938618 [[.under],[.under,.left]] .chain = true := by decide
def e598476938670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e598476938670 : Closed e598476938670 ∧ code e598476938670 = 9394569960878 := by decide
theorem cert_e598476938670 : check e598476938670 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e598476938682 : Closed e598476938682 ∧ code e598476938682 = 9394569960890 := by decide
theorem cert_e598476938682 : check e598476938682 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e598476938710 : Closed e598476938710 ∧ code e598476938710 = 9394569960918 := by decide
theorem cert_e598476938710 : check e598476938710 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e598476938714 : Closed e598476938714 ∧ code e598476938714 = 9394569960922 := by decide
theorem cert_e598476938714 : check e598476938714 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e598476938730 : Closed e598476938730 ∧ code e598476938730 = 9394569960938 := by decide
theorem cert_e598476938730 : check e598476938730 [[.under],[.under,.left]] .chain = true := by decide
def e598476938934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e598476938934 : Closed e598476938934 ∧ code e598476938934 = 9394569961142 := by decide
theorem cert_e598476938934 : check e598476938934 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e598476938966 : Closed e598476938966 ∧ code e598476938966 = 9394569961174 := by decide
theorem cert_e598476938966 : check e598476938966 [[.under],[.under,.left]] .smaller = true := by decide
def e598476938970 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e598476938970 : Closed e598476938970 ∧ code e598476938970 = 9394569961178 := by decide
theorem cert_e598476938970 : check e598476938970 [[.under],[.under,.left]] .smaller = true := by decide
def e598476939094 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e598476939094 : Closed e598476939094 ∧ code e598476939094 = 9394569961302 := by decide
theorem cert_e598476939094 : check e598476939094 [[.under],[.under,.left]] .chain = true := by decide
def e598476939098 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e598476939098 : Closed e598476939098 ∧ code e598476939098 = 9394569961306 := by decide
theorem cert_e598476939098 : check e598476939098 [[.under],[.under,.left]] .chain = true := by decide
def e598476939114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e598476939114 : Closed e598476939114 ∧ code e598476939114 = 9394569961322 := by decide
theorem cert_e598476939114 : check e598476939114 [[.under],[.under,.left]] .chain = true := by decide
def e598476941022 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e598476941022 : Closed e598476941022 ∧ code e598476941022 = 9394569963230 := by decide
theorem cert_e598476941022 : check e598476941022 [[.under],[.under,.left]] .chain = true := by decide
def e598476941046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e598476941046 : Closed e598476941046 ∧ code e598476941046 = 9394569963254 := by decide
theorem cert_e598476941046 : check e598476941046 [[.under],[.under,.left]] .chain = true := by decide
def e598476941150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e598476941150 : Closed e598476941150 ∧ code e598476941150 = 9394569963358 := by decide
theorem cert_e598476941150 : check e598476941150 [[.under],[.under,.left]] .chain = true := by decide
def e598476941166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e598476941166 : Closed e598476941166 ∧ code e598476941166 = 9394569963374 := by decide
theorem cert_e598476941166 : check e598476941166 [[.under],[.under,.left]] .smaller = true := by decide
def e598476941174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e598476941174 : Closed e598476941174 ∧ code e598476941174 = 9394569963382 := by decide
theorem cert_e598476941174 : check e598476941174 [[.under],[.under,.left]] .smaller = true := by decide
def e598476941178 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e598476941178 : Closed e598476941178 ∧ code e598476941178 = 9394569963386 := by decide
theorem cert_e598476941178 : check e598476941178 [[.under],[.under,.left]] .chain = true := by decide
def e598476941238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e598476941238 : Closed e598476941238 ∧ code e598476941238 = 9394569963446 := by decide
theorem cert_e598476941238 : check e598476941238 [[.under],[.under,.left]] .smaller = true := by decide
def e598476941270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e598476941270 : Closed e598476941270 ∧ code e598476941270 = 9394569963478 := by decide
theorem cert_e598476941270 : check e598476941270 [[.under],[.under,.left]] .chain = true := by decide
def e598476941274 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e598476941274 : Closed e598476941274 ∧ code e598476941274 = 9394569963482 := by decide
theorem cert_e598476941274 : check e598476941274 [[.under],[.under,.left]] .chain = true := by decide
def e598476941790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e598476941790 : Closed e598476941790 ∧ code e598476941790 = 9394569963998 := by decide
theorem cert_e598476941790 : check e598476941790 [[.under],[.under,.left]] .chain = true := by decide
def e598476941814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e598476941814 : Closed e598476941814 ∧ code e598476941814 = 9394569964022 := by decide
theorem cert_e598476941814 : check e598476941814 [[.under],[.under,.left]] .chain = true := by decide
def e598476942558 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e598476942558 : Closed e598476942558 ∧ code e598476942558 = 9394569964766 := by decide
theorem cert_e598476942558 : check e598476942558 [[.under],[.under,.left]] .chain = true := by decide
def e598476942574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598476942574 : Closed e598476942574 ∧ code e598476942574 = 9394569964782 := by decide
theorem cert_e598476942574 : check e598476942574 [[.under],[.under,.left]] .smaller = true := by decide
def e598476942582 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598476942582 : Closed e598476942582 ∧ code e598476942582 = 9394569964790 := by decide
theorem cert_e598476942582 : check e598476942582 [[.under],[.under,.left]] .smaller = true := by decide
def e598476942586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e598476942586 : Closed e598476942586 ∧ code e598476942586 = 9394569964794 := by decide
theorem cert_e598476942586 : check e598476942586 [[.under],[.under,.left]] .chain = true := by decide
def e598476942966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e598476942966 : Closed e598476942966 ∧ code e598476942966 = 9394569965174 := by decide
theorem cert_e598476942966 : check e598476942966 [[.under],[.under,.left]] .smaller = true := by decide
def e598476943158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598476943158 : Closed e598476943158 ∧ code e598476943158 = 9394569965366 := by decide
theorem cert_e598476943158 : check e598476943158 [[.under],[.under,.left]] .chain = true := by decide
def e598476943162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598476943162 : Closed e598476943162 ∧ code e598476943162 = 9394569965370 := by decide
theorem cert_e598476943162 : check e598476943162 [[.under],[.under,.left]] .chain = true := by decide
def e598476944222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e598476944222 : Closed e598476944222 ∧ code e598476944222 = 9394569966430 := by decide
theorem cert_e598476944222 : check e598476944222 [[.under],[.under,.left]] .chain = true := by decide
def e598476944238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e598476944238 : Closed e598476944238 ∧ code e598476944238 = 9394569966446 := by decide
theorem cert_e598476944238 : check e598476944238 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e598476944246 : Closed e598476944246 ∧ code e598476944246 = 9394569966454 := by decide
theorem cert_e598476944246 : check e598476944246 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944250 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e598476944250 : Closed e598476944250 ∧ code e598476944250 = 9394569966458 := by decide
theorem cert_e598476944250 : check e598476944250 [[.under],[.under,.left]] .chain = true := by decide
def e598476944302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e598476944302 : Closed e598476944302 ∧ code e598476944302 = 9394569966510 := by decide
theorem cert_e598476944302 : check e598476944302 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e598476944314 : Closed e598476944314 ∧ code e598476944314 = 9394569966522 := by decide
theorem cert_e598476944314 : check e598476944314 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e598476944342 : Closed e598476944342 ∧ code e598476944342 = 9394569966550 := by decide
theorem cert_e598476944342 : check e598476944342 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944346 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e598476944346 : Closed e598476944346 ∧ code e598476944346 = 9394569966554 := by decide
theorem cert_e598476944346 : check e598476944346 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e598476944362 : Closed e598476944362 ∧ code e598476944362 = 9394569966570 := by decide
theorem cert_e598476944362 : check e598476944362 [[.under],[.under,.left]] .chain = true := by decide
def e598476944606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e598476944606 : Closed e598476944606 ∧ code e598476944606 = 9394569966814 := by decide
theorem cert_e598476944606 : check e598476944606 [[.under],[.under,.left]] .chain = true := by decide
def e598476944622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e598476944622 : Closed e598476944622 ∧ code e598476944622 = 9394569966830 := by decide
theorem cert_e598476944622 : check e598476944622 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e598476944630 : Closed e598476944630 ∧ code e598476944630 = 9394569966838 := by decide
theorem cert_e598476944630 : check e598476944630 [[.under],[.under,.left]] .smaller = true := by decide
def e598476944634 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e598476944634 : Closed e598476944634 ∧ code e598476944634 = 9394569966842 := by decide
theorem cert_e598476944634 : check e598476944634 [[.under],[.under,.left]] .chain = true := by decide
def e598476945006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e598476945006 : Closed e598476945006 ∧ code e598476945006 = 9394569967214 := by decide
theorem cert_e598476945006 : check e598476945006 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e598476945018 : Closed e598476945018 ∧ code e598476945018 = 9394569967226 := by decide
theorem cert_e598476945018 : check e598476945018 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598476945206 : Closed e598476945206 ∧ code e598476945206 = 9394569967414 := by decide
theorem cert_e598476945206 : check e598476945206 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598476945210 : Closed e598476945210 ∧ code e598476945210 = 9394569967418 := by decide
theorem cert_e598476945210 : check e598476945210 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e598476945306 : Closed e598476945306 ∧ code e598476945306 = 9394569967514 := by decide
theorem cert_e598476945306 : check e598476945306 [[.under],[.under,.left]] .chain = true := by decide
def e598476945846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e598476945846 : Closed e598476945846 ∧ code e598476945846 = 9394569968054 := by decide
theorem cert_e598476945846 : check e598476945846 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e598476945878 : Closed e598476945878 ∧ code e598476945878 = 9394569968086 := by decide
theorem cert_e598476945878 : check e598476945878 [[.under],[.under,.left]] .smaller = true := by decide
def e598476945882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e598476945882 : Closed e598476945882 ∧ code e598476945882 = 9394569968090 := by decide
theorem cert_e598476945882 : check e598476945882 [[.under],[.under,.left]] .smaller = true := by decide
def e598476946038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e598476946038 : Closed e598476946038 ∧ code e598476946038 = 9394569968246 := by decide
theorem cert_e598476946038 : check e598476946038 [[.under],[.under,.left]] .smaller = true := by decide
def e598476946230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598476946230 : Closed e598476946230 ∧ code e598476946230 = 9394569968438 := by decide
theorem cert_e598476946230 : check e598476946230 [[.under],[.under,.left]] .smaller = true := by decide
def e598476946234 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e598476946234 : Closed e598476946234 ∧ code e598476946234 = 9394569968442 := by decide
theorem cert_e598476946234 : check e598476946234 [[.under],[.under,.left]] .smaller = true := by decide
def e598476946646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e598476946646 : Closed e598476946646 ∧ code e598476946646 = 9394569968854 := by decide
theorem cert_e598476946646 : check e598476946646 [[.under],[.under,.left]] .chain = true := by decide
def e598476946650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e598476946650 : Closed e598476946650 ∧ code e598476946650 = 9394569968858 := by decide
theorem cert_e598476946650 : check e598476946650 [[.under],[.under,.left]] .chain = true := by decide
def e598476946666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e598476946666 : Closed e598476946666 ∧ code e598476946666 = 9394569968874 := by decide
theorem cert_e598476946666 : check e598476946666 [[.under],[.under,.left]] .chain = true := by decide
def e598476946742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e598476946742 : Closed e598476946742 ∧ code e598476946742 = 9394569968950 := by decide
theorem cert_e598476946742 : check e598476946742 [[.under],[.under,.left]] .chain = true := by decide
end Blc.Floor43
