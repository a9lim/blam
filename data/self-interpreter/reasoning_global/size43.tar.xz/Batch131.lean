import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2212930389602 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2212930389602 : Closed e2212930389602 ∧ code e2212930389602 = 11009023411810 := by decide
theorem cert_e2212930389602 : check e2212930389602 [[]] .width = true := by decide
def e2212930389622 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2212930389622 : Closed e2212930389622 ∧ code e2212930389622 = 11009023411830 := by decide
theorem cert_e2212930389622 : check e2212930389622 [[]] .width = true := by decide
def e2212930389814 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2212930389814 : Closed e2212930389814 ∧ code e2212930389814 = 11009023412022 := by decide
theorem cert_e2212930389814 : check e2212930389814 [[]] .width = true := by decide
def e2212930389818 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2212930389818 : Closed e2212930389818 ∧ code e2212930389818 = 11009023412026 := by decide
theorem cert_e2212930389818 : check e2212930389818 [[]] .width = true := by decide
def e2212930393514 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2212930393514 : Closed e2212930393514 ∧ code e2212930393514 = 11009023415722 := by decide
theorem cert_e2212930393514 : check e2212930393514 [[]] .width = true := by decide
def e2212930393610 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2212930393610 : Closed e2212930393610 ∧ code e2212930393610 = 11009023415818 := by decide
theorem cert_e2212930393610 : check e2212930393610 [[]] .width = true := by decide
def e2212930393706 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2212930393706 : Closed e2212930393706 ∧ code e2212930393706 = 11009023415914 := by decide
theorem cert_e2212930393706 : check e2212930393706 [[]] .width = true := by decide
def e2212930393730 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2212930393730 : Closed e2212930393730 ∧ code e2212930393730 = 11009023415938 := by decide
theorem cert_e2212930393730 : check e2212930393730 [[]] .width = true := by decide
def e2212930393754 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2212930393754 : Closed e2212930393754 ∧ code e2212930393754 = 11009023415962 := by decide
theorem cert_e2212930393754 : check e2212930393754 [[]] .width = true := by decide
def e2212930394138 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212930394138 : Closed e2212930394138 ∧ code e2212930394138 = 11009023416346 := by decide
theorem cert_e2212930394138 : check e2212930394138 [[]] .width = true := by decide
def e2212930394230 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2212930394230 : Closed e2212930394230 ∧ code e2212930394230 = 11009023416438 := by decide
theorem cert_e2212930394230 : check e2212930394230 [[]] .width = true := by decide
def e2212930394474 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2212930394474 : Closed e2212930394474 ∧ code e2212930394474 = 11009023416682 := by decide
theorem cert_e2212930394474 : check e2212930394474 [[]] .width = true := by decide
def e2212930394498 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2212930394498 : Closed e2212930394498 ∧ code e2212930394498 = 11009023416706 := by decide
theorem cert_e2212930394498 : check e2212930394498 [[]] .width = true := by decide
def e2212930394522 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2212930394522 : Closed e2212930394522 ∧ code e2212930394522 = 11009023416730 := by decide
theorem cert_e2212930394522 : check e2212930394522 [[]] .width = true := by decide
def e2212930633926 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2212930633926 : Closed e2212930633926 ∧ code e2212930633926 = 11009023656134 := by decide
theorem cert_e2212930633926 : check e2212930633926 [[]] .width = true := by decide
def e2212930740250 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212930740250 : Closed e2212930740250 ∧ code e2212930740250 = 11009023762458 := by decide
theorem cert_e2212930740250 : check e2212930740250 [[]] .width = true := by decide
def e2212930740342 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212930740342 : Closed e2212930740342 ∧ code e2212930740342 = 11009023762550 := by decide
theorem cert_e2212930740342 : check e2212930740342 [[]] .width = true := by decide
def e2212930740586 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212930740586 : Closed e2212930740586 ∧ code e2212930740586 = 11009023762794 := by decide
theorem cert_e2212930740586 : check e2212930740586 [[]] .width = true := by decide
def e2212930740634 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212930740634 : Closed e2212930740634 ∧ code e2212930740634 = 11009023762842 := by decide
theorem cert_e2212930740634 : check e2212930740634 [[]] .width = true := by decide
def e2212930756634 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2212930756634 : Closed e2212930756634 ∧ code e2212930756634 = 11009023778842 := by decide
theorem cert_e2212930756634 : check e2212930756634 [[]] .width = true := by decide
def e2212930756726 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2212930756726 : Closed e2212930756726 ∧ code e2212930756726 = 11009023778934 := by decide
theorem cert_e2212930756726 : check e2212930756726 [[]] .width = true := by decide
def e2212930756970 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2212930756970 : Closed e2212930756970 ∧ code e2212930756970 = 11009023779178 := by decide
theorem cert_e2212930756970 : check e2212930756970 [[]] .width = true := by decide
def e2212930757018 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2212930757018 : Closed e2212930757018 ∧ code e2212930757018 = 11009023779226 := by decide
theorem cert_e2212930757018 : check e2212930757018 [[]] .width = true := by decide
def e2212930762778 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212930762778 : Closed e2212930762778 ∧ code e2212930762778 = 11009023784986 := by decide
theorem cert_e2212930762778 : check e2212930762778 [[]] .width = true := by decide
def e2212930770970 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2212930770970 : Closed e2212930770970 ∧ code e2212930770970 = 11009023793178 := by decide
theorem cert_e2212930770970 : check e2212930770970 [[]] .width = true := by decide
def e2212930912282 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2212930912282 : Closed e2212930912282 ∧ code e2212930912282 = 11009023934490 := by decide
theorem cert_e2212930912282 : check e2212930912282 [[]] .width = true := by decide
def e2212930912374 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2212930912374 : Closed e2212930912374 ∧ code e2212930912374 = 11009023934582 := by decide
theorem cert_e2212930912374 : check e2212930912374 [[]] .width = true := by decide
def e2212930912618 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2212930912618 : Closed e2212930912618 ∧ code e2212930912618 = 11009023934826 := by decide
theorem cert_e2212930912618 : check e2212930912618 [[]] .width = true := by decide
def e2212930912666 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2212930912666 : Closed e2212930912666 ∧ code e2212930912666 = 11009023934874 := by decide
theorem cert_e2212930912666 : check e2212930912666 [[]] .width = true := by decide
def e2212930912750 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2212930912750 : Closed e2212930912750 ∧ code e2212930912750 = 11009023934958 := by decide
theorem cert_e2212930912750 : check e2212930912750 [[]] .width = true := by decide
def e2212930913674 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2212930913674 : Closed e2212930913674 ∧ code e2212930913674 = 11009023935882 := by decide
theorem cert_e2212930913674 : check e2212930913674 [[]] .width = true := by decide
def e2212930913698 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2212930913698 : Closed e2212930913698 ∧ code e2212930913698 = 11009023935906 := by decide
theorem cert_e2212930913698 : check e2212930913698 [[]] .width = true := by decide
def e2212930913718 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2212930913718 : Closed e2212930913718 ∧ code e2212930913718 = 11009023935926 := by decide
theorem cert_e2212930913718 : check e2212930913718 [[]] .width = true := by decide
def e2212930913750 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2212930913750 : Closed e2212930913750 ∧ code e2212930913750 = 11009023935958 := by decide
theorem cert_e2212930913750 : check e2212930913750 [[]] .width = true := by decide
def e2212930913754 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2212930913754 : Closed e2212930913754 ∧ code e2212930913754 = 11009023935962 := by decide
theorem cert_e2212930913754 : check e2212930913754 [[]] .width = true := by decide
def e2212930913806 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2212930913806 : Closed e2212930913806 ∧ code e2212930913806 = 11009023936014 := by decide
theorem cert_e2212930913806 : check e2212930913806 [[]] .width = true := by decide
def e2212930913818 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212930913818 : Closed e2212930913818 ∧ code e2212930913818 = 11009023936026 := by decide
theorem cert_e2212930913818 : check e2212930913818 [[]] .width = true := by decide
def e2212930913890 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2212930913890 : Closed e2212930913890 ∧ code e2212930913890 = 11009023936098 := by decide
theorem cert_e2212930913890 : check e2212930913890 [[]] .width = true := by decide
def e2212930913910 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2212930913910 : Closed e2212930913910 ∧ code e2212930913910 = 11009023936118 := by decide
theorem cert_e2212930913910 : check e2212930913910 [[]] .width = true := by decide
def e2212930914102 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2212930914102 : Closed e2212930914102 ∧ code e2212930914102 = 11009023936310 := by decide
theorem cert_e2212930914102 : check e2212930914102 [[]] .width = true := by decide
def e2212930914106 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2212930914106 : Closed e2212930914106 ∧ code e2212930914106 = 11009023936314 := by decide
theorem cert_e2212930914106 : check e2212930914106 [[]] .width = true := by decide
def e2212930917802 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2212930917802 : Closed e2212930917802 ∧ code e2212930917802 = 11009023940010 := by decide
theorem cert_e2212930917802 : check e2212930917802 [[]] .width = true := by decide
def e2212930917898 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2212930917898 : Closed e2212930917898 ∧ code e2212930917898 = 11009023940106 := by decide
theorem cert_e2212930917898 : check e2212930917898 [[]] .width = true := by decide
def e2212930917994 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2212930917994 : Closed e2212930917994 ∧ code e2212930917994 = 11009023940202 := by decide
theorem cert_e2212930917994 : check e2212930917994 [[]] .width = true := by decide
def e2212930918018 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2212930918018 : Closed e2212930918018 ∧ code e2212930918018 = 11009023940226 := by decide
theorem cert_e2212930918018 : check e2212930918018 [[]] .width = true := by decide
def e2212930918042 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2212930918042 : Closed e2212930918042 ∧ code e2212930918042 = 11009023940250 := by decide
theorem cert_e2212930918042 : check e2212930918042 [[]] .width = true := by decide
def e2212930918426 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2212930918426 : Closed e2212930918426 ∧ code e2212930918426 = 11009023940634 := by decide
theorem cert_e2212930918426 : check e2212930918426 [[]] .width = true := by decide
def e2212930918518 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2212930918518 : Closed e2212930918518 ∧ code e2212930918518 = 11009023940726 := by decide
theorem cert_e2212930918518 : check e2212930918518 [[]] .width = true := by decide
def e2212930918762 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2212930918762 : Closed e2212930918762 ∧ code e2212930918762 = 11009023940970 := by decide
theorem cert_e2212930918762 : check e2212930918762 [[]] .width = true := by decide
def e2212930918786 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2212930918786 : Closed e2212930918786 ∧ code e2212930918786 = 11009023940994 := by decide
theorem cert_e2212930918786 : check e2212930918786 [[]] .width = true := by decide
def e2212930918810 : Term := (.app (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2212930918810 : Closed e2212930918810 ∧ code e2212930918810 = 11009023941018 := by decide
theorem cert_e2212930918810 : check e2212930918810 [[]] .width = true := by decide
def e2214419423258 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214419423258 : Closed e2214419423258 ∧ code e2214419423258 = 11010512445466 := by decide
theorem cert_e2214419423258 : check e2214419423258 [[]] .width = true := by decide
def e2214419423350 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214419423350 : Closed e2214419423350 ∧ code e2214419423350 = 11010512445558 := by decide
theorem cert_e2214419423350 : check e2214419423350 [[]] .width = true := by decide
def e2214419423594 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214419423594 : Closed e2214419423594 ∧ code e2214419423594 = 11010512445802 := by decide
theorem cert_e2214419423594 : check e2214419423594 [[]] .width = true := by decide
def e2214419423642 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214419423642 : Closed e2214419423642 ∧ code e2214419423642 = 11010512445850 := by decide
theorem cert_e2214419423642 : check e2214419423642 [[]] .width = true := by decide
def e2214420209690 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214420209690 : Closed e2214420209690 ∧ code e2214420209690 = 11010513231898 := by decide
theorem cert_e2214420209690 : check e2214420209690 [[]] .width = true := by decide
def e2214420209782 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214420209782 : Closed e2214420209782 ∧ code e2214420209782 = 11010513231990 := by decide
theorem cert_e2214420209782 : check e2214420209782 [[]] .width = true := by decide
def e2214420210026 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214420210026 : Closed e2214420210026 ∧ code e2214420210026 = 11010513232234 := by decide
theorem cert_e2214420210026 : check e2214420210026 [[]] .width = true := by decide
def e2214420210074 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214420210074 : Closed e2214420210074 ∧ code e2214420210074 = 11010513232282 := by decide
theorem cert_e2214420210074 : check e2214420210074 [[]] .width = true := by decide
def e2214420258842 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214420258842 : Closed e2214420258842 ∧ code e2214420258842 = 11010513281050 := by decide
theorem cert_e2214420258842 : check e2214420258842 [[]] .width = true := by decide
def e2214420258934 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214420258934 : Closed e2214420258934 ∧ code e2214420258934 = 11010513281142 := by decide
theorem cert_e2214420258934 : check e2214420258934 [[]] .width = true := by decide
def e2214420259178 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214420259178 : Closed e2214420259178 ∧ code e2214420259178 = 11010513281386 := by decide
theorem cert_e2214420259178 : check e2214420259178 [[]] .width = true := by decide
def e2214420259226 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214420259226 : Closed e2214420259226 ∧ code e2214420259226 = 11010513281434 := by decide
theorem cert_e2214420259226 : check e2214420259226 [[]] .width = true := by decide
def e2214420264986 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214420264986 : Closed e2214420264986 ∧ code e2214420264986 = 11010513287194 := by decide
theorem cert_e2214420264986 : check e2214420264986 [[]] .width = true := by decide
def e2214423355418 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214423355418 : Closed e2214423355418 ∧ code e2214423355418 = 11010516377626 := by decide
theorem cert_e2214423355418 : check e2214423355418 [[]] .width = true := by decide
def e2214423355510 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214423355510 : Closed e2214423355510 ∧ code e2214423355510 = 11010516377718 := by decide
theorem cert_e2214423355510 : check e2214423355510 [[]] .width = true := by decide
def e2214423355754 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214423355754 : Closed e2214423355754 ∧ code e2214423355754 = 11010516377962 := by decide
theorem cert_e2214423355754 : check e2214423355754 [[]] .width = true := by decide
def e2214423355802 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214423355802 : Closed e2214423355802 ∧ code e2214423355802 = 11010516378010 := by decide
theorem cert_e2214423355802 : check e2214423355802 [[]] .width = true := by decide
def e2214423404570 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214423404570 : Closed e2214423404570 ∧ code e2214423404570 = 11010516426778 := by decide
theorem cert_e2214423404570 : check e2214423404570 [[]] .width = true := by decide
def e2214423404662 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214423404662 : Closed e2214423404662 ∧ code e2214423404662 = 11010516426870 := by decide
theorem cert_e2214423404662 : check e2214423404662 [[]] .width = true := by decide
def e2214423404906 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214423404906 : Closed e2214423404906 ∧ code e2214423404906 = 11010516427114 := by decide
theorem cert_e2214423404906 : check e2214423404906 [[]] .width = true := by decide
def e2214423404954 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214423404954 : Closed e2214423404954 ∧ code e2214423404954 = 11010516427162 := by decide
theorem cert_e2214423404954 : check e2214423404954 [[]] .width = true := by decide
def e2214423410714 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214423410714 : Closed e2214423410714 ∧ code e2214423410714 = 11010516432922 := by decide
theorem cert_e2214423410714 : check e2214423410714 [[]] .width = true := by decide
def e2214423601178 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214423601178 : Closed e2214423601178 ∧ code e2214423601178 = 11010516623386 := by decide
theorem cert_e2214423601178 : check e2214423601178 [[]] .width = true := by decide
def e2214423601270 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214423601270 : Closed e2214423601270 ∧ code e2214423601270 = 11010516623478 := by decide
theorem cert_e2214423601270 : check e2214423601270 [[]] .width = true := by decide
def e2214423601514 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214423601514 : Closed e2214423601514 ∧ code e2214423601514 = 11010516623722 := by decide
theorem cert_e2214423601514 : check e2214423601514 [[]] .width = true := by decide
def e2214423601562 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214423601562 : Closed e2214423601562 ∧ code e2214423601562 = 11010516623770 := by decide
theorem cert_e2214423601562 : check e2214423601562 [[]] .width = true := by decide
def e2214423607322 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214423607322 : Closed e2214423607322 ∧ code e2214423607322 = 11010516629530 := by decide
theorem cert_e2214423607322 : check e2214423607322 [[]] .width = true := by decide
def e2214423619610 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214423619610 : Closed e2214423619610 ∧ code e2214423619610 = 11010516641818 := by decide
theorem cert_e2214423619610 : check e2214423619610 [[]] .width = true := by decide
def e2214428786886 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214428786886 : Closed e2214428786886 ∧ code e2214428786886 = 11010521809094 := by decide
theorem cert_e2214428786886 : check e2214428786886 [[]] .width = true := by decide
def e2214432006170 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214432006170 : Closed e2214432006170 ∧ code e2214432006170 = 11010525028378 := by decide
theorem cert_e2214432006170 : check e2214432006170 [[]] .width = true := by decide
def e2214432006262 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214432006262 : Closed e2214432006262 ∧ code e2214432006262 = 11010525028470 := by decide
theorem cert_e2214432006262 : check e2214432006262 [[]] .width = true := by decide
def e2214432006506 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214432006506 : Closed e2214432006506 ∧ code e2214432006506 = 11010525028714 := by decide
theorem cert_e2214432006506 : check e2214432006506 [[]] .width = true := by decide
def e2214432006554 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214432006554 : Closed e2214432006554 ∧ code e2214432006554 = 11010525028762 := by decide
theorem cert_e2214432006554 : check e2214432006554 [[]] .width = true := by decide
def e2214432792602 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214432792602 : Closed e2214432792602 ∧ code e2214432792602 = 11010525814810 := by decide
theorem cert_e2214432792602 : check e2214432792602 [[]] .width = true := by decide
def e2214432792694 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214432792694 : Closed e2214432792694 ∧ code e2214432792694 = 11010525814902 := by decide
theorem cert_e2214432792694 : check e2214432792694 [[]] .width = true := by decide
def e2214432792938 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214432792938 : Closed e2214432792938 ∧ code e2214432792938 = 11010525815146 := by decide
theorem cert_e2214432792938 : check e2214432792938 [[]] .width = true := by decide
def e2214432792986 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214432792986 : Closed e2214432792986 ∧ code e2214432792986 = 11010525815194 := by decide
theorem cert_e2214432792986 : check e2214432792986 [[]] .width = true := by decide
def e2214432841754 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214432841754 : Closed e2214432841754 ∧ code e2214432841754 = 11010525863962 := by decide
theorem cert_e2214432841754 : check e2214432841754 [[]] .width = true := by decide
def e2214432841846 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214432841846 : Closed e2214432841846 ∧ code e2214432841846 = 11010525864054 := by decide
theorem cert_e2214432841846 : check e2214432841846 [[]] .width = true := by decide
def e2214432842090 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214432842090 : Closed e2214432842090 ∧ code e2214432842090 = 11010525864298 := by decide
theorem cert_e2214432842090 : check e2214432842090 [[]] .width = true := by decide
def e2214432842138 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214432842138 : Closed e2214432842138 ∧ code e2214432842138 = 11010525864346 := by decide
theorem cert_e2214432842138 : check e2214432842138 [[]] .width = true := by decide
def e2214432847898 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214432847898 : Closed e2214432847898 ∧ code e2214432847898 = 11010525870106 := by decide
theorem cert_e2214432847898 : check e2214432847898 [[]] .width = true := by decide
def e2214435151898 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214435151898 : Closed e2214435151898 ∧ code e2214435151898 = 11010528174106 := by decide
theorem cert_e2214435151898 : check e2214435151898 [[]] .width = true := by decide
def e2214435151990 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214435151990 : Closed e2214435151990 ∧ code e2214435151990 = 11010528174198 := by decide
theorem cert_e2214435151990 : check e2214435151990 [[]] .width = true := by decide
def e2214435152234 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214435152234 : Closed e2214435152234 ∧ code e2214435152234 = 11010528174442 := by decide
theorem cert_e2214435152234 : check e2214435152234 [[]] .width = true := by decide
def e2214435152282 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214435152282 : Closed e2214435152282 ∧ code e2214435152282 = 11010528174490 := by decide
theorem cert_e2214435152282 : check e2214435152282 [[]] .width = true := by decide
def e2214439665862 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214439665862 : Closed e2214439665862 ∧ code e2214439665862 = 11010532688070 := by decide
theorem cert_e2214439665862 : check e2214439665862 [[]] .width = true := by decide
def e2214439870490 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214439870490 : Closed e2214439870490 ∧ code e2214439870490 = 11010532892698 := by decide
theorem cert_e2214439870490 : check e2214439870490 [[]] .width = true := by decide
def e2214439870582 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214439870582 : Closed e2214439870582 ∧ code e2214439870582 = 11010532892790 := by decide
theorem cert_e2214439870582 : check e2214439870582 [[]] .width = true := by decide
def e2214439870826 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214439870826 : Closed e2214439870826 ∧ code e2214439870826 = 11010532893034 := by decide
theorem cert_e2214439870826 : check e2214439870826 [[]] .width = true := by decide
def e2214439870874 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214439870874 : Closed e2214439870874 ∧ code e2214439870874 = 11010532893082 := by decide
theorem cert_e2214439870874 : check e2214439870874 [[]] .width = true := by decide
def e2214439919642 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214439919642 : Closed e2214439919642 ∧ code e2214439919642 = 11010532941850 := by decide
theorem cert_e2214439919642 : check e2214439919642 [[]] .width = true := by decide
def e2214439919734 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214439919734 : Closed e2214439919734 ∧ code e2214439919734 = 11010532941942 := by decide
theorem cert_e2214439919734 : check e2214439919734 [[]] .width = true := by decide
def e2214439919978 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214439919978 : Closed e2214439919978 ∧ code e2214439919978 = 11010532942186 := by decide
theorem cert_e2214439919978 : check e2214439919978 [[]] .width = true := by decide
def e2214439920026 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214439920026 : Closed e2214439920026 ∧ code e2214439920026 = 11010532942234 := by decide
theorem cert_e2214439920026 : check e2214439920026 [[]] .width = true := by decide
def e2214439925786 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214439925786 : Closed e2214439925786 ∧ code e2214439925786 = 11010532947994 := by decide
theorem cert_e2214439925786 : check e2214439925786 [[]] .width = true := by decide
def e2214440337434 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2214440337434 : Closed e2214440337434 ∧ code e2214440337434 = 11010533359642 := by decide
theorem cert_e2214440337434 : check e2214440337434 [[]] .width = true := by decide
def e2214440337526 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2214440337526 : Closed e2214440337526 ∧ code e2214440337526 = 11010533359734 := by decide
theorem cert_e2214440337526 : check e2214440337526 [[]] .width = true := by decide
def e2214440337770 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2214440337770 : Closed e2214440337770 ∧ code e2214440337770 = 11010533359978 := by decide
theorem cert_e2214440337770 : check e2214440337770 [[]] .width = true := by decide
def e2214440337818 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2214440337818 : Closed e2214440337818 ∧ code e2214440337818 = 11010533360026 := by decide
theorem cert_e2214440337818 : check e2214440337818 [[]] .width = true := by decide
def e2214440337902 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2214440337902 : Closed e2214440337902 ∧ code e2214440337902 = 11010533360110 := by decide
theorem cert_e2214440337902 : check e2214440337902 [[]] .width = true := by decide
def e2214440338826 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2214440338826 : Closed e2214440338826 ∧ code e2214440338826 = 11010533361034 := by decide
theorem cert_e2214440338826 : check e2214440338826 [[]] .width = true := by decide
def e2214440338850 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2214440338850 : Closed e2214440338850 ∧ code e2214440338850 = 11010533361058 := by decide
theorem cert_e2214440338850 : check e2214440338850 [[]] .width = true := by decide
def e2214440338870 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2214440338870 : Closed e2214440338870 ∧ code e2214440338870 = 11010533361078 := by decide
theorem cert_e2214440338870 : check e2214440338870 [[]] .width = true := by decide
def e2214440338902 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2214440338902 : Closed e2214440338902 ∧ code e2214440338902 = 11010533361110 := by decide
theorem cert_e2214440338902 : check e2214440338902 [[]] .width = true := by decide
def e2214440338906 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2214440338906 : Closed e2214440338906 ∧ code e2214440338906 = 11010533361114 := by decide
theorem cert_e2214440338906 : check e2214440338906 [[]] .width = true := by decide
def e2214440338958 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2214440338958 : Closed e2214440338958 ∧ code e2214440338958 = 11010533361166 := by decide
theorem cert_e2214440338958 : check e2214440338958 [[]] .width = true := by decide
def e2214440338970 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2214440338970 : Closed e2214440338970 ∧ code e2214440338970 = 11010533361178 := by decide
theorem cert_e2214440338970 : check e2214440338970 [[]] .width = true := by decide
def e2214440339042 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2214440339042 : Closed e2214440339042 ∧ code e2214440339042 = 11010533361250 := by decide
theorem cert_e2214440339042 : check e2214440339042 [[]] .width = true := by decide
def e2214440339062 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2214440339062 : Closed e2214440339062 ∧ code e2214440339062 = 11010533361270 := by decide
theorem cert_e2214440339062 : check e2214440339062 [[]] .width = true := by decide
def e2214440339254 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2214440339254 : Closed e2214440339254 ∧ code e2214440339254 = 11010533361462 := by decide
theorem cert_e2214440339254 : check e2214440339254 [[]] .width = true := by decide
def e2214440339258 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2214440339258 : Closed e2214440339258 ∧ code e2214440339258 = 11010533361466 := by decide
theorem cert_e2214440339258 : check e2214440339258 [[]] .width = true := by decide
def e2214440342954 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2214440342954 : Closed e2214440342954 ∧ code e2214440342954 = 11010533365162 := by decide
theorem cert_e2214440342954 : check e2214440342954 [[]] .width = true := by decide
def e2214440343050 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2214440343050 : Closed e2214440343050 ∧ code e2214440343050 = 11010533365258 := by decide
theorem cert_e2214440343050 : check e2214440343050 [[]] .width = true := by decide
def e2214440343146 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2214440343146 : Closed e2214440343146 ∧ code e2214440343146 = 11010533365354 := by decide
theorem cert_e2214440343146 : check e2214440343146 [[]] .width = true := by decide
def e2214440343170 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2214440343170 : Closed e2214440343170 ∧ code e2214440343170 = 11010533365378 := by decide
theorem cert_e2214440343170 : check e2214440343170 [[]] .width = true := by decide
def e2214440343194 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2214440343194 : Closed e2214440343194 ∧ code e2214440343194 = 11010533365402 := by decide
theorem cert_e2214440343194 : check e2214440343194 [[]] .width = true := by decide
def e2214440343578 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2214440343578 : Closed e2214440343578 ∧ code e2214440343578 = 11010533365786 := by decide
theorem cert_e2214440343578 : check e2214440343578 [[]] .width = true := by decide
def e2214440343670 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2214440343670 : Closed e2214440343670 ∧ code e2214440343670 = 11010533365878 := by decide
theorem cert_e2214440343670 : check e2214440343670 [[]] .width = true := by decide
def e2214440343914 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2214440343914 : Closed e2214440343914 ∧ code e2214440343914 = 11010533366122 := by decide
theorem cert_e2214440343914 : check e2214440343914 [[]] .width = true := by decide
def e2214440343938 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2214440343938 : Closed e2214440343938 ∧ code e2214440343938 = 11010533366146 := by decide
theorem cert_e2214440343938 : check e2214440343938 [[]] .width = true := by decide
def e2214440343962 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2214440343962 : Closed e2214440343962 ∧ code e2214440343962 = 11010533366170 := by decide
theorem cert_e2214440343962 : check e2214440343962 [[]] .width = true := by decide
def e2214450806982 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214450806982 : Closed e2214450806982 ∧ code e2214450806982 = 11010543829190 := by decide
theorem cert_e2214450806982 : check e2214450806982 [[]] .width = true := by decide
def e2214450905286 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214450905286 : Closed e2214450905286 ∧ code e2214450905286 = 11010543927494 := by decide
theorem cert_e2214450905286 : check e2214450905286 [[]] .width = true := by decide
def e2214451666970 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214451666970 : Closed e2214451666970 ∧ code e2214451666970 = 11010544689178 := by decide
theorem cert_e2214451666970 : check e2214451666970 [[]] .width = true := by decide
def e2214451667062 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214451667062 : Closed e2214451667062 ∧ code e2214451667062 = 11010544689270 := by decide
theorem cert_e2214451667062 : check e2214451667062 [[]] .width = true := by decide
def e2214451667306 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214451667306 : Closed e2214451667306 ∧ code e2214451667306 = 11010544689514 := by decide
theorem cert_e2214451667306 : check e2214451667306 [[]] .width = true := by decide
def e2214451667354 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214451667354 : Closed e2214451667354 ∧ code e2214451667354 = 11010544689562 := by decide
theorem cert_e2214451667354 : check e2214451667354 [[]] .width = true := by decide
def e2214451716122 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214451716122 : Closed e2214451716122 ∧ code e2214451716122 = 11010544738330 := by decide
theorem cert_e2214451716122 : check e2214451716122 [[]] .width = true := by decide
def e2214451716214 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214451716214 : Closed e2214451716214 ∧ code e2214451716214 = 11010544738422 := by decide
theorem cert_e2214451716214 : check e2214451716214 [[]] .width = true := by decide
def e2214451716458 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214451716458 : Closed e2214451716458 ∧ code e2214451716458 = 11010544738666 := by decide
theorem cert_e2214451716458 : check e2214451716458 [[]] .width = true := by decide
def e2214451716506 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214451716506 : Closed e2214451716506 ∧ code e2214451716506 = 11010544738714 := by decide
theorem cert_e2214451716506 : check e2214451716506 [[]] .width = true := by decide
def e2214451722266 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214451722266 : Closed e2214451722266 ∧ code e2214451722266 = 11010544744474 := by decide
theorem cert_e2214451722266 : check e2214451722266 [[]] .width = true := by decide
def e2214451912730 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214451912730 : Closed e2214451912730 ∧ code e2214451912730 = 11010544934938 := by decide
theorem cert_e2214451912730 : check e2214451912730 [[]] .width = true := by decide
def e2214451912822 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214451912822 : Closed e2214451912822 ∧ code e2214451912822 = 11010544935030 := by decide
theorem cert_e2214451912822 : check e2214451912822 [[]] .width = true := by decide
def e2214451913066 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214451913066 : Closed e2214451913066 ∧ code e2214451913066 = 11010544935274 := by decide
theorem cert_e2214451913066 : check e2214451913066 [[]] .width = true := by decide
def e2214451913114 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214451913114 : Closed e2214451913114 ∧ code e2214451913114 = 11010544935322 := by decide
theorem cert_e2214451913114 : check e2214451913114 [[]] .width = true := by decide
def e2214451918874 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214451918874 : Closed e2214451918874 ∧ code e2214451918874 = 11010544941082 := by decide
theorem cert_e2214451918874 : check e2214451918874 [[]] .width = true := by decide
def e2214451931162 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214451931162 : Closed e2214451931162 ∧ code e2214451931162 = 11010544953370 := by decide
theorem cert_e2214451931162 : check e2214451931162 [[]] .width = true := by decide
def e2214452248774 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2214452248774 : Closed e2214452248774 ∧ code e2214452248774 = 11010545270982 := by decide
theorem cert_e2214452248774 : check e2214452248774 [[]] .width = true := by decide
def e2214452453402 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214452453402 : Closed e2214452453402 ∧ code e2214452453402 = 11010545475610 := by decide
theorem cert_e2214452453402 : check e2214452453402 [[]] .width = true := by decide
def e2214452453494 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214452453494 : Closed e2214452453494 ∧ code e2214452453494 = 11010545475702 := by decide
theorem cert_e2214452453494 : check e2214452453494 [[]] .width = true := by decide
def e2214452453738 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214452453738 : Closed e2214452453738 ∧ code e2214452453738 = 11010545475946 := by decide
theorem cert_e2214452453738 : check e2214452453738 [[]] .width = true := by decide
def e2214452453786 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214452453786 : Closed e2214452453786 ∧ code e2214452453786 = 11010545475994 := by decide
theorem cert_e2214452453786 : check e2214452453786 [[]] .width = true := by decide
def e2214452502554 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2214452502554 : Closed e2214452502554 ∧ code e2214452502554 = 11010545524762 := by decide
theorem cert_e2214452502554 : check e2214452502554 [[]] .width = true := by decide
def e2214452502646 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2214452502646 : Closed e2214452502646 ∧ code e2214452502646 = 11010545524854 := by decide
theorem cert_e2214452502646 : check e2214452502646 [[]] .width = true := by decide
def e2214452502890 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2214452502890 : Closed e2214452502890 ∧ code e2214452502890 = 11010545525098 := by decide
theorem cert_e2214452502890 : check e2214452502890 [[]] .width = true := by decide
def e2214452502938 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2214452502938 : Closed e2214452502938 ∧ code e2214452502938 = 11010545525146 := by decide
theorem cert_e2214452502938 : check e2214452502938 [[]] .width = true := by decide
def e2214452508698 : Term := (.app (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2214452508698 : Closed e2214452508698 ∧ code e2214452508698 = 11010545530906 := by decide
theorem cert_e2214452508698 : check e2214452508698 [[]] .width = true := by decide
end Blc.Floor43
