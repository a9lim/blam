import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605639936878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605639936878 : Closed e605639936878 ∧ code e605639936878 = 9401732959086 := by decide
theorem cert_e605639936878 : check e605639936878 [[.under],[.under]] .smaller = true := by decide
def e605639936886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605639936886 : Closed e605639936886 ∧ code e605639936886 = 9401732959094 := by decide
theorem cert_e605639936886 : check e605639936886 [[.under],[.under]] .smaller = true := by decide
def e605639936942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605639936942 : Closed e605639936942 ∧ code e605639936942 = 9401732959150 := by decide
theorem cert_e605639936942 : check e605639936942 [[.under],[.under]] .smaller = true := by decide
def e605639936954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605639936954 : Closed e605639936954 ∧ code e605639936954 = 9401732959162 := by decide
theorem cert_e605639936954 : check e605639936954 [[.under],[.under]] .smaller = true := by decide
def e605639936982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605639936982 : Closed e605639936982 ∧ code e605639936982 = 9401732959190 := by decide
theorem cert_e605639936982 : check e605639936982 [[.under],[.under]] .smaller = true := by decide
def e605639936986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605639936986 : Closed e605639936986 ∧ code e605639936986 = 9401732959194 := by decide
theorem cert_e605639936986 : check e605639936986 [[.under],[.under]] .smaller = true := by decide
def e605639937262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605639937262 : Closed e605639937262 ∧ code e605639937262 = 9401732959470 := by decide
theorem cert_e605639937262 : check e605639937262 [[.under],[.under]] .smaller = true := by decide
def e605639937270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605639937270 : Closed e605639937270 ∧ code e605639937270 = 9401732959478 := by decide
theorem cert_e605639937270 : check e605639937270 [[.under],[.under]] .smaller = true := by decide
def e605639937646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605639937646 : Closed e605639937646 ∧ code e605639937646 = 9401732959854 := by decide
theorem cert_e605639937646 : check e605639937646 [[.under],[.under]] .smaller = true := by decide
def e605639937658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605639937658 : Closed e605639937658 ∧ code e605639937658 = 9401732959866 := by decide
theorem cert_e605639937658 : check e605639937658 [[.under],[.under]] .smaller = true := by decide
def e605639937846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605639937846 : Closed e605639937846 ∧ code e605639937846 = 9401732960054 := by decide
theorem cert_e605639937846 : check e605639937846 [[.under],[.under]] .smaller = true := by decide
def e605639937850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605639937850 : Closed e605639937850 ∧ code e605639937850 = 9401732960058 := by decide
theorem cert_e605639937850 : check e605639937850 [[.under],[.under]] .smaller = true := by decide
def e605644655470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605644655470 : Closed e605644655470 ∧ code e605644655470 = 9401737677678 := by decide
theorem cert_e605644655470 : check e605644655470 [[.under],[.under]] .smaller = true := by decide
def e605644655478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605644655478 : Closed e605644655478 ∧ code e605644655478 = 9401737677686 := by decide
theorem cert_e605644655478 : check e605644655478 [[.under],[.under]] .smaller = true := by decide
def e605644655534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605644655534 : Closed e605644655534 ∧ code e605644655534 = 9401737677742 := by decide
theorem cert_e605644655534 : check e605644655534 [[.under],[.under]] .smaller = true := by decide
def e605644655546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605644655546 : Closed e605644655546 ∧ code e605644655546 = 9401737677754 := by decide
theorem cert_e605644655546 : check e605644655546 [[.under],[.under]] .smaller = true := by decide
def e605644655574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605644655574 : Closed e605644655574 ∧ code e605644655574 = 9401737677782 := by decide
theorem cert_e605644655574 : check e605644655574 [[.under],[.under]] .smaller = true := by decide
def e605644655578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605644655578 : Closed e605644655578 ∧ code e605644655578 = 9401737677786 := by decide
theorem cert_e605644655578 : check e605644655578 [[.under],[.under]] .smaller = true := by decide
def e605644655854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605644655854 : Closed e605644655854 ∧ code e605644655854 = 9401737678062 := by decide
theorem cert_e605644655854 : check e605644655854 [[.under],[.under]] .smaller = true := by decide
def e605644655862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605644655862 : Closed e605644655862 ∧ code e605644655862 = 9401737678070 := by decide
theorem cert_e605644655862 : check e605644655862 [[.under],[.under]] .smaller = true := by decide
def e605644656238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605644656238 : Closed e605644656238 ∧ code e605644656238 = 9401737678446 := by decide
theorem cert_e605644656238 : check e605644656238 [[.under],[.under]] .smaller = true := by decide
def e605644656250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605644656250 : Closed e605644656250 ∧ code e605644656250 = 9401737678458 := by decide
theorem cert_e605644656250 : check e605644656250 [[.under],[.under]] .smaller = true := by decide
def e605644656438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605644656438 : Closed e605644656438 ∧ code e605644656438 = 9401737678646 := by decide
theorem cert_e605644656438 : check e605644656438 [[.under],[.under]] .smaller = true := by decide
def e605644656442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605644656442 : Closed e605644656442 ∧ code e605644656442 = 9401737678650 := by decide
theorem cert_e605644656442 : check e605644656442 [[.under],[.under]] .smaller = true := by decide
def e605649464798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e605649464798 : Closed e605649464798 ∧ code e605649464798 = 9401742487006 := by decide
theorem cert_e605649464798 : check e605649464798 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649464814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e605649464814 : Closed e605649464814 ∧ code e605649464814 = 9401742487022 := by decide
theorem cert_e605649464814 : check e605649464814 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649465054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e605649465054 : Closed e605649465054 ∧ code e605649465054 = 9401742487262 := by decide
private def t_e605649465054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3))))))))
theorem cert_e605649465054 : ¬ IsSelfInterpreter e605649465054 :=
  wSource (t := t_e605649465054) (replay_sound (ps := []) (t := e605649465054) (by decide)) (by decide)
def e605649465078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e605649465078 : Closed e605649465078 ∧ code e605649465078 = 9401742487286 := by decide
private def t_e605649465078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1))))))))
theorem cert_e605649465078 : ¬ IsSelfInterpreter e605649465078 :=
  wSource (t := t_e605649465078) (replay_sound (ps := []) (t := e605649465078) (by decide)) (by decide)
def e605649465198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e605649465198 : Closed e605649465198 ∧ code e605649465198 = 9401742487406 := by decide
theorem cert_e605649465198 : check e605649465198 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649465206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e605649465206 : Closed e605649465206 ∧ code e605649465206 = 9401742487414 := by decide
theorem cert_e605649465206 : check e605649465206 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649466846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e605649466846 : Closed e605649466846 ∧ code e605649466846 = 9401742489054 := by decide
theorem cert_e605649466846 : check e605649466846 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649466862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e605649466862 : Closed e605649466862 ∧ code e605649466862 = 9401742489070 := by decide
theorem cert_e605649466862 : check e605649466862 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649467230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e605649467230 : Closed e605649467230 ∧ code e605649467230 = 9401742489438 := by decide
theorem cert_e605649467230 : check e605649467230 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649467258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e605649467258 : Closed e605649467258 ∧ code e605649467258 = 9401742489466 := by decide
theorem cert_e605649467258 : check e605649467258 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649467310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e605649467310 : Closed e605649467310 ∧ code e605649467310 = 9401742489518 := by decide
theorem cert_e605649467310 : check e605649467310 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649467322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e605649467322 : Closed e605649467322 ∧ code e605649467322 = 9401742489530 := by decide
theorem cert_e605649467322 : check e605649467322 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e605649468126 : Closed e605649468126 ∧ code e605649468126 = 9401742490334 := by decide
private def t_e605649468126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3))))))))
theorem cert_e605649468126 : ¬ IsSelfInterpreter e605649468126 :=
  wSource (t := t_e605649468126) (replay_sound (ps := []) (t := e605649468126) (by decide)) (by decide)
def e605649468150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e605649468150 : Closed e605649468150 ∧ code e605649468150 = 9401742490358 := by decide
private def t_e605649468150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1))))))))
theorem cert_e605649468150 : ¬ IsSelfInterpreter e605649468150 :=
  wSource (t := t_e605649468150) (replay_sound (ps := []) (t := e605649468150) (by decide)) (by decide)
def e605649468254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e605649468254 : Closed e605649468254 ∧ code e605649468254 = 9401742490462 := by decide
theorem cert_e605649468254 : check e605649468254 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e605649468282 : Closed e605649468282 ∧ code e605649468282 = 9401742490490 := by decide
theorem cert_e605649468282 : check e605649468282 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e605649468374 : Closed e605649468374 ∧ code e605649468374 = 9401742490582 := by decide
theorem cert_e605649468374 : check e605649468374 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e605649468378 : Closed e605649468378 ∧ code e605649468378 = 9401742490586 := by decide
theorem cert_e605649468378 : check e605649468378 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e605649468782 : Closed e605649468782 ∧ code e605649468782 = 9401742490990 := by decide
theorem cert_e605649468782 : check e605649468782 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e605649468790 : Closed e605649468790 ∧ code e605649468790 = 9401742490998 := by decide
theorem cert_e605649468790 : check e605649468790 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e605649468846 : Closed e605649468846 ∧ code e605649468846 = 9401742491054 := by decide
theorem cert_e605649468846 : check e605649468846 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e605649468858 : Closed e605649468858 ∧ code e605649468858 = 9401742491066 := by decide
theorem cert_e605649468858 : check e605649468858 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e605649468886 : Closed e605649468886 ∧ code e605649468886 = 9401742491094 := by decide
theorem cert_e605649468886 : check e605649468886 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649468890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e605649468890 : Closed e605649468890 ∧ code e605649468890 = 9401742491098 := by decide
theorem cert_e605649468890 : check e605649468890 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e605649477086 : Closed e605649477086 ∧ code e605649477086 = 9401742499294 := by decide
theorem cert_e605649477086 : check e605649477086 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e605649477102 : Closed e605649477102 ∧ code e605649477102 = 9401742499310 := by decide
theorem cert_e605649477102 : check e605649477102 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e605649477342 : Closed e605649477342 ∧ code e605649477342 = 9401742499550 := by decide
theorem cert_e605649477342 : check e605649477342 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e605649477366 : Closed e605649477366 ∧ code e605649477366 = 9401742499574 := by decide
theorem cert_e605649477366 : check e605649477366 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e605649477486 : Closed e605649477486 ∧ code e605649477486 = 9401742499694 := by decide
theorem cert_e605649477486 : check e605649477486 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649477494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e605649477494 : Closed e605649477494 ∧ code e605649477494 = 9401742499702 := by decide
theorem cert_e605649477494 : check e605649477494 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649482718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605649482718 : Closed e605649482718 ∧ code e605649482718 = 9401742504926 := by decide
theorem cert_e605649482718 : check e605649482718 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649482734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605649482734 : Closed e605649482734 ∧ code e605649482734 = 9401742504942 := by decide
theorem cert_e605649482734 : check e605649482734 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649484254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605649484254 : Closed e605649484254 ∧ code e605649484254 = 9401742506462 := by decide
private def t_e605649484254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem cert_e605649484254 : ¬ IsSelfInterpreter e605649484254 :=
  wSource (t := t_e605649484254) (replay_sound (ps := []) (t := e605649484254) (by decide)) (by decide)
def e605649484278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605649484278 : Closed e605649484278 ∧ code e605649484278 = 9401742506486 := by decide
private def t_e605649484278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem cert_e605649484278 : ¬ IsSelfInterpreter e605649484278 :=
  wSource (t := t_e605649484278) (replay_sound (ps := []) (t := e605649484278) (by decide)) (by decide)
def e605649485038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605649485038 : Closed e605649485038 ∧ code e605649485038 = 9401742507246 := by decide
theorem cert_e605649485038 : check e605649485038 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649485046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605649485046 : Closed e605649485046 ∧ code e605649485046 = 9401742507254 := by decide
theorem cert_e605649485046 : check e605649485046 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e605649489374 : Closed e605649489374 ∧ code e605649489374 = 9401742511582 := by decide
theorem cert_e605649489374 : check e605649489374 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e605649489390 : Closed e605649489390 ∧ code e605649489390 = 9401742511598 := by decide
theorem cert_e605649489390 : check e605649489390 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e605649489758 : Closed e605649489758 ∧ code e605649489758 = 9401742511966 := by decide
theorem cert_e605649489758 : check e605649489758 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e605649489786 : Closed e605649489786 ∧ code e605649489786 = 9401742511994 := by decide
theorem cert_e605649489786 : check e605649489786 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e605649489838 : Closed e605649489838 ∧ code e605649489838 = 9401742512046 := by decide
theorem cert_e605649489838 : check e605649489838 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649489850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e605649489850 : Closed e605649489850 ∧ code e605649489850 = 9401742512058 := by decide
theorem cert_e605649489850 : check e605649489850 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649490910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e605649490910 : Closed e605649490910 ∧ code e605649490910 = 9401742513118 := by decide
theorem cert_e605649490910 : check e605649490910 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649490926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e605649490926 : Closed e605649490926 ∧ code e605649490926 = 9401742513134 := by decide
theorem cert_e605649490926 : check e605649490926 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649493214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605649493214 : Closed e605649493214 ∧ code e605649493214 = 9401742515422 := by decide
theorem cert_e605649493214 : check e605649493214 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649493242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605649493242 : Closed e605649493242 ∧ code e605649493242 = 9401742515450 := by decide
theorem cert_e605649493242 : check e605649493242 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649493614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605649493614 : Closed e605649493614 ∧ code e605649493614 = 9401742515822 := by decide
theorem cert_e605649493614 : check e605649493614 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649493626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605649493626 : Closed e605649493626 ∧ code e605649493626 = 9401742515834 := by decide
theorem cert_e605649493626 : check e605649493626 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649495774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e605649495774 : Closed e605649495774 ∧ code e605649495774 = 9401742517982 := by decide
theorem cert_e605649495774 : check e605649495774 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649495798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e605649495798 : Closed e605649495798 ∧ code e605649495798 = 9401742518006 := by decide
theorem cert_e605649495798 : check e605649495798 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649495902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e605649495902 : Closed e605649495902 ∧ code e605649495902 = 9401742518110 := by decide
theorem cert_e605649495902 : check e605649495902 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649495930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e605649495930 : Closed e605649495930 ∧ code e605649495930 = 9401742518138 := by decide
theorem cert_e605649495930 : check e605649495930 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649496022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e605649496022 : Closed e605649496022 ∧ code e605649496022 = 9401742518230 := by decide
theorem cert_e605649496022 : check e605649496022 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649496026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e605649496026 : Closed e605649496026 ∧ code e605649496026 = 9401742518234 := by decide
theorem cert_e605649496026 : check e605649496026 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649496542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e605649496542 : Closed e605649496542 ∧ code e605649496542 = 9401742518750 := by decide
private def t_e605649496542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem cert_e605649496542 : ¬ IsSelfInterpreter e605649496542 :=
  wSource (t := t_e605649496542) (replay_sound (ps := []) (t := e605649496542) (by decide)) (by decide)
def e605649496566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e605649496566 : Closed e605649496566 ∧ code e605649496566 = 9401742518774 := by decide
private def t_e605649496566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem cert_e605649496566 : ¬ IsSelfInterpreter e605649496566 :=
  wSource (t := t_e605649496566) (replay_sound (ps := []) (t := e605649496566) (by decide)) (by decide)
def e605649497310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e605649497310 : Closed e605649497310 ∧ code e605649497310 = 9401742519518 := by decide
theorem cert_e605649497310 : check e605649497310 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649497338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e605649497338 : Closed e605649497338 ∧ code e605649497338 = 9401742519546 := by decide
theorem cert_e605649497338 : check e605649497338 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649497910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649497910 : Closed e605649497910 ∧ code e605649497910 = 9401742520118 := by decide
theorem cert_e605649497910 : check e605649497910 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649497914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649497914 : Closed e605649497914 ∧ code e605649497914 = 9401742520122 := by decide
theorem cert_e605649497914 : check e605649497914 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649498990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e605649498990 : Closed e605649498990 ∧ code e605649498990 = 9401742521198 := by decide
theorem cert_e605649498990 : check e605649498990 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649498998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e605649498998 : Closed e605649498998 ∧ code e605649498998 = 9401742521206 := by decide
theorem cert_e605649498998 : check e605649498998 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e605649499054 : Closed e605649499054 ∧ code e605649499054 = 9401742521262 := by decide
theorem cert_e605649499054 : check e605649499054 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e605649499066 : Closed e605649499066 ∧ code e605649499066 = 9401742521274 := by decide
theorem cert_e605649499066 : check e605649499066 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e605649499094 : Closed e605649499094 ∧ code e605649499094 = 9401742521302 := by decide
theorem cert_e605649499094 : check e605649499094 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e605649499098 : Closed e605649499098 ∧ code e605649499098 = 9401742521306 := by decide
theorem cert_e605649499098 : check e605649499098 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e605649499374 : Closed e605649499374 ∧ code e605649499374 = 9401742521582 := by decide
theorem cert_e605649499374 : check e605649499374 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e605649499382 : Closed e605649499382 ∧ code e605649499382 = 9401742521590 := by decide
theorem cert_e605649499382 : check e605649499382 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e605649499758 : Closed e605649499758 ∧ code e605649499758 = 9401742521966 := by decide
theorem cert_e605649499758 : check e605649499758 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e605649499770 : Closed e605649499770 ∧ code e605649499770 = 9401742521978 := by decide
theorem cert_e605649499770 : check e605649499770 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605649499958 : Closed e605649499958 ∧ code e605649499958 = 9401742522166 := by decide
theorem cert_e605649499958 : check e605649499958 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649499962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605649499962 : Closed e605649499962 ∧ code e605649499962 = 9401742522170 := by decide
theorem cert_e605649499962 : check e605649499962 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e605649526238 : Closed e605649526238 ∧ code e605649526238 = 9401742548446 := by decide
theorem cert_e605649526238 : check e605649526238 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e605649526254 : Closed e605649526254 ∧ code e605649526254 = 9401742548462 := by decide
theorem cert_e605649526254 : check e605649526254 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3)))))))))
theorem wire_e605649526494 : Closed e605649526494 ∧ code e605649526494 = 9401742548702 := by decide
theorem cert_e605649526494 : check e605649526494 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1)))))))))
theorem wire_e605649526518 : Closed e605649526518 ∧ code e605649526518 = 9401742548726 := by decide
theorem cert_e605649526518 : check e605649526518 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2)))))))))
theorem wire_e605649526638 : Closed e605649526638 ∧ code e605649526638 = 9401742548846 := by decide
theorem cert_e605649526638 : check e605649526638 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649526646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1)))))))))
theorem wire_e605649526646 : Closed e605649526646 ∧ code e605649526646 = 9401742548854 := by decide
theorem cert_e605649526646 : check e605649526646 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649531870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3))))))))))
theorem wire_e605649531870 : Closed e605649531870 ∧ code e605649531870 = 9401742554078 := by decide
theorem cert_e605649531870 : check e605649531870 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649531886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2))))))))))
theorem wire_e605649531886 : Closed e605649531886 ∧ code e605649531886 = 9401742554094 := by decide
theorem cert_e605649531886 : check e605649531886 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649533406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3))))))))))
theorem wire_e605649533406 : Closed e605649533406 ∧ code e605649533406 = 9401742555614 := by decide
theorem cert_e605649533406 : check e605649533406 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649533430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1))))))))))
theorem wire_e605649533430 : Closed e605649533430 ∧ code e605649533430 = 9401742555638 := by decide
theorem cert_e605649533430 : check e605649533430 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649534190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2))))))))))
theorem wire_e605649534190 : Closed e605649534190 ∧ code e605649534190 = 9401742556398 := by decide
theorem cert_e605649534190 : check e605649534190 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649534198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1))))))))))
theorem wire_e605649534198 : Closed e605649534198 ∧ code e605649534198 = 9401742556406 := by decide
theorem cert_e605649534198 : check e605649534198 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e605649579486 : Closed e605649579486 ∧ code e605649579486 = 9401742601694 := by decide
theorem cert_e605649579486 : check e605649579486 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e605649579502 : Closed e605649579502 ∧ code e605649579502 = 9401742601710 := by decide
theorem cert_e605649579502 : check e605649579502 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e605649579870 : Closed e605649579870 ∧ code e605649579870 = 9401742602078 := by decide
theorem cert_e605649579870 : check e605649579870 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e605649579898 : Closed e605649579898 ∧ code e605649579898 = 9401742602106 := by decide
theorem cert_e605649579898 : check e605649579898 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e605649579950 : Closed e605649579950 ∧ code e605649579950 = 9401742602158 := by decide
theorem cert_e605649579950 : check e605649579950 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649579962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e605649579962 : Closed e605649579962 ∧ code e605649579962 = 9401742602170 := by decide
theorem cert_e605649579962 : check e605649579962 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649581022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e605649581022 : Closed e605649581022 ∧ code e605649581022 = 9401742603230 := by decide
theorem cert_e605649581022 : check e605649581022 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649581038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e605649581038 : Closed e605649581038 ∧ code e605649581038 = 9401742603246 := by decide
theorem cert_e605649581038 : check e605649581038 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649583326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e605649583326 : Closed e605649583326 ∧ code e605649583326 = 9401742605534 := by decide
theorem cert_e605649583326 : check e605649583326 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649583354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e605649583354 : Closed e605649583354 ∧ code e605649583354 = 9401742605562 := by decide
theorem cert_e605649583354 : check e605649583354 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649583726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e605649583726 : Closed e605649583726 ∧ code e605649583726 = 9401742605934 := by decide
theorem cert_e605649583726 : check e605649583726 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649583738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e605649583738 : Closed e605649583738 ∧ code e605649583738 = 9401742605946 := by decide
theorem cert_e605649583738 : check e605649583738 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605649606366 : Closed e605649606366 ∧ code e605649606366 = 9401742628574 := by decide
theorem cert_e605649606366 : check e605649606366 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605649606390 : Closed e605649606390 ∧ code e605649606390 = 9401742628598 := by decide
theorem cert_e605649606390 : check e605649606390 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605649606494 : Closed e605649606494 ∧ code e605649606494 = 9401742628702 := by decide
theorem cert_e605649606494 : check e605649606494 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605649606522 : Closed e605649606522 ∧ code e605649606522 = 9401742628730 := by decide
theorem cert_e605649606522 : check e605649606522 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605649606614 : Closed e605649606614 ∧ code e605649606614 = 9401742628822 := by decide
theorem cert_e605649606614 : check e605649606614 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649606618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605649606618 : Closed e605649606618 ∧ code e605649606618 = 9401742628826 := by decide
theorem cert_e605649606618 : check e605649606618 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649607134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605649607134 : Closed e605649607134 ∧ code e605649607134 = 9401742629342 := by decide
theorem cert_e605649607134 : check e605649607134 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649607158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605649607158 : Closed e605649607158 ∧ code e605649607158 = 9401742629366 := by decide
theorem cert_e605649607158 : check e605649607158 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649607902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605649607902 : Closed e605649607902 ∧ code e605649607902 = 9401742630110 := by decide
theorem cert_e605649607902 : check e605649607902 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649607930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605649607930 : Closed e605649607930 ∧ code e605649607930 = 9401742630138 := by decide
theorem cert_e605649607930 : check e605649607930 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649608502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649608502 : Closed e605649608502 ∧ code e605649608502 = 9401742630710 := by decide
theorem cert_e605649608502 : check e605649608502 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649608506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649608506 : Closed e605649608506 ∧ code e605649608506 = 9401742630714 := by decide
theorem cert_e605649608506 : check e605649608506 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605649619822 : Closed e605649619822 ∧ code e605649619822 = 9401742642030 := by decide
theorem cert_e605649619822 : check e605649619822 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605649619830 : Closed e605649619830 ∧ code e605649619830 = 9401742642038 := by decide
theorem cert_e605649619830 : check e605649619830 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605649619886 : Closed e605649619886 ∧ code e605649619886 = 9401742642094 := by decide
theorem cert_e605649619886 : check e605649619886 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605649619898 : Closed e605649619898 ∧ code e605649619898 = 9401742642106 := by decide
theorem cert_e605649619898 : check e605649619898 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605649619926 : Closed e605649619926 ∧ code e605649619926 = 9401742642134 := by decide
theorem cert_e605649619926 : check e605649619926 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649619930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605649619930 : Closed e605649619930 ∧ code e605649619930 = 9401742642138 := by decide
theorem cert_e605649619930 : check e605649619930 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620206 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605649620206 : Closed e605649620206 ∧ code e605649620206 = 9401742642414 := by decide
theorem cert_e605649620206 : check e605649620206 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605649620214 : Closed e605649620214 ∧ code e605649620214 = 9401742642422 := by decide
theorem cert_e605649620214 : check e605649620214 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605649620590 : Closed e605649620590 ∧ code e605649620590 = 9401742642798 := by decide
theorem cert_e605649620590 : check e605649620590 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605649620602 : Closed e605649620602 ∧ code e605649620602 = 9401742642810 := by decide
theorem cert_e605649620602 : check e605649620602 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605649620790 : Closed e605649620790 ∧ code e605649620790 = 9401742642998 := by decide
theorem cert_e605649620790 : check e605649620790 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605649620794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605649620794 : Closed e605649620794 ∧ code e605649620794 = 9401742643002 := by decide
theorem cert_e605649620794 : check e605649620794 [[.under],[.under],[.under,.under]] .three = true := by decide
def e605653347694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605653347694 : Closed e605653347694 ∧ code e605653347694 = 9401746369902 := by decide
theorem cert_e605653347694 : check e605653347694 [[.under],[.under]] .smaller = true := by decide
def e605653347702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605653347702 : Closed e605653347702 ∧ code e605653347702 = 9401746369910 := by decide
theorem cert_e605653347702 : check e605653347702 [[.under],[.under]] .smaller = true := by decide
def e605653347758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605653347758 : Closed e605653347758 ∧ code e605653347758 = 9401746369966 := by decide
theorem cert_e605653347758 : check e605653347758 [[.under],[.under]] .smaller = true := by decide
def e605653347770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605653347770 : Closed e605653347770 ∧ code e605653347770 = 9401746369978 := by decide
theorem cert_e605653347770 : check e605653347770 [[.under],[.under]] .smaller = true := by decide
def e605653347798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605653347798 : Closed e605653347798 ∧ code e605653347798 = 9401746370006 := by decide
theorem cert_e605653347798 : check e605653347798 [[.under],[.under]] .smaller = true := by decide
def e605653347802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605653347802 : Closed e605653347802 ∧ code e605653347802 = 9401746370010 := by decide
theorem cert_e605653347802 : check e605653347802 [[.under],[.under]] .smaller = true := by decide
def e605653348014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e605653348014 : Closed e605653348014 ∧ code e605653348014 = 9401746370222 := by decide
theorem cert_e605653348014 : check e605653348014 [[.under],[.under]] .smaller = true := by decide
def e605653348026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e605653348026 : Closed e605653348026 ∧ code e605653348026 = 9401746370234 := by decide
theorem cert_e605653348026 : check e605653348026 [[.under],[.under]] .smaller = true := by decide
def e605653348074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e605653348074 : Closed e605653348074 ∧ code e605653348074 = 9401746370282 := by decide
theorem cert_e605653348074 : check e605653348074 [[.under],[.under]] .smaller = true := by decide
def e605653348182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605653348182 : Closed e605653348182 ∧ code e605653348182 = 9401746370390 := by decide
theorem cert_e605653348182 : check e605653348182 [[.under],[.under]] .smaller = true := by decide
def e605653348186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605653348186 : Closed e605653348186 ∧ code e605653348186 = 9401746370394 := by decide
theorem cert_e605653348186 : check e605653348186 [[.under],[.under]] .smaller = true := by decide
def e605653348202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605653348202 : Closed e605653348202 ∧ code e605653348202 = 9401746370410 := by decide
theorem cert_e605653348202 : check e605653348202 [[.under],[.under]] .smaller = true := by decide
def e605653349230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605653349230 : Closed e605653349230 ∧ code e605653349230 = 9401746371438 := by decide
theorem cert_e605653349230 : check e605653349230 [[.under],[.under]] .smaller = true := by decide
def e605653349238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605653349238 : Closed e605653349238 ∧ code e605653349238 = 9401746371446 := by decide
theorem cert_e605653349238 : check e605653349238 [[.under],[.under]] .smaller = true := by decide
def e605653349294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605653349294 : Closed e605653349294 ∧ code e605653349294 = 9401746371502 := by decide
theorem cert_e605653349294 : check e605653349294 [[.under],[.under]] .smaller = true := by decide
def e605653349306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605653349306 : Closed e605653349306 ∧ code e605653349306 = 9401746371514 := by decide
theorem cert_e605653349306 : check e605653349306 [[.under],[.under]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e605649465054
#print axioms Blc.Floor43.cert_e605649465078
#print axioms Blc.Floor43.cert_e605649468126
#print axioms Blc.Floor43.cert_e605649468150
#print axioms Blc.Floor43.cert_e605649484254
#print axioms Blc.Floor43.cert_e605649484278
#print axioms Blc.Floor43.cert_e605649496542
#print axioms Blc.Floor43.cert_e605649496566
