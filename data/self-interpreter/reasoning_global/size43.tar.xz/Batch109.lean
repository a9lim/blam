import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e862484114550 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e862484114550 : Closed e862484114550 ∧ code e862484114550 = 9658577136758 := by decide
theorem cert_e862484114550 : check e862484114550 [] .sourceHead = true := by decide
def e862484114646 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e862484114646 : Closed e862484114646 ∧ code e862484114646 = 9658577136854 := by decide
theorem cert_e862484114646 : check e862484114646 [] .sourceHead = true := by decide
def e862484114650 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e862484114650 : Closed e862484114650 ∧ code e862484114650 = 9658577136858 := by decide
theorem cert_e862484114650 : check e862484114650 [] .sourceHead = true := by decide
def e862484114666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e862484114666 : Closed e862484114666 ∧ code e862484114666 = 9658577136874 := by decide
theorem cert_e862484114666 : check e862484114666 [] .sourceHead = true := by decide
def e862484114742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862484114742 : Closed e862484114742 ∧ code e862484114742 = 9658577136950 := by decide
theorem cert_e862484114742 : check e862484114742 [] .sourceHead = true := by decide
def e862484114746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862484114746 : Closed e862484114746 ∧ code e862484114746 = 9658577136954 := by decide
theorem cert_e862484114746 : check e862484114746 [] .sourceHead = true := by decide
def e862484114830 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e862484114830 : Closed e862484114830 ∧ code e862484114830 = 9658577137038 := by decide
theorem cert_e862484114830 : check e862484114830 [] .sourceHead = true := by decide
def e862484114842 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862484114842 : Closed e862484114842 ∧ code e862484114842 = 9658577137050 := by decide
theorem cert_e862484114842 : check e862484114842 [] .sourceHead = true := by decide
def e862484114998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e862484114998 : Closed e862484114998 ∧ code e862484114998 = 9658577137206 := by decide
theorem cert_e862484114998 : check e862484114998 [] .sourceHead = true := by decide
def e862484115002 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e862484115002 : Closed e862484115002 ∧ code e862484115002 = 9658577137210 := by decide
theorem cert_e862484115002 : check e862484115002 [] .sourceHead = true := by decide
def e862484115050 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e862484115050 : Closed e862484115050 ∧ code e862484115050 = 9658577137258 := by decide
theorem cert_e862484115050 : check e862484115050 [] .sourceHead = true := by decide
def e862484115086 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e862484115086 : Closed e862484115086 ∧ code e862484115086 = 9658577137294 := by decide
theorem cert_e862484115086 : check e862484115086 [] .sourceHead = true := by decide
def e862484115098 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862484115098 : Closed e862484115098 ∧ code e862484115098 = 9658577137306 := by decide
theorem cert_e862484115098 : check e862484115098 [] .sourceHead = true := by decide
def e862484115142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e862484115142 : Closed e862484115142 ∧ code e862484115142 = 9658577137350 := by decide
theorem cert_e862484115142 : check e862484115142 [] .sourceHead = true := by decide
def e862484115694 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e862484115694 : Closed e862484115694 ∧ code e862484115694 = 9658577137902 := by decide
theorem cert_e862484115694 : check e862484115694 [] .sourceHead = true := by decide
def e862484115702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e862484115702 : Closed e862484115702 ∧ code e862484115702 = 9658577137910 := by decide
theorem cert_e862484115702 : check e862484115702 [] .sourceHead = true := by decide
def e862484116182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e862484116182 : Closed e862484116182 ∧ code e862484116182 = 9658577138390 := by decide
theorem cert_e862484116182 : check e862484116182 [] .sourceHead = true := by decide
def e862484116186 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e862484116186 : Closed e862484116186 ∧ code e862484116186 = 9658577138394 := by decide
theorem cert_e862484116186 : check e862484116186 [] .sourceHead = true := by decide
def e862484116202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e862484116202 : Closed e862484116202 ∧ code e862484116202 = 9658577138410 := by decide
theorem cert_e862484116202 : check e862484116202 [] .sourceHead = true := by decide
def e862484116278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862484116278 : Closed e862484116278 ∧ code e862484116278 = 9658577138486 := by decide
theorem cert_e862484116278 : check e862484116278 [] .sourceHead = true := by decide
def e862484116282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862484116282 : Closed e862484116282 ∧ code e862484116282 = 9658577138490 := by decide
theorem cert_e862484116282 : check e862484116282 [] .sourceHead = true := by decide
def e862484116366 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e862484116366 : Closed e862484116366 ∧ code e862484116366 = 9658577138574 := by decide
theorem cert_e862484116366 : check e862484116366 [] .sourceHead = true := by decide
def e862484116378 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862484116378 : Closed e862484116378 ∧ code e862484116378 = 9658577138586 := by decide
theorem cert_e862484116378 : check e862484116378 [] .sourceHead = true := by decide
def e862484117622 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e862484117622 : Closed e862484117622 ∧ code e862484117622 = 9658577139830 := by decide
theorem cert_e862484117622 : check e862484117622 [] .sourceHead = true := by decide
def e862484117866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e862484117866 : Closed e862484117866 ∧ code e862484117866 = 9658577140074 := by decide
theorem cert_e862484117866 : check e862484117866 [] .sourceHead = true := by decide
def e862484117902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e862484117902 : Closed e862484117902 ∧ code e862484117902 = 9658577140110 := by decide
theorem cert_e862484117902 : check e862484117902 [] .sourceHead = true := by decide
def e862484117914 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862484117914 : Closed e862484117914 ∧ code e862484117914 = 9658577140122 := by decide
theorem cert_e862484117914 : check e862484117914 [] .sourceHead = true := by decide
def e862484117958 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e862484117958 : Closed e862484117958 ∧ code e862484117958 = 9658577140166 := by decide
theorem cert_e862484117958 : check e862484117958 [] .sourceHead = true := by decide
def e862486015418 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e862486015418 : Closed e862486015418 ∧ code e862486015418 = 9658579037626 := by decide
theorem cert_e862486015418 : check e862486015418 [] .sourceHead = true := by decide
def e862486015450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e862486015450 : Closed e862486015450 ∧ code e862486015450 = 9658579037658 := by decide
theorem cert_e862486015450 : check e862486015450 [] .sourceHead = true := by decide
def e862486015674 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e862486015674 : Closed e862486015674 ∧ code e862486015674 = 9658579037882 := by decide
theorem cert_e862486015674 : check e862486015674 [] .sourceHead = true := by decide
def e862486015722 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e862486015722 : Closed e862486015722 ∧ code e862486015722 = 9658579037930 := by decide
theorem cert_e862486015722 : check e862486015722 [] .sourceHead = true := by decide
def e862486015834 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e862486015834 : Closed e862486015834 ∧ code e862486015834 = 9658579038042 := by decide
theorem cert_e862486015834 : check e862486015834 [] .sourceHead = true := by decide
def e862486015850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e862486015850 : Closed e862486015850 ∧ code e862486015850 = 9658579038058 := by decide
theorem cert_e862486015850 : check e862486015850 [] .sourceHead = true := by decide
def e862486016954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e862486016954 : Closed e862486016954 ∧ code e862486016954 = 9658579039162 := by decide
theorem cert_e862486016954 : check e862486016954 [] .sourceHead = true := by decide
def e862486016986 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e862486016986 : Closed e862486016986 ∧ code e862486016986 = 9658579039194 := by decide
theorem cert_e862486016986 : check e862486016986 [] .sourceHead = true := by decide
def e862486018490 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e862486018490 : Closed e862486018490 ∧ code e862486018490 = 9658579040698 := by decide
theorem cert_e862486018490 : check e862486018490 [] .sourceHead = true := by decide
def e862486018538 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e862486018538 : Closed e862486018538 ∧ code e862486018538 = 9658579040746 := by decide
theorem cert_e862486018538 : check e862486018538 [] .sourceHead = true := by decide
def e862486019290 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e862486019290 : Closed e862486019290 ∧ code e862486019290 = 9658579041498 := by decide
theorem cert_e862486019290 : check e862486019290 [] .sourceHead = true := by decide
def e862486019306 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e862486019306 : Closed e862486019306 ∧ code e862486019306 = 9658579041514 := by decide
theorem cert_e862486019306 : check e862486019306 [] .sourceHead = true := by decide
def e862486072174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e862486072174 : Closed e862486072174 ∧ code e862486072174 = 9658579094382 := by decide
theorem cert_e862486072174 : check e862486072174 [] .sourceHead = true := by decide
def e862486072182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e862486072182 : Closed e862486072182 ∧ code e862486072182 = 9658579094390 := by decide
theorem cert_e862486072182 : check e862486072182 [] .sourceHead = true := by decide
def e862486072238 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e862486072238 : Closed e862486072238 ∧ code e862486072238 = 9658579094446 := by decide
theorem cert_e862486072238 : check e862486072238 [] .sourceHead = true := by decide
def e862486072250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e862486072250 : Closed e862486072250 ∧ code e862486072250 = 9658579094458 := by decide
theorem cert_e862486072250 : check e862486072250 [] .sourceHead = true := by decide
def e862486072278 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e862486072278 : Closed e862486072278 ∧ code e862486072278 = 9658579094486 := by decide
theorem cert_e862486072278 : check e862486072278 [] .sourceHead = true := by decide
def e862486072282 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e862486072282 : Closed e862486072282 ∧ code e862486072282 = 9658579094490 := by decide
theorem cert_e862486072282 : check e862486072282 [] .sourceHead = true := by decide
def e862486072558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e862486072558 : Closed e862486072558 ∧ code e862486072558 = 9658579094766 := by decide
theorem cert_e862486072558 : check e862486072558 [] .sourceHead = true := by decide
def e862486072566 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e862486072566 : Closed e862486072566 ∧ code e862486072566 = 9658579094774 := by decide
theorem cert_e862486072566 : check e862486072566 [] .sourceHead = true := by decide
def e862486072942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e862486072942 : Closed e862486072942 ∧ code e862486072942 = 9658579095150 := by decide
theorem cert_e862486072942 : check e862486072942 [] .sourceHead = true := by decide
def e862486072954 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e862486072954 : Closed e862486072954 ∧ code e862486072954 = 9658579095162 := by decide
theorem cert_e862486072954 : check e862486072954 [] .sourceHead = true := by decide
def e862486073142 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e862486073142 : Closed e862486073142 ∧ code e862486073142 = 9658579095350 := by decide
theorem cert_e862486073142 : check e862486073142 [] .sourceHead = true := by decide
def e862486073146 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e862486073146 : Closed e862486073146 ∧ code e862486073146 = 9658579095354 := by decide
theorem cert_e862486073146 : check e862486073146 [] .sourceHead = true := by decide
def e862486277598 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e862486277598 : Closed e862486277598 ∧ code e862486277598 = 9658579299806 := by decide
theorem cert_e862486277598 : check e862486277598 [] .sourceHead = true := by decide
def e862486277614 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e862486277614 : Closed e862486277614 ∧ code e862486277614 = 9658579299822 := by decide
theorem cert_e862486277614 : check e862486277614 [] .sourceHead = true := by decide
def e862486277982 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e862486277982 : Closed e862486277982 ∧ code e862486277982 = 9658579300190 := by decide
theorem cert_e862486277982 : check e862486277982 [] .sourceHead = true := by decide
def e862486278010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e862486278010 : Closed e862486278010 ∧ code e862486278010 = 9658579300218 := by decide
theorem cert_e862486278010 : check e862486278010 [] .sourceHead = true := by decide
def e862486278062 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e862486278062 : Closed e862486278062 ∧ code e862486278062 = 9658579300270 := by decide
theorem cert_e862486278062 : check e862486278062 [] .sourceHead = true := by decide
def e862486278074 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e862486278074 : Closed e862486278074 ∧ code e862486278074 = 9658579300282 := by decide
theorem cert_e862486278074 : check e862486278074 [] .sourceHead = true := by decide
def e862486279134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e862486279134 : Closed e862486279134 ∧ code e862486279134 = 9658579301342 := by decide
theorem cert_e862486279134 : check e862486279134 [] .sourceHead = true := by decide
def e862486279150 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e862486279150 : Closed e862486279150 ∧ code e862486279150 = 9658579301358 := by decide
theorem cert_e862486279150 : check e862486279150 [] .sourceHead = true := by decide
def e862486281438 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862486281438 : Closed e862486281438 ∧ code e862486281438 = 9658579303646 := by decide
theorem cert_e862486281438 : check e862486281438 [] .sourceHead = true := by decide
def e862486281466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862486281466 : Closed e862486281466 ∧ code e862486281466 = 9658579303674 := by decide
theorem cert_e862486281466 : check e862486281466 [] .sourceHead = true := by decide
def e862486281838 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862486281838 : Closed e862486281838 ∧ code e862486281838 = 9658579304046 := by decide
theorem cert_e862486281838 : check e862486281838 [] .sourceHead = true := by decide
def e862486281850 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862486281850 : Closed e862486281850 ∧ code e862486281850 = 9658579304058 := by decide
theorem cert_e862486281850 : check e862486281850 [] .sourceHead = true := by decide
def e862486310254 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e862486310254 : Closed e862486310254 ∧ code e862486310254 = 9658579332462 := by decide
theorem cert_e862486310254 : check e862486310254 [] .sourceHead = true := by decide
def e862486310262 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e862486310262 : Closed e862486310262 ∧ code e862486310262 = 9658579332470 := by decide
theorem cert_e862486310262 : check e862486310262 [] .sourceHead = true := by decide
def e862486310318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e862486310318 : Closed e862486310318 ∧ code e862486310318 = 9658579332526 := by decide
theorem cert_e862486310318 : check e862486310318 [] .sourceHead = true := by decide
def e862486310330 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e862486310330 : Closed e862486310330 ∧ code e862486310330 = 9658579332538 := by decide
theorem cert_e862486310330 : check e862486310330 [] .sourceHead = true := by decide
def e862486310358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e862486310358 : Closed e862486310358 ∧ code e862486310358 = 9658579332566 := by decide
theorem cert_e862486310358 : check e862486310358 [] .sourceHead = true := by decide
def e862486310362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e862486310362 : Closed e862486310362 ∧ code e862486310362 = 9658579332570 := by decide
theorem cert_e862486310362 : check e862486310362 [] .sourceHead = true := by decide
def e862486310574 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e862486310574 : Closed e862486310574 ∧ code e862486310574 = 9658579332782 := by decide
theorem cert_e862486310574 : check e862486310574 [] .sourceHead = true := by decide
def e862486310586 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e862486310586 : Closed e862486310586 ∧ code e862486310586 = 9658579332794 := by decide
theorem cert_e862486310586 : check e862486310586 [] .sourceHead = true := by decide
def e862486310634 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e862486310634 : Closed e862486310634 ∧ code e862486310634 = 9658579332842 := by decide
theorem cert_e862486310634 : check e862486310634 [] .sourceHead = true := by decide
def e862486310742 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e862486310742 : Closed e862486310742 ∧ code e862486310742 = 9658579332950 := by decide
theorem cert_e862486310742 : check e862486310742 [] .sourceHead = true := by decide
def e862486310746 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e862486310746 : Closed e862486310746 ∧ code e862486310746 = 9658579332954 := by decide
theorem cert_e862486310746 : check e862486310746 [] .sourceHead = true := by decide
def e862486310762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e862486310762 : Closed e862486310762 ∧ code e862486310762 = 9658579332970 := by decide
theorem cert_e862486310762 : check e862486310762 [] .sourceHead = true := by decide
def e862486311790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e862486311790 : Closed e862486311790 ∧ code e862486311790 = 9658579333998 := by decide
theorem cert_e862486311790 : check e862486311790 [] .sourceHead = true := by decide
def e862486311798 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e862486311798 : Closed e862486311798 ∧ code e862486311798 = 9658579334006 := by decide
theorem cert_e862486311798 : check e862486311798 [] .sourceHead = true := by decide
def e862486311854 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e862486311854 : Closed e862486311854 ∧ code e862486311854 = 9658579334062 := by decide
theorem cert_e862486311854 : check e862486311854 [] .sourceHead = true := by decide
def e862486311866 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e862486311866 : Closed e862486311866 ∧ code e862486311866 = 9658579334074 := by decide
theorem cert_e862486311866 : check e862486311866 [] .sourceHead = true := by decide
def e862486311894 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e862486311894 : Closed e862486311894 ∧ code e862486311894 = 9658579334102 := by decide
theorem cert_e862486311894 : check e862486311894 [] .sourceHead = true := by decide
def e862486311898 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e862486311898 : Closed e862486311898 ∧ code e862486311898 = 9658579334106 := by decide
theorem cert_e862486311898 : check e862486311898 [] .sourceHead = true := by decide
def e862486312174 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e862486312174 : Closed e862486312174 ∧ code e862486312174 = 9658579334382 := by decide
theorem cert_e862486312174 : check e862486312174 [] .sourceHead = true := by decide
def e862486312182 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e862486312182 : Closed e862486312182 ∧ code e862486312182 = 9658579334390 := by decide
theorem cert_e862486312182 : check e862486312182 [] .sourceHead = true := by decide
def e862486312558 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862486312558 : Closed e862486312558 ∧ code e862486312558 = 9658579334766 := by decide
theorem cert_e862486312558 : check e862486312558 [] .sourceHead = true := by decide
def e862486312570 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862486312570 : Closed e862486312570 ∧ code e862486312570 = 9658579334778 := by decide
theorem cert_e862486312570 : check e862486312570 [] .sourceHead = true := by decide
def e862486312758 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862486312758 : Closed e862486312758 ∧ code e862486312758 = 9658579334966 := by decide
theorem cert_e862486312758 : check e862486312758 [] .sourceHead = true := by decide
def e862486312762 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862486312762 : Closed e862486312762 ∧ code e862486312762 = 9658579334970 := by decide
theorem cert_e862486312762 : check e862486312762 [] .sourceHead = true := by decide
def e862486313390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e862486313390 : Closed e862486313390 ∧ code e862486313390 = 9658579335598 := by decide
theorem cert_e862486313390 : check e862486313390 [] .sourceHead = true := by decide
def e862486313402 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e862486313402 : Closed e862486313402 ∧ code e862486313402 = 9658579335610 := by decide
theorem cert_e862486313402 : check e862486313402 [] .sourceHead = true := by decide
def e862486313450 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e862486313450 : Closed e862486313450 ∧ code e862486313450 = 9658579335658 := by decide
theorem cert_e862486313450 : check e862486313450 [] .sourceHead = true := by decide
def e862486313582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e862486313582 : Closed e862486313582 ∧ code e862486313582 = 9658579335790 := by decide
theorem cert_e862486313582 : check e862486313582 [] .sourceHead = true := by decide
def e862486313594 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e862486313594 : Closed e862486313594 ∧ code e862486313594 = 9658579335802 := by decide
theorem cert_e862486313594 : check e862486313594 [] .sourceHead = true := by decide
def e862486313882 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862486313882 : Closed e862486313882 ∧ code e862486313882 = 9658579336090 := by decide
theorem cert_e862486313882 : check e862486313882 [] .sourceHead = true := by decide
def e862486314198 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e862486314198 : Closed e862486314198 ∧ code e862486314198 = 9658579336406 := by decide
theorem cert_e862486314198 : check e862486314198 [] .sourceHead = true := by decide
def e862486314202 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e862486314202 : Closed e862486314202 ∧ code e862486314202 = 9658579336410 := by decide
theorem cert_e862486314202 : check e862486314202 [] .sourceHead = true := by decide
def e862486314218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e862486314218 : Closed e862486314218 ∧ code e862486314218 = 9658579336426 := by decide
theorem cert_e862486314218 : check e862486314218 [] .sourceHead = true := by decide
def e862486314294 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e862486314294 : Closed e862486314294 ∧ code e862486314294 = 9658579336502 := by decide
theorem cert_e862486314294 : check e862486314294 [] .sourceHead = true := by decide
def e862486314298 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e862486314298 : Closed e862486314298 ∧ code e862486314298 = 9658579336506 := by decide
theorem cert_e862486314298 : check e862486314298 [] .sourceHead = true := by decide
def e862486314394 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e862486314394 : Closed e862486314394 ∧ code e862486314394 = 9658579336602 := by decide
theorem cert_e862486314394 : check e862486314394 [] .sourceHead = true := by decide
def e862486315998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e862486315998 : Closed e862486315998 ∧ code e862486315998 = 9658579338206 := by decide
theorem cert_e862486315998 : check e862486315998 [] .sourceHead = true := by decide
def e862486316014 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e862486316014 : Closed e862486316014 ∧ code e862486316014 = 9658579338222 := by decide
theorem cert_e862486316014 : check e862486316014 [] .sourceHead = true := by decide
def e862486317934 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862486317934 : Closed e862486317934 ∧ code e862486317934 = 9658579340142 := by decide
theorem cert_e862486317934 : check e862486317934 [] .sourceHead = true := by decide
def e862486317942 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862486317942 : Closed e862486317942 ∧ code e862486317942 = 9658579340150 := by decide
theorem cert_e862486317942 : check e862486317942 [] .sourceHead = true := by decide
def e862486317998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862486317998 : Closed e862486317998 ∧ code e862486317998 = 9658579340206 := by decide
theorem cert_e862486317998 : check e862486317998 [] .sourceHead = true := by decide
def e862486318010 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862486318010 : Closed e862486318010 ∧ code e862486318010 = 9658579340218 := by decide
theorem cert_e862486318010 : check e862486318010 [] .sourceHead = true := by decide
def e862486318038 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862486318038 : Closed e862486318038 ∧ code e862486318038 = 9658579340246 := by decide
theorem cert_e862486318038 : check e862486318038 [] .sourceHead = true := by decide
def e862486318042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862486318042 : Closed e862486318042 ∧ code e862486318042 = 9658579340250 := by decide
theorem cert_e862486318042 : check e862486318042 [] .sourceHead = true := by decide
def e862486318318 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862486318318 : Closed e862486318318 ∧ code e862486318318 = 9658579340526 := by decide
theorem cert_e862486318318 : check e862486318318 [] .sourceHead = true := by decide
def e862486318326 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862486318326 : Closed e862486318326 ∧ code e862486318326 = 9658579340534 := by decide
theorem cert_e862486318326 : check e862486318326 [] .sourceHead = true := by decide
def e862486318702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862486318702 : Closed e862486318702 ∧ code e862486318702 = 9658579340910 := by decide
theorem cert_e862486318702 : check e862486318702 [] .sourceHead = true := by decide
def e862486318714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862486318714 : Closed e862486318714 ∧ code e862486318714 = 9658579340922 := by decide
theorem cert_e862486318714 : check e862486318714 [] .sourceHead = true := by decide
def e862486318902 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862486318902 : Closed e862486318902 ∧ code e862486318902 = 9658579341110 := by decide
theorem cert_e862486318902 : check e862486318902 [] .sourceHead = true := by decide
def e862486318906 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862486318906 : Closed e862486318906 ∧ code e862486318906 = 9658579341114 := by decide
theorem cert_e862486318906 : check e862486318906 [] .sourceHead = true := by decide
def e862486323678 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e862486323678 : Closed e862486323678 ∧ code e862486323678 = 9658579345886 := by decide
theorem cert_e862486323678 : check e862486323678 [] .sourceHead = true := by decide
def e862486323702 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e862486323702 : Closed e862486323702 ∧ code e862486323702 = 9658579345910 := by decide
theorem cert_e862486323702 : check e862486323702 [] .sourceHead = true := by decide
def e862486324654 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e862486324654 : Closed e862486324654 ∧ code e862486324654 = 9658579346862 := by decide
theorem cert_e862486324654 : check e862486324654 [] .sourceHead = true := by decide
def e862486324666 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e862486324666 : Closed e862486324666 ∧ code e862486324666 = 9658579346874 := by decide
theorem cert_e862486324666 : check e862486324666 [] .sourceHead = true := by decide
def e862486324714 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e862486324714 : Closed e862486324714 ∧ code e862486324714 = 9658579346922 := by decide
theorem cert_e862486324714 : check e862486324714 [] .sourceHead = true := by decide
def e862486324846 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862486324846 : Closed e862486324846 ∧ code e862486324846 = 9658579347054 := by decide
theorem cert_e862486324846 : check e862486324846 [] .sourceHead = true := by decide
def e862486324858 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862486324858 : Closed e862486324858 ∧ code e862486324858 = 9658579347066 := by decide
theorem cert_e862486324858 : check e862486324858 [] .sourceHead = true := by decide
def e862486325146 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862486325146 : Closed e862486325146 ∧ code e862486325146 = 9658579347354 := by decide
theorem cert_e862486325146 : check e862486325146 [] .sourceHead = true := by decide
def e862486327534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e862486327534 : Closed e862486327534 ∧ code e862486327534 = 9658579349742 := by decide
theorem cert_e862486327534 : check e862486327534 [] .sourceHead = true := by decide
def e862486327542 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e862486327542 : Closed e862486327542 ∧ code e862486327542 = 9658579349750 := by decide
theorem cert_e862486327542 : check e862486327542 [] .sourceHead = true := by decide
def e862486328022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e862486328022 : Closed e862486328022 ∧ code e862486328022 = 9658579350230 := by decide
theorem cert_e862486328022 : check e862486328022 [] .sourceHead = true := by decide
def e862486328026 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e862486328026 : Closed e862486328026 ∧ code e862486328026 = 9658579350234 := by decide
theorem cert_e862486328026 : check e862486328026 [] .sourceHead = true := by decide
def e862486328042 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e862486328042 : Closed e862486328042 ∧ code e862486328042 = 9658579350250 := by decide
theorem cert_e862486328042 : check e862486328042 [] .sourceHead = true := by decide
def e862486328118 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862486328118 : Closed e862486328118 ∧ code e862486328118 = 9658579350326 := by decide
theorem cert_e862486328118 : check e862486328118 [] .sourceHead = true := by decide
def e862486328122 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862486328122 : Closed e862486328122 ∧ code e862486328122 = 9658579350330 := by decide
theorem cert_e862486328122 : check e862486328122 [] .sourceHead = true := by decide
def e862486328218 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e862486328218 : Closed e862486328218 ∧ code e862486328218 = 9658579350426 := by decide
theorem cert_e862486328218 : check e862486328218 [] .sourceHead = true := by decide
def e862486465390 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e862486465390 : Closed e862486465390 ∧ code e862486465390 = 9658579487598 := by decide
theorem cert_e862486465390 : check e862486465390 [] .sourceHead = true := by decide
def e862486465398 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e862486465398 : Closed e862486465398 ∧ code e862486465398 = 9658579487606 := by decide
theorem cert_e862486465398 : check e862486465398 [] .sourceHead = true := by decide
def e862486465454 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e862486465454 : Closed e862486465454 ∧ code e862486465454 = 9658579487662 := by decide
theorem cert_e862486465454 : check e862486465454 [] .sourceHead = true := by decide
def e862486465466 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e862486465466 : Closed e862486465466 ∧ code e862486465466 = 9658579487674 := by decide
theorem cert_e862486465466 : check e862486465466 [] .sourceHead = true := by decide
def e862486465494 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e862486465494 : Closed e862486465494 ∧ code e862486465494 = 9658579487702 := by decide
theorem cert_e862486465494 : check e862486465494 [] .sourceHead = true := by decide
def e862486465498 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e862486465498 : Closed e862486465498 ∧ code e862486465498 = 9658579487706 := by decide
theorem cert_e862486465498 : check e862486465498 [] .sourceHead = true := by decide
def e862486465774 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e862486465774 : Closed e862486465774 ∧ code e862486465774 = 9658579487982 := by decide
theorem cert_e862486465774 : check e862486465774 [] .sourceHead = true := by decide
def e862486465782 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e862486465782 : Closed e862486465782 ∧ code e862486465782 = 9658579487990 := by decide
theorem cert_e862486465782 : check e862486465782 [] .sourceHead = true := by decide
def e862486466158 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e862486466158 : Closed e862486466158 ∧ code e862486466158 = 9658579488366 := by decide
theorem cert_e862486466158 : check e862486466158 [] .sourceHead = true := by decide
def e862486466170 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e862486466170 : Closed e862486466170 ∧ code e862486466170 = 9658579488378 := by decide
theorem cert_e862486466170 : check e862486466170 [] .sourceHead = true := by decide
def e862486466358 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862486466358 : Closed e862486466358 ∧ code e862486466358 = 9658579488566 := by decide
theorem cert_e862486466358 : check e862486466358 [] .sourceHead = true := by decide
def e862486466362 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862486466362 : Closed e862486466362 ∧ code e862486466362 = 9658579488570 := by decide
theorem cert_e862486466362 : check e862486466362 [] .sourceHead = true := by decide
def e862486795998 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e862486795998 : Closed e862486795998 ∧ code e862486795998 = 9658579818206 := by decide
theorem cert_e862486795998 : check e862486795998 [] .sourceHead = true := by decide
def e862486796022 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e862486796022 : Closed e862486796022 ∧ code e862486796022 = 9658579818230 := by decide
theorem cert_e862486796022 : check e862486796022 [] .sourceHead = true := by decide
def e862486796126 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e862486796126 : Closed e862486796126 ∧ code e862486796126 = 9658579818334 := by decide
theorem cert_e862486796126 : check e862486796126 [] .sourceHead = true := by decide
def e862486796154 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e862486796154 : Closed e862486796154 ∧ code e862486796154 = 9658579818362 := by decide
theorem cert_e862486796154 : check e862486796154 [] .sourceHead = true := by decide
def e862486796246 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e862486796246 : Closed e862486796246 ∧ code e862486796246 = 9658579818454 := by decide
theorem cert_e862486796246 : check e862486796246 [] .sourceHead = true := by decide
def e862486796250 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e862486796250 : Closed e862486796250 ∧ code e862486796250 = 9658579818458 := by decide
theorem cert_e862486796250 : check e862486796250 [] .sourceHead = true := by decide
def e862486796766 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e862486796766 : Closed e862486796766 ∧ code e862486796766 = 9658579818974 := by decide
theorem cert_e862486796766 : check e862486796766 [] .sourceHead = true := by decide
def e862486796790 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e862486796790 : Closed e862486796790 ∧ code e862486796790 = 9658579818998 := by decide
theorem cert_e862486796790 : check e862486796790 [] .sourceHead = true := by decide
def e862486797534 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e862486797534 : Closed e862486797534 ∧ code e862486797534 = 9658579819742 := by decide
theorem cert_e862486797534 : check e862486797534 [] .sourceHead = true := by decide
def e862486797562 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e862486797562 : Closed e862486797562 ∧ code e862486797562 = 9658579819770 := by decide
theorem cert_e862486797562 : check e862486797562 [] .sourceHead = true := by decide
def e862486798134 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e862486798134 : Closed e862486798134 ∧ code e862486798134 = 9658579820342 := by decide
theorem cert_e862486798134 : check e862486798134 [] .sourceHead = true := by decide
def e862486798138 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e862486798138 : Closed e862486798138 ∧ code e862486798138 = 9658579820346 := by decide
theorem cert_e862486798138 : check e862486798138 [] .sourceHead = true := by decide
def e862486812910 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e862486812910 : Closed e862486812910 ∧ code e862486812910 = 9658579835118 := by decide
theorem cert_e862486812910 : check e862486812910 [] .sourceHead = true := by decide
def e862486812918 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e862486812918 : Closed e862486812918 ∧ code e862486812918 = 9658579835126 := by decide
theorem cert_e862486812918 : check e862486812918 [] .sourceHead = true := by decide
def e862486813470 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e862486813470 : Closed e862486813470 ∧ code e862486813470 = 9658579835678 := by decide
theorem cert_e862486813470 : check e862486813470 [] .sourceHead = true := by decide
def e862486813582 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e862486813582 : Closed e862486813582 ∧ code e862486813582 = 9658579835790 := by decide
theorem cert_e862486813582 : check e862486813582 [] .sourceHead = true := by decide
def e862486813806 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e862486813806 : Closed e862486813806 ∧ code e862486813806 = 9658579836014 := by decide
theorem cert_e862486813806 : check e862486813806 [] .sourceHead = true := by decide
def e862486813818 : Term := (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e862486813818 : Closed e862486813818 ∧ code e862486813818 = 9658579836026 := by decide
theorem cert_e862486813818 : check e862486813818 [] .sourceHead = true := by decide
end Blc.Floor43
