import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406200418422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200418422 : Closed e2406200418422 ∧ code e2406200418422 = 11202293440630 := by decide
theorem cert_e2406200418422 : check e2406200418422 [[]] .width = true := by decide
def e2406200418666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200418666 : Closed e2406200418666 ∧ code e2406200418666 = 11202293440874 := by decide
theorem cert_e2406200418666 : check e2406200418666 [[]] .width = true := by decide
def e2406200418714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200418714 : Closed e2406200418714 ∧ code e2406200418714 = 11202293440922 := by decide
theorem cert_e2406200418714 : check e2406200418714 [[]] .width = true := by decide
def e2406200430790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406200430790 : Closed e2406200430790 ∧ code e2406200430790 = 11202293452998 := by decide
theorem cert_e2406200430790 : check e2406200430790 [[]] .width = true := by decide
def e2406200432666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200432666 : Closed e2406200432666 ∧ code e2406200432666 = 11202293454874 := by decide
theorem cert_e2406200432666 : check e2406200432666 [[]] .width = true := by decide
def e2406200436762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200436762 : Closed e2406200436762 ∧ code e2406200436762 = 11202293458970 := by decide
theorem cert_e2406200436762 : check e2406200436762 [[]] .width = true := by decide
def e2406200485914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200485914 : Closed e2406200485914 ∧ code e2406200485914 = 11202293508122 := by decide
theorem cert_e2406200485914 : check e2406200485914 [[]] .width = true := by decide
def e2406200487450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200487450 : Closed e2406200487450 ∧ code e2406200487450 = 11202293509658 := by decide
theorem cert_e2406200487450 : check e2406200487450 [[]] .width = true := by decide
def e2406200490522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200490522 : Closed e2406200490522 ∧ code e2406200490522 = 11202293512730 := by decide
theorem cert_e2406200490522 : check e2406200490522 [[]] .width = true := by decide
def e2406200502810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200502810 : Closed e2406200502810 ∧ code e2406200502810 = 11202293525018 := by decide
theorem cert_e2406200502810 : check e2406200502810 [[]] .width = true := by decide
def e2406200510490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200510490 : Closed e2406200510490 ∧ code e2406200510490 = 11202293532698 := by decide
theorem cert_e2406200510490 : check e2406200510490 [[]] .width = true := by decide
def e2406200516634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200516634 : Closed e2406200516634 ∧ code e2406200516634 = 11202293538842 := by decide
theorem cert_e2406200516634 : check e2406200516634 [[]] .width = true := by decide
def e2406200516726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200516726 : Closed e2406200516726 ∧ code e2406200516726 = 11202293538934 := by decide
theorem cert_e2406200516726 : check e2406200516726 [[]] .width = true := by decide
def e2406200516970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200516970 : Closed e2406200516970 ∧ code e2406200516970 = 11202293539178 := by decide
theorem cert_e2406200516970 : check e2406200516970 [[]] .width = true := by decide
def e2406200517018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200517018 : Closed e2406200517018 ∧ code e2406200517018 = 11202293539226 := by decide
theorem cert_e2406200517018 : check e2406200517018 [[]] .width = true := by decide
def e2406200520902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406200520902 : Closed e2406200520902 ∧ code e2406200520902 = 11202293543110 := by decide
theorem cert_e2406200520902 : check e2406200520902 [[]] .width = true := by decide
def e2406200522778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200522778 : Closed e2406200522778 ∧ code e2406200522778 = 11202293544986 := by decide
theorem cert_e2406200522778 : check e2406200522778 [[]] .width = true := by decide
def e2406200535066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200535066 : Closed e2406200535066 ∧ code e2406200535066 = 11202293557274 := by decide
theorem cert_e2406200535066 : check e2406200535066 [[]] .width = true := by decide
def e2406200536602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200536602 : Closed e2406200536602 ∧ code e2406200536602 = 11202293558810 := by decide
theorem cert_e2406200536602 : check e2406200536602 [[]] .width = true := by decide
def e2406200539674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200539674 : Closed e2406200539674 ∧ code e2406200539674 = 11202293561882 := by decide
theorem cert_e2406200539674 : check e2406200539674 [[]] .width = true := by decide
def e2406200541210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406200541210 : Closed e2406200541210 ∧ code e2406200541210 = 11202293563418 := by decide
theorem cert_e2406200541210 : check e2406200541210 [[]] .width = true := by decide
def e2406200541302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406200541302 : Closed e2406200541302 ∧ code e2406200541302 = 11202293563510 := by decide
theorem cert_e2406200541302 : check e2406200541302 [[]] .width = true := by decide
def e2406200541546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406200541546 : Closed e2406200541546 ∧ code e2406200541546 = 11202293563754 := by decide
theorem cert_e2406200541546 : check e2406200541546 [[]] .width = true := by decide
def e2406200541594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406200541594 : Closed e2406200541594 ∧ code e2406200541594 = 11202293563802 := by decide
theorem cert_e2406200541594 : check e2406200541594 [[]] .width = true := by decide
def e2406200542602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406200542602 : Closed e2406200542602 ∧ code e2406200542602 = 11202293564810 := by decide
theorem cert_e2406200542602 : check e2406200542602 [[]] .width = true := by decide
def e2406200542626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406200542626 : Closed e2406200542626 ∧ code e2406200542626 = 11202293564834 := by decide
theorem cert_e2406200542626 : check e2406200542626 [[]] .width = true := by decide
def e2406200542734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406200542734 : Closed e2406200542734 ∧ code e2406200542734 = 11202293564942 := by decide
theorem cert_e2406200542734 : check e2406200542734 [[]] .width = true := by decide
def e2406200542746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200542746 : Closed e2406200542746 ∧ code e2406200542746 = 11202293564954 := by decide
theorem cert_e2406200542746 : check e2406200542746 [[]] .width = true := by decide
def e2406200542818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406200542818 : Closed e2406200542818 ∧ code e2406200542818 = 11202293565026 := by decide
theorem cert_e2406200542818 : check e2406200542818 [[]] .width = true := by decide
def e2406200557766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406200557766 : Closed e2406200557766 ∧ code e2406200557766 = 11202293579974 := by decide
theorem cert_e2406200557766 : check e2406200557766 [[]] .width = true := by decide
def e2406200565786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200565786 : Closed e2406200565786 ∧ code e2406200565786 = 11202293587994 := by decide
theorem cert_e2406200565786 : check e2406200565786 [[]] .width = true := by decide
def e2406200565878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200565878 : Closed e2406200565878 ∧ code e2406200565878 = 11202293588086 := by decide
theorem cert_e2406200565878 : check e2406200565878 [[]] .width = true := by decide
def e2406200566122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200566122 : Closed e2406200566122 ∧ code e2406200566122 = 11202293588330 := by decide
theorem cert_e2406200566122 : check e2406200566122 [[]] .width = true := by decide
def e2406200566170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200566170 : Closed e2406200566170 ∧ code e2406200566170 = 11202293588378 := by decide
theorem cert_e2406200566170 : check e2406200566170 [[]] .width = true := by decide
def e2406200580122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406200580122 : Closed e2406200580122 ∧ code e2406200580122 = 11202293602330 := by decide
theorem cert_e2406200580122 : check e2406200580122 [[]] .width = true := by decide
def e2406200590534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406200590534 : Closed e2406200590534 ∧ code e2406200590534 = 11202293612742 := by decide
theorem cert_e2406200590534 : check e2406200590534 [[]] .width = true := by decide
def e2406200613402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200613402 : Closed e2406200613402 ∧ code e2406200613402 = 11202293635610 := by decide
private def t_e2406200613402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406200613402 : ¬ IsSelfInterpreter e2406200613402 :=
  wSource (t := t_e2406200613402) (replay_sound (ps := []) (t := e2406200613402) (by decide)) (by decide)
def e2406200614938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200614938 : Closed e2406200614938 ∧ code e2406200614938 = 11202293637146 := by decide
theorem cert_e2406200614938 : check e2406200614938 [[]] .width = true := by decide
def e2406200615030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200615030 : Closed e2406200615030 ∧ code e2406200615030 = 11202293637238 := by decide
private def t_e2406200615030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2406200615030 : ¬ IsSelfInterpreter e2406200615030 :=
  wSource (t := t_e2406200615030) (replay_sound (ps := []) (t := e2406200615030) (by decide)) (by decide)
def e2406200615274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200615274 : Closed e2406200615274 ∧ code e2406200615274 = 11202293637482 := by decide
private def t_e2406200615274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2406200615274 : ¬ IsSelfInterpreter e2406200615274 :=
  wSource (t := t_e2406200615274) (replay_sound (ps := []) (t := e2406200615274) (by decide)) (by decide)
def e2406200615322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200615322 : Closed e2406200615322 ∧ code e2406200615322 = 11202293637530 := by decide
private def t_e2406200615322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2406200615322 : ¬ IsSelfInterpreter e2406200615322 :=
  wSource (t := t_e2406200615322) (replay_sound (ps := []) (t := e2406200615322) (by decide)) (by decide)
def e2406200694298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200694298 : Closed e2406200694298 ∧ code e2406200694298 = 11202293716506 := by decide
theorem cert_e2406200694298 : check e2406200694298 [[]] .width = true := by decide
def e2406200695322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200695322 : Closed e2406200695322 ∧ code e2406200695322 = 11202293717530 := by decide
theorem cert_e2406200695322 : check e2406200695322 [[]] .width = true := by decide
def e2406200699418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200699418 : Closed e2406200699418 ∧ code e2406200699418 = 11202293721626 := by decide
theorem cert_e2406200699418 : check e2406200699418 [[]] .width = true := by decide
def e2406200718874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200718874 : Closed e2406200718874 ∧ code e2406200718874 = 11202293741082 := by decide
theorem cert_e2406200718874 : check e2406200718874 [[]] .width = true := by decide
def e2406200719898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200719898 : Closed e2406200719898 ∧ code e2406200719898 = 11202293742106 := by decide
theorem cert_e2406200719898 : check e2406200719898 [[]] .width = true := by decide
def e2406200729626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200729626 : Closed e2406200729626 ∧ code e2406200729626 = 11202293751834 := by decide
theorem cert_e2406200729626 : check e2406200729626 [[]] .width = true := by decide
def e2406200729718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200729718 : Closed e2406200729718 ∧ code e2406200729718 = 11202293751926 := by decide
theorem cert_e2406200729718 : check e2406200729718 [[]] .width = true := by decide
def e2406200729962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200729962 : Closed e2406200729962 ∧ code e2406200729962 = 11202293752170 := by decide
theorem cert_e2406200729962 : check e2406200729962 [[]] .width = true := by decide
def e2406200730010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200730010 : Closed e2406200730010 ∧ code e2406200730010 = 11202293752218 := by decide
theorem cert_e2406200730010 : check e2406200730010 [[]] .width = true := by decide
def e2406200744474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406200744474 : Closed e2406200744474 ∧ code e2406200744474 = 11202293766682 := by decide
private def t_e2406200744474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406200744474 : ¬ IsSelfInterpreter e2406200744474 :=
  wSource (t := t_e2406200744474) (replay_sound (ps := []) (t := e2406200744474) (by decide)) (by decide)
def e2406200746010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406200746010 : Closed e2406200746010 ∧ code e2406200746010 = 11202293768218 := by decide
theorem cert_e2406200746010 : check e2406200746010 [[]] .width = true := by decide
def e2406200746102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406200746102 : Closed e2406200746102 ∧ code e2406200746102 = 11202293768310 := by decide
private def t_e2406200746102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2406200746102 : ¬ IsSelfInterpreter e2406200746102 :=
  wSource (t := t_e2406200746102) (replay_sound (ps := []) (t := e2406200746102) (by decide)) (by decide)
def e2406200746346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406200746346 : Closed e2406200746346 ∧ code e2406200746346 = 11202293768554 := by decide
private def t_e2406200746346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2406200746346 : ¬ IsSelfInterpreter e2406200746346 :=
  wSource (t := t_e2406200746346) (replay_sound (ps := []) (t := e2406200746346) (by decide)) (by decide)
def e2406200746394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406200746394 : Closed e2406200746394 ∧ code e2406200746394 = 11202293768602 := by decide
private def t_e2406200746394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2406200746394 : ¬ IsSelfInterpreter e2406200746394 :=
  wSource (t := t_e2406200746394) (replay_sound (ps := []) (t := e2406200746394) (by decide)) (by decide)
def e2406201024538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201024538 : Closed e2406201024538 ∧ code e2406201024538 = 11202294046746 := by decide
theorem cert_e2406201024538 : check e2406201024538 [[]] .width = true := by decide
def e2406201024630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406201024630 : Closed e2406201024630 ∧ code e2406201024630 = 11202294046838 := by decide
theorem cert_e2406201024630 : check e2406201024630 [[]] .width = true := by decide
def e2406201024874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406201024874 : Closed e2406201024874 ∧ code e2406201024874 = 11202294047082 := by decide
theorem cert_e2406201024874 : check e2406201024874 [[]] .width = true := by decide
def e2406201024922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406201024922 : Closed e2406201024922 ∧ code e2406201024922 = 11202294047130 := by decide
theorem cert_e2406201024922 : check e2406201024922 [[]] .width = true := by decide
def e2406201127110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406201127110 : Closed e2406201127110 ∧ code e2406201127110 = 11202294149318 := by decide
theorem cert_e2406201127110 : check e2406201127110 [[]] .width = true := by decide
def e2406201145370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201145370 : Closed e2406201145370 ∧ code e2406201145370 = 11202294167578 := by decide
theorem cert_e2406201145370 : check e2406201145370 [[]] .width = true := by decide
def e2406201151686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406201151686 : Closed e2406201151686 ∧ code e2406201151686 = 11202294173894 := by decide
theorem cert_e2406201151686 : check e2406201151686 [[]] .width = true := by decide
def e2406201153562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201153562 : Closed e2406201153562 ∧ code e2406201153562 = 11202294175770 := by decide
theorem cert_e2406201153562 : check e2406201153562 [[]] .width = true := by decide
def e2406201155098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201155098 : Closed e2406201155098 ∧ code e2406201155098 = 11202294177306 := by decide
theorem cert_e2406201155098 : check e2406201155098 [[]] .width = true := by decide
def e2406201159194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201159194 : Closed e2406201159194 ∧ code e2406201159194 = 11202294181402 := by decide
theorem cert_e2406201159194 : check e2406201159194 [[]] .width = true := by decide
def e2406201360582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406201360582 : Closed e2406201360582 ∧ code e2406201360582 = 11202294382790 := by decide
theorem cert_e2406201360582 : check e2406201360582 [[]] .width = true := by decide
def e2406201361110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2406201361110 : Closed e2406201361110 ∧ code e2406201361110 = 11202294383318 := by decide
theorem cert_e2406201361110 : check e2406201361110 [[]] .width = true := by decide
def e2406201361114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2406201361114 : Closed e2406201361114 ∧ code e2406201361114 = 11202294383322 := by decide
theorem cert_e2406201361114 : check e2406201361114 [[]] .width = true := by decide
def e2406201361130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2406201361130 : Closed e2406201361130 ∧ code e2406201361130 = 11202294383338 := by decide
theorem cert_e2406201361130 : check e2406201361130 [[]] .width = true := by decide
def e2406201361206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2406201361206 : Closed e2406201361206 ∧ code e2406201361206 = 11202294383414 := by decide
theorem cert_e2406201361206 : check e2406201361206 [[]] .width = true := by decide
def e2406201361210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2406201361210 : Closed e2406201361210 ∧ code e2406201361210 = 11202294383418 := by decide
theorem cert_e2406201361210 : check e2406201361210 [[]] .width = true := by decide
def e2406201361294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2406201361294 : Closed e2406201361294 ∧ code e2406201361294 = 11202294383502 := by decide
theorem cert_e2406201361294 : check e2406201361294 [[]] .width = true := by decide
def e2406201361306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2406201361306 : Closed e2406201361306 ∧ code e2406201361306 = 11202294383514 := by decide
theorem cert_e2406201361306 : check e2406201361306 [[]] .width = true := by decide
def e2406201363226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2406201363226 : Closed e2406201363226 ∧ code e2406201363226 = 11202294385434 := by decide
theorem cert_e2406201363226 : check e2406201363226 [[]] .width = true := by decide
def e2406201363270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2406201363270 : Closed e2406201363270 ∧ code e2406201363270 = 11202294385478 := by decide
theorem cert_e2406201363270 : check e2406201363270 [[]] .width = true := by decide
def e2406201363510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2406201363510 : Closed e2406201363510 ∧ code e2406201363510 = 11202294385718 := by decide
theorem cert_e2406201363510 : check e2406201363510 [[]] .width = true := by decide
def e2406201363514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2406201363514 : Closed e2406201363514 ∧ code e2406201363514 = 11202294385722 := by decide
theorem cert_e2406201363514 : check e2406201363514 [[]] .width = true := by decide
def e2406201363654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406201363654 : Closed e2406201363654 ∧ code e2406201363654 = 11202294385862 := by decide
theorem cert_e2406201363654 : check e2406201363654 [[]] .width = true := by decide
def e2406201645082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201645082 : Closed e2406201645082 ∧ code e2406201645082 = 11202294667290 := by decide
theorem cert_e2406201645082 : check e2406201645082 [[]] .width = true := by decide
def e2406201649178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201649178 : Closed e2406201649178 ∧ code e2406201649178 = 11202294671386 := by decide
theorem cert_e2406201649178 : check e2406201649178 [[]] .width = true := by decide
def e2406201650714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201650714 : Closed e2406201650714 ∧ code e2406201650714 = 11202294672922 := by decide
theorem cert_e2406201650714 : check e2406201650714 [[]] .width = true := by decide
def e2406201652762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201652762 : Closed e2406201652762 ∧ code e2406201652762 = 11202294674970 := by decide
theorem cert_e2406201652762 : check e2406201652762 [[]] .width = true := by decide
def e2406201665562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201665562 : Closed e2406201665562 ∧ code e2406201665562 = 11202294687770 := by decide
theorem cert_e2406201665562 : check e2406201665562 [[]] .width = true := by decide
def e2406201667098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201667098 : Closed e2406201667098 ∧ code e2406201667098 = 11202294689306 := by decide
theorem cert_e2406201667098 : check e2406201667098 [[]] .width = true := by decide
def e2406201670170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201670170 : Closed e2406201670170 ∧ code e2406201670170 = 11202294692378 := by decide
theorem cert_e2406201670170 : check e2406201670170 [[]] .width = true := by decide
def e2406201677338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201677338 : Closed e2406201677338 ∧ code e2406201677338 = 11202294699546 := by decide
theorem cert_e2406201677338 : check e2406201677338 [[]] .width = true := by decide
def e2406201678362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201678362 : Closed e2406201678362 ∧ code e2406201678362 = 11202294700570 := by decide
theorem cert_e2406201678362 : check e2406201678362 [[]] .width = true := by decide
def e2406201716934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406201716934 : Closed e2406201716934 ∧ code e2406201716934 = 11202294739142 := by decide
theorem cert_e2406201716934 : check e2406201716934 [[]] .width = true := by decide
def e2406201743386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201743386 : Closed e2406201743386 ∧ code e2406201743386 = 11202294765594 := by decide
theorem cert_e2406201743386 : check e2406201743386 [[]] .width = true := by decide
def e2406201747482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201747482 : Closed e2406201747482 ∧ code e2406201747482 = 11202294769690 := by decide
theorem cert_e2406201747482 : check e2406201747482 [[]] .width = true := by decide
def e2406201749018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201749018 : Closed e2406201749018 ∧ code e2406201749018 = 11202294771226 := by decide
theorem cert_e2406201749018 : check e2406201749018 [[]] .width = true := by decide
def e2406201751066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201751066 : Closed e2406201751066 ∧ code e2406201751066 = 11202294773274 := by decide
theorem cert_e2406201751066 : check e2406201751066 [[]] .width = true := by decide
def e2406201786394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406201786394 : Closed e2406201786394 ∧ code e2406201786394 = 11202294808602 := by decide
theorem cert_e2406201786394 : check e2406201786394 [[]] .width = true := by decide
def e2406201786486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406201786486 : Closed e2406201786486 ∧ code e2406201786486 = 11202294808694 := by decide
theorem cert_e2406201786486 : check e2406201786486 [[]] .width = true := by decide
def e2406201786730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406201786730 : Closed e2406201786730 ∧ code e2406201786730 = 11202294808938 := by decide
theorem cert_e2406201786730 : check e2406201786730 [[]] .width = true := by decide
def e2406201786778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406201786778 : Closed e2406201786778 ∧ code e2406201786778 = 11202294808986 := by decide
theorem cert_e2406201786778 : check e2406201786778 [[]] .width = true := by decide
def e2406201787786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406201787786 : Closed e2406201787786 ∧ code e2406201787786 = 11202294809994 := by decide
theorem cert_e2406201787786 : check e2406201787786 [[]] .width = true := by decide
def e2406201787810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406201787810 : Closed e2406201787810 ∧ code e2406201787810 = 11202294810018 := by decide
theorem cert_e2406201787810 : check e2406201787810 [[]] .width = true := by decide
def e2406201787918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406201787918 : Closed e2406201787918 ∧ code e2406201787918 = 11202294810126 := by decide
theorem cert_e2406201787918 : check e2406201787918 [[]] .width = true := by decide
def e2406201787930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201787930 : Closed e2406201787930 ∧ code e2406201787930 = 11202294810138 := by decide
theorem cert_e2406201787930 : check e2406201787930 [[]] .width = true := by decide
def e2406201788002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406201788002 : Closed e2406201788002 ∧ code e2406201788002 = 11202294810210 := by decide
theorem cert_e2406201788002 : check e2406201788002 [[]] .width = true := by decide
def e2406201821210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201821210 : Closed e2406201821210 ∧ code e2406201821210 = 11202294843418 := by decide
theorem cert_e2406201821210 : check e2406201821210 [[]] .width = true := by decide
def e2406201827354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201827354 : Closed e2406201827354 ∧ code e2406201827354 = 11202294849562 := by decide
theorem cert_e2406201827354 : check e2406201827354 [[]] .width = true := by decide
def e2406201827446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406201827446 : Closed e2406201827446 ∧ code e2406201827446 = 11202294849654 := by decide
theorem cert_e2406201827446 : check e2406201827446 [[]] .width = true := by decide
def e2406201827690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406201827690 : Closed e2406201827690 ∧ code e2406201827690 = 11202294849898 := by decide
theorem cert_e2406201827690 : check e2406201827690 [[]] .width = true := by decide
def e2406201827738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406201827738 : Closed e2406201827738 ∧ code e2406201827738 = 11202294849946 := by decide
theorem cert_e2406201827738 : check e2406201827738 [[]] .width = true := by decide
def e2406201831622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406201831622 : Closed e2406201831622 ∧ code e2406201831622 = 11202294853830 := by decide
theorem cert_e2406201831622 : check e2406201831622 [[]] .width = true := by decide
def e2406201833498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201833498 : Closed e2406201833498 ∧ code e2406201833498 = 11202294855706 := by decide
theorem cert_e2406201833498 : check e2406201833498 [[]] .width = true := by decide
def e2406201845786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406201845786 : Closed e2406201845786 ∧ code e2406201845786 = 11202294867994 := by decide
theorem cert_e2406201845786 : check e2406201845786 [[]] .width = true := by decide
def e2406201847322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201847322 : Closed e2406201847322 ∧ code e2406201847322 = 11202294869530 := by decide
theorem cert_e2406201847322 : check e2406201847322 [[]] .width = true := by decide
def e2406201850394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201850394 : Closed e2406201850394 ∧ code e2406201850394 = 11202294872602 := by decide
theorem cert_e2406201850394 : check e2406201850394 [[]] .width = true := by decide
def e2406201851930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406201851930 : Closed e2406201851930 ∧ code e2406201851930 = 11202294874138 := by decide
theorem cert_e2406201851930 : check e2406201851930 [[]] .width = true := by decide
def e2406201852022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406201852022 : Closed e2406201852022 ∧ code e2406201852022 = 11202294874230 := by decide
theorem cert_e2406201852022 : check e2406201852022 [[]] .width = true := by decide
def e2406201852266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406201852266 : Closed e2406201852266 ∧ code e2406201852266 = 11202294874474 := by decide
theorem cert_e2406201852266 : check e2406201852266 [[]] .width = true := by decide
def e2406201852314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406201852314 : Closed e2406201852314 ∧ code e2406201852314 = 11202294874522 := by decide
theorem cert_e2406201852314 : check e2406201852314 [[]] .width = true := by decide
def e2406201853322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406201853322 : Closed e2406201853322 ∧ code e2406201853322 = 11202294875530 := by decide
theorem cert_e2406201853322 : check e2406201853322 [[]] .width = true := by decide
def e2406201853346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406201853346 : Closed e2406201853346 ∧ code e2406201853346 = 11202294875554 := by decide
theorem cert_e2406201853346 : check e2406201853346 [[]] .width = true := by decide
def e2406201853454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406201853454 : Closed e2406201853454 ∧ code e2406201853454 = 11202294875662 := by decide
theorem cert_e2406201853454 : check e2406201853454 [[]] .width = true := by decide
def e2406201853466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201853466 : Closed e2406201853466 ∧ code e2406201853466 = 11202294875674 := by decide
theorem cert_e2406201853466 : check e2406201853466 [[]] .width = true := by decide
def e2406201853538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406201853538 : Closed e2406201853538 ∧ code e2406201853538 = 11202294875746 := by decide
theorem cert_e2406201853538 : check e2406201853538 [[]] .width = true := by decide
def e2406201868486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406201868486 : Closed e2406201868486 ∧ code e2406201868486 = 11202294890694 := by decide
theorem cert_e2406201868486 : check e2406201868486 [[]] .width = true := by decide
def e2406201876506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201876506 : Closed e2406201876506 ∧ code e2406201876506 = 11202294898714 := by decide
theorem cert_e2406201876506 : check e2406201876506 [[]] .width = true := by decide
def e2406201876598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406201876598 : Closed e2406201876598 ∧ code e2406201876598 = 11202294898806 := by decide
theorem cert_e2406201876598 : check e2406201876598 [[]] .width = true := by decide
def e2406201876842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406201876842 : Closed e2406201876842 ∧ code e2406201876842 = 11202294899050 := by decide
theorem cert_e2406201876842 : check e2406201876842 [[]] .width = true := by decide
def e2406201876890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406201876890 : Closed e2406201876890 ∧ code e2406201876890 = 11202294899098 := by decide
theorem cert_e2406201876890 : check e2406201876890 [[]] .width = true := by decide
def e2406201898522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201898522 : Closed e2406201898522 ∧ code e2406201898522 = 11202294920730 := by decide
theorem cert_e2406201898522 : check e2406201898522 [[]] .width = true := by decide
def e2406201899546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406201899546 : Closed e2406201899546 ∧ code e2406201899546 = 11202294921754 := by decide
theorem cert_e2406201899546 : check e2406201899546 [[]] .width = true := by decide
def e2406201909274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406201909274 : Closed e2406201909274 ∧ code e2406201909274 = 11202294931482 := by decide
theorem cert_e2406201909274 : check e2406201909274 [[]] .width = true := by decide
def e2406201909366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406201909366 : Closed e2406201909366 ∧ code e2406201909366 = 11202294931574 := by decide
theorem cert_e2406201909366 : check e2406201909366 [[]] .width = true := by decide
def e2406201909610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406201909610 : Closed e2406201909610 ∧ code e2406201909610 = 11202294931818 := by decide
theorem cert_e2406201909610 : check e2406201909610 [[]] .width = true := by decide
def e2406201909658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406201909658 : Closed e2406201909658 ∧ code e2406201909658 = 11202294931866 := by decide
theorem cert_e2406201909658 : check e2406201909658 [[]] .width = true := by decide
def e2406202474522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2406202474522 : Closed e2406202474522 ∧ code e2406202474522 = 11202295496730 := by decide
theorem cert_e2406202474522 : check e2406202474522 [[]] .width = true := by decide
def e2406202474614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2406202474614 : Closed e2406202474614 ∧ code e2406202474614 = 11202295496822 := by decide
theorem cert_e2406202474614 : check e2406202474614 [[]] .width = true := by decide
def e2406202474858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2406202474858 : Closed e2406202474858 ∧ code e2406202474858 = 11202295497066 := by decide
theorem cert_e2406202474858 : check e2406202474858 [[]] .width = true := by decide
def e2406202474906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2406202474906 : Closed e2406202474906 ∧ code e2406202474906 = 11202295497114 := by decide
theorem cert_e2406202474906 : check e2406202474906 [[]] .width = true := by decide
def e2406202474990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2406202474990 : Closed e2406202474990 ∧ code e2406202474990 = 11202295497198 := by decide
theorem cert_e2406202474990 : check e2406202474990 [[]] .width = true := by decide
def e2406202475914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2406202475914 : Closed e2406202475914 ∧ code e2406202475914 = 11202295498122 := by decide
theorem cert_e2406202475914 : check e2406202475914 [[]] .width = true := by decide
def e2406202475938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2406202475938 : Closed e2406202475938 ∧ code e2406202475938 = 11202295498146 := by decide
theorem cert_e2406202475938 : check e2406202475938 [[]] .width = true := by decide
def e2406202475950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2406202475950 : Closed e2406202475950 ∧ code e2406202475950 = 11202295498158 := by decide
theorem cert_e2406202475950 : check e2406202475950 [[]] .width = true := by decide
def e2406202475958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2406202475958 : Closed e2406202475958 ∧ code e2406202475958 = 11202295498166 := by decide
theorem cert_e2406202475958 : check e2406202475958 [[]] .width = true := by decide
def e2406202475962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2406202475962 : Closed e2406202475962 ∧ code e2406202475962 = 11202295498170 := by decide
theorem cert_e2406202475962 : check e2406202475962 [[]] .width = true := by decide
def e2406202475990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2406202475990 : Closed e2406202475990 ∧ code e2406202475990 = 11202295498198 := by decide
theorem cert_e2406202475990 : check e2406202475990 [[]] .width = true := by decide
def e2406202475994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2406202475994 : Closed e2406202475994 ∧ code e2406202475994 = 11202295498202 := by decide
theorem cert_e2406202475994 : check e2406202475994 [[]] .width = true := by decide
def e2406202476010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2406202476010 : Closed e2406202476010 ∧ code e2406202476010 = 11202295498218 := by decide
theorem cert_e2406202476010 : check e2406202476010 [[]] .width = true := by decide
def e2406202476046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2406202476046 : Closed e2406202476046 ∧ code e2406202476046 = 11202295498254 := by decide
theorem cert_e2406202476046 : check e2406202476046 [[]] .width = true := by decide
def e2406202476058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406202476058 : Closed e2406202476058 ∧ code e2406202476058 = 11202295498266 := by decide
theorem cert_e2406202476058 : check e2406202476058 [[]] .width = true := by decide
def e2406202476130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2406202476130 : Closed e2406202476130 ∧ code e2406202476130 = 11202295498338 := by decide
theorem cert_e2406202476130 : check e2406202476130 [[]] .width = true := by decide
def e2406202476142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2406202476142 : Closed e2406202476142 ∧ code e2406202476142 = 11202295498350 := by decide
theorem cert_e2406202476142 : check e2406202476142 [[]] .width = true := by decide
def e2406202476150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2406202476150 : Closed e2406202476150 ∧ code e2406202476150 = 11202295498358 := by decide
theorem cert_e2406202476150 : check e2406202476150 [[]] .width = true := by decide
def e2406202476154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2406202476154 : Closed e2406202476154 ∧ code e2406202476154 = 11202295498362 := by decide
theorem cert_e2406202476154 : check e2406202476154 [[]] .width = true := by decide
def e2406202476342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2406202476342 : Closed e2406202476342 ∧ code e2406202476342 = 11202295498550 := by decide
theorem cert_e2406202476342 : check e2406202476342 [[]] .width = true := by decide
def e2406202476346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2406202476346 : Closed e2406202476346 ∧ code e2406202476346 = 11202295498554 := by decide
theorem cert_e2406202476346 : check e2406202476346 [[]] .width = true := by decide
def e2406202476442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2406202476442 : Closed e2406202476442 ∧ code e2406202476442 = 11202295498650 := by decide
theorem cert_e2406202476442 : check e2406202476442 [[]] .width = true := by decide
def e2406202480042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2406202480042 : Closed e2406202480042 ∧ code e2406202480042 = 11202295502250 := by decide
theorem cert_e2406202480042 : check e2406202480042 [[]] .width = true := by decide
def e2406202480138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2406202480138 : Closed e2406202480138 ∧ code e2406202480138 = 11202295502346 := by decide
theorem cert_e2406202480138 : check e2406202480138 [[]] .width = true := by decide
def e2406202480182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2406202480182 : Closed e2406202480182 ∧ code e2406202480182 = 11202295502390 := by decide
theorem cert_e2406202480182 : check e2406202480182 [[]] .width = true := by decide
def e2406202480186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2406202480186 : Closed e2406202480186 ∧ code e2406202480186 = 11202295502394 := by decide
theorem cert_e2406202480186 : check e2406202480186 [[]] .width = true := by decide
def e2406202480234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2406202480234 : Closed e2406202480234 ∧ code e2406202480234 = 11202295502442 := by decide
theorem cert_e2406202480234 : check e2406202480234 [[]] .width = true := by decide
def e2406202480258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2406202480258 : Closed e2406202480258 ∧ code e2406202480258 = 11202295502466 := by decide
theorem cert_e2406202480258 : check e2406202480258 [[]] .width = true := by decide
def e2406202480270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2406202480270 : Closed e2406202480270 ∧ code e2406202480270 = 11202295502478 := by decide
theorem cert_e2406202480270 : check e2406202480270 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2406200613402
#print axioms Blc.Floor43.cert_e2406200615030
#print axioms Blc.Floor43.cert_e2406200615274
#print axioms Blc.Floor43.cert_e2406200615322
#print axioms Blc.Floor43.cert_e2406200744474
#print axioms Blc.Floor43.cert_e2406200746102
#print axioms Blc.Floor43.cert_e2406200746346
#print axioms Blc.Floor43.cert_e2406200746394
