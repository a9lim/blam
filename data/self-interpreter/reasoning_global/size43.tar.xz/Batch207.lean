import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2391492242970 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492242970 : Closed e2391492242970 ∧ code e2391492242970 = 11187585265178 := by decide
private def t_e2391492242970 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492242970 : ¬ IsSelfInterpreter e2391492242970 :=
  wSource (t := t_e2391492242970) (replay_sound (ps := []) (t := e2391492242970) (by decide)) (by decide)
def e2391492246042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492246042 : Closed e2391492246042 ∧ code e2391492246042 = 11187585268250 := by decide
private def t_e2391492246042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492246042 : ¬ IsSelfInterpreter e2391492246042 :=
  wSource (t := t_e2391492246042) (replay_sound (ps := []) (t := e2391492246042) (by decide)) (by decide)
def e2391492253210 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492253210 : Closed e2391492253210 ∧ code e2391492253210 = 11187585275418 := by decide
private def t_e2391492253210 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492253210 : ¬ IsSelfInterpreter e2391492253210 :=
  wSource (t := t_e2391492253210) (replay_sound (ps := []) (t := e2391492253210) (by decide)) (by decide)
def e2391492254234 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492254234 : Closed e2391492254234 ∧ code e2391492254234 = 11187585276442 := by decide
private def t_e2391492254234 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492254234 : ¬ IsSelfInterpreter e2391492254234 :=
  wSource (t := t_e2391492254234) (replay_sound (ps := []) (t := e2391492254234) (by decide)) (by decide)
def e2391492324890 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492324890 : Closed e2391492324890 ∧ code e2391492324890 = 11187585347098 := by decide
private def t_e2391492324890 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492324890 : ¬ IsSelfInterpreter e2391492324890 :=
  wSource (t := t_e2391492324890) (replay_sound (ps := []) (t := e2391492324890) (by decide)) (by decide)
def e2391492326938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492326938 : Closed e2391492326938 ∧ code e2391492326938 = 11187585349146 := by decide
private def t_e2391492326938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492326938 : ¬ IsSelfInterpreter e2391492326938 :=
  wSource (t := t_e2391492326938) (replay_sound (ps := []) (t := e2391492326938) (by decide)) (by decide)
def e2391492423194 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492423194 : Closed e2391492423194 ∧ code e2391492423194 = 11187585445402 := by decide
private def t_e2391492423194 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492423194 : ¬ IsSelfInterpreter e2391492423194 :=
  wSource (t := t_e2391492423194) (replay_sound (ps := []) (t := e2391492423194) (by decide)) (by decide)
def e2391492426266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492426266 : Closed e2391492426266 ∧ code e2391492426266 = 11187585448474 := by decide
private def t_e2391492426266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492426266 : ¬ IsSelfInterpreter e2391492426266 :=
  wSource (t := t_e2391492426266) (replay_sound (ps := []) (t := e2391492426266) (by decide)) (by decide)
def e2391492474394 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492474394 : Closed e2391492474394 ∧ code e2391492474394 = 11187585496602 := by decide
private def t_e2391492474394 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492474394 : ¬ IsSelfInterpreter e2391492474394 :=
  wSource (t := t_e2391492474394) (replay_sound (ps := []) (t := e2391492474394) (by decide)) (by decide)
def e2391492475418 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492475418 : Closed e2391492475418 ∧ code e2391492475418 = 11187585497626 := by decide
private def t_e2391492475418 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492475418 : ¬ IsSelfInterpreter e2391492475418 :=
  wSource (t := t_e2391492475418) (replay_sound (ps := []) (t := e2391492475418) (by decide)) (by decide)
def e2391494473754 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494473754 : Closed e2391494473754 ∧ code e2391494473754 = 11187587495962 := by decide
theorem cert_e2391494473754 : check e2391494473754 [[]] .width = true := by decide
def e2391494481946 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494481946 : Closed e2391494481946 ∧ code e2391494481946 = 11187587504154 := by decide
theorem cert_e2391494481946 : check e2391494481946 [[]] .width = true := by decide
def e2391494539290 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494539290 : Closed e2391494539290 ∧ code e2391494539290 = 11187587561498 := by decide
theorem cert_e2391494539290 : check e2391494539290 [[]] .width = true := by decide
def e2391494551578 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494551578 : Closed e2391494551578 ∧ code e2391494551578 = 11187587573786 := by decide
theorem cert_e2391494551578 : check e2391494551578 [[]] .width = true := by decide
def e2391494580250 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494580250 : Closed e2391494580250 ∧ code e2391494580250 = 11187587602458 := by decide
theorem cert_e2391494580250 : check e2391494580250 [[]] .width = true := by decide
def e2391494584346 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494584346 : Closed e2391494584346 ∧ code e2391494584346 = 11187587606554 := by decide
theorem cert_e2391494584346 : check e2391494584346 [[]] .width = true := by decide
def e2391494866970 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494866970 : Closed e2391494866970 ∧ code e2391494866970 = 11187587889178 := by decide
theorem cert_e2391494866970 : check e2391494866970 [[]] .width = true := by decide
def e2391494875162 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391494875162 : Closed e2391494875162 ∧ code e2391494875162 = 11187587897370 := by decide
theorem cert_e2391494875162 : check e2391494875162 [[]] .width = true := by decide
def e2391495260186 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391495260186 : Closed e2391495260186 ∧ code e2391495260186 = 11187588282394 := by decide
theorem cert_e2391495260186 : check e2391495260186 [[]] .width = true := by decide
def e2391495272474 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391495272474 : Closed e2391495272474 ∧ code e2391495272474 = 11187588294682 := by decide
theorem cert_e2391495272474 : check e2391495272474 [[]] .width = true := by decide
def e2391495464986 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391495464986 : Closed e2391495464986 ∧ code e2391495464986 = 11187588487194 := by decide
theorem cert_e2391495464986 : check e2391495464986 [[]] .width = true := by decide
def e2391495469082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391495469082 : Closed e2391495469082 ∧ code e2391495469082 = 11187588491290 := by decide
theorem cert_e2391495469082 : check e2391495469082 [[]] .width = true := by decide
def e2391508299118 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2391508299118 : Closed e2391508299118 ∧ code e2391508299118 = 11187601321326 := by decide
theorem cert_e2391508299118 : check e2391508299118 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2391508299126 : Closed e2391508299126 ∧ code e2391508299126 = 11187601321334 := by decide
theorem cert_e2391508299126 : check e2391508299126 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299182 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2391508299182 : Closed e2391508299182 ∧ code e2391508299182 = 11187601321390 := by decide
theorem cert_e2391508299182 : check e2391508299182 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299194 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2391508299194 : Closed e2391508299194 ∧ code e2391508299194 = 11187601321402 := by decide
theorem cert_e2391508299194 : check e2391508299194 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299222 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2391508299222 : Closed e2391508299222 ∧ code e2391508299222 = 11187601321430 := by decide
theorem cert_e2391508299222 : check e2391508299222 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299226 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2391508299226 : Closed e2391508299226 ∧ code e2391508299226 = 11187601321434 := by decide
theorem cert_e2391508299226 : check e2391508299226 [[],[.left],[]] .sourceHead = true := by decide
def e2391508299438 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2391508299438 : Closed e2391508299438 ∧ code e2391508299438 = 11187601321646 := by decide
theorem cert_e2391508299438 : check e2391508299438 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2391508299450 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2391508299450 : Closed e2391508299450 ∧ code e2391508299450 = 11187601321658 := by decide
theorem cert_e2391508299450 : check e2391508299450 [[],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2391508299498 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2391508299498 : Closed e2391508299498 ∧ code e2391508299498 = 11187601321706 := by decide
theorem cert_e2391508299498 : check e2391508299498 [[],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2391508299606 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2391508299606 : Closed e2391508299606 ∧ code e2391508299606 = 11187601321814 := by decide
theorem cert_e2391508299606 : check e2391508299606 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2391508299610 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2391508299610 : Closed e2391508299610 ∧ code e2391508299610 = 11187601321818 := by decide
theorem cert_e2391508299610 : check e2391508299610 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2391508299626 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2391508299626 : Closed e2391508299626 ∧ code e2391508299626 = 11187601321834 := by decide
theorem cert_e2391508299626 : check e2391508299626 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2391508300654 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2391508300654 : Closed e2391508300654 ∧ code e2391508300654 = 11187601322862 := by decide
theorem cert_e2391508300654 : check e2391508300654 [[],[.left],[]] .sourceHead = true := by decide
def e2391508300662 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2391508300662 : Closed e2391508300662 ∧ code e2391508300662 = 11187601322870 := by decide
theorem cert_e2391508300662 : check e2391508300662 [[],[.left],[]] .sourceHead = true := by decide
def e2391508300718 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2391508300718 : Closed e2391508300718 ∧ code e2391508300718 = 11187601322926 := by decide
theorem cert_e2391508300718 : check e2391508300718 [[],[.left],[]] .sourceHead = true := by decide
def e2391508300730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2391508300730 : Closed e2391508300730 ∧ code e2391508300730 = 11187601322938 := by decide
theorem cert_e2391508300730 : check e2391508300730 [[],[.left],[]] .sourceHead = true := by decide
def e2391508300758 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2391508300758 : Closed e2391508300758 ∧ code e2391508300758 = 11187601322966 := by decide
theorem cert_e2391508300758 : check e2391508300758 [[],[.left],[]] .sourceHead = true := by decide
def e2391508300762 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2391508300762 : Closed e2391508300762 ∧ code e2391508300762 = 11187601322970 := by decide
theorem cert_e2391508300762 : check e2391508300762 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301038 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2391508301038 : Closed e2391508301038 ∧ code e2391508301038 = 11187601323246 := by decide
theorem cert_e2391508301038 : check e2391508301038 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301046 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2391508301046 : Closed e2391508301046 ∧ code e2391508301046 = 11187601323254 := by decide
theorem cert_e2391508301046 : check e2391508301046 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301422 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391508301422 : Closed e2391508301422 ∧ code e2391508301422 = 11187601323630 := by decide
theorem cert_e2391508301422 : check e2391508301422 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301434 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391508301434 : Closed e2391508301434 ∧ code e2391508301434 = 11187601323642 := by decide
theorem cert_e2391508301434 : check e2391508301434 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301622 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2391508301622 : Closed e2391508301622 ∧ code e2391508301622 = 11187601323830 := by decide
theorem cert_e2391508301622 : check e2391508301622 [[],[.left],[]] .sourceHead = true := by decide
def e2391508301626 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2391508301626 : Closed e2391508301626 ∧ code e2391508301626 = 11187601323834 := by decide
theorem cert_e2391508301626 : check e2391508301626 [[],[.left],[]] .sourceHead = true := by decide
def e2391508302254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2391508302254 : Closed e2391508302254 ∧ code e2391508302254 = 11187601324462 := by decide
theorem cert_e2391508302254 : check e2391508302254 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2391508302266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2391508302266 : Closed e2391508302266 ∧ code e2391508302266 = 11187601324474 := by decide
theorem cert_e2391508302266 : check e2391508302266 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2391508302314 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2391508302314 : Closed e2391508302314 ∧ code e2391508302314 = 11187601324522 := by decide
theorem cert_e2391508302314 : check e2391508302314 [[],[.left],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2391508302446 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391508302446 : Closed e2391508302446 ∧ code e2391508302446 = 11187601324654 := by decide
theorem cert_e2391508302446 : check e2391508302446 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2391508302458 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391508302458 : Closed e2391508302458 ∧ code e2391508302458 = 11187601324666 := by decide
theorem cert_e2391508302458 : check e2391508302458 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2391508302746 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2391508302746 : Closed e2391508302746 ∧ code e2391508302746 = 11187601324954 := by decide
theorem cert_e2391508302746 : check e2391508302746 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2391508303062 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2391508303062 : Closed e2391508303062 ∧ code e2391508303062 = 11187601325270 := by decide
theorem cert_e2391508303062 : check e2391508303062 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508303066 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2391508303066 : Closed e2391508303066 ∧ code e2391508303066 = 11187601325274 := by decide
theorem cert_e2391508303066 : check e2391508303066 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508303082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2391508303082 : Closed e2391508303082 ∧ code e2391508303082 = 11187601325290 := by decide
theorem cert_e2391508303082 : check e2391508303082 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508303158 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2391508303158 : Closed e2391508303158 ∧ code e2391508303158 = 11187601325366 := by decide
theorem cert_e2391508303158 : check e2391508303158 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508303162 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2391508303162 : Closed e2391508303162 ∧ code e2391508303162 = 11187601325370 := by decide
theorem cert_e2391508303162 : check e2391508303162 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508303258 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2391508303258 : Closed e2391508303258 ∧ code e2391508303258 = 11187601325466 := by decide
theorem cert_e2391508303258 : check e2391508303258 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391508306798 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391508306798 : Closed e2391508306798 ∧ code e2391508306798 = 11187601329006 := by decide
theorem cert_e2391508306798 : check e2391508306798 [[],[.left],[]] .sourceHead = true := by decide
def e2391508306806 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391508306806 : Closed e2391508306806 ∧ code e2391508306806 = 11187601329014 := by decide
theorem cert_e2391508306806 : check e2391508306806 [[],[.left],[]] .sourceHead = true := by decide
def e2391508306862 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391508306862 : Closed e2391508306862 ∧ code e2391508306862 = 11187601329070 := by decide
theorem cert_e2391508306862 : check e2391508306862 [[],[.left],[]] .sourceHead = true := by decide
def e2391508306874 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391508306874 : Closed e2391508306874 ∧ code e2391508306874 = 11187601329082 := by decide
theorem cert_e2391508306874 : check e2391508306874 [[],[.left],[]] .sourceHead = true := by decide
def e2391508306902 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391508306902 : Closed e2391508306902 ∧ code e2391508306902 = 11187601329110 := by decide
theorem cert_e2391508306902 : check e2391508306902 [[],[.left],[]] .sourceHead = true := by decide
def e2391508306906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391508306906 : Closed e2391508306906 ∧ code e2391508306906 = 11187601329114 := by decide
theorem cert_e2391508306906 : check e2391508306906 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307182 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391508307182 : Closed e2391508307182 ∧ code e2391508307182 = 11187601329390 := by decide
theorem cert_e2391508307182 : check e2391508307182 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307190 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391508307190 : Closed e2391508307190 ∧ code e2391508307190 = 11187601329398 := by decide
theorem cert_e2391508307190 : check e2391508307190 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307566 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391508307566 : Closed e2391508307566 ∧ code e2391508307566 = 11187601329774 := by decide
theorem cert_e2391508307566 : check e2391508307566 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307578 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391508307578 : Closed e2391508307578 ∧ code e2391508307578 = 11187601329786 := by decide
theorem cert_e2391508307578 : check e2391508307578 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307766 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391508307766 : Closed e2391508307766 ∧ code e2391508307766 = 11187601329974 := by decide
theorem cert_e2391508307766 : check e2391508307766 [[],[.left],[]] .sourceHead = true := by decide
def e2391508307770 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391508307770 : Closed e2391508307770 ∧ code e2391508307770 = 11187601329978 := by decide
theorem cert_e2391508307770 : check e2391508307770 [[],[.left],[]] .sourceHead = true := by decide
def e2391508313518 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2391508313518 : Closed e2391508313518 ∧ code e2391508313518 = 11187601335726 := by decide
theorem cert_e2391508313518 : check e2391508313518 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2391508313530 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2391508313530 : Closed e2391508313530 ∧ code e2391508313530 = 11187601335738 := by decide
theorem cert_e2391508313530 : check e2391508313530 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2391508313578 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2391508313578 : Closed e2391508313578 ∧ code e2391508313578 = 11187601335786 := by decide
theorem cert_e2391508313578 : check e2391508313578 [[],[.left],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e2391508313710 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2391508313710 : Closed e2391508313710 ∧ code e2391508313710 = 11187601335918 := by decide
theorem cert_e2391508313710 : check e2391508313710 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2391508313722 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2391508313722 : Closed e2391508313722 ∧ code e2391508313722 = 11187601335930 := by decide
theorem cert_e2391508313722 : check e2391508313722 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2391508314010 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2391508314010 : Closed e2391508314010 ∧ code e2391508314010 = 11187601336218 := by decide
theorem cert_e2391508314010 : check e2391508314010 [[],[.left],[],[.under],[.under,.left]] .chain = true := by decide
def e2391508316886 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2391508316886 : Closed e2391508316886 ∧ code e2391508316886 = 11187601339094 := by decide
theorem cert_e2391508316886 : check e2391508316886 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508316890 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2391508316890 : Closed e2391508316890 ∧ code e2391508316890 = 11187601339098 := by decide
theorem cert_e2391508316890 : check e2391508316890 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508316906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2391508316906 : Closed e2391508316906 ∧ code e2391508316906 = 11187601339114 := by decide
theorem cert_e2391508316906 : check e2391508316906 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508316982 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2391508316982 : Closed e2391508316982 ∧ code e2391508316982 = 11187601339190 := by decide
theorem cert_e2391508316982 : check e2391508316982 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508316986 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2391508316986 : Closed e2391508316986 ∧ code e2391508316986 = 11187601339194 := by decide
theorem cert_e2391508316986 : check e2391508316986 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508317082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2391508317082 : Closed e2391508317082 ∧ code e2391508317082 = 11187601339290 := by decide
theorem cert_e2391508317082 : check e2391508317082 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391508454254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391508454254 : Closed e2391508454254 ∧ code e2391508454254 = 11187601476462 := by decide
theorem cert_e2391508454254 : check e2391508454254 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391508454262 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391508454262 : Closed e2391508454262 ∧ code e2391508454262 = 11187601476470 := by decide
theorem cert_e2391508454262 : check e2391508454262 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391508454318 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391508454318 : Closed e2391508454318 ∧ code e2391508454318 = 11187601476526 := by decide
theorem cert_e2391508454318 : check e2391508454318 [[],[.left],[],[],[.under,.left]] .sourceHead = true := by decide
def e2391508454330 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391508454330 : Closed e2391508454330 ∧ code e2391508454330 = 11187601476538 := by decide
theorem cert_e2391508454330 : check e2391508454330 [[],[.left],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2391508454358 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391508454358 : Closed e2391508454358 ∧ code e2391508454358 = 11187601476566 := by decide
theorem cert_e2391508454358 : check e2391508454358 [[],[.left],[],[],[.under,.left,.left]] .chain = true := by decide
def e2391508454362 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391508454362 : Closed e2391508454362 ∧ code e2391508454362 = 11187601476570 := by decide
theorem cert_e2391508454362 : check e2391508454362 [[],[.left],[],[],[.under,.left,.left]] .chain = true := by decide
def e2391508454638 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391508454638 : Closed e2391508454638 ∧ code e2391508454638 = 11187601476846 := by decide
theorem cert_e2391508454638 : check e2391508454638 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391508454646 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391508454646 : Closed e2391508454646 ∧ code e2391508454646 = 11187601476854 := by decide
theorem cert_e2391508454646 : check e2391508454646 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391508455022 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391508455022 : Closed e2391508455022 ∧ code e2391508455022 = 11187601477230 := by decide
theorem cert_e2391508455022 : check e2391508455022 [[],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2391508455034 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391508455034 : Closed e2391508455034 ∧ code e2391508455034 = 11187601477242 := by decide
theorem cert_e2391508455034 : check e2391508455034 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e2391508455222 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391508455222 : Closed e2391508455222 ∧ code e2391508455222 = 11187601477430 := by decide
theorem cert_e2391508455222 : check e2391508455222 [[],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2391508455226 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391508455226 : Closed e2391508455226 ∧ code e2391508455226 = 11187601477434 := by decide
theorem cert_e2391508455226 : check e2391508455226 [[],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2391509044078 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391509044078 : Closed e2391509044078 ∧ code e2391509044078 = 11187602066286 := by decide
def e2391509044086 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391509044086 : Closed e2391509044086 ∧ code e2391509044086 = 11187602066294 := by decide
def e2391509044142 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391509044142 : Closed e2391509044142 ∧ code e2391509044142 = 11187602066350 := by decide
def e2391509044154 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391509044154 : Closed e2391509044154 ∧ code e2391509044154 = 11187602066362 := by decide
private def t_e2391509044154 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2391509044154 : ¬ IsSelfInterpreter e2391509044154 :=
  wSource (t := t_e2391509044154) (replay_sound (ps := []) (t := e2391509044154) (by decide)) (by decide)
def e2391509044182 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391509044182 : Closed e2391509044182 ∧ code e2391509044182 = 11187602066390 := by decide
def e2391509044186 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391509044186 : Closed e2391509044186 ∧ code e2391509044186 = 11187602066394 := by decide
private def t_e2391509044186 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2391509044186 : ¬ IsSelfInterpreter e2391509044186 :=
  wSource (t := t_e2391509044186) (replay_sound (ps := []) (t := e2391509044186) (by decide)) (by decide)
def e2391509044462 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391509044462 : Closed e2391509044462 ∧ code e2391509044462 = 11187602066670 := by decide
def e2391509044470 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391509044470 : Closed e2391509044470 ∧ code e2391509044470 = 11187602066678 := by decide
def e2391509044846 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391509044846 : Closed e2391509044846 ∧ code e2391509044846 = 11187602067054 := by decide
def e2391509044858 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391509044858 : Closed e2391509044858 ∧ code e2391509044858 = 11187602067066 := by decide
theorem cert_e2391509044858 : checkPay e2391509044858 [[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left,.left],[.left]] 1 [[],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left]] = true := by decide
def e2391509045046 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391509045046 : Closed e2391509045046 ∧ code e2391509045046 = 11187602067254 := by decide
def e2391509045050 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391509045050 : Closed e2391509045050 ∧ code e2391509045050 = 11187602067258 := by decide
def e2391558630766 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2391558630766 : Closed e2391558630766 ∧ code e2391558630766 = 11187651652974 := by decide
theorem cert_e2391558630766 : check e2391558630766 [[],[.left],[]] .smaller = true := by decide
def e2391558630774 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2391558630774 : Closed e2391558630774 ∧ code e2391558630774 = 11187651652982 := by decide
theorem cert_e2391558630774 : check e2391558630774 [[],[.left],[]] .smaller = true := by decide
def e2391558630830 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2391558630830 : Closed e2391558630830 ∧ code e2391558630830 = 11187651653038 := by decide
theorem cert_e2391558630830 : check e2391558630830 [[],[.left],[]] .smaller = true := by decide
def e2391558630842 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2391558630842 : Closed e2391558630842 ∧ code e2391558630842 = 11187651653050 := by decide
theorem cert_e2391558630842 : check e2391558630842 [[],[.left],[]] .smaller = true := by decide
def e2391558630870 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2391558630870 : Closed e2391558630870 ∧ code e2391558630870 = 11187651653078 := by decide
theorem cert_e2391558630870 : check e2391558630870 [[],[.left],[]] .smaller = true := by decide
def e2391558630874 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2391558630874 : Closed e2391558630874 ∧ code e2391558630874 = 11187651653082 := by decide
theorem cert_e2391558630874 : check e2391558630874 [[],[.left],[]] .smaller = true := by decide
def e2391558631086 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2391558631086 : Closed e2391558631086 ∧ code e2391558631086 = 11187651653294 := by decide
theorem cert_e2391558631086 : check e2391558631086 [[],[.left],[]] .smaller = true := by decide
def e2391558631098 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2391558631098 : Closed e2391558631098 ∧ code e2391558631098 = 11187651653306 := by decide
theorem cert_e2391558631098 : check e2391558631098 [[],[.left],[]] .smaller = true := by decide
def e2391558631146 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2391558631146 : Closed e2391558631146 ∧ code e2391558631146 = 11187651653354 := by decide
theorem cert_e2391558631146 : check e2391558631146 [[],[.left],[]] .smaller = true := by decide
def e2391558631254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2391558631254 : Closed e2391558631254 ∧ code e2391558631254 = 11187651653462 := by decide
theorem cert_e2391558631254 : check e2391558631254 [[],[.left],[]] .smaller = true := by decide
def e2391558631258 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2391558631258 : Closed e2391558631258 ∧ code e2391558631258 = 11187651653466 := by decide
theorem cert_e2391558631258 : check e2391558631258 [[],[.left],[]] .smaller = true := by decide
def e2391558631274 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2391558631274 : Closed e2391558631274 ∧ code e2391558631274 = 11187651653482 := by decide
theorem cert_e2391558631274 : check e2391558631274 [[],[.left],[]] .smaller = true := by decide
def e2391558632302 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2391558632302 : Closed e2391558632302 ∧ code e2391558632302 = 11187651654510 := by decide
theorem cert_e2391558632302 : check e2391558632302 [[],[.left],[]] .smaller = true := by decide
def e2391558632310 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2391558632310 : Closed e2391558632310 ∧ code e2391558632310 = 11187651654518 := by decide
theorem cert_e2391558632310 : check e2391558632310 [[],[.left],[]] .smaller = true := by decide
def e2391558632366 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2391558632366 : Closed e2391558632366 ∧ code e2391558632366 = 11187651654574 := by decide
theorem cert_e2391558632366 : check e2391558632366 [[],[.left],[]] .smaller = true := by decide
def e2391558632378 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2391558632378 : Closed e2391558632378 ∧ code e2391558632378 = 11187651654586 := by decide
theorem cert_e2391558632378 : check e2391558632378 [[],[.left],[]] .smaller = true := by decide
def e2391558632406 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2391558632406 : Closed e2391558632406 ∧ code e2391558632406 = 11187651654614 := by decide
theorem cert_e2391558632406 : check e2391558632406 [[],[.left],[]] .smaller = true := by decide
def e2391558632410 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2391558632410 : Closed e2391558632410 ∧ code e2391558632410 = 11187651654618 := by decide
theorem cert_e2391558632410 : check e2391558632410 [[],[.left],[]] .smaller = true := by decide
def e2391558632686 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2391558632686 : Closed e2391558632686 ∧ code e2391558632686 = 11187651654894 := by decide
theorem cert_e2391558632686 : check e2391558632686 [[],[.left],[]] .smaller = true := by decide
def e2391558632694 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2391558632694 : Closed e2391558632694 ∧ code e2391558632694 = 11187651654902 := by decide
theorem cert_e2391558632694 : check e2391558632694 [[],[.left],[]] .smaller = true := by decide
def e2391558633070 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2391558633070 : Closed e2391558633070 ∧ code e2391558633070 = 11187651655278 := by decide
theorem cert_e2391558633070 : check e2391558633070 [[],[.left],[]] .smaller = true := by decide
def e2391558633082 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2391558633082 : Closed e2391558633082 ∧ code e2391558633082 = 11187651655290 := by decide
theorem cert_e2391558633082 : check e2391558633082 [[],[.left],[]] .smaller = true := by decide
def e2391558633270 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2391558633270 : Closed e2391558633270 ∧ code e2391558633270 = 11187651655478 := by decide
theorem cert_e2391558633270 : check e2391558633270 [[],[.left],[]] .smaller = true := by decide
def e2391558633274 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2391558633274 : Closed e2391558633274 ∧ code e2391558633274 = 11187651655482 := by decide
theorem cert_e2391558633274 : check e2391558633274 [[],[.left],[]] .smaller = true := by decide
def e2391558633902 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2391558633902 : Closed e2391558633902 ∧ code e2391558633902 = 11187651656110 := by decide
theorem cert_e2391558633902 : check e2391558633902 [[],[.left],[]] .smaller = true := by decide
def e2391558633914 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2391558633914 : Closed e2391558633914 ∧ code e2391558633914 = 11187651656122 := by decide
theorem cert_e2391558633914 : check e2391558633914 [[],[.left],[]] .smaller = true := by decide
def e2391558633962 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2391558633962 : Closed e2391558633962 ∧ code e2391558633962 = 11187651656170 := by decide
theorem cert_e2391558633962 : check e2391558633962 [[],[.left],[]] .smaller = true := by decide
def e2391558634094 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2391558634094 : Closed e2391558634094 ∧ code e2391558634094 = 11187651656302 := by decide
theorem cert_e2391558634094 : check e2391558634094 [[],[.left],[]] .smaller = true := by decide
def e2391558634106 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2391558634106 : Closed e2391558634106 ∧ code e2391558634106 = 11187651656314 := by decide
theorem cert_e2391558634106 : check e2391558634106 [[],[.left],[]] .smaller = true := by decide
def e2391558634394 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2391558634394 : Closed e2391558634394 ∧ code e2391558634394 = 11187651656602 := by decide
theorem cert_e2391558634394 : check e2391558634394 [[],[.left],[]] .smaller = true := by decide
def e2391558634710 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2391558634710 : Closed e2391558634710 ∧ code e2391558634710 = 11187651656918 := by decide
theorem cert_e2391558634710 : check e2391558634710 [[],[.left],[]] .smaller = true := by decide
def e2391558634714 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2391558634714 : Closed e2391558634714 ∧ code e2391558634714 = 11187651656922 := by decide
theorem cert_e2391558634714 : check e2391558634714 [[],[.left],[]] .smaller = true := by decide
def e2391558634730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2391558634730 : Closed e2391558634730 ∧ code e2391558634730 = 11187651656938 := by decide
theorem cert_e2391558634730 : check e2391558634730 [[],[.left],[]] .smaller = true := by decide
def e2391558634806 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2391558634806 : Closed e2391558634806 ∧ code e2391558634806 = 11187651657014 := by decide
theorem cert_e2391558634806 : check e2391558634806 [[],[.left],[]] .smaller = true := by decide
def e2391558634810 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2391558634810 : Closed e2391558634810 ∧ code e2391558634810 = 11187651657018 := by decide
theorem cert_e2391558634810 : check e2391558634810 [[],[.left],[]] .smaller = true := by decide
def e2391558634906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2391558634906 : Closed e2391558634906 ∧ code e2391558634906 = 11187651657114 := by decide
theorem cert_e2391558634906 : check e2391558634906 [[],[.left],[]] .smaller = true := by decide
def e2391558638446 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2391558638446 : Closed e2391558638446 ∧ code e2391558638446 = 11187651660654 := by decide
theorem cert_e2391558638446 : check e2391558638446 [[],[.left],[]] .smaller = true := by decide
def e2391558638454 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2391558638454 : Closed e2391558638454 ∧ code e2391558638454 = 11187651660662 := by decide
theorem cert_e2391558638454 : check e2391558638454 [[],[.left],[]] .smaller = true := by decide
def e2391558638510 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2391558638510 : Closed e2391558638510 ∧ code e2391558638510 = 11187651660718 := by decide
theorem cert_e2391558638510 : check e2391558638510 [[],[.left],[]] .smaller = true := by decide
def e2391558638522 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2391558638522 : Closed e2391558638522 ∧ code e2391558638522 = 11187651660730 := by decide
theorem cert_e2391558638522 : check e2391558638522 [[],[.left],[]] .smaller = true := by decide
def e2391558638550 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2391558638550 : Closed e2391558638550 ∧ code e2391558638550 = 11187651660758 := by decide
theorem cert_e2391558638550 : check e2391558638550 [[],[.left],[]] .smaller = true := by decide
def e2391558638554 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2391558638554 : Closed e2391558638554 ∧ code e2391558638554 = 11187651660762 := by decide
theorem cert_e2391558638554 : check e2391558638554 [[],[.left],[]] .smaller = true := by decide
def e2391558638830 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2391558638830 : Closed e2391558638830 ∧ code e2391558638830 = 11187651661038 := by decide
theorem cert_e2391558638830 : check e2391558638830 [[],[.left],[]] .smaller = true := by decide
def e2391558638838 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2391558638838 : Closed e2391558638838 ∧ code e2391558638838 = 11187651661046 := by decide
theorem cert_e2391558638838 : check e2391558638838 [[],[.left],[]] .smaller = true := by decide
def e2391558639214 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2391558639214 : Closed e2391558639214 ∧ code e2391558639214 = 11187651661422 := by decide
theorem cert_e2391558639214 : check e2391558639214 [[],[.left],[]] .smaller = true := by decide
def e2391558639226 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2391558639226 : Closed e2391558639226 ∧ code e2391558639226 = 11187651661434 := by decide
theorem cert_e2391558639226 : check e2391558639226 [[],[.left],[]] .smaller = true := by decide
def e2391558639414 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2391558639414 : Closed e2391558639414 ∧ code e2391558639414 = 11187651661622 := by decide
theorem cert_e2391558639414 : check e2391558639414 [[],[.left],[]] .smaller = true := by decide
def e2391558639418 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2391558639418 : Closed e2391558639418 ∧ code e2391558639418 = 11187651661626 := by decide
theorem cert_e2391558639418 : check e2391558639418 [[],[.left],[]] .smaller = true := by decide
def e2391558645166 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2391558645166 : Closed e2391558645166 ∧ code e2391558645166 = 11187651667374 := by decide
theorem cert_e2391558645166 : check e2391558645166 [[],[.left],[]] .smaller = true := by decide
def e2391558645178 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2391558645178 : Closed e2391558645178 ∧ code e2391558645178 = 11187651667386 := by decide
theorem cert_e2391558645178 : check e2391558645178 [[],[.left],[]] .smaller = true := by decide
def e2391558645226 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2391558645226 : Closed e2391558645226 ∧ code e2391558645226 = 11187651667434 := by decide
theorem cert_e2391558645226 : check e2391558645226 [[],[.left],[]] .smaller = true := by decide
def e2391558645358 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2391558645358 : Closed e2391558645358 ∧ code e2391558645358 = 11187651667566 := by decide
theorem cert_e2391558645358 : check e2391558645358 [[],[.left],[]] .smaller = true := by decide
def e2391558645370 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2391558645370 : Closed e2391558645370 ∧ code e2391558645370 = 11187651667578 := by decide
theorem cert_e2391558645370 : check e2391558645370 [[],[.left],[]] .smaller = true := by decide
def e2391558645658 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2391558645658 : Closed e2391558645658 ∧ code e2391558645658 = 11187651667866 := by decide
theorem cert_e2391558645658 : check e2391558645658 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2391492242970
#print axioms Blc.Floor43.cert_e2391492246042
#print axioms Blc.Floor43.cert_e2391492253210
#print axioms Blc.Floor43.cert_e2391492254234
#print axioms Blc.Floor43.cert_e2391492324890
#print axioms Blc.Floor43.cert_e2391492326938
#print axioms Blc.Floor43.cert_e2391492423194
#print axioms Blc.Floor43.cert_e2391492426266
#print axioms Blc.Floor43.cert_e2391492474394
#print axioms Blc.Floor43.cert_e2391492475418
#print axioms Blc.Floor43.cert_e2391509044154
#print axioms Blc.Floor43.cert_e2391509044186
