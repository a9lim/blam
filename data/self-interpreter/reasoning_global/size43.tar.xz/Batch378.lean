import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364516310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2422364516310 : Closed e2422364516310 ∧ code e2422364516310 = 11218457538518 := by decide
theorem cert_e2422364516310 : check e2422364516310 [[],[]] .three = true := by decide
def e2422364516314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2422364516314 : Closed e2422364516314 ∧ code e2422364516314 = 11218457538522 := by decide
theorem cert_e2422364516314 : check e2422364516314 [[],[]] .three = true := by decide
def e2422364517310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364517310 : Closed e2422364517310 ∧ code e2422364517310 = 11218457539518 := by decide
theorem cert_e2422364517310 : check e2422364517310 [[],[]] .three = true := by decide
def e2422364517342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422364517342 : Closed e2422364517342 ∧ code e2422364517342 = 11218457539550 := by decide
theorem cert_e2422364517342 : check e2422364517342 [[],[]] .smaller = true := by decide
def e2422364517358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422364517358 : Closed e2422364517358 ∧ code e2422364517358 = 11218457539566 := by decide
theorem cert_e2422364517358 : check e2422364517358 [[],[]] .smaller = true := by decide
def e2422364517366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364517366 : Closed e2422364517366 ∧ code e2422364517366 = 11218457539574 := by decide
theorem cert_e2422364517366 : check e2422364517366 [[],[]] .three = true := by decide
def e2422364518462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422364518462 : Closed e2422364518462 ∧ code e2422364518462 = 11218457540670 := by decide
theorem cert_e2422364518462 : check e2422364518462 [[],[]] .smaller = true := by decide
def e2422364518846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422364518846 : Closed e2422364518846 ∧ code e2422364518846 = 11218457541054 := by decide
theorem cert_e2422364518846 : check e2422364518846 [[],[]] .three = true := by decide
def e2422364518878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364518878 : Closed e2422364518878 ∧ code e2422364518878 = 11218457541086 := by decide
theorem cert_e2422364518878 : check e2422364518878 [[],[]] .smaller = true := by decide
def e2422364518882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422364518882 : Closed e2422364518882 ∧ code e2422364518882 = 11218457541090 := by decide
theorem cert_e2422364518882 : check e2422364518882 [[],[]] .smaller = true := by decide
def e2422364518894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364518894 : Closed e2422364518894 ∧ code e2422364518894 = 11218457541102 := by decide
theorem cert_e2422364518894 : check e2422364518894 [[],[]] .smaller = true := by decide
def e2422364518902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364518902 : Closed e2422364518902 ∧ code e2422364518902 = 11218457541110 := by decide
theorem cert_e2422364518902 : check e2422364518902 [[],[]] .smaller = true := by decide
def e2422364518906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422364518906 : Closed e2422364518906 ∧ code e2422364518906 = 11218457541114 := by decide
theorem cert_e2422364518906 : check e2422364518906 [[],[]] .three = true := by decide
def e2422364519454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422364519454 : Closed e2422364519454 ∧ code e2422364519454 = 11218457541662 := by decide
theorem cert_e2422364519454 : check e2422364519454 [[],[]] .smaller = true := by decide
def e2422364519550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 5))))))))))
theorem wire_e2422364519550 : Closed e2422364519550 ∧ code e2422364519550 = 11218457541758 := by decide
theorem cert_e2422364519550 : check e2422364519550 [[],[]] .three = true := by decide
def e2422364519646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364519646 : Closed e2422364519646 ∧ code e2422364519646 = 11218457541854 := by decide
theorem cert_e2422364519646 : check e2422364519646 [[],[]] .smaller = true := by decide
def e2422364519650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422364519650 : Closed e2422364519650 ∧ code e2422364519650 = 11218457541858 := by decide
theorem cert_e2422364519650 : check e2422364519650 [[],[]] .smaller = true := by decide
def e2422364519662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364519662 : Closed e2422364519662 ∧ code e2422364519662 = 11218457541870 := by decide
theorem cert_e2422364519662 : check e2422364519662 [[],[]] .smaller = true := by decide
def e2422364519670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364519670 : Closed e2422364519670 ∧ code e2422364519670 = 11218457541878 := by decide
theorem cert_e2422364519670 : check e2422364519670 [[],[]] .smaller = true := by decide
def e2422364519674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364519674 : Closed e2422364519674 ∧ code e2422364519674 = 11218457541882 := by decide
theorem cert_e2422364519674 : check e2422364519674 [[],[]] .smaller = true := by decide
def e2422364520046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364520046 : Closed e2422364520046 ∧ code e2422364520046 = 11218457542254 := by decide
theorem cert_e2422364520046 : check e2422364520046 [[],[]] .smaller = true := by decide
def e2422364520054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364520054 : Closed e2422364520054 ∧ code e2422364520054 = 11218457542262 := by decide
theorem cert_e2422364520054 : check e2422364520054 [[],[]] .smaller = true := by decide
def e2422364520058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364520058 : Closed e2422364520058 ∧ code e2422364520058 = 11218457542266 := by decide
theorem cert_e2422364520058 : check e2422364520058 [[],[]] .smaller = true := by decide
def e2422364520222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.lam (.var 3))))))))))
theorem wire_e2422364520222 : Closed e2422364520222 ∧ code e2422364520222 = 11218457542430 := by decide
theorem cert_e2422364520222 : check e2422364520222 [[],[]] .three = true := by decide
def e2422364520246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364520246 : Closed e2422364520246 ∧ code e2422364520246 = 11218457542454 := by decide
theorem cert_e2422364520246 : check e2422364520246 [[],[]] .three = true := by decide
def e2422364520250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364520250 : Closed e2422364520250 ∧ code e2422364520250 = 11218457542458 := by decide
theorem cert_e2422364520250 : check e2422364520250 [[],[]] .three = true := by decide
def e2422364538750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 5))))))))))
theorem wire_e2422364538750 : Closed e2422364538750 ∧ code e2422364538750 = 11218457560958 := by decide
theorem cert_e2422364538750 : check e2422364538750 [[],[]] .three = true := by decide
def e2422364538814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422364538814 : Closed e2422364538814 ∧ code e2422364538814 = 11218457561022 := by decide
theorem cert_e2422364538814 : check e2422364538814 [[],[]] .smaller = true := by decide
def e2422364538846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e2422364538846 : Closed e2422364538846 ∧ code e2422364538846 = 11218457561054 := by decide
theorem cert_e2422364538846 : check e2422364538846 [[],[]] .smaller = true := by decide
def e2422364538862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422364538862 : Closed e2422364538862 ∧ code e2422364538862 = 11218457561070 := by decide
theorem cert_e2422364538862 : check e2422364538862 [[],[]] .smaller = true := by decide
def e2422364538870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 5) (.var 1))))))))))
theorem wire_e2422364538870 : Closed e2422364538870 ∧ code e2422364538870 = 11218457561078 := by decide
theorem cert_e2422364538870 : check e2422364538870 [[],[]] .three = true := by decide
def e2422364542510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422364542510 : Closed e2422364542510 ∧ code e2422364542510 = 11218457564718 := by decide
theorem cert_e2422364542510 : check e2422364542510 [[],[]] .smaller = true := by decide
def e2422364542654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2422364542654 : Closed e2422364542654 ∧ code e2422364542654 = 11218457564862 := by decide
theorem cert_e2422364542654 : check e2422364542654 [[],[]] .three = true := by decide
def e2422364542686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422364542686 : Closed e2422364542686 ∧ code e2422364542686 = 11218457564894 := by decide
theorem cert_e2422364542686 : check e2422364542686 [[],[]] .smaller = true := by decide
def e2422364542690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422364542690 : Closed e2422364542690 ∧ code e2422364542690 = 11218457564898 := by decide
theorem cert_e2422364542690 : check e2422364542690 [[],[]] .smaller = true := by decide
def e2422364542702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422364542702 : Closed e2422364542702 ∧ code e2422364542702 = 11218457564910 := by decide
theorem cert_e2422364542702 : check e2422364542702 [[],[]] .smaller = true := by decide
def e2422364542710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422364542710 : Closed e2422364542710 ∧ code e2422364542710 = 11218457564918 := by decide
theorem cert_e2422364542710 : check e2422364542710 [[],[]] .smaller = true := by decide
def e2422364542714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2422364542714 : Closed e2422364542714 ∧ code e2422364542714 = 11218457564922 := by decide
theorem cert_e2422364542714 : check e2422364542714 [[],[]] .three = true := by decide
def e2422364542814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422364542814 : Closed e2422364542814 ∧ code e2422364542814 = 11218457565022 := by decide
theorem cert_e2422364542814 : check e2422364542814 [[],[]] .smaller = true := by decide
def e2422364542830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2422364542830 : Closed e2422364542830 ∧ code e2422364542830 = 11218457565038 := by decide
theorem cert_e2422364542830 : check e2422364542830 [[],[]] .smaller = true := by decide
def e2422364542838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2422364542838 : Closed e2422364542838 ∧ code e2422364542838 = 11218457565046 := by decide
theorem cert_e2422364542838 : check e2422364542838 [[],[]] .smaller = true := by decide
def e2422364542842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422364542842 : Closed e2422364542842 ∧ code e2422364542842 = 11218457565050 := by decide
theorem cert_e2422364542842 : check e2422364542842 [[],[]] .smaller = true := by decide
def e2422364542858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364542858 : Closed e2422364542858 ∧ code e2422364542858 = 11218457565066 := by decide
theorem cert_e2422364542858 : check e2422364542858 [[],[]] .smaller = true := by decide
def e2422364542882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364542882 : Closed e2422364542882 ∧ code e2422364542882 = 11218457565090 := by decide
theorem cert_e2422364542882 : check e2422364542882 [[],[]] .smaller = true := by decide
def e2422364542894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422364542894 : Closed e2422364542894 ∧ code e2422364542894 = 11218457565102 := by decide
theorem cert_e2422364542894 : check e2422364542894 [[],[]] .smaller = true := by decide
def e2422364542902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2422364542902 : Closed e2422364542902 ∧ code e2422364542902 = 11218457565110 := by decide
theorem cert_e2422364542902 : check e2422364542902 [[],[]] .smaller = true := by decide
def e2422364542906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422364542906 : Closed e2422364542906 ∧ code e2422364542906 = 11218457565114 := by decide
theorem cert_e2422364542906 : check e2422364542906 [[],[]] .smaller = true := by decide
def e2422364542934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422364542934 : Closed e2422364542934 ∧ code e2422364542934 = 11218457565142 := by decide
theorem cert_e2422364542934 : check e2422364542934 [[],[]] .smaller = true := by decide
def e2422364542938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422364542938 : Closed e2422364542938 ∧ code e2422364542938 = 11218457565146 := by decide
theorem cert_e2422364542938 : check e2422364542938 [[],[]] .smaller = true := by decide
def e2422364542954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2422364542954 : Closed e2422364542954 ∧ code e2422364542954 = 11218457565162 := by decide
theorem cert_e2422364542954 : check e2422364542954 [[],[]] .three = true := by decide
def e2422364543038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422364543038 : Closed e2422364543038 ∧ code e2422364543038 = 11218457565246 := by decide
theorem cert_e2422364543038 : check e2422364543038 [[],[]] .smaller = true := by decide
def e2422364543422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422364543422 : Closed e2422364543422 ∧ code e2422364543422 = 11218457565630 := by decide
theorem cert_e2422364543422 : check e2422364543422 [[],[]] .three = true := by decide
def e2422364543454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364543454 : Closed e2422364543454 ∧ code e2422364543454 = 11218457565662 := by decide
theorem cert_e2422364543454 : check e2422364543454 [[],[]] .smaller = true := by decide
def e2422364543458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422364543458 : Closed e2422364543458 ∧ code e2422364543458 = 11218457565666 := by decide
theorem cert_e2422364543458 : check e2422364543458 [[],[]] .smaller = true := by decide
def e2422364543470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364543470 : Closed e2422364543470 ∧ code e2422364543470 = 11218457565678 := by decide
theorem cert_e2422364543470 : check e2422364543470 [[],[]] .smaller = true := by decide
def e2422364543478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364543478 : Closed e2422364543478 ∧ code e2422364543478 = 11218457565686 := by decide
theorem cert_e2422364543478 : check e2422364543478 [[],[]] .smaller = true := by decide
def e2422364543482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422364543482 : Closed e2422364543482 ∧ code e2422364543482 = 11218457565690 := by decide
theorem cert_e2422364543482 : check e2422364543482 [[],[]] .three = true := by decide
def e2422364544126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 5))))))))))
theorem wire_e2422364544126 : Closed e2422364544126 ∧ code e2422364544126 = 11218457566334 := by decide
theorem cert_e2422364544126 : check e2422364544126 [[],[]] .three = true := by decide
def e2422364544222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364544222 : Closed e2422364544222 ∧ code e2422364544222 = 11218457566430 := by decide
theorem cert_e2422364544222 : check e2422364544222 [[],[]] .smaller = true := by decide
def e2422364544238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364544238 : Closed e2422364544238 ∧ code e2422364544238 = 11218457566446 := by decide
theorem cert_e2422364544238 : check e2422364544238 [[],[]] .smaller = true := by decide
def e2422364544246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364544246 : Closed e2422364544246 ∧ code e2422364544246 = 11218457566454 := by decide
theorem cert_e2422364544246 : check e2422364544246 [[],[]] .smaller = true := by decide
def e2422364544250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364544250 : Closed e2422364544250 ∧ code e2422364544250 = 11218457566458 := by decide
theorem cert_e2422364544250 : check e2422364544250 [[],[]] .smaller = true := by decide
def e2422364544526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364544526 : Closed e2422364544526 ∧ code e2422364544526 = 11218457566734 := by decide
theorem cert_e2422364544526 : check e2422364544526 [[],[]] .smaller = true := by decide
def e2422364544538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364544538 : Closed e2422364544538 ∧ code e2422364544538 = 11218457566746 := by decide
theorem cert_e2422364544538 : check e2422364544538 [[],[]] .smaller = true := by decide
def e2422364544610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364544610 : Closed e2422364544610 ∧ code e2422364544610 = 11218457566818 := by decide
theorem cert_e2422364544610 : check e2422364544610 [[],[]] .smaller = true := by decide
def e2422364544622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364544622 : Closed e2422364544622 ∧ code e2422364544622 = 11218457566830 := by decide
theorem cert_e2422364544622 : check e2422364544622 [[],[]] .smaller = true := by decide
def e2422364544630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364544630 : Closed e2422364544630 ∧ code e2422364544630 = 11218457566838 := by decide
theorem cert_e2422364544630 : check e2422364544630 [[],[]] .smaller = true := by decide
def e2422364544634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364544634 : Closed e2422364544634 ∧ code e2422364544634 = 11218457566842 := by decide
theorem cert_e2422364544634 : check e2422364544634 [[],[]] .smaller = true := by decide
def e2422364544822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364544822 : Closed e2422364544822 ∧ code e2422364544822 = 11218457567030 := by decide
theorem cert_e2422364544822 : check e2422364544822 [[],[]] .smaller = true := by decide
def e2422364544826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364544826 : Closed e2422364544826 ∧ code e2422364544826 = 11218457567034 := by decide
theorem cert_e2422364544826 : check e2422364544826 [[],[]] .smaller = true := by decide
def e2422364544910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.lam (.var 2))))))))))
theorem wire_e2422364544910 : Closed e2422364544910 ∧ code e2422364544910 = 11218457567118 := by decide
theorem cert_e2422364544910 : check e2422364544910 [[],[]] .three = true := by decide
def e2422364544922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364544922 : Closed e2422364544922 ∧ code e2422364544922 = 11218457567130 := by decide
theorem cert_e2422364544922 : check e2422364544922 [[],[]] .three = true := by decide
def e2422364544958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 4)))))))))
theorem wire_e2422364544958 : Closed e2422364544958 ∧ code e2422364544958 = 11218457567166 := by decide
theorem cert_e2422364544958 : check e2422364544958 [[],[]] .three = true := by decide
def e2422364554174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422364554174 : Closed e2422364554174 ∧ code e2422364554174 = 11218457576382 := by decide
theorem cert_e2422364554174 : check e2422364554174 [[],[]] .smaller = true := by decide
def e2422364554206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422364554206 : Closed e2422364554206 ∧ code e2422364554206 = 11218457576414 := by decide
theorem cert_e2422364554206 : check e2422364554206 [[],[]] .smaller = true := by decide
def e2422364554222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422364554222 : Closed e2422364554222 ∧ code e2422364554222 = 11218457576430 := by decide
theorem cert_e2422364554222 : check e2422364554222 [[],[]] .smaller = true := by decide
def e2422364554230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422364554230 : Closed e2422364554230 ∧ code e2422364554230 = 11218457576438 := by decide
theorem cert_e2422364554230 : check e2422364554230 [[],[]] .smaller = true := by decide
def e2422364556054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422364556054 : Closed e2422364556054 ∧ code e2422364556054 = 11218457578262 := by decide
theorem cert_e2422364556054 : check e2422364556054 [[],[]] .smaller = true := by decide
def e2422364556126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422364556126 : Closed e2422364556126 ∧ code e2422364556126 = 11218457578334 := by decide
theorem cert_e2422364556126 : check e2422364556126 [[],[]] .smaller = true := by decide
def e2422364556130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422364556130 : Closed e2422364556130 ∧ code e2422364556130 = 11218457578338 := by decide
theorem cert_e2422364556130 : check e2422364556130 [[],[]] .smaller = true := by decide
def e2422364556142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422364556142 : Closed e2422364556142 ∧ code e2422364556142 = 11218457578350 := by decide
theorem cert_e2422364556142 : check e2422364556142 [[],[]] .smaller = true := by decide
def e2422364556150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422364556150 : Closed e2422364556150 ∧ code e2422364556150 = 11218457578358 := by decide
theorem cert_e2422364556150 : check e2422364556150 [[],[]] .smaller = true := by decide
def e2422364556154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422364556154 : Closed e2422364556154 ∧ code e2422364556154 = 11218457578362 := by decide
theorem cert_e2422364556154 : check e2422364556154 [[],[]] .smaller = true := by decide
def e2422364556170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422364556170 : Closed e2422364556170 ∧ code e2422364556170 = 11218457578378 := by decide
theorem cert_e2422364556170 : check e2422364556170 [[],[]] .smaller = true := by decide
def e2422364556194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422364556194 : Closed e2422364556194 ∧ code e2422364556194 = 11218457578402 := by decide
theorem cert_e2422364556194 : check e2422364556194 [[],[]] .smaller = true := by decide
def e2422364556206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422364556206 : Closed e2422364556206 ∧ code e2422364556206 = 11218457578414 := by decide
theorem cert_e2422364556206 : check e2422364556206 [[],[]] .smaller = true := by decide
def e2422364556214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))))
theorem wire_e2422364556214 : Closed e2422364556214 ∧ code e2422364556214 = 11218457578422 := by decide
theorem cert_e2422364556214 : check e2422364556214 [[],[]] .smaller = true := by decide
def e2422364556218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422364556218 : Closed e2422364556218 ∧ code e2422364556218 = 11218457578426 := by decide
theorem cert_e2422364556218 : check e2422364556218 [[],[]] .smaller = true := by decide
def e2422364556246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422364556246 : Closed e2422364556246 ∧ code e2422364556246 = 11218457578454 := by decide
theorem cert_e2422364556246 : check e2422364556246 [[],[]] .smaller = true := by decide
def e2422364556250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422364556250 : Closed e2422364556250 ∧ code e2422364556250 = 11218457578458 := by decide
theorem cert_e2422364556250 : check e2422364556250 [[],[]] .smaller = true := by decide
def e2422364556266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422364556266 : Closed e2422364556266 ∧ code e2422364556266 = 11218457578474 := by decide
theorem cert_e2422364556266 : check e2422364556266 [[],[]] .smaller = true := by decide
def e2422364556318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422364556318 : Closed e2422364556318 ∧ code e2422364556318 = 11218457578526 := by decide
theorem cert_e2422364556318 : check e2422364556318 [[],[]] .smaller = true := by decide
def e2422364556414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 5))))))))))
theorem wire_e2422364556414 : Closed e2422364556414 ∧ code e2422364556414 = 11218457578622 := by decide
theorem cert_e2422364556414 : check e2422364556414 [[],[]] .three = true := by decide
def e2422364556510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422364556510 : Closed e2422364556510 ∧ code e2422364556510 = 11218457578718 := by decide
theorem cert_e2422364556510 : check e2422364556510 [[],[]] .smaller = true := by decide
def e2422364556514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422364556514 : Closed e2422364556514 ∧ code e2422364556514 = 11218457578722 := by decide
theorem cert_e2422364556514 : check e2422364556514 [[],[]] .smaller = true := by decide
def e2422364556526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364556526 : Closed e2422364556526 ∧ code e2422364556526 = 11218457578734 := by decide
theorem cert_e2422364556526 : check e2422364556526 [[],[]] .smaller = true := by decide
def e2422364556534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364556534 : Closed e2422364556534 ∧ code e2422364556534 = 11218457578742 := by decide
theorem cert_e2422364556534 : check e2422364556534 [[],[]] .smaller = true := by decide
def e2422364556538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422364556538 : Closed e2422364556538 ∧ code e2422364556538 = 11218457578746 := by decide
theorem cert_e2422364556538 : check e2422364556538 [[],[]] .smaller = true := by decide
def e2422364556814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422364556814 : Closed e2422364556814 ∧ code e2422364556814 = 11218457579022 := by decide
theorem cert_e2422364556814 : check e2422364556814 [[],[]] .smaller = true := by decide
def e2422364556826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364556826 : Closed e2422364556826 ∧ code e2422364556826 = 11218457579034 := by decide
theorem cert_e2422364556826 : check e2422364556826 [[],[]] .smaller = true := by decide
def e2422364556898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422364556898 : Closed e2422364556898 ∧ code e2422364556898 = 11218457579106 := by decide
theorem cert_e2422364556898 : check e2422364556898 [[],[]] .smaller = true := by decide
def e2422364556910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364556910 : Closed e2422364556910 ∧ code e2422364556910 = 11218457579118 := by decide
theorem cert_e2422364556910 : check e2422364556910 [[],[]] .smaller = true := by decide
def e2422364556918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364556918 : Closed e2422364556918 ∧ code e2422364556918 = 11218457579126 := by decide
theorem cert_e2422364556918 : check e2422364556918 [[],[]] .smaller = true := by decide
def e2422364556922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364556922 : Closed e2422364556922 ∧ code e2422364556922 = 11218457579130 := by decide
theorem cert_e2422364556922 : check e2422364556922 [[],[]] .smaller = true := by decide
def e2422364557110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364557110 : Closed e2422364557110 ∧ code e2422364557110 = 11218457579318 := by decide
theorem cert_e2422364557110 : check e2422364557110 [[],[]] .smaller = true := by decide
def e2422364557114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364557114 : Closed e2422364557114 ∧ code e2422364557114 = 11218457579322 := by decide
theorem cert_e2422364557114 : check e2422364557114 [[],[]] .smaller = true := by decide
def e2422364557210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364557210 : Closed e2422364557210 ∧ code e2422364557210 = 11218457579418 := by decide
theorem cert_e2422364557210 : check e2422364557210 [[],[]] .smaller = true := by decide
def e2422364557254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 4) (.lam (.var 1))))))))))
theorem wire_e2422364557254 : Closed e2422364557254 ∧ code e2422364557254 = 11218457579462 := by decide
theorem cert_e2422364557254 : check e2422364557254 [[],[]] .three = true := by decide
def e2422364561886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422364561886 : Closed e2422364561886 ∧ code e2422364561886 = 11218457584094 := by decide
theorem cert_e2422364561886 : check e2422364561886 [[],[]] .smaller = true := by decide
def e2422364561902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422364561902 : Closed e2422364561902 ∧ code e2422364561902 = 11218457584110 := by decide
theorem cert_e2422364561902 : check e2422364561902 [[],[]] .smaller = true := by decide
def e2422364561910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422364561910 : Closed e2422364561910 ∧ code e2422364561910 = 11218457584118 := by decide
theorem cert_e2422364561910 : check e2422364561910 [[],[]] .smaller = true := by decide
def e2422364562862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422364562862 : Closed e2422364562862 ∧ code e2422364562862 = 11218457585070 := by decide
theorem cert_e2422364562862 : check e2422364562862 [[],[]] .smaller = true := by decide
def e2422364562870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422364562870 : Closed e2422364562870 ∧ code e2422364562870 = 11218457585078 := by decide
theorem cert_e2422364562870 : check e2422364562870 [[],[]] .smaller = true := by decide
def e2422364562874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422364562874 : Closed e2422364562874 ∧ code e2422364562874 = 11218457585082 := by decide
theorem cert_e2422364562874 : check e2422364562874 [[],[]] .smaller = true := by decide
def e2422364562902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422364562902 : Closed e2422364562902 ∧ code e2422364562902 = 11218457585110 := by decide
theorem cert_e2422364562902 : check e2422364562902 [[],[]] .smaller = true := by decide
def e2422364562906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422364562906 : Closed e2422364562906 ∧ code e2422364562906 = 11218457585114 := by decide
theorem cert_e2422364562906 : check e2422364562906 [[],[]] .smaller = true := by decide
def e2422364562922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422364562922 : Closed e2422364562922 ∧ code e2422364562922 = 11218457585130 := by decide
theorem cert_e2422364562922 : check e2422364562922 [[],[]] .smaller = true := by decide
def e2422364563054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364563054 : Closed e2422364563054 ∧ code e2422364563054 = 11218457585262 := by decide
theorem cert_e2422364563054 : check e2422364563054 [[],[]] .smaller = true := by decide
def e2422364563062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422364563062 : Closed e2422364563062 ∧ code e2422364563062 = 11218457585270 := by decide
theorem cert_e2422364563062 : check e2422364563062 [[],[]] .smaller = true := by decide
def e2422364563066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364563066 : Closed e2422364563066 ∧ code e2422364563066 = 11218457585274 := by decide
theorem cert_e2422364563066 : check e2422364563066 [[],[]] .smaller = true := by decide
def e2422364563254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364563254 : Closed e2422364563254 ∧ code e2422364563254 = 11218457585462 := by decide
theorem cert_e2422364563254 : check e2422364563254 [[],[]] .smaller = true := by decide
def e2422364563258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364563258 : Closed e2422364563258 ∧ code e2422364563258 = 11218457585466 := by decide
theorem cert_e2422364563258 : check e2422364563258 [[],[]] .smaller = true := by decide
def e2422364563354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364563354 : Closed e2422364563354 ∧ code e2422364563354 = 11218457585562 := by decide
theorem cert_e2422364563354 : check e2422364563354 [[],[]] .smaller = true := by decide
def e2422364565742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364565742 : Closed e2422364565742 ∧ code e2422364565742 = 11218457587950 := by decide
theorem cert_e2422364565742 : check e2422364565742 [[],[]] .three = true := by decide
def e2422364565750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364565750 : Closed e2422364565750 ∧ code e2422364565750 = 11218457587958 := by decide
theorem cert_e2422364565750 : check e2422364565750 [[],[]] .three = true := by decide
def e2422364566230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422364566230 : Closed e2422364566230 ∧ code e2422364566230 = 11218457588438 := by decide
theorem cert_e2422364566230 : check e2422364566230 [[],[]] .three = true := by decide
def e2422364566234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422364566234 : Closed e2422364566234 ∧ code e2422364566234 = 11218457588442 := by decide
theorem cert_e2422364566234 : check e2422364566234 [[],[]] .three = true := by decide
def e2422364566250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422364566250 : Closed e2422364566250 ∧ code e2422364566250 = 11218457588458 := by decide
theorem cert_e2422364566250 : check e2422364566250 [[],[]] .three = true := by decide
def e2422364566302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422364566302 : Closed e2422364566302 ∧ code e2422364566302 = 11218457588510 := by decide
theorem cert_e2422364566302 : check e2422364566302 [[],[]] .three = true := by decide
def e2422364566326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422364566326 : Closed e2422364566326 ∧ code e2422364566326 = 11218457588534 := by decide
theorem cert_e2422364566326 : check e2422364566326 [[],[]] .three = true := by decide
def e2422364566330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422364566330 : Closed e2422364566330 ∧ code e2422364566330 = 11218457588538 := by decide
theorem cert_e2422364566330 : check e2422364566330 [[],[]] .three = true := by decide
def e2422364566414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422364566414 : Closed e2422364566414 ∧ code e2422364566414 = 11218457588622 := by decide
theorem cert_e2422364566414 : check e2422364566414 [[],[]] .three = true := by decide
def e2422364566426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364566426 : Closed e2422364566426 ∧ code e2422364566426 = 11218457588634 := by decide
theorem cert_e2422364566426 : check e2422364566426 [[],[]] .three = true := by decide
def e2422364566462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364566462 : Closed e2422364566462 ∧ code e2422364566462 = 11218457588670 := by decide
theorem cert_e2422364566462 : check e2422364566462 [[],[]] .three = true := by decide
def e2422364566470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422364566470 : Closed e2422364566470 ∧ code e2422364566470 = 11218457588678 := by decide
theorem cert_e2422364566470 : check e2422364566470 [[],[]] .three = true := by decide
def e2422364566518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364566518 : Closed e2422364566518 ∧ code e2422364566518 = 11218457588726 := by decide
theorem cert_e2422364566518 : check e2422364566518 [[],[]] .three = true := by decide
def e2422364573294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364573294 : Closed e2422364573294 ∧ code e2422364573294 = 11218457595502 := by decide
theorem cert_e2422364573294 : check e2422364573294 [[],[]] .smaller = true := by decide
def e2422364573306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364573306 : Closed e2422364573306 ∧ code e2422364573306 = 11218457595514 := by decide
theorem cert_e2422364573306 : check e2422364573306 [[],[]] .smaller = true := by decide
def e2422364573594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364573594 : Closed e2422364573594 ∧ code e2422364573594 = 11218457595802 := by decide
theorem cert_e2422364573594 : check e2422364573594 [[],[]] .smaller = true := by decide
def e2422364576366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364576366 : Closed e2422364576366 ∧ code e2422364576366 = 11218457598574 := by decide
theorem cert_e2422364576366 : check e2422364576366 [[],[]] .smaller = true := by decide
def e2422364576378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364576378 : Closed e2422364576378 ∧ code e2422364576378 = 11218457598586 := by decide
theorem cert_e2422364576378 : check e2422364576378 [[],[]] .smaller = true := by decide
def e2422364577214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 4))))))))
theorem wire_e2422364577214 : Closed e2422364577214 ∧ code e2422364577214 = 11218457599422 := by decide
theorem cert_e2422364577214 : check e2422364577214 [[],[]] .three = true := by decide
def e2422364577246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 3))))))))
theorem wire_e2422364577246 : Closed e2422364577246 ∧ code e2422364577246 = 11218457599454 := by decide
theorem cert_e2422364577246 : check e2422364577246 [[],[]] .smaller = true := by decide
def e2422364577262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))))
theorem wire_e2422364577262 : Closed e2422364577262 ∧ code e2422364577262 = 11218457599470 := by decide
theorem cert_e2422364577262 : check e2422364577262 [[],[]] .smaller = true := by decide
def e2422364577270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 1))))))))
theorem wire_e2422364577270 : Closed e2422364577270 ∧ code e2422364577270 = 11218457599478 := by decide
theorem cert_e2422364577270 : check e2422364577270 [[],[]] .smaller = true := by decide
def e2422364577274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 5)))) (.var 0))))))))
theorem wire_e2422364577274 : Closed e2422364577274 ∧ code e2422364577274 = 11218457599482 := by decide
theorem cert_e2422364577274 : check e2422364577274 [[],[]] .three = true := by decide
def e2422364577502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 3))))))))
theorem wire_e2422364577502 : Closed e2422364577502 ∧ code e2422364577502 = 11218457599710 := by decide
theorem cert_e2422364577502 : check e2422364577502 [[],[]] .smaller = true := by decide
def e2422364577530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 4)))) (.var 0))))))))
theorem wire_e2422364577530 : Closed e2422364577530 ∧ code e2422364577530 = 11218457599738 := by decide
theorem cert_e2422364577530 : check e2422364577530 [[],[]] .smaller = true := by decide
def e2422364577646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))))
theorem wire_e2422364577646 : Closed e2422364577646 ∧ code e2422364577646 = 11218457599854 := by decide
theorem cert_e2422364577646 : check e2422364577646 [[],[]] .smaller = true := by decide
def e2422364577658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))))
theorem wire_e2422364577658 : Closed e2422364577658 ∧ code e2422364577658 = 11218457599866 := by decide
theorem cert_e2422364577658 : check e2422364577658 [[],[]] .smaller = true := by decide
def e2422364577718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 1))))))))
theorem wire_e2422364577718 : Closed e2422364577718 ∧ code e2422364577718 = 11218457599926 := by decide
theorem cert_e2422364577718 : check e2422364577718 [[],[]] .smaller = true := by decide
def e2422364577722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 2)))) (.var 0))))))))
theorem wire_e2422364577722 : Closed e2422364577722 ∧ code e2422364577722 = 11218457599930 := by decide
theorem cert_e2422364577722 : check e2422364577722 [[],[]] .smaller = true := by decide
def e2422364577754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 5) (.var 1)))) (.var 0))))))))
theorem wire_e2422364577754 : Closed e2422364577754 ∧ code e2422364577754 = 11218457599962 := by decide
theorem cert_e2422364577754 : check e2422364577754 [[],[]] .three = true := by decide
def e2422364579246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422364579246 : Closed e2422364579246 ∧ code e2422364579246 = 11218457601454 := by decide
theorem cert_e2422364579246 : check e2422364579246 [[],[]] .smaller = true := by decide
def e2422364579258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422364579258 : Closed e2422364579258 ∧ code e2422364579258 = 11218457601466 := by decide
theorem cert_e2422364579258 : check e2422364579258 [[],[]] .smaller = true := by decide
def e2422364579306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422364579306 : Closed e2422364579306 ∧ code e2422364579306 = 11218457601514 := by decide
theorem cert_e2422364579306 : check e2422364579306 [[],[]] .smaller = true := by decide
def e2422364579438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422364579438 : Closed e2422364579438 ∧ code e2422364579438 = 11218457601646 := by decide
theorem cert_e2422364579438 : check e2422364579438 [[],[]] .smaller = true := by decide
def e2422364579450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422364579450 : Closed e2422364579450 ∧ code e2422364579450 = 11218457601658 := by decide
theorem cert_e2422364579450 : check e2422364579450 [[],[]] .smaller = true := by decide
def e2422364579738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364579738 : Closed e2422364579738 ∧ code e2422364579738 = 11218457601946 := by decide
theorem cert_e2422364579738 : check e2422364579738 [[],[]] .smaller = true := by decide
def e2422364582686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422364582686 : Closed e2422364582686 ∧ code e2422364582686 = 11218457604894 := by decide
theorem cert_e2422364582686 : check e2422364582686 [[],[]] .smaller = true := by decide
end Blc.Floor43
