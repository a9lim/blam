import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389344039854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2389344039854 : Closed e2389344039854 ∧ code e2389344039854 = 11185437062062 := by decide
theorem cert_e2389344039854 : check e2389344039854 [[],[.left],[]] .smaller = true := by decide
def e2389344039866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2389344039866 : Closed e2389344039866 ∧ code e2389344039866 = 11185437062074 := by decide
theorem cert_e2389344039866 : check e2389344039866 [[],[.left],[]] .smaller = true := by decide
def e2389344039894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2389344039894 : Closed e2389344039894 ∧ code e2389344039894 = 11185437062102 := by decide
theorem cert_e2389344039894 : check e2389344039894 [[],[.left],[]] .smaller = true := by decide
def e2389344039898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2389344039898 : Closed e2389344039898 ∧ code e2389344039898 = 11185437062106 := by decide
theorem cert_e2389344039898 : check e2389344039898 [[],[.left],[]] .smaller = true := by decide
def e2389344040174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389344040174 : Closed e2389344040174 ∧ code e2389344040174 = 11185437062382 := by decide
theorem cert_e2389344040174 : check e2389344040174 [[],[.left],[]] .smaller = true := by decide
def e2389344040182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389344040182 : Closed e2389344040182 ∧ code e2389344040182 = 11185437062390 := by decide
theorem cert_e2389344040182 : check e2389344040182 [[],[.left],[]] .smaller = true := by decide
def e2389344040558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344040558 : Closed e2389344040558 ∧ code e2389344040558 = 11185437062766 := by decide
theorem cert_e2389344040558 : check e2389344040558 [[],[.left],[]] .smaller = true := by decide
def e2389344040570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344040570 : Closed e2389344040570 ∧ code e2389344040570 = 11185437062778 := by decide
theorem cert_e2389344040570 : check e2389344040570 [[],[.left],[]] .smaller = true := by decide
def e2389344040758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344040758 : Closed e2389344040758 ∧ code e2389344040758 = 11185437062966 := by decide
theorem cert_e2389344040758 : check e2389344040758 [[],[.left],[]] .smaller = true := by decide
def e2389344040762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344040762 : Closed e2389344040762 ∧ code e2389344040762 = 11185437062970 := by decide
theorem cert_e2389344040762 : check e2389344040762 [[],[.left],[]] .smaller = true := by decide
def e2389344041390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2389344041390 : Closed e2389344041390 ∧ code e2389344041390 = 11185437063598 := by decide
theorem cert_e2389344041390 : check e2389344041390 [[],[.left],[]] .smaller = true := by decide
def e2389344041402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2389344041402 : Closed e2389344041402 ∧ code e2389344041402 = 11185437063610 := by decide
theorem cert_e2389344041402 : check e2389344041402 [[],[.left],[]] .smaller = true := by decide
def e2389344041450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2389344041450 : Closed e2389344041450 ∧ code e2389344041450 = 11185437063658 := by decide
theorem cert_e2389344041450 : check e2389344041450 [[],[.left],[]] .smaller = true := by decide
def e2389344041582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389344041582 : Closed e2389344041582 ∧ code e2389344041582 = 11185437063790 := by decide
theorem cert_e2389344041582 : check e2389344041582 [[],[.left],[]] .smaller = true := by decide
def e2389344041594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389344041594 : Closed e2389344041594 ∧ code e2389344041594 = 11185437063802 := by decide
theorem cert_e2389344041594 : check e2389344041594 [[],[.left],[]] .smaller = true := by decide
def e2389344041882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344041882 : Closed e2389344041882 ∧ code e2389344041882 = 11185437064090 := by decide
theorem cert_e2389344041882 : check e2389344041882 [[],[.left],[]] .smaller = true := by decide
def e2389344042198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2389344042198 : Closed e2389344042198 ∧ code e2389344042198 = 11185437064406 := by decide
theorem cert_e2389344042198 : check e2389344042198 [[],[.left],[]] .smaller = true := by decide
def e2389344042202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2389344042202 : Closed e2389344042202 ∧ code e2389344042202 = 11185437064410 := by decide
theorem cert_e2389344042202 : check e2389344042202 [[],[.left],[]] .smaller = true := by decide
def e2389344042218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2389344042218 : Closed e2389344042218 ∧ code e2389344042218 = 11185437064426 := by decide
theorem cert_e2389344042218 : check e2389344042218 [[],[.left],[]] .smaller = true := by decide
def e2389344042294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389344042294 : Closed e2389344042294 ∧ code e2389344042294 = 11185437064502 := by decide
theorem cert_e2389344042294 : check e2389344042294 [[],[.left],[]] .smaller = true := by decide
def e2389344042298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389344042298 : Closed e2389344042298 ∧ code e2389344042298 = 11185437064506 := by decide
theorem cert_e2389344042298 : check e2389344042298 [[],[.left],[]] .smaller = true := by decide
def e2389344042394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389344042394 : Closed e2389344042394 ∧ code e2389344042394 = 11185437064602 := by decide
theorem cert_e2389344042394 : check e2389344042394 [[],[.left],[]] .smaller = true := by decide
def e2389344045934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2389344045934 : Closed e2389344045934 ∧ code e2389344045934 = 11185437068142 := by decide
theorem cert_e2389344045934 : check e2389344045934 [[],[.left],[]] .smaller = true := by decide
def e2389344045942 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2389344045942 : Closed e2389344045942 ∧ code e2389344045942 = 11185437068150 := by decide
theorem cert_e2389344045942 : check e2389344045942 [[],[.left],[]] .smaller = true := by decide
def e2389344045998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2389344045998 : Closed e2389344045998 ∧ code e2389344045998 = 11185437068206 := by decide
theorem cert_e2389344045998 : check e2389344045998 [[],[.left],[]] .smaller = true := by decide
def e2389344046010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2389344046010 : Closed e2389344046010 ∧ code e2389344046010 = 11185437068218 := by decide
theorem cert_e2389344046010 : check e2389344046010 [[],[.left],[]] .smaller = true := by decide
def e2389344046038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2389344046038 : Closed e2389344046038 ∧ code e2389344046038 = 11185437068246 := by decide
theorem cert_e2389344046038 : check e2389344046038 [[],[.left],[]] .smaller = true := by decide
def e2389344046042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2389344046042 : Closed e2389344046042 ∧ code e2389344046042 = 11185437068250 := by decide
theorem cert_e2389344046042 : check e2389344046042 [[],[.left],[]] .smaller = true := by decide
def e2389344046318 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2389344046318 : Closed e2389344046318 ∧ code e2389344046318 = 11185437068526 := by decide
theorem cert_e2389344046318 : check e2389344046318 [[],[.left],[]] .smaller = true := by decide
def e2389344046326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2389344046326 : Closed e2389344046326 ∧ code e2389344046326 = 11185437068534 := by decide
theorem cert_e2389344046326 : check e2389344046326 [[],[.left],[]] .smaller = true := by decide
def e2389344046702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2389344046702 : Closed e2389344046702 ∧ code e2389344046702 = 11185437068910 := by decide
theorem cert_e2389344046702 : check e2389344046702 [[],[.left],[]] .smaller = true := by decide
def e2389344046714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2389344046714 : Closed e2389344046714 ∧ code e2389344046714 = 11185437068922 := by decide
theorem cert_e2389344046714 : check e2389344046714 [[],[.left],[]] .smaller = true := by decide
def e2389344046902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2389344046902 : Closed e2389344046902 ∧ code e2389344046902 = 11185437069110 := by decide
theorem cert_e2389344046902 : check e2389344046902 [[],[.left],[]] .smaller = true := by decide
def e2389344046906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2389344046906 : Closed e2389344046906 ∧ code e2389344046906 = 11185437069114 := by decide
theorem cert_e2389344046906 : check e2389344046906 [[],[.left],[]] .smaller = true := by decide
def e2389344052654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2389344052654 : Closed e2389344052654 ∧ code e2389344052654 = 11185437074862 := by decide
theorem cert_e2389344052654 : check e2389344052654 [[],[.left],[]] .smaller = true := by decide
def e2389344052666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2389344052666 : Closed e2389344052666 ∧ code e2389344052666 = 11185437074874 := by decide
theorem cert_e2389344052666 : check e2389344052666 [[],[.left],[]] .smaller = true := by decide
def e2389344052714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2389344052714 : Closed e2389344052714 ∧ code e2389344052714 = 11185437074922 := by decide
theorem cert_e2389344052714 : check e2389344052714 [[],[.left],[]] .smaller = true := by decide
def e2389344052846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2389344052846 : Closed e2389344052846 ∧ code e2389344052846 = 11185437075054 := by decide
theorem cert_e2389344052846 : check e2389344052846 [[],[.left],[]] .smaller = true := by decide
def e2389344052858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2389344052858 : Closed e2389344052858 ∧ code e2389344052858 = 11185437075066 := by decide
theorem cert_e2389344052858 : check e2389344052858 [[],[.left],[]] .smaller = true := by decide
def e2389344053146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2389344053146 : Closed e2389344053146 ∧ code e2389344053146 = 11185437075354 := by decide
theorem cert_e2389344053146 : check e2389344053146 [[],[.left],[]] .smaller = true := by decide
def e2389344056022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2389344056022 : Closed e2389344056022 ∧ code e2389344056022 = 11185437078230 := by decide
theorem cert_e2389344056022 : check e2389344056022 [[],[.left],[]] .smaller = true := by decide
def e2389344056026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2389344056026 : Closed e2389344056026 ∧ code e2389344056026 = 11185437078234 := by decide
theorem cert_e2389344056026 : check e2389344056026 [[],[.left],[]] .smaller = true := by decide
def e2389344056042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2389344056042 : Closed e2389344056042 ∧ code e2389344056042 = 11185437078250 := by decide
theorem cert_e2389344056042 : check e2389344056042 [[],[.left],[]] .smaller = true := by decide
def e2389344056118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2389344056118 : Closed e2389344056118 ∧ code e2389344056118 = 11185437078326 := by decide
theorem cert_e2389344056118 : check e2389344056118 [[],[.left],[]] .smaller = true := by decide
def e2389344056122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2389344056122 : Closed e2389344056122 ∧ code e2389344056122 = 11185437078330 := by decide
theorem cert_e2389344056122 : check e2389344056122 [[],[.left],[]] .smaller = true := by decide
def e2389344056218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2389344056218 : Closed e2389344056218 ∧ code e2389344056218 = 11185437078426 := by decide
theorem cert_e2389344056218 : check e2389344056218 [[],[.left],[]] .smaller = true := by decide
def e2389344171486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2389344171486 : Closed e2389344171486 ∧ code e2389344171486 = 11185437193694 := by decide
theorem cert_e2389344171486 : check e2389344171486 [[],[.left],[]] .chain = true := by decide
def e2389344171502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2389344171502 : Closed e2389344171502 ∧ code e2389344171502 = 11185437193710 := by decide
theorem cert_e2389344171502 : check e2389344171502 [[],[.left],[]] .chain = true := by decide
def e2389344171742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2389344171742 : Closed e2389344171742 ∧ code e2389344171742 = 11185437193950 := by decide
theorem cert_e2389344171742 : check e2389344171742 [[],[.left],[]] .smaller = true := by decide
def e2389344171758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2389344171758 : Closed e2389344171758 ∧ code e2389344171758 = 11185437193966 := by decide
theorem cert_e2389344171758 : check e2389344171758 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2389344171766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2389344171766 : Closed e2389344171766 ∧ code e2389344171766 = 11185437193974 := by decide
theorem cert_e2389344171766 : check e2389344171766 [[],[.left],[]] .smaller = true := by decide
def e2389344171870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2389344171870 : Closed e2389344171870 ∧ code e2389344171870 = 11185437194078 := by decide
theorem cert_e2389344171870 : check e2389344171870 [[],[.left],[]] .chain = true := by decide
def e2389344171886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2389344171886 : Closed e2389344171886 ∧ code e2389344171886 = 11185437194094 := by decide
theorem cert_e2389344171886 : check e2389344171886 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344171894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2389344171894 : Closed e2389344171894 ∧ code e2389344171894 = 11185437194102 := by decide
theorem cert_e2389344171894 : check e2389344171894 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344171898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2389344171898 : Closed e2389344171898 ∧ code e2389344171898 = 11185437194106 := by decide
theorem cert_e2389344171898 : check e2389344171898 [[],[.left],[]] .chain = true := by decide
def e2389344171950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2389344171950 : Closed e2389344171950 ∧ code e2389344171950 = 11185437194158 := by decide
theorem cert_e2389344171950 : check e2389344171950 [[],[.left],[]] .chain = true := by decide
def e2389344171958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2389344171958 : Closed e2389344171958 ∧ code e2389344171958 = 11185437194166 := by decide
theorem cert_e2389344171958 : check e2389344171958 [[],[.left],[]] .smaller = true := by decide
def e2389344171962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2389344171962 : Closed e2389344171962 ∧ code e2389344171962 = 11185437194170 := by decide
theorem cert_e2389344171962 : check e2389344171962 [[],[.left],[]] .chain = true := by decide
def e2389344172766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2389344172766 : Closed e2389344172766 ∧ code e2389344172766 = 11185437194974 := by decide
theorem cert_e2389344172766 : check e2389344172766 [[],[.left],[]] .smaller = true := by decide
def e2389344172782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2389344172782 : Closed e2389344172782 ∧ code e2389344172782 = 11185437194990 := by decide
theorem cert_e2389344172782 : check e2389344172782 [[],[.left],[]] .sourceHead = true := by decide
def e2389344172790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2389344172790 : Closed e2389344172790 ∧ code e2389344172790 = 11185437194998 := by decide
theorem cert_e2389344172790 : check e2389344172790 [[],[.left],[]] .smaller = true := by decide
def e2389344172894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2389344172894 : Closed e2389344172894 ∧ code e2389344172894 = 11185437195102 := by decide
theorem cert_e2389344172894 : check e2389344172894 [[],[.left],[]] .smaller = true := by decide
def e2389344172922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2389344172922 : Closed e2389344172922 ∧ code e2389344172922 = 11185437195130 := by decide
theorem cert_e2389344172922 : check e2389344172922 [[],[.left],[]] .smaller = true := by decide
def e2389344172974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2389344172974 : Closed e2389344172974 ∧ code e2389344172974 = 11185437195182 := by decide
theorem cert_e2389344172974 : check e2389344172974 [[],[.left],[]] .sourceHead = true := by decide
def e2389344172986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2389344172986 : Closed e2389344172986 ∧ code e2389344172986 = 11185437195194 := by decide
theorem cert_e2389344172986 : check e2389344172986 [[],[.left],[]] .sourceHead = true := by decide
def e2389344173014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2389344173014 : Closed e2389344173014 ∧ code e2389344173014 = 11185437195222 := by decide
theorem cert_e2389344173014 : check e2389344173014 [[],[.left],[]] .smaller = true := by decide
def e2389344173018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2389344173018 : Closed e2389344173018 ∧ code e2389344173018 = 11185437195226 := by decide
theorem cert_e2389344173018 : check e2389344173018 [[],[.left],[]] .smaller = true := by decide
def e2389344173406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2389344173406 : Closed e2389344173406 ∧ code e2389344173406 = 11185437195614 := by decide
theorem cert_e2389344173406 : check e2389344173406 [[],[.left],[]] .chain = true := by decide
def e2389344173422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2389344173422 : Closed e2389344173422 ∧ code e2389344173422 = 11185437195630 := by decide
theorem cert_e2389344173422 : check e2389344173422 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344173430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2389344173430 : Closed e2389344173430 ∧ code e2389344173430 = 11185437195638 := by decide
theorem cert_e2389344173430 : check e2389344173430 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344173434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2389344173434 : Closed e2389344173434 ∧ code e2389344173434 = 11185437195642 := by decide
theorem cert_e2389344173434 : check e2389344173434 [[],[.left],[]] .chain = true := by decide
def e2389344173486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2389344173486 : Closed e2389344173486 ∧ code e2389344173486 = 11185437195694 := by decide
theorem cert_e2389344173486 : check e2389344173486 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2389344173498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2389344173498 : Closed e2389344173498 ∧ code e2389344173498 = 11185437195706 := by decide
theorem cert_e2389344173498 : check e2389344173498 [[],[.left],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344173526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2389344173526 : Closed e2389344173526 ∧ code e2389344173526 = 11185437195734 := by decide
theorem cert_e2389344173526 : check e2389344173526 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2389344173530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2389344173530 : Closed e2389344173530 ∧ code e2389344173530 = 11185437195738 := by decide
theorem cert_e2389344173530 : check e2389344173530 [[],[.left],[],[.under,.under,.left,.left]] .smaller = true := by decide
def e2389344173546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2389344173546 : Closed e2389344173546 ∧ code e2389344173546 = 11185437195754 := by decide
theorem cert_e2389344173546 : check e2389344173546 [[],[.left],[]] .chain = true := by decide
def e2389344173742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2389344173742 : Closed e2389344173742 ∧ code e2389344173742 = 11185437195950 := by decide
theorem cert_e2389344173742 : check e2389344173742 [[],[.left],[]] .chain = true := by decide
def e2389344173750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2389344173750 : Closed e2389344173750 ∧ code e2389344173750 = 11185437195958 := by decide
theorem cert_e2389344173750 : check e2389344173750 [[],[.left],[]] .smaller = true := by decide
def e2389344173754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2389344173754 : Closed e2389344173754 ∧ code e2389344173754 = 11185437195962 := by decide
theorem cert_e2389344173754 : check e2389344173754 [[],[.left],[]] .chain = true := by decide
def e2389344173782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2389344173782 : Closed e2389344173782 ∧ code e2389344173782 = 11185437195990 := by decide
theorem cert_e2389344173782 : check e2389344173782 [[],[.left],[]] .smaller = true := by decide
def e2389344173786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2389344173786 : Closed e2389344173786 ∧ code e2389344173786 = 11185437195994 := by decide
theorem cert_e2389344173786 : check e2389344173786 [[],[.left],[]] .smaller = true := by decide
def e2389344173802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2389344173802 : Closed e2389344173802 ∧ code e2389344173802 = 11185437196010 := by decide
theorem cert_e2389344173802 : check e2389344173802 [[],[.left],[]] .chain = true := by decide
def e2389344177630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2389344177630 : Closed e2389344177630 ∧ code e2389344177630 = 11185437199838 := by decide
theorem cert_e2389344177630 : check e2389344177630 [[],[.left],[]] .chain = true := by decide
def e2389344177646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2389344177646 : Closed e2389344177646 ∧ code e2389344177646 = 11185437199854 := by decide
theorem cert_e2389344177646 : check e2389344177646 [[],[.left],[]] .chain = true := by decide
def e2389344177886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2389344177886 : Closed e2389344177886 ∧ code e2389344177886 = 11185437200094 := by decide
theorem cert_e2389344177886 : check e2389344177886 [[],[.left],[]] .smaller = true := by decide
def e2389344177902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2389344177902 : Closed e2389344177902 ∧ code e2389344177902 = 11185437200110 := by decide
theorem cert_e2389344177902 : check e2389344177902 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2389344177910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2389344177910 : Closed e2389344177910 ∧ code e2389344177910 = 11185437200118 := by decide
theorem cert_e2389344177910 : check e2389344177910 [[],[.left],[]] .smaller = true := by decide
def e2389344178014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2389344178014 : Closed e2389344178014 ∧ code e2389344178014 = 11185437200222 := by decide
theorem cert_e2389344178014 : check e2389344178014 [[],[.left],[]] .chain = true := by decide
def e2389344178030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2389344178030 : Closed e2389344178030 ∧ code e2389344178030 = 11185437200238 := by decide
theorem cert_e2389344178030 : check e2389344178030 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2389344178038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2389344178038 : Closed e2389344178038 ∧ code e2389344178038 = 11185437200246 := by decide
theorem cert_e2389344178038 : checkPay e2389344178038 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2389344178042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2389344178042 : Closed e2389344178042 ∧ code e2389344178042 = 11185437200250 := by decide
theorem cert_e2389344178042 : check e2389344178042 [[],[.left],[]] .chain = true := by decide
def e2389344178094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2389344178094 : Closed e2389344178094 ∧ code e2389344178094 = 11185437200302 := by decide
theorem cert_e2389344178094 : check e2389344178094 [[],[.left],[]] .chain = true := by decide
def e2389344178102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2389344178102 : Closed e2389344178102 ∧ code e2389344178102 = 11185437200310 := by decide
theorem cert_e2389344178102 : check e2389344178102 [[],[.left],[]] .smaller = true := by decide
def e2389344178106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2389344178106 : Closed e2389344178106 ∧ code e2389344178106 = 11185437200314 := by decide
theorem cert_e2389344178106 : check e2389344178106 [[],[.left],[]] .chain = true := by decide
def e2389344179166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2389344179166 : Closed e2389344179166 ∧ code e2389344179166 = 11185437201374 := by decide
theorem cert_e2389344179166 : check e2389344179166 [[],[.left],[]] .chain = true := by decide
def e2389344179182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2389344179182 : Closed e2389344179182 ∧ code e2389344179182 = 11185437201390 := by decide
theorem cert_e2389344179182 : check e2389344179182 [[],[.left],[]] .chain = true := by decide
def e2389344180702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2389344180702 : Closed e2389344180702 ∧ code e2389344180702 = 11185437202910 := by decide
theorem cert_e2389344180702 : check e2389344180702 [[],[.left],[]] .smaller = true := by decide
def e2389344180718 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2389344180718 : Closed e2389344180718 ∧ code e2389344180718 = 11185437202926 := by decide
theorem cert_e2389344180718 : check e2389344180718 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2389344180726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2389344180726 : Closed e2389344180726 ∧ code e2389344180726 = 11185437202934 := by decide
theorem cert_e2389344180726 : check e2389344180726 [[],[.left],[]] .smaller = true := by decide
def e2389344181470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2389344181470 : Closed e2389344181470 ∧ code e2389344181470 = 11185437203678 := by decide
theorem cert_e2389344181470 : check e2389344181470 [[],[.left],[]] .chain = true := by decide
def e2389344181486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389344181486 : Closed e2389344181486 ∧ code e2389344181486 = 11185437203694 := by decide
theorem cert_e2389344181486 : check e2389344181486 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344181494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389344181494 : Closed e2389344181494 ∧ code e2389344181494 = 11185437203702 := by decide
theorem cert_e2389344181494 : check e2389344181494 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2389344181498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2389344181498 : Closed e2389344181498 ∧ code e2389344181498 = 11185437203706 := by decide
theorem cert_e2389344181498 : check e2389344181498 [[],[.left],[]] .chain = true := by decide
def e2389344181870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344181870 : Closed e2389344181870 ∧ code e2389344181870 = 11185437204078 := by decide
theorem cert_e2389344181870 : check e2389344181870 [[],[.left],[]] .chain = true := by decide
def e2389344181878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2389344181878 : Closed e2389344181878 ∧ code e2389344181878 = 11185437204086 := by decide
theorem cert_e2389344181878 : check e2389344181878 [[],[.left],[]] .smaller = true := by decide
def e2389344181882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344181882 : Closed e2389344181882 ∧ code e2389344181882 = 11185437204090 := by decide
theorem cert_e2389344181882 : check e2389344181882 [[],[.left],[]] .chain = true := by decide
def e2389344184030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2389344184030 : Closed e2389344184030 ∧ code e2389344184030 = 11185437206238 := by decide
theorem cert_e2389344184030 : check e2389344184030 [[],[.left],[]] .smaller = true := by decide
def e2389344184046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2389344184046 : Closed e2389344184046 ∧ code e2389344184046 = 11185437206254 := by decide
theorem cert_e2389344184046 : checkPay e2389344184046 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2389344184054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2389344184054 : Closed e2389344184054 ∧ code e2389344184054 = 11185437206262 := by decide
theorem cert_e2389344184054 : check e2389344184054 [[],[.left],[]] .smaller = true := by decide
def e2389344184158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2389344184158 : Closed e2389344184158 ∧ code e2389344184158 = 11185437206366 := by decide
theorem cert_e2389344184158 : check e2389344184158 [[],[.left],[]] .smaller = true := by decide
def e2389344184186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2389344184186 : Closed e2389344184186 ∧ code e2389344184186 = 11185437206394 := by decide
theorem cert_e2389344184186 : check e2389344184186 [[],[.left],[]] .smaller = true := by decide
def e2389344184238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2389344184238 : Closed e2389344184238 ∧ code e2389344184238 = 11185437206446 := by decide
theorem cert_e2389344184238 : checkPay e2389344184238 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2389344184250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2389344184250 : Closed e2389344184250 ∧ code e2389344184250 = 11185437206458 := by decide
theorem cert_e2389344184250 : checkPay e2389344184250 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2389344184278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2389344184278 : Closed e2389344184278 ∧ code e2389344184278 = 11185437206486 := by decide
theorem cert_e2389344184278 : check e2389344184278 [[],[.left],[]] .smaller = true := by decide
def e2389344184282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2389344184282 : Closed e2389344184282 ∧ code e2389344184282 = 11185437206490 := by decide
theorem cert_e2389344184282 : check e2389344184282 [[],[.left],[]] .smaller = true := by decide
def e2389344184798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2389344184798 : Closed e2389344184798 ∧ code e2389344184798 = 11185437207006 := by decide
theorem cert_e2389344184798 : check e2389344184798 [[],[.left],[]] .smaller = true := by decide
def e2389344184814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2389344184814 : Closed e2389344184814 ∧ code e2389344184814 = 11185437207022 := by decide
theorem cert_e2389344184814 : checkPay e2389344184814 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2389344184822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2389344184822 : Closed e2389344184822 ∧ code e2389344184822 = 11185437207030 := by decide
theorem cert_e2389344184822 : check e2389344184822 [[],[.left],[]] .smaller = true := by decide
def e2389344185566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2389344185566 : Closed e2389344185566 ∧ code e2389344185566 = 11185437207774 := by decide
theorem cert_e2389344185566 : check e2389344185566 [[],[.left],[]] .smaller = true := by decide
def e2389344185594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2389344185594 : Closed e2389344185594 ∧ code e2389344185594 = 11185437207802 := by decide
theorem cert_e2389344185594 : check e2389344185594 [[],[.left],[]] .smaller = true := by decide
def e2389344185966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344185966 : Closed e2389344185966 ∧ code e2389344185966 = 11185437208174 := by decide
theorem cert_e2389344185966 : checkPay e2389344185966 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2389344185978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344185978 : Closed e2389344185978 ∧ code e2389344185978 = 11185437208186 := by decide
theorem cert_e2389344185978 : checkPay e2389344185978 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2389344186166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344186166 : Closed e2389344186166 ∧ code e2389344186166 = 11185437208374 := by decide
theorem cert_e2389344186166 : check e2389344186166 [[],[.left],[]] .smaller = true := by decide
def e2389344186170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344186170 : Closed e2389344186170 ∧ code e2389344186170 = 11185437208378 := by decide
theorem cert_e2389344186170 : check e2389344186170 [[],[.left],[]] .smaller = true := by decide
def e2389344187230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2389344187230 : Closed e2389344187230 ∧ code e2389344187230 = 11185437209438 := by decide
theorem cert_e2389344187230 : check e2389344187230 [[],[.left],[]] .chain = true := by decide
def e2389344187246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2389344187246 : Closed e2389344187246 ∧ code e2389344187246 = 11185437209454 := by decide
theorem cert_e2389344187246 : check e2389344187246 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344187254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2389344187254 : Closed e2389344187254 ∧ code e2389344187254 = 11185437209462 := by decide
theorem cert_e2389344187254 : check e2389344187254 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344187258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2389344187258 : Closed e2389344187258 ∧ code e2389344187258 = 11185437209466 := by decide
theorem cert_e2389344187258 : check e2389344187258 [[],[.left],[]] .chain = true := by decide
def e2389344187310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2389344187310 : Closed e2389344187310 ∧ code e2389344187310 = 11185437209518 := by decide
theorem cert_e2389344187310 : check e2389344187310 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344187322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2389344187322 : Closed e2389344187322 ∧ code e2389344187322 = 11185437209530 := by decide
theorem cert_e2389344187322 : check e2389344187322 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344187350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2389344187350 : Closed e2389344187350 ∧ code e2389344187350 = 11185437209558 := by decide
theorem cert_e2389344187350 : check e2389344187350 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344187354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2389344187354 : Closed e2389344187354 ∧ code e2389344187354 = 11185437209562 := by decide
theorem cert_e2389344187354 : check e2389344187354 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344187370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2389344187370 : Closed e2389344187370 ∧ code e2389344187370 = 11185437209578 := by decide
theorem cert_e2389344187370 : check e2389344187370 [[],[.left],[]] .chain = true := by decide
def e2389344187614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2389344187614 : Closed e2389344187614 ∧ code e2389344187614 = 11185437209822 := by decide
theorem cert_e2389344187614 : check e2389344187614 [[],[.left],[]] .chain = true := by decide
def e2389344187630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389344187630 : Closed e2389344187630 ∧ code e2389344187630 = 11185437209838 := by decide
theorem cert_e2389344187630 : check e2389344187630 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344187638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389344187638 : Closed e2389344187638 ∧ code e2389344187638 = 11185437209846 := by decide
theorem cert_e2389344187638 : check e2389344187638 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344187642 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2389344187642 : Closed e2389344187642 ∧ code e2389344187642 = 11185437209850 := by decide
theorem cert_e2389344187642 : check e2389344187642 [[],[.left],[]] .chain = true := by decide
def e2389344188014 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344188014 : Closed e2389344188014 ∧ code e2389344188014 = 11185437210222 := by decide
theorem cert_e2389344188014 : check e2389344188014 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344188026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344188026 : Closed e2389344188026 ∧ code e2389344188026 = 11185437210234 := by decide
theorem cert_e2389344188026 : check e2389344188026 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2389344188214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344188214 : Closed e2389344188214 ∧ code e2389344188214 = 11185437210422 := by decide
theorem cert_e2389344188214 : check e2389344188214 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344188218 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344188218 : Closed e2389344188218 ∧ code e2389344188218 = 11185437210426 := by decide
theorem cert_e2389344188218 : check e2389344188218 [[],[.left],[],[.under,.under,.left]] .smaller = true := by decide
def e2389344188314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344188314 : Closed e2389344188314 ∧ code e2389344188314 = 11185437210522 := by decide
theorem cert_e2389344188314 : check e2389344188314 [[],[.left],[]] .chain = true := by decide
def e2389344188846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2389344188846 : Closed e2389344188846 ∧ code e2389344188846 = 11185437211054 := by decide
theorem cert_e2389344188846 : check e2389344188846 [[],[.left],[]] .chain = true := by decide
def e2389344188854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2389344188854 : Closed e2389344188854 ∧ code e2389344188854 = 11185437211062 := by decide
theorem cert_e2389344188854 : check e2389344188854 [[],[.left],[]] .smaller = true := by decide
def e2389344188858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2389344188858 : Closed e2389344188858 ∧ code e2389344188858 = 11185437211066 := by decide
theorem cert_e2389344188858 : check e2389344188858 [[],[.left],[]] .chain = true := by decide
def e2389344188886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2389344188886 : Closed e2389344188886 ∧ code e2389344188886 = 11185437211094 := by decide
theorem cert_e2389344188886 : check e2389344188886 [[],[.left],[]] .smaller = true := by decide
def e2389344188890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2389344188890 : Closed e2389344188890 ∧ code e2389344188890 = 11185437211098 := by decide
theorem cert_e2389344188890 : check e2389344188890 [[],[.left],[]] .smaller = true := by decide
def e2389344188906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2389344188906 : Closed e2389344188906 ∧ code e2389344188906 = 11185437211114 := by decide
theorem cert_e2389344188906 : check e2389344188906 [[],[.left],[]] .chain = true := by decide
def e2389344189038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389344189038 : Closed e2389344189038 ∧ code e2389344189038 = 11185437211246 := by decide
theorem cert_e2389344189038 : check e2389344189038 [[],[.left],[]] .chain = true := by decide
def e2389344189046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2389344189046 : Closed e2389344189046 ∧ code e2389344189046 = 11185437211254 := by decide
theorem cert_e2389344189046 : check e2389344189046 [[],[.left],[]] .smaller = true := by decide
def e2389344189050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389344189050 : Closed e2389344189050 ∧ code e2389344189050 = 11185437211258 := by decide
theorem cert_e2389344189050 : check e2389344189050 [[],[.left],[]] .chain = true := by decide
def e2389344189238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389344189238 : Closed e2389344189238 ∧ code e2389344189238 = 11185437211446 := by decide
theorem cert_e2389344189238 : check e2389344189238 [[],[.left],[]] .smaller = true := by decide
def e2389344189242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389344189242 : Closed e2389344189242 ∧ code e2389344189242 = 11185437211450 := by decide
theorem cert_e2389344189242 : check e2389344189242 [[],[.left],[]] .smaller = true := by decide
def e2389344189338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389344189338 : Closed e2389344189338 ∧ code e2389344189338 = 11185437211546 := by decide
theorem cert_e2389344189338 : check e2389344189338 [[],[.left],[]] .chain = true := by decide
def e2389344193390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2389344193390 : Closed e2389344193390 ∧ code e2389344193390 = 11185437215598 := by decide
theorem cert_e2389344193390 : check e2389344193390 [[],[.left],[]] .smaller = true := by decide
def e2389344193398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2389344193398 : Closed e2389344193398 ∧ code e2389344193398 = 11185437215606 := by decide
theorem cert_e2389344193398 : check e2389344193398 [[],[.left],[]] .smaller = true := by decide
def e2389344193454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2389344193454 : Closed e2389344193454 ∧ code e2389344193454 = 11185437215662 := by decide
theorem cert_e2389344193454 : check e2389344193454 [[],[.left],[]] .smaller = true := by decide
def e2389344193466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2389344193466 : Closed e2389344193466 ∧ code e2389344193466 = 11185437215674 := by decide
theorem cert_e2389344193466 : check e2389344193466 [[],[.left],[]] .smaller = true := by decide
def e2389344193494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2389344193494 : Closed e2389344193494 ∧ code e2389344193494 = 11185437215702 := by decide
theorem cert_e2389344193494 : check e2389344193494 [[],[.left],[]] .smaller = true := by decide
def e2389344193498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2389344193498 : Closed e2389344193498 ∧ code e2389344193498 = 11185437215706 := by decide
theorem cert_e2389344193498 : check e2389344193498 [[],[.left],[]] .smaller = true := by decide
end Blc.Floor43
