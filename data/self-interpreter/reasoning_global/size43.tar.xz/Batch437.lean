import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374918626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422374918626 : Closed e2422374918626 ∧ code e2422374918626 = 11218467940834 := by decide
theorem cert_e2422374918626 : check e2422374918626 [[],[]] .three = true := by decide
def e2422374918638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374918638 : Closed e2422374918638 ∧ code e2422374918638 = 11218467940846 := by decide
theorem cert_e2422374918638 : check e2422374918638 [[],[]] .three = true := by decide
def e2422374918646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374918646 : Closed e2422374918646 ∧ code e2422374918646 = 11218467940854 := by decide
theorem cert_e2422374918646 : check e2422374918646 [[],[]] .three = true := by decide
def e2422374919198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422374919198 : Closed e2422374919198 ∧ code e2422374919198 = 11218467941406 := by decide
theorem cert_e2422374919198 : check e2422374919198 [[],[]] .three = true := by decide
def e2422374919222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374919222 : Closed e2422374919222 ∧ code e2422374919222 = 11218467941430 := by decide
theorem cert_e2422374919222 : check e2422374919222 [[],[]] .three = true := by decide
def e2422374919226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374919226 : Closed e2422374919226 ∧ code e2422374919226 = 11218467941434 := by decide
theorem cert_e2422374919226 : check e2422374919226 [[],[]] .three = true := by decide
def e2422374919366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422374919366 : Closed e2422374919366 ∧ code e2422374919366 = 11218467941574 := by decide
theorem cert_e2422374919366 : check e2422374919366 [[],[]] .three = true := by decide
def e2422374919390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374919390 : Closed e2422374919390 ∧ code e2422374919390 = 11218467941598 := by decide
theorem cert_e2422374919390 : check e2422374919390 [[],[]] .three = true := by decide
def e2422374919394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422374919394 : Closed e2422374919394 ∧ code e2422374919394 = 11218467941602 := by decide
theorem cert_e2422374919394 : check e2422374919394 [[],[]] .three = true := by decide
def e2422374919406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374919406 : Closed e2422374919406 ∧ code e2422374919406 = 11218467941614 := by decide
theorem cert_e2422374919406 : check e2422374919406 [[],[]] .three = true := by decide
def e2422374919414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374919414 : Closed e2422374919414 ∧ code e2422374919414 = 11218467941622 := by decide
theorem cert_e2422374919414 : check e2422374919414 [[],[]] .three = true := by decide
def e2422374919418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374919418 : Closed e2422374919418 ∧ code e2422374919418 = 11218467941626 := by decide
theorem cert_e2422374919418 : check e2422374919418 [[],[]] .three = true := by decide
def e2422374919694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374919694 : Closed e2422374919694 ∧ code e2422374919694 = 11218467941902 := by decide
theorem cert_e2422374919694 : check e2422374919694 [[],[]] .three = true := by decide
def e2422374919706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374919706 : Closed e2422374919706 ∧ code e2422374919706 = 11218467941914 := by decide
theorem cert_e2422374919706 : check e2422374919706 [[],[]] .three = true := by decide
def e2422374919742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 4)))))))))
theorem wire_e2422374919742 : Closed e2422374919742 ∧ code e2422374919742 = 11218467941950 := by decide
theorem cert_e2422374919742 : check e2422374919742 [[],[]] .three = true := by decide
def e2422374919778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374919778 : Closed e2422374919778 ∧ code e2422374919778 = 11218467941986 := by decide
theorem cert_e2422374919778 : check e2422374919778 [[],[]] .three = true := by decide
def e2422374919790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374919790 : Closed e2422374919790 ∧ code e2422374919790 = 11218467941998 := by decide
theorem cert_e2422374919790 : check e2422374919790 [[],[]] .three = true := by decide
def e2422374919798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374919798 : Closed e2422374919798 ∧ code e2422374919798 = 11218467942006 := by decide
theorem cert_e2422374919798 : check e2422374919798 [[],[]] .three = true := by decide
def e2422374919802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374919802 : Closed e2422374919802 ∧ code e2422374919802 = 11218467942010 := by decide
theorem cert_e2422374919802 : check e2422374919802 [[],[]] .three = true := by decide
def e2422374919966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.lam (.var 3)))))))))
theorem wire_e2422374919966 : Closed e2422374919966 ∧ code e2422374919966 = 11218467942174 := by decide
theorem cert_e2422374919966 : check e2422374919966 [[],[]] .three = true := by decide
def e2422374919990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374919990 : Closed e2422374919990 ∧ code e2422374919990 = 11218467942198 := by decide
theorem cert_e2422374919990 : check e2422374919990 [[],[]] .three = true := by decide
def e2422374919994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374919994 : Closed e2422374919994 ∧ code e2422374919994 = 11218467942202 := by decide
theorem cert_e2422374919994 : check e2422374919994 [[],[]] .three = true := by decide
def e2422374927214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422374927214 : Closed e2422374927214 ∧ code e2422374927214 = 11218467949422 := by decide
theorem cert_e2422374927214 : check e2422374927214 [[],[]] .smaller = true := by decide
def e2422374927222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422374927222 : Closed e2422374927222 ∧ code e2422374927222 = 11218467949430 := by decide
theorem cert_e2422374927222 : check e2422374927222 [[],[]] .smaller = true := by decide
def e2422374927278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422374927278 : Closed e2422374927278 ∧ code e2422374927278 = 11218467949486 := by decide
theorem cert_e2422374927278 : check e2422374927278 [[],[]] .smaller = true := by decide
def e2422374927290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422374927290 : Closed e2422374927290 ∧ code e2422374927290 = 11218467949498 := by decide
theorem cert_e2422374927290 : check e2422374927290 [[],[]] .smaller = true := by decide
def e2422374927318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422374927318 : Closed e2422374927318 ∧ code e2422374927318 = 11218467949526 := by decide
theorem cert_e2422374927318 : check e2422374927318 [[],[]] .smaller = true := by decide
def e2422374927322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422374927322 : Closed e2422374927322 ∧ code e2422374927322 = 11218467949530 := by decide
theorem cert_e2422374927322 : check e2422374927322 [[],[]] .smaller = true := by decide
def e2422374927598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422374927598 : Closed e2422374927598 ∧ code e2422374927598 = 11218467949806 := by decide
theorem cert_e2422374927598 : check e2422374927598 [[],[]] .smaller = true := by decide
def e2422374927606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422374927606 : Closed e2422374927606 ∧ code e2422374927606 = 11218467949814 := by decide
theorem cert_e2422374927606 : check e2422374927606 [[],[]] .smaller = true := by decide
def e2422374927982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422374927982 : Closed e2422374927982 ∧ code e2422374927982 = 11218467950190 := by decide
theorem cert_e2422374927982 : check e2422374927982 [[],[]] .smaller = true := by decide
def e2422374927994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422374927994 : Closed e2422374927994 ∧ code e2422374927994 = 11218467950202 := by decide
theorem cert_e2422374927994 : check e2422374927994 [[],[]] .smaller = true := by decide
def e2422374928182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422374928182 : Closed e2422374928182 ∧ code e2422374928182 = 11218467950390 := by decide
theorem cert_e2422374928182 : check e2422374928182 [[],[]] .smaller = true := by decide
def e2422374928186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422374928186 : Closed e2422374928186 ∧ code e2422374928186 = 11218467950394 := by decide
theorem cert_e2422374928186 : check e2422374928186 [[],[]] .smaller = true := by decide
def e2422374928318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 4)))))))))))
theorem wire_e2422374928318 : Closed e2422374928318 ∧ code e2422374928318 = 11218467950526 := by decide
theorem cert_e2422374928318 : check e2422374928318 [[],[]] .smaller = true := by decide
def e2422374928350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 3)))))))))))
theorem wire_e2422374928350 : Closed e2422374928350 ∧ code e2422374928350 = 11218467950558 := by decide
theorem cert_e2422374928350 : check e2422374928350 [[],[]] .smaller = true := by decide
def e2422374935998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))))
theorem wire_e2422374935998 : Closed e2422374935998 ∧ code e2422374935998 = 11218467958206 := by decide
theorem cert_e2422374935998 : check e2422374935998 [[],[]] .three = true := by decide
def e2422374936030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e2422374936030 : Closed e2422374936030 ∧ code e2422374936030 = 11218467958238 := by decide
theorem cert_e2422374936030 : check e2422374936030 [[],[]] .smaller = true := by decide
def e2422374936046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e2422374936046 : Closed e2422374936046 ∧ code e2422374936046 = 11218467958254 := by decide
theorem cert_e2422374936046 : check e2422374936046 [[],[]] .smaller = true := by decide
def e2422374936054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))))
theorem wire_e2422374936054 : Closed e2422374936054 ∧ code e2422374936054 = 11218467958262 := by decide
theorem cert_e2422374936054 : check e2422374936054 [[],[]] .three = true := by decide
def e2422374936254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))))
theorem wire_e2422374936254 : Closed e2422374936254 ∧ code e2422374936254 = 11218467958462 := by decide
theorem cert_e2422374936254 : check e2422374936254 [[],[]] .three = true := by decide
def e2422374936314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))))
theorem wire_e2422374936314 : Closed e2422374936314 ∧ code e2422374936314 = 11218467958522 := by decide
theorem cert_e2422374936314 : check e2422374936314 [[],[]] .three = true := by decide
def e2422374936414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e2422374936414 : Closed e2422374936414 ∧ code e2422374936414 = 11218467958622 := by decide
theorem cert_e2422374936414 : check e2422374936414 [[],[]] .smaller = true := by decide
def e2422374936442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e2422374936442 : Closed e2422374936442 ∧ code e2422374936442 = 11218467958650 := by decide
theorem cert_e2422374936442 : check e2422374936442 [[],[]] .smaller = true := by decide
def e2422374936494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e2422374936494 : Closed e2422374936494 ∧ code e2422374936494 = 11218467958702 := by decide
theorem cert_e2422374936494 : check e2422374936494 [[],[]] .smaller = true := by decide
def e2422374936506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e2422374936506 : Closed e2422374936506 ∧ code e2422374936506 = 11218467958714 := by decide
theorem cert_e2422374936506 : check e2422374936506 [[],[]] .smaller = true := by decide
def e2422374936534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e2422374936534 : Closed e2422374936534 ∧ code e2422374936534 = 11218467958742 := by decide
theorem cert_e2422374936534 : check e2422374936534 [[],[]] .three = true := by decide
def e2422374936538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e2422374936538 : Closed e2422374936538 ∧ code e2422374936538 = 11218467958746 := by decide
theorem cert_e2422374936538 : check e2422374936538 [[],[]] .three = true := by decide
def e2422374937534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422374937534 : Closed e2422374937534 ∧ code e2422374937534 = 11218467959742 := by decide
theorem cert_e2422374937534 : check e2422374937534 [[],[]] .three = true := by decide
def e2422374937566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422374937566 : Closed e2422374937566 ∧ code e2422374937566 = 11218467959774 := by decide
theorem cert_e2422374937566 : check e2422374937566 [[],[]] .smaller = true := by decide
def e2422374937582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422374937582 : Closed e2422374937582 ∧ code e2422374937582 = 11218467959790 := by decide
theorem cert_e2422374937582 : check e2422374937582 [[],[]] .smaller = true := by decide
def e2422374937590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422374937590 : Closed e2422374937590 ∧ code e2422374937590 = 11218467959798 := by decide
theorem cert_e2422374937590 : check e2422374937590 [[],[]] .three = true := by decide
def e2422374939070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422374939070 : Closed e2422374939070 ∧ code e2422374939070 = 11218467961278 := by decide
theorem cert_e2422374939070 : check e2422374939070 [[],[]] .three = true := by decide
def e2422374939130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422374939130 : Closed e2422374939130 ∧ code e2422374939130 = 11218467961338 := by decide
theorem cert_e2422374939130 : check e2422374939130 [[],[]] .three = true := by decide
def e2422374939774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 5)))))))))))
theorem wire_e2422374939774 : Closed e2422374939774 ∧ code e2422374939774 = 11218467961982 := by decide
theorem cert_e2422374939774 : check e2422374939774 [[],[]] .three = true := by decide
def e2422374939870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422374939870 : Closed e2422374939870 ∧ code e2422374939870 = 11218467962078 := by decide
theorem cert_e2422374939870 : check e2422374939870 [[],[]] .smaller = true := by decide
def e2422374939898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422374939898 : Closed e2422374939898 ∧ code e2422374939898 = 11218467962106 := by decide
theorem cert_e2422374939898 : check e2422374939898 [[],[]] .smaller = true := by decide
def e2422374940270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374940270 : Closed e2422374940270 ∧ code e2422374940270 = 11218467962478 := by decide
theorem cert_e2422374940270 : check e2422374940270 [[],[]] .smaller = true := by decide
def e2422374940282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374940282 : Closed e2422374940282 ∧ code e2422374940282 = 11218467962490 := by decide
theorem cert_e2422374940282 : check e2422374940282 [[],[]] .smaller = true := by decide
def e2422374940446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.lam (.var 3)))))))))))
theorem wire_e2422374940446 : Closed e2422374940446 ∧ code e2422374940446 = 11218467962654 := by decide
theorem cert_e2422374940446 : check e2422374940446 [[],[]] .three = true := by decide
def e2422374940470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374940470 : Closed e2422374940470 ∧ code e2422374940470 = 11218467962678 := by decide
theorem cert_e2422374940470 : check e2422374940470 [[],[]] .three = true := by decide
def e2422374940474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374940474 : Closed e2422374940474 ∧ code e2422374940474 = 11218467962682 := by decide
theorem cert_e2422374940474 : check e2422374940474 [[],[]] .three = true := by decide
def e2422374968686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422374968686 : Closed e2422374968686 ∧ code e2422374968686 = 11218467990894 := by decide
theorem cert_e2422374968686 : check e2422374968686 [[],[]] .smaller = true := by decide
def e2422374968694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422374968694 : Closed e2422374968694 ∧ code e2422374968694 = 11218467990902 := by decide
theorem cert_e2422374968694 : check e2422374968694 [[],[]] .smaller = true := by decide
def e2422374968750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374968750 : Closed e2422374968750 ∧ code e2422374968750 = 11218467990958 := by decide
theorem cert_e2422374968750 : check e2422374968750 [[],[]] .smaller = true := by decide
def e2422374968762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374968762 : Closed e2422374968762 ∧ code e2422374968762 = 11218467990970 := by decide
theorem cert_e2422374968762 : check e2422374968762 [[],[]] .smaller = true := by decide
def e2422374968790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374968790 : Closed e2422374968790 ∧ code e2422374968790 = 11218467990998 := by decide
theorem cert_e2422374968790 : check e2422374968790 [[],[]] .smaller = true := by decide
def e2422374968794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374968794 : Closed e2422374968794 ∧ code e2422374968794 = 11218467991002 := by decide
theorem cert_e2422374968794 : check e2422374968794 [[],[]] .smaller = true := by decide
def e2422374969006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422374969006 : Closed e2422374969006 ∧ code e2422374969006 = 11218467991214 := by decide
theorem cert_e2422374969006 : check e2422374969006 [[],[]] .smaller = true := by decide
def e2422374969018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422374969018 : Closed e2422374969018 ∧ code e2422374969018 = 11218467991226 := by decide
theorem cert_e2422374969018 : check e2422374969018 [[],[]] .smaller = true := by decide
def e2422374969066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374969066 : Closed e2422374969066 ∧ code e2422374969066 = 11218467991274 := by decide
theorem cert_e2422374969066 : check e2422374969066 [[],[]] .smaller = true := by decide
def e2422374969174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422374969174 : Closed e2422374969174 ∧ code e2422374969174 = 11218467991382 := by decide
theorem cert_e2422374969174 : check e2422374969174 [[],[]] .smaller = true := by decide
def e2422374969178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422374969178 : Closed e2422374969178 ∧ code e2422374969178 = 11218467991386 := by decide
theorem cert_e2422374969178 : check e2422374969178 [[],[]] .smaller = true := by decide
def e2422374969194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422374969194 : Closed e2422374969194 ∧ code e2422374969194 = 11218467991402 := by decide
theorem cert_e2422374969194 : check e2422374969194 [[],[]] .smaller = true := by decide
def e2422374969822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e2422374969822 : Closed e2422374969822 ∧ code e2422374969822 = 11218467992030 := by decide
theorem cert_e2422374969822 : check e2422374969822 [[],[]] .three = true := by decide
def e2422374969846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e2422374969846 : Closed e2422374969846 ∧ code e2422374969846 = 11218467992054 := by decide
theorem cert_e2422374969846 : check e2422374969846 [[],[]] .three = true := by decide
def e2422374970222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422374970222 : Closed e2422374970222 ∧ code e2422374970222 = 11218467992430 := by decide
theorem cert_e2422374970222 : check e2422374970222 [[],[]] .smaller = true := by decide
def e2422374970230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422374970230 : Closed e2422374970230 ∧ code e2422374970230 = 11218467992438 := by decide
theorem cert_e2422374970230 : check e2422374970230 [[],[]] .smaller = true := by decide
def e2422374970286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422374970286 : Closed e2422374970286 ∧ code e2422374970286 = 11218467992494 := by decide
theorem cert_e2422374970286 : check e2422374970286 [[],[]] .smaller = true := by decide
def e2422374970298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422374970298 : Closed e2422374970298 ∧ code e2422374970298 = 11218467992506 := by decide
theorem cert_e2422374970298 : check e2422374970298 [[],[]] .smaller = true := by decide
def e2422374970326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422374970326 : Closed e2422374970326 ∧ code e2422374970326 = 11218467992534 := by decide
theorem cert_e2422374970326 : check e2422374970326 [[],[]] .smaller = true := by decide
def e2422374970330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422374970330 : Closed e2422374970330 ∧ code e2422374970330 = 11218467992538 := by decide
theorem cert_e2422374970330 : check e2422374970330 [[],[]] .smaller = true := by decide
def e2422374970606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374970606 : Closed e2422374970606 ∧ code e2422374970606 = 11218467992814 := by decide
theorem cert_e2422374970606 : check e2422374970606 [[],[]] .smaller = true := by decide
def e2422374970614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374970614 : Closed e2422374970614 ∧ code e2422374970614 = 11218467992822 := by decide
theorem cert_e2422374970614 : check e2422374970614 [[],[]] .smaller = true := by decide
def e2422374970942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e2422374970942 : Closed e2422374970942 ∧ code e2422374970942 = 11218467993150 := by decide
theorem cert_e2422374970942 : check e2422374970942 [[],[]] .three = true := by decide
def e2422374970990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374970990 : Closed e2422374970990 ∧ code e2422374970990 = 11218467993198 := by decide
theorem cert_e2422374970990 : check e2422374970990 [[],[]] .smaller = true := by decide
def e2422374971002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374971002 : Closed e2422374971002 ∧ code e2422374971002 = 11218467993210 := by decide
theorem cert_e2422374971002 : check e2422374971002 [[],[]] .smaller = true := by decide
def e2422374971190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374971190 : Closed e2422374971190 ∧ code e2422374971190 = 11218467993398 := by decide
theorem cert_e2422374971190 : check e2422374971190 [[],[]] .smaller = true := by decide
def e2422374971194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374971194 : Closed e2422374971194 ∧ code e2422374971194 = 11218467993402 := by decide
theorem cert_e2422374971194 : check e2422374971194 [[],[]] .smaller = true := by decide
def e2422374971278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e2422374971278 : Closed e2422374971278 ∧ code e2422374971278 = 11218467993486 := by decide
theorem cert_e2422374971278 : check e2422374971278 [[],[]] .three = true := by decide
def e2422374971438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)))))))))
theorem wire_e2422374971438 : Closed e2422374971438 ∧ code e2422374971438 = 11218467993646 := by decide
theorem cert_e2422374971438 : check e2422374971438 [[],[]] .smaller = true := by decide
def e2422374971614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422374971614 : Closed e2422374971614 ∧ code e2422374971614 = 11218467993822 := by decide
theorem cert_e2422374971614 : check e2422374971614 [[],[]] .three = true := by decide
def e2422374971630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422374971630 : Closed e2422374971630 ∧ code e2422374971630 = 11218467993838 := by decide
theorem cert_e2422374971630 : check e2422374971630 [[],[]] .smaller = true := by decide
def e2422374971638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422374971638 : Closed e2422374971638 ∧ code e2422374971638 = 11218467993846 := by decide
theorem cert_e2422374971638 : check e2422374971638 [[],[]] .smaller = true := by decide
def e2422374971642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422374971642 : Closed e2422374971642 ∧ code e2422374971642 = 11218467993850 := by decide
theorem cert_e2422374971642 : check e2422374971642 [[],[]] .three = true := by decide
def e2422374971822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422374971822 : Closed e2422374971822 ∧ code e2422374971822 = 11218467994030 := by decide
theorem cert_e2422374971822 : check e2422374971822 [[],[]] .smaller = true := by decide
def e2422374971834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422374971834 : Closed e2422374971834 ∧ code e2422374971834 = 11218467994042 := by decide
theorem cert_e2422374971834 : check e2422374971834 [[],[]] .smaller = true := by decide
def e2422374971882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422374971882 : Closed e2422374971882 ∧ code e2422374971882 = 11218467994090 := by decide
theorem cert_e2422374971882 : check e2422374971882 [[],[]] .smaller = true := by decide
def e2422374971966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422374971966 : Closed e2422374971966 ∧ code e2422374971966 = 11218467994174 := by decide
theorem cert_e2422374971966 : check e2422374971966 [[],[]] .three = true := by decide
def e2422374972014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374972014 : Closed e2422374972014 ∧ code e2422374972014 = 11218467994222 := by decide
theorem cert_e2422374972014 : check e2422374972014 [[],[]] .smaller = true := by decide
def e2422374972026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374972026 : Closed e2422374972026 ∧ code e2422374972026 = 11218467994234 := by decide
theorem cert_e2422374972026 : check e2422374972026 [[],[]] .smaller = true := by decide
def e2422374972190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e2422374972190 : Closed e2422374972190 ∧ code e2422374972190 = 11218467994398 := by decide
theorem cert_e2422374972190 : check e2422374972190 [[],[]] .smaller = true := by decide
def e2422374972290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374972290 : Closed e2422374972290 ∧ code e2422374972290 = 11218467994498 := by decide
theorem cert_e2422374972290 : check e2422374972290 [[],[]] .smaller = true := by decide
def e2422374972302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e2422374972302 : Closed e2422374972302 ∧ code e2422374972302 = 11218467994510 := by decide
theorem cert_e2422374972302 : check e2422374972302 [[],[]] .smaller = true := by decide
def e2422374972314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374972314 : Closed e2422374972314 ∧ code e2422374972314 = 11218467994522 := by decide
theorem cert_e2422374972314 : check e2422374972314 [[],[]] .smaller = true := by decide
def e2422374972358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422374972358 : Closed e2422374972358 ∧ code e2422374972358 = 11218467994566 := by decide
theorem cert_e2422374972358 : check e2422374972358 [[],[]] .three = true := by decide
def e2422374972382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3)))))))))
theorem wire_e2422374972382 : Closed e2422374972382 ∧ code e2422374972382 = 11218467994590 := by decide
theorem cert_e2422374972382 : check e2422374972382 [[],[]] .three = true := by decide
def e2422374972438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422374972438 : Closed e2422374972438 ∧ code e2422374972438 = 11218467994646 := by decide
theorem cert_e2422374972438 : check e2422374972438 [[],[]] .smaller = true := by decide
def e2422374972510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422374972510 : Closed e2422374972510 ∧ code e2422374972510 = 11218467994718 := by decide
theorem cert_e2422374972510 : check e2422374972510 [[],[]] .three = true := by decide
def e2422374972534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422374972534 : Closed e2422374972534 ∧ code e2422374972534 = 11218467994742 := by decide
theorem cert_e2422374972534 : check e2422374972534 [[],[]] .smaller = true := by decide
def e2422374972630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422374972630 : Closed e2422374972630 ∧ code e2422374972630 = 11218467994838 := by decide
theorem cert_e2422374972630 : check e2422374972630 [[],[]] .smaller = true := by decide
def e2422374972634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422374972634 : Closed e2422374972634 ∧ code e2422374972634 = 11218467994842 := by decide
theorem cert_e2422374972634 : check e2422374972634 [[],[]] .smaller = true := by decide
def e2422374972650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422374972650 : Closed e2422374972650 ∧ code e2422374972650 = 11218467994858 := by decide
theorem cert_e2422374972650 : check e2422374972650 [[],[]] .smaller = true := by decide
def e2422374972726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374972726 : Closed e2422374972726 ∧ code e2422374972726 = 11218467994934 := by decide
theorem cert_e2422374972726 : check e2422374972726 [[],[]] .smaller = true := by decide
def e2422374972730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374972730 : Closed e2422374972730 ∧ code e2422374972730 = 11218467994938 := by decide
theorem cert_e2422374972730 : check e2422374972730 [[],[]] .smaller = true := by decide
def e2422374972802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374972802 : Closed e2422374972802 ∧ code e2422374972802 = 11218467995010 := by decide
theorem cert_e2422374972802 : check e2422374972802 [[],[]] .smaller = true := by decide
def e2422374972814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422374972814 : Closed e2422374972814 ∧ code e2422374972814 = 11218467995022 := by decide
theorem cert_e2422374972814 : check e2422374972814 [[],[]] .smaller = true := by decide
def e2422374972826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374972826 : Closed e2422374972826 ∧ code e2422374972826 = 11218467995034 := by decide
theorem cert_e2422374972826 : check e2422374972826 [[],[]] .smaller = true := by decide
def e2422374972894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 3)))))))))
theorem wire_e2422374972894 : Closed e2422374972894 ∧ code e2422374972894 = 11218467995102 := by decide
theorem cert_e2422374972894 : check e2422374972894 [[],[]] .three = true := by decide
def e2422374972898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422374972898 : Closed e2422374972898 ∧ code e2422374972898 = 11218467995106 := by decide
theorem cert_e2422374972898 : check e2422374972898 [[],[]] .three = true := by decide
def e2422374972910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 2)))))))))
theorem wire_e2422374972910 : Closed e2422374972910 ∧ code e2422374972910 = 11218467995118 := by decide
theorem cert_e2422374972910 : check e2422374972910 [[],[]] .three = true := by decide
def e2422374972974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422374972974 : Closed e2422374972974 ∧ code e2422374972974 = 11218467995182 := by decide
theorem cert_e2422374972974 : check e2422374972974 [[],[]] .three = true := by decide
def e2422374972982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422374972982 : Closed e2422374972982 ∧ code e2422374972982 = 11218467995190 := by decide
theorem cert_e2422374972982 : check e2422374972982 [[],[]] .three = true := by decide
def e2422374972986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422374972986 : Closed e2422374972986 ∧ code e2422374972986 = 11218467995194 := by decide
theorem cert_e2422374972986 : check e2422374972986 [[],[]] .three = true := by decide
def e2422374973070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422374973070 : Closed e2422374973070 ∧ code e2422374973070 = 11218467995278 := by decide
theorem cert_e2422374973070 : check e2422374973070 [[],[]] .three = true := by decide
def e2422374973126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422374973126 : Closed e2422374973126 ∧ code e2422374973126 = 11218467995334 := by decide
theorem cert_e2422374973126 : check e2422374973126 [[],[]] .three = true := by decide
def e2422374973150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3)))))))))
theorem wire_e2422374973150 : Closed e2422374973150 ∧ code e2422374973150 = 11218467995358 := by decide
theorem cert_e2422374973150 : check e2422374973150 [[],[]] .three = true := by decide
def e2422374973154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422374973154 : Closed e2422374973154 ∧ code e2422374973154 = 11218467995362 := by decide
theorem cert_e2422374973154 : check e2422374973154 [[],[]] .three = true := by decide
def e2422374973166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 2)))))))))
theorem wire_e2422374973166 : Closed e2422374973166 ∧ code e2422374973166 = 11218467995374 := by decide
theorem cert_e2422374973166 : check e2422374973166 [[],[]] .three = true := by decide
def e2422374973174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1)))))))))
theorem wire_e2422374973174 : Closed e2422374973174 ∧ code e2422374973174 = 11218467995382 := by decide
theorem cert_e2422374973174 : check e2422374973174 [[],[]] .three = true := by decide
def e2422374974430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422374974430 : Closed e2422374974430 ∧ code e2422374974430 = 11218467996638 := by decide
theorem cert_e2422374974430 : check e2422374974430 [[],[]] .smaller = true := by decide
def e2422374974446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422374974446 : Closed e2422374974446 ∧ code e2422374974446 = 11218467996654 := by decide
theorem cert_e2422374974446 : check e2422374974446 [[],[]] .smaller = true := by decide
def e2422374976366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422374976366 : Closed e2422374976366 ∧ code e2422374976366 = 11218467998574 := by decide
theorem cert_e2422374976366 : check e2422374976366 [[],[]] .smaller = true := by decide
def e2422374976374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422374976374 : Closed e2422374976374 ∧ code e2422374976374 = 11218467998582 := by decide
theorem cert_e2422374976374 : check e2422374976374 [[],[]] .smaller = true := by decide
def e2422374976430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422374976430 : Closed e2422374976430 ∧ code e2422374976430 = 11218467998638 := by decide
theorem cert_e2422374976430 : check e2422374976430 [[],[]] .smaller = true := by decide
def e2422374976442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422374976442 : Closed e2422374976442 ∧ code e2422374976442 = 11218467998650 := by decide
theorem cert_e2422374976442 : check e2422374976442 [[],[]] .smaller = true := by decide
def e2422374976470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422374976470 : Closed e2422374976470 ∧ code e2422374976470 = 11218467998678 := by decide
theorem cert_e2422374976470 : check e2422374976470 [[],[]] .smaller = true := by decide
def e2422374976474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422374976474 : Closed e2422374976474 ∧ code e2422374976474 = 11218467998682 := by decide
theorem cert_e2422374976474 : check e2422374976474 [[],[]] .smaller = true := by decide
def e2422374976750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374976750 : Closed e2422374976750 ∧ code e2422374976750 = 11218467998958 := by decide
theorem cert_e2422374976750 : check e2422374976750 [[],[]] .smaller = true := by decide
def e2422374976758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374976758 : Closed e2422374976758 ∧ code e2422374976758 = 11218467998966 := by decide
theorem cert_e2422374976758 : check e2422374976758 [[],[]] .smaller = true := by decide
def e2422374977086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422374977086 : Closed e2422374977086 ∧ code e2422374977086 = 11218467999294 := by decide
theorem cert_e2422374977086 : check e2422374977086 [[],[]] .three = true := by decide
def e2422374977134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374977134 : Closed e2422374977134 ∧ code e2422374977134 = 11218467999342 := by decide
theorem cert_e2422374977134 : check e2422374977134 [[],[]] .smaller = true := by decide
def e2422374977146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374977146 : Closed e2422374977146 ∧ code e2422374977146 = 11218467999354 := by decide
theorem cert_e2422374977146 : check e2422374977146 [[],[]] .smaller = true := by decide
def e2422374977334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374977334 : Closed e2422374977334 ∧ code e2422374977334 = 11218467999542 := by decide
theorem cert_e2422374977334 : check e2422374977334 [[],[]] .smaller = true := by decide
def e2422374977338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374977338 : Closed e2422374977338 ∧ code e2422374977338 = 11218467999546 := by decide
theorem cert_e2422374977338 : check e2422374977338 [[],[]] .smaller = true := by decide
def e2422374977422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422374977422 : Closed e2422374977422 ∧ code e2422374977422 = 11218467999630 := by decide
theorem cert_e2422374977422 : check e2422374977422 [[],[]] .three = true := by decide
def e2422374982078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422374982078 : Closed e2422374982078 ∧ code e2422374982078 = 11218468004286 := by decide
theorem cert_e2422374982078 : check e2422374982078 [[],[]] .three = true := by decide
def e2422374982110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422374982110 : Closed e2422374982110 ∧ code e2422374982110 = 11218468004318 := by decide
theorem cert_e2422374982110 : check e2422374982110 [[],[]] .smaller = true := by decide
def e2422374982134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422374982134 : Closed e2422374982134 ∧ code e2422374982134 = 11218468004342 := by decide
theorem cert_e2422374982134 : check e2422374982134 [[],[]] .smaller = true := by decide
def e2422374982138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422374982138 : Closed e2422374982138 ∧ code e2422374982138 = 11218468004346 := by decide
theorem cert_e2422374982138 : check e2422374982138 [[],[]] .three = true := by decide
def e2422374983086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422374983086 : Closed e2422374983086 ∧ code e2422374983086 = 11218468005294 := by decide
theorem cert_e2422374983086 : check e2422374983086 [[],[]] .smaller = true := by decide
def e2422374983098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422374983098 : Closed e2422374983098 ∧ code e2422374983098 = 11218468005306 := by decide
theorem cert_e2422374983098 : check e2422374983098 [[],[]] .smaller = true := by decide
def e2422374983146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422374983146 : Closed e2422374983146 ∧ code e2422374983146 = 11218468005354 := by decide
theorem cert_e2422374983146 : check e2422374983146 [[],[]] .smaller = true := by decide
def e2422374983230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422374983230 : Closed e2422374983230 ∧ code e2422374983230 = 11218468005438 := by decide
theorem cert_e2422374983230 : check e2422374983230 [[],[]] .three = true := by decide
def e2422374983278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374983278 : Closed e2422374983278 ∧ code e2422374983278 = 11218468005486 := by decide
theorem cert_e2422374983278 : check e2422374983278 [[],[]] .smaller = true := by decide
def e2422374983290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374983290 : Closed e2422374983290 ∧ code e2422374983290 = 11218468005498 := by decide
theorem cert_e2422374983290 : check e2422374983290 [[],[]] .smaller = true := by decide
def e2422374983454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422374983454 : Closed e2422374983454 ∧ code e2422374983454 = 11218468005662 := by decide
theorem cert_e2422374983454 : check e2422374983454 [[],[]] .smaller = true := by decide
def e2422374983554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422374983554 : Closed e2422374983554 ∧ code e2422374983554 = 11218468005762 := by decide
theorem cert_e2422374983554 : check e2422374983554 [[],[]] .smaller = true := by decide
def e2422374983566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422374983566 : Closed e2422374983566 ∧ code e2422374983566 = 11218468005774 := by decide
theorem cert_e2422374983566 : check e2422374983566 [[],[]] .smaller = true := by decide
def e2422374983578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374983578 : Closed e2422374983578 ∧ code e2422374983578 = 11218468005786 := by decide
theorem cert_e2422374983578 : check e2422374983578 [[],[]] .smaller = true := by decide
end Blc.Floor43
