import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377108378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377108378 : Closed e2262377108378 ∧ code e2262377108378 = 11058470130586 := by decide
theorem cert_e2262377108378 : check e2262377108378 [[],[.under]] .three = true := by decide
def e2262377109902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2262377109902 : Closed e2262377109902 ∧ code e2262377109902 = 11058470132110 := by decide
theorem cert_e2262377109902 : check e2262377109902 [[],[.under]] .three = true := by decide
def e2262377109958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2262377109958 : Closed e2262377109958 ∧ code e2262377109958 = 11058470132166 := by decide
theorem cert_e2262377109958 : check e2262377109958 [[],[.under]] .three = true := by decide
def e2262377110726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2262377110726 : Closed e2262377110726 ∧ code e2262377110726 = 11058470132934 := by decide
theorem cert_e2262377110726 : check e2262377110726 [[],[.under]] .three = true := by decide
def e2262377114710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2262377114710 : Closed e2262377114710 ∧ code e2262377114710 = 11058470136918 := by decide
theorem cert_e2262377114710 : check e2262377114710 [[],[.under]] .three = true := by decide
def e2262377114714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2262377114714 : Closed e2262377114714 ∧ code e2262377114714 = 11058470136922 := by decide
theorem cert_e2262377114714 : check e2262377114714 [[],[.under]] .three = true := by decide
def e2262377114902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2262377114902 : Closed e2262377114902 ∧ code e2262377114902 = 11058470137110 := by decide
theorem cert_e2262377114902 : check e2262377114902 [[],[.under]] .three = true := by decide
def e2262377114978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2262377114978 : Closed e2262377114978 ∧ code e2262377114978 = 11058470137186 := by decide
theorem cert_e2262377114978 : check e2262377114978 [[],[.under]] .three = true := by decide
def e2262377114990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2262377114990 : Closed e2262377114990 ∧ code e2262377114990 = 11058470137198 := by decide
theorem cert_e2262377114990 : check e2262377114990 [[],[.under]] .three = true := by decide
def e2262377114998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2262377114998 : Closed e2262377114998 ∧ code e2262377114998 = 11058470137206 := by decide
theorem cert_e2262377114998 : check e2262377114998 [[],[.under]] .three = true := by decide
def e2262377115018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262377115018 : Closed e2262377115018 ∧ code e2262377115018 = 11058470137226 := by decide
theorem cert_e2262377115018 : check e2262377115018 [[],[.under]] .three = true := by decide
def e2262377115042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262377115042 : Closed e2262377115042 ∧ code e2262377115042 = 11058470137250 := by decide
theorem cert_e2262377115042 : check e2262377115042 [[],[.under]] .three = true := by decide
def e2262377115054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2262377115054 : Closed e2262377115054 ∧ code e2262377115054 = 11058470137262 := by decide
theorem cert_e2262377115054 : check e2262377115054 [[],[.under]] .three = true := by decide
def e2262377115062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2262377115062 : Closed e2262377115062 ∧ code e2262377115062 = 11058470137270 := by decide
theorem cert_e2262377115062 : check e2262377115062 [[],[.under]] .three = true := by decide
def e2262377115066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2262377115066 : Closed e2262377115066 ∧ code e2262377115066 = 11058470137274 := by decide
theorem cert_e2262377115066 : check e2262377115066 [[],[.under]] .three = true := by decide
def e2262377115094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2262377115094 : Closed e2262377115094 ∧ code e2262377115094 = 11058470137302 := by decide
theorem cert_e2262377115094 : check e2262377115094 [[],[.under]] .three = true := by decide
def e2262377115098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2262377115098 : Closed e2262377115098 ∧ code e2262377115098 = 11058470137306 := by decide
theorem cert_e2262377115098 : check e2262377115098 [[],[.under]] .three = true := by decide
def e2262377115178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2262377115178 : Closed e2262377115178 ∧ code e2262377115178 = 11058470137386 := by decide
theorem cert_e2262377115178 : check e2262377115178 [[],[.under]] .three = true := by decide
def e2262377115274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2262377115274 : Closed e2262377115274 ∧ code e2262377115274 = 11058470137482 := by decide
theorem cert_e2262377115274 : check e2262377115274 [[],[.under]] .three = true := by decide
def e2262377115298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2262377115298 : Closed e2262377115298 ∧ code e2262377115298 = 11058470137506 := by decide
theorem cert_e2262377115298 : check e2262377115298 [[],[.under]] .three = true := by decide
def e2262377115310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2262377115310 : Closed e2262377115310 ∧ code e2262377115310 = 11058470137518 := by decide
theorem cert_e2262377115310 : check e2262377115310 [[],[.under]] .three = true := by decide
def e2262377115318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2262377115318 : Closed e2262377115318 ∧ code e2262377115318 = 11058470137526 := by decide
theorem cert_e2262377115318 : check e2262377115318 [[],[.under]] .three = true := by decide
def e2262377115322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2262377115322 : Closed e2262377115322 ∧ code e2262377115322 = 11058470137530 := by decide
theorem cert_e2262377115322 : check e2262377115322 [[],[.under]] .three = true := by decide
def e2262377115350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2262377115350 : Closed e2262377115350 ∧ code e2262377115350 = 11058470137558 := by decide
theorem cert_e2262377115350 : check e2262377115350 [[],[.under]] .three = true := by decide
def e2262377115354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2262377115354 : Closed e2262377115354 ∧ code e2262377115354 = 11058470137562 := by decide
theorem cert_e2262377115354 : check e2262377115354 [[],[.under]] .three = true := by decide
def e2262377115370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2262377115370 : Closed e2262377115370 ∧ code e2262377115370 = 11058470137578 := by decide
theorem cert_e2262377115370 : check e2262377115370 [[],[.under]] .three = true := by decide
def e2262377115478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2262377115478 : Closed e2262377115478 ∧ code e2262377115478 = 11058470137686 := by decide
theorem cert_e2262377115478 : check e2262377115478 [[],[.under]] .three = true := by decide
def e2262377115482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2262377115482 : Closed e2262377115482 ∧ code e2262377115482 = 11058470137690 := by decide
theorem cert_e2262377115482 : check e2262377115482 [[],[.under]] .three = true := by decide
def e2262377115498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2262377115498 : Closed e2262377115498 ∧ code e2262377115498 = 11058470137706 := by decide
theorem cert_e2262377115498 : check e2262377115498 [[],[.under]] .three = true := by decide
def e2262377115766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2262377115766 : Closed e2262377115766 ∧ code e2262377115766 = 11058470137974 := by decide
theorem cert_e2262377115766 : check e2262377115766 [[],[.under]] .three = true := by decide
def e2262377115770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2262377115770 : Closed e2262377115770 ∧ code e2262377115770 = 11058470137978 := by decide
theorem cert_e2262377115770 : check e2262377115770 [[],[.under]] .three = true := by decide
def e2262377115862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2262377115862 : Closed e2262377115862 ∧ code e2262377115862 = 11058470138070 := by decide
theorem cert_e2262377115862 : check e2262377115862 [[],[.under]] .three = true := by decide
def e2262377115958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377115958 : Closed e2262377115958 ∧ code e2262377115958 = 11058470138166 := by decide
theorem cert_e2262377115958 : check e2262377115958 [[],[.under]] .three = true := by decide
def e2262377115962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377115962 : Closed e2262377115962 ∧ code e2262377115962 = 11058470138170 := by decide
theorem cert_e2262377115962 : check e2262377115962 [[],[.under]] .three = true := by decide
def e2262377116046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2262377116046 : Closed e2262377116046 ∧ code e2262377116046 = 11058470138254 := by decide
theorem cert_e2262377116046 : check e2262377116046 [[],[.under]] .three = true := by decide
def e2262377116102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2262377116102 : Closed e2262377116102 ∧ code e2262377116102 = 11058470138310 := by decide
theorem cert_e2262377116102 : check e2262377116102 [[],[.under]] .three = true := by decide
def e2262377116438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2262377116438 : Closed e2262377116438 ∧ code e2262377116438 = 11058470138646 := by decide
theorem cert_e2262377116438 : check e2262377116438 [[],[.under]] .three = true := by decide
def e2262377116514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2262377116514 : Closed e2262377116514 ∧ code e2262377116514 = 11058470138722 := by decide
theorem cert_e2262377116514 : check e2262377116514 [[],[.under]] .three = true := by decide
def e2262377116526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2262377116526 : Closed e2262377116526 ∧ code e2262377116526 = 11058470138734 := by decide
theorem cert_e2262377116526 : check e2262377116526 [[],[.under]] .three = true := by decide
def e2262377116534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2262377116534 : Closed e2262377116534 ∧ code e2262377116534 = 11058470138742 := by decide
theorem cert_e2262377116534 : check e2262377116534 [[],[.under]] .three = true := by decide
def e2262377116554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262377116554 : Closed e2262377116554 ∧ code e2262377116554 = 11058470138762 := by decide
theorem cert_e2262377116554 : check e2262377116554 [[],[.under]] .three = true := by decide
def e2262377116578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262377116578 : Closed e2262377116578 ∧ code e2262377116578 = 11058470138786 := by decide
theorem cert_e2262377116578 : check e2262377116578 [[],[.under]] .three = true := by decide
def e2262377116590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2262377116590 : Closed e2262377116590 ∧ code e2262377116590 = 11058470138798 := by decide
theorem cert_e2262377116590 : check e2262377116590 [[],[.under]] .three = true := by decide
def e2262377116598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2262377116598 : Closed e2262377116598 ∧ code e2262377116598 = 11058470138806 := by decide
theorem cert_e2262377116598 : check e2262377116598 [[],[.under]] .three = true := by decide
def e2262377116602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2262377116602 : Closed e2262377116602 ∧ code e2262377116602 = 11058470138810 := by decide
theorem cert_e2262377116602 : check e2262377116602 [[],[.under]] .three = true := by decide
def e2262377116630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2262377116630 : Closed e2262377116630 ∧ code e2262377116630 = 11058470138838 := by decide
theorem cert_e2262377116630 : check e2262377116630 [[],[.under]] .three = true := by decide
def e2262377116634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2262377116634 : Closed e2262377116634 ∧ code e2262377116634 = 11058470138842 := by decide
theorem cert_e2262377116634 : check e2262377116634 [[],[.under]] .three = true := by decide
def e2262377116702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2262377116702 : Closed e2262377116702 ∧ code e2262377116702 = 11058470138910 := by decide
theorem cert_e2262377116702 : check e2262377116702 [[],[.under]] .three = true := by decide
def e2262377116898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2262377116898 : Closed e2262377116898 ∧ code e2262377116898 = 11058470139106 := by decide
theorem cert_e2262377116898 : check e2262377116898 [[],[.under]] .three = true := by decide
def e2262377116910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2262377116910 : Closed e2262377116910 ∧ code e2262377116910 = 11058470139118 := by decide
theorem cert_e2262377116910 : check e2262377116910 [[],[.under]] .three = true := by decide
def e2262377116918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2262377116918 : Closed e2262377116918 ∧ code e2262377116918 = 11058470139126 := by decide
theorem cert_e2262377116918 : check e2262377116918 [[],[.under]] .three = true := by decide
def e2262377117198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2262377117198 : Closed e2262377117198 ∧ code e2262377117198 = 11058470139406 := by decide
theorem cert_e2262377117198 : check e2262377117198 [[],[.under]] .three = true := by decide
def e2262377117210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262377117210 : Closed e2262377117210 ∧ code e2262377117210 = 11058470139418 := by decide
theorem cert_e2262377117210 : check e2262377117210 [[],[.under]] .three = true := by decide
def e2262377117282 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262377117282 : Closed e2262377117282 ∧ code e2262377117282 = 11058470139490 := by decide
theorem cert_e2262377117282 : check e2262377117282 [[],[.under]] .three = true := by decide
def e2262377117294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377117294 : Closed e2262377117294 ∧ code e2262377117294 = 11058470139502 := by decide
theorem cert_e2262377117294 : check e2262377117294 [[],[.under]] .three = true := by decide
def e2262377117302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262377117302 : Closed e2262377117302 ∧ code e2262377117302 = 11058470139510 := by decide
theorem cert_e2262377117302 : check e2262377117302 [[],[.under]] .three = true := by decide
def e2262377117306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377117306 : Closed e2262377117306 ∧ code e2262377117306 = 11058470139514 := by decide
theorem cert_e2262377117306 : check e2262377117306 [[],[.under]] .three = true := by decide
def e2262377117494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377117494 : Closed e2262377117494 ∧ code e2262377117494 = 11058470139702 := by decide
theorem cert_e2262377117494 : check e2262377117494 [[],[.under]] .three = true := by decide
def e2262377117498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377117498 : Closed e2262377117498 ∧ code e2262377117498 = 11058470139706 := by decide
theorem cert_e2262377117498 : check e2262377117498 [[],[.under]] .three = true := by decide
def e2262377117754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2262377117754 : Closed e2262377117754 ∧ code e2262377117754 = 11058470139962 := by decide
theorem cert_e2262377117754 : check e2262377117754 [[],[.under]] .three = true := by decide
def e2262377117802 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2262377117802 : Closed e2262377117802 ∧ code e2262377117802 = 11058470140010 := by decide
theorem cert_e2262377117802 : check e2262377117802 [[],[.under]] .three = true := by decide
def e2262377117850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377117850 : Closed e2262377117850 ∧ code e2262377117850 = 11058470140058 := by decide
theorem cert_e2262377117850 : check e2262377117850 [[],[.under]] .three = true := by decide
def e2262377117894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2262377117894 : Closed e2262377117894 ∧ code e2262377117894 = 11058470140102 := by decide
theorem cert_e2262377117894 : check e2262377117894 [[],[.under]] .three = true := by decide
def e2262377118090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2262377118090 : Closed e2262377118090 ∧ code e2262377118090 = 11058470140298 := by decide
theorem cert_e2262377118090 : check e2262377118090 [[],[.under]] .three = true := by decide
def e2262377118114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2262377118114 : Closed e2262377118114 ∧ code e2262377118114 = 11058470140322 := by decide
theorem cert_e2262377118114 : check e2262377118114 [[],[.under]] .three = true := by decide
def e2262377118126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2262377118126 : Closed e2262377118126 ∧ code e2262377118126 = 11058470140334 := by decide
theorem cert_e2262377118126 : check e2262377118126 [[],[.under]] .three = true := by decide
def e2262377118134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2262377118134 : Closed e2262377118134 ∧ code e2262377118134 = 11058470140342 := by decide
theorem cert_e2262377118134 : check e2262377118134 [[],[.under]] .three = true := by decide
def e2262377118138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2262377118138 : Closed e2262377118138 ∧ code e2262377118138 = 11058470140346 := by decide
theorem cert_e2262377118138 : check e2262377118138 [[],[.under]] .three = true := by decide
def e2262377118166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2262377118166 : Closed e2262377118166 ∧ code e2262377118166 = 11058470140374 := by decide
theorem cert_e2262377118166 : check e2262377118166 [[],[.under]] .three = true := by decide
def e2262377118170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2262377118170 : Closed e2262377118170 ∧ code e2262377118170 = 11058470140378 := by decide
theorem cert_e2262377118170 : check e2262377118170 [[],[.under]] .three = true := by decide
def e2262377118186 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2262377118186 : Closed e2262377118186 ∧ code e2262377118186 = 11058470140394 := by decide
theorem cert_e2262377118186 : check e2262377118186 [[],[.under]] .three = true := by decide
def e2262377118222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2262377118222 : Closed e2262377118222 ∧ code e2262377118222 = 11058470140430 := by decide
theorem cert_e2262377118222 : check e2262377118222 [[],[.under]] .three = true := by decide
def e2262377118234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2262377118234 : Closed e2262377118234 ∧ code e2262377118234 = 11058470140442 := by decide
theorem cert_e2262377118234 : check e2262377118234 [[],[.under]] .three = true := by decide
def e2262377118306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2262377118306 : Closed e2262377118306 ∧ code e2262377118306 = 11058470140514 := by decide
theorem cert_e2262377118306 : check e2262377118306 [[],[.under]] .three = true := by decide
def e2262377118318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2262377118318 : Closed e2262377118318 ∧ code e2262377118318 = 11058470140526 := by decide
theorem cert_e2262377118318 : check e2262377118318 [[],[.under]] .three = true := by decide
def e2262377118326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2262377118326 : Closed e2262377118326 ∧ code e2262377118326 = 11058470140534 := by decide
theorem cert_e2262377118326 : check e2262377118326 [[],[.under]] .three = true := by decide
def e2262377118330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2262377118330 : Closed e2262377118330 ∧ code e2262377118330 = 11058470140538 := by decide
theorem cert_e2262377118330 : check e2262377118330 [[],[.under]] .three = true := by decide
def e2262377118518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377118518 : Closed e2262377118518 ∧ code e2262377118518 = 11058470140726 := by decide
theorem cert_e2262377118518 : check e2262377118518 [[],[.under]] .three = true := by decide
def e2262377118522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377118522 : Closed e2262377118522 ∧ code e2262377118522 = 11058470140730 := by decide
theorem cert_e2262377118522 : check e2262377118522 [[],[.under]] .three = true := by decide
def e2262377118618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377118618 : Closed e2262377118618 ∧ code e2262377118618 = 11058470140826 := by decide
theorem cert_e2262377118618 : check e2262377118618 [[],[.under]] .three = true := by decide
def e2262377118934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2262377118934 : Closed e2262377118934 ∧ code e2262377118934 = 11058470141142 := by decide
theorem cert_e2262377118934 : check e2262377118934 [[],[.under]] .three = true := by decide
def e2262377118938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2262377118938 : Closed e2262377118938 ∧ code e2262377118938 = 11058470141146 := by decide
theorem cert_e2262377118938 : check e2262377118938 [[],[.under]] .three = true := by decide
def e2262377118954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2262377118954 : Closed e2262377118954 ∧ code e2262377118954 = 11058470141162 := by decide
theorem cert_e2262377118954 : check e2262377118954 [[],[.under]] .three = true := by decide
def e2262377119030 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2262377119030 : Closed e2262377119030 ∧ code e2262377119030 = 11058470141238 := by decide
theorem cert_e2262377119030 : check e2262377119030 [[],[.under]] .three = true := by decide
def e2262377119034 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2262377119034 : Closed e2262377119034 ∧ code e2262377119034 = 11058470141242 := by decide
theorem cert_e2262377119034 : check e2262377119034 [[],[.under]] .three = true := by decide
def e2262377119130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2262377119130 : Closed e2262377119130 ∧ code e2262377119130 = 11058470141338 := by decide
theorem cert_e2262377119130 : check e2262377119130 [[],[.under]] .three = true := by decide
def e2262377120734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2262377120734 : Closed e2262377120734 ∧ code e2262377120734 = 11058470142942 := by decide
theorem cert_e2262377120734 : check e2262377120734 [[],[.under]] .three = true := by decide
def e2262377120750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2262377120750 : Closed e2262377120750 ∧ code e2262377120750 = 11058470142958 := by decide
theorem cert_e2262377120750 : check e2262377120750 [[],[.under]] .three = true := by decide
def e2262377122582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262377122582 : Closed e2262377122582 ∧ code e2262377122582 = 11058470144790 := by decide
theorem cert_e2262377122582 : check e2262377122582 [[],[.under]] .three = true := by decide
def e2262377122658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262377122658 : Closed e2262377122658 ∧ code e2262377122658 = 11058470144866 := by decide
theorem cert_e2262377122658 : check e2262377122658 [[],[.under]] .three = true := by decide
def e2262377122670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262377122670 : Closed e2262377122670 ∧ code e2262377122670 = 11058470144878 := by decide
theorem cert_e2262377122670 : check e2262377122670 [[],[.under]] .three = true := by decide
def e2262377122678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262377122678 : Closed e2262377122678 ∧ code e2262377122678 = 11058470144886 := by decide
theorem cert_e2262377122678 : check e2262377122678 [[],[.under]] .three = true := by decide
def e2262377122698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377122698 : Closed e2262377122698 ∧ code e2262377122698 = 11058470144906 := by decide
theorem cert_e2262377122698 : check e2262377122698 [[],[.under]] .three = true := by decide
def e2262377122722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377122722 : Closed e2262377122722 ∧ code e2262377122722 = 11058470144930 := by decide
theorem cert_e2262377122722 : check e2262377122722 [[],[.under]] .three = true := by decide
def e2262377122734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262377122734 : Closed e2262377122734 ∧ code e2262377122734 = 11058470144942 := by decide
theorem cert_e2262377122734 : check e2262377122734 [[],[.under]] .three = true := by decide
def e2262377122742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2262377122742 : Closed e2262377122742 ∧ code e2262377122742 = 11058470144950 := by decide
theorem cert_e2262377122742 : check e2262377122742 [[],[.under]] .three = true := by decide
def e2262377122746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262377122746 : Closed e2262377122746 ∧ code e2262377122746 = 11058470144954 := by decide
theorem cert_e2262377122746 : check e2262377122746 [[],[.under]] .three = true := by decide
def e2262377122774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262377122774 : Closed e2262377122774 ∧ code e2262377122774 = 11058470144982 := by decide
theorem cert_e2262377122774 : check e2262377122774 [[],[.under]] .three = true := by decide
def e2262377122778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262377122778 : Closed e2262377122778 ∧ code e2262377122778 = 11058470144986 := by decide
theorem cert_e2262377122778 : check e2262377122778 [[],[.under]] .three = true := by decide
def e2262377122846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2262377122846 : Closed e2262377122846 ∧ code e2262377122846 = 11058470145054 := by decide
theorem cert_e2262377122846 : check e2262377122846 [[],[.under]] .three = true := by decide
def e2262377123042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262377123042 : Closed e2262377123042 ∧ code e2262377123042 = 11058470145250 := by decide
theorem cert_e2262377123042 : check e2262377123042 [[],[.under]] .three = true := by decide
def e2262377123054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377123054 : Closed e2262377123054 ∧ code e2262377123054 = 11058470145262 := by decide
theorem cert_e2262377123054 : check e2262377123054 [[],[.under]] .three = true := by decide
def e2262377123062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377123062 : Closed e2262377123062 ∧ code e2262377123062 = 11058470145270 := by decide
theorem cert_e2262377123062 : check e2262377123062 [[],[.under]] .three = true := by decide
def e2262377123342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377123342 : Closed e2262377123342 ∧ code e2262377123342 = 11058470145550 := by decide
theorem cert_e2262377123342 : check e2262377123342 [[],[.under]] .three = true := by decide
def e2262377123354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377123354 : Closed e2262377123354 ∧ code e2262377123354 = 11058470145562 := by decide
theorem cert_e2262377123354 : check e2262377123354 [[],[.under]] .three = true := by decide
def e2262377123426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377123426 : Closed e2262377123426 ∧ code e2262377123426 = 11058470145634 := by decide
theorem cert_e2262377123426 : check e2262377123426 [[],[.under]] .three = true := by decide
def e2262377123438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377123438 : Closed e2262377123438 ∧ code e2262377123438 = 11058470145646 := by decide
theorem cert_e2262377123438 : check e2262377123438 [[],[.under]] .three = true := by decide
def e2262377123446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377123446 : Closed e2262377123446 ∧ code e2262377123446 = 11058470145654 := by decide
theorem cert_e2262377123446 : check e2262377123446 [[],[.under]] .three = true := by decide
def e2262377123450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377123450 : Closed e2262377123450 ∧ code e2262377123450 = 11058470145658 := by decide
theorem cert_e2262377123450 : check e2262377123450 [[],[.under]] .three = true := by decide
def e2262377123638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377123638 : Closed e2262377123638 ∧ code e2262377123638 = 11058470145846 := by decide
theorem cert_e2262377123638 : check e2262377123638 [[],[.under]] .three = true := by decide
def e2262377123642 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377123642 : Closed e2262377123642 ∧ code e2262377123642 = 11058470145850 := by decide
theorem cert_e2262377123642 : check e2262377123642 [[],[.under]] .three = true := by decide
def e2262377128414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2262377128414 : Closed e2262377128414 ∧ code e2262377128414 = 11058470150622 := by decide
theorem cert_e2262377128414 : check e2262377128414 [[],[.under]] .three = true := by decide
def e2262377128438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2262377128438 : Closed e2262377128438 ∧ code e2262377128438 = 11058470150646 := by decide
theorem cert_e2262377128438 : check e2262377128438 [[],[.under]] .three = true := by decide
def e2262377129354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377129354 : Closed e2262377129354 ∧ code e2262377129354 = 11058470151562 := by decide
theorem cert_e2262377129354 : check e2262377129354 [[],[.under]] .three = true := by decide
def e2262377129378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377129378 : Closed e2262377129378 ∧ code e2262377129378 = 11058470151586 := by decide
theorem cert_e2262377129378 : check e2262377129378 [[],[.under]] .three = true := by decide
def e2262377129390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2262377129390 : Closed e2262377129390 ∧ code e2262377129390 = 11058470151598 := by decide
theorem cert_e2262377129390 : check e2262377129390 [[],[.under]] .three = true := by decide
def e2262377129398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2262377129398 : Closed e2262377129398 ∧ code e2262377129398 = 11058470151606 := by decide
theorem cert_e2262377129398 : check e2262377129398 [[],[.under]] .three = true := by decide
def e2262377129402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2262377129402 : Closed e2262377129402 ∧ code e2262377129402 = 11058470151610 := by decide
theorem cert_e2262377129402 : check e2262377129402 [[],[.under]] .three = true := by decide
def e2262377129430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2262377129430 : Closed e2262377129430 ∧ code e2262377129430 = 11058470151638 := by decide
theorem cert_e2262377129430 : check e2262377129430 [[],[.under]] .three = true := by decide
def e2262377129434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2262377129434 : Closed e2262377129434 ∧ code e2262377129434 = 11058470151642 := by decide
theorem cert_e2262377129434 : check e2262377129434 [[],[.under]] .three = true := by decide
def e2262377129450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2262377129450 : Closed e2262377129450 ∧ code e2262377129450 = 11058470151658 := by decide
theorem cert_e2262377129450 : check e2262377129450 [[],[.under]] .three = true := by decide
def e2262377129486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377129486 : Closed e2262377129486 ∧ code e2262377129486 = 11058470151694 := by decide
theorem cert_e2262377129486 : check e2262377129486 [[],[.under]] .three = true := by decide
def e2262377129498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377129498 : Closed e2262377129498 ∧ code e2262377129498 = 11058470151706 := by decide
theorem cert_e2262377129498 : check e2262377129498 [[],[.under]] .three = true := by decide
def e2262377129570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377129570 : Closed e2262377129570 ∧ code e2262377129570 = 11058470151778 := by decide
theorem cert_e2262377129570 : check e2262377129570 [[],[.under]] .three = true := by decide
def e2262377129582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377129582 : Closed e2262377129582 ∧ code e2262377129582 = 11058470151790 := by decide
theorem cert_e2262377129582 : check e2262377129582 [[],[.under]] .three = true := by decide
def e2262377129590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377129590 : Closed e2262377129590 ∧ code e2262377129590 = 11058470151798 := by decide
theorem cert_e2262377129590 : check e2262377129590 [[],[.under]] .three = true := by decide
def e2262377129594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377129594 : Closed e2262377129594 ∧ code e2262377129594 = 11058470151802 := by decide
theorem cert_e2262377129594 : check e2262377129594 [[],[.under]] .three = true := by decide
def e2262377129782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377129782 : Closed e2262377129782 ∧ code e2262377129782 = 11058470151990 := by decide
theorem cert_e2262377129782 : check e2262377129782 [[],[.under]] .three = true := by decide
def e2262377129786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377129786 : Closed e2262377129786 ∧ code e2262377129786 = 11058470151994 := by decide
theorem cert_e2262377129786 : check e2262377129786 [[],[.under]] .three = true := by decide
def e2262377129882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377129882 : Closed e2262377129882 ∧ code e2262377129882 = 11058470152090 := by decide
theorem cert_e2262377129882 : check e2262377129882 [[],[.under]] .three = true := by decide
def e2262377132270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2262377132270 : Closed e2262377132270 ∧ code e2262377132270 = 11058470154478 := by decide
private def t_e2262377132270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem cert_e2262377132270 : ¬ IsSelfInterpreter e2262377132270 :=
  wSource (t := t_e2262377132270) (replay_sound (ps := []) (t := e2262377132270) (by decide)) (by decide)
def e2262377132278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2262377132278 : Closed e2262377132278 ∧ code e2262377132278 = 11058470154486 := by decide
private def t_e2262377132278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem cert_e2262377132278 : ¬ IsSelfInterpreter e2262377132278 :=
  wSource (t := t_e2262377132278) (replay_sound (ps := []) (t := e2262377132278) (by decide)) (by decide)
def e2262377132758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2262377132758 : Closed e2262377132758 ∧ code e2262377132758 = 11058470154966 := by decide
private def t_e2262377132758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem cert_e2262377132758 : ¬ IsSelfInterpreter e2262377132758 :=
  wSource (t := t_e2262377132758) (replay_sound (ps := []) (t := e2262377132758) (by decide)) (by decide)
def e2262377132762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2262377132762 : Closed e2262377132762 ∧ code e2262377132762 = 11058470154970 := by decide
private def t_e2262377132762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem cert_e2262377132762 : ¬ IsSelfInterpreter e2262377132762 :=
  wSource (t := t_e2262377132762) (replay_sound (ps := []) (t := e2262377132762) (by decide)) (by decide)
def e2262377132778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2262377132778 : Closed e2262377132778 ∧ code e2262377132778 = 11058470154986 := by decide
private def t_e2262377132778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem cert_e2262377132778 : ¬ IsSelfInterpreter e2262377132778 :=
  wSource (t := t_e2262377132778) (replay_sound (ps := []) (t := e2262377132778) (by decide)) (by decide)
def e2262377132854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377132854 : Closed e2262377132854 ∧ code e2262377132854 = 11058470155062 := by decide
private def t_e2262377132854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem cert_e2262377132854 : ¬ IsSelfInterpreter e2262377132854 :=
  wSource (t := t_e2262377132854) (replay_sound (ps := []) (t := e2262377132854) (by decide)) (by decide)
def e2262377132858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377132858 : Closed e2262377132858 ∧ code e2262377132858 = 11058470155066 := by decide
private def t_e2262377132858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem cert_e2262377132858 : ¬ IsSelfInterpreter e2262377132858 :=
  wSource (t := t_e2262377132858) (replay_sound (ps := []) (t := e2262377132858) (by decide)) (by decide)
def e2262377132954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377132954 : Closed e2262377132954 ∧ code e2262377132954 = 11058470155162 := by decide
private def t_e2262377132954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem cert_e2262377132954 : ¬ IsSelfInterpreter e2262377132954 :=
  wSource (t := t_e2262377132954) (replay_sound (ps := []) (t := e2262377132954) (by decide)) (by decide)
def e2262377180638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2262377180638 : Closed e2262377180638 ∧ code e2262377180638 = 11058470202846 := by decide
theorem cert_e2262377180638 : check e2262377180638 [[],[.under]] .smaller = true := by decide
def e2262377180654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2262377180654 : Closed e2262377180654 ∧ code e2262377180654 = 11058470202862 := by decide
theorem cert_e2262377180654 : check e2262377180654 [[],[.under]] .smaller = true := by decide
def e2262377181022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2262377181022 : Closed e2262377181022 ∧ code e2262377181022 = 11058470203230 := by decide
theorem cert_e2262377181022 : check e2262377181022 [[],[.under]] .smaller = true := by decide
def e2262377181050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2262377181050 : Closed e2262377181050 ∧ code e2262377181050 = 11058470203258 := by decide
theorem cert_e2262377181050 : check e2262377181050 [[],[.under]] .smaller = true := by decide
def e2262377181102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2262377181102 : Closed e2262377181102 ∧ code e2262377181102 = 11058470203310 := by decide
theorem cert_e2262377181102 : check e2262377181102 [[],[.under]] .smaller = true := by decide
def e2262377181114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2262377181114 : Closed e2262377181114 ∧ code e2262377181114 = 11058470203322 := by decide
theorem cert_e2262377181114 : check e2262377181114 [[],[.under]] .smaller = true := by decide
def e2262377182174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2262377182174 : Closed e2262377182174 ∧ code e2262377182174 = 11058470204382 := by decide
theorem cert_e2262377182174 : check e2262377182174 [[],[.under]] .smaller = true := by decide
def e2262377182190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2262377182190 : Closed e2262377182190 ∧ code e2262377182190 = 11058470204398 := by decide
theorem cert_e2262377182190 : check e2262377182190 [[],[.under]] .smaller = true := by decide
def e2262377184478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262377184478 : Closed e2262377184478 ∧ code e2262377184478 = 11058470206686 := by decide
theorem cert_e2262377184478 : check e2262377184478 [[],[.under]] .smaller = true := by decide
def e2262377184506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262377184506 : Closed e2262377184506 ∧ code e2262377184506 = 11058470206714 := by decide
theorem cert_e2262377184506 : check e2262377184506 [[],[.under]] .smaller = true := by decide
def e2262377184878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262377184878 : Closed e2262377184878 ∧ code e2262377184878 = 11058470207086 := by decide
theorem cert_e2262377184878 : check e2262377184878 [[],[.under]] .smaller = true := by decide
def e2262377184890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262377184890 : Closed e2262377184890 ∧ code e2262377184890 = 11058470207098 := by decide
theorem cert_e2262377184890 : check e2262377184890 [[],[.under]] .smaller = true := by decide
def e2262377213294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2262377213294 : Closed e2262377213294 ∧ code e2262377213294 = 11058470235502 := by decide
theorem cert_e2262377213294 : check e2262377213294 [[],[.under]] .smaller = true := by decide
def e2262377213302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2262377213302 : Closed e2262377213302 ∧ code e2262377213302 = 11058470235510 := by decide
theorem cert_e2262377213302 : check e2262377213302 [[],[.under]] .smaller = true := by decide
def e2262377213358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2262377213358 : Closed e2262377213358 ∧ code e2262377213358 = 11058470235566 := by decide
theorem cert_e2262377213358 : check e2262377213358 [[],[.under]] .smaller = true := by decide
def e2262377213370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2262377213370 : Closed e2262377213370 ∧ code e2262377213370 = 11058470235578 := by decide
theorem cert_e2262377213370 : check e2262377213370 [[],[.under]] .smaller = true := by decide
def e2262377213398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2262377213398 : Closed e2262377213398 ∧ code e2262377213398 = 11058470235606 := by decide
theorem cert_e2262377213398 : check e2262377213398 [[],[.under]] .smaller = true := by decide
def e2262377213402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2262377213402 : Closed e2262377213402 ∧ code e2262377213402 = 11058470235610 := by decide
theorem cert_e2262377213402 : check e2262377213402 [[],[.under]] .smaller = true := by decide
def e2262377213614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262377213614 : Closed e2262377213614 ∧ code e2262377213614 = 11058470235822 := by decide
theorem cert_e2262377213614 : check e2262377213614 [[],[.under]] .smaller = true := by decide
def e2262377213626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262377213626 : Closed e2262377213626 ∧ code e2262377213626 = 11058470235834 := by decide
theorem cert_e2262377213626 : check e2262377213626 [[],[.under]] .smaller = true := by decide
def e2262377213674 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262377213674 : Closed e2262377213674 ∧ code e2262377213674 = 11058470235882 := by decide
theorem cert_e2262377213674 : check e2262377213674 [[],[.under]] .smaller = true := by decide
def e2262377213782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262377213782 : Closed e2262377213782 ∧ code e2262377213782 = 11058470235990 := by decide
theorem cert_e2262377213782 : check e2262377213782 [[],[.under]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262377132270
#print axioms Blc.Floor43.cert_e2262377132278
#print axioms Blc.Floor43.cert_e2262377132758
#print axioms Blc.Floor43.cert_e2262377132762
#print axioms Blc.Floor43.cert_e2262377132778
#print axioms Blc.Floor43.cert_e2262377132854
#print axioms Blc.Floor43.cert_e2262377132858
#print axioms Blc.Floor43.cert_e2262377132954
