import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e743247498478 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e743247498478 : Closed e743247498478 ∧ code e743247498478 = 9539340520686 := by decide
theorem cert_e743247498478 : check e743247498478 [] .sourceHead = true := by decide
def e743247498486 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e743247498486 : Closed e743247498486 ∧ code e743247498486 = 9539340520694 := by decide
theorem cert_e743247498486 : check e743247498486 [] .sourceHead = true := by decide
def e743247498862 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e743247498862 : Closed e743247498862 ∧ code e743247498862 = 9539340521070 := by decide
theorem cert_e743247498862 : check e743247498862 [] .sourceHead = true := by decide
def e743247498874 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e743247498874 : Closed e743247498874 ∧ code e743247498874 = 9539340521082 := by decide
theorem cert_e743247498874 : check e743247498874 [] .sourceHead = true := by decide
def e743247499062 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e743247499062 : Closed e743247499062 ∧ code e743247499062 = 9539340521270 := by decide
theorem cert_e743247499062 : check e743247499062 [] .sourceHead = true := by decide
def e743247499066 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e743247499066 : Closed e743247499066 ∧ code e743247499066 = 9539340521274 := by decide
theorem cert_e743247499066 : check e743247499066 [] .sourceHead = true := by decide
def e743247504814 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e743247504814 : Closed e743247504814 ∧ code e743247504814 = 9539340527022 := by decide
theorem cert_e743247504814 : check e743247504814 [] .sourceHead = true := by decide
def e743247504826 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e743247504826 : Closed e743247504826 ∧ code e743247504826 = 9539340527034 := by decide
theorem cert_e743247504826 : check e743247504826 [] .sourceHead = true := by decide
def e743247504874 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e743247504874 : Closed e743247504874 ∧ code e743247504874 = 9539340527082 := by decide
theorem cert_e743247504874 : check e743247504874 [] .sourceHead = true := by decide
def e743247505006 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e743247505006 : Closed e743247505006 ∧ code e743247505006 = 9539340527214 := by decide
theorem cert_e743247505006 : check e743247505006 [] .sourceHead = true := by decide
def e743247505018 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e743247505018 : Closed e743247505018 ∧ code e743247505018 = 9539340527226 := by decide
theorem cert_e743247505018 : check e743247505018 [] .sourceHead = true := by decide
def e743247505306 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e743247505306 : Closed e743247505306 ∧ code e743247505306 = 9539340527514 := by decide
theorem cert_e743247505306 : check e743247505306 [] .sourceHead = true := by decide
def e743247508182 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e743247508182 : Closed e743247508182 ∧ code e743247508182 = 9539340530390 := by decide
theorem cert_e743247508182 : check e743247508182 [] .sourceHead = true := by decide
def e743247508186 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e743247508186 : Closed e743247508186 ∧ code e743247508186 = 9539340530394 := by decide
theorem cert_e743247508186 : check e743247508186 [] .sourceHead = true := by decide
def e743247508202 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e743247508202 : Closed e743247508202 ∧ code e743247508202 = 9539340530410 := by decide
theorem cert_e743247508202 : check e743247508202 [] .sourceHead = true := by decide
def e743247508278 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e743247508278 : Closed e743247508278 ∧ code e743247508278 = 9539340530486 := by decide
theorem cert_e743247508278 : check e743247508278 [] .sourceHead = true := by decide
def e743247508282 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e743247508282 : Closed e743247508282 ∧ code e743247508282 = 9539340530490 := by decide
theorem cert_e743247508282 : check e743247508282 [] .sourceHead = true := by decide
def e743247508378 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e743247508378 : Closed e743247508378 ∧ code e743247508378 = 9539340530586 := by decide
theorem cert_e743247508378 : check e743247508378 [] .sourceHead = true := by decide
def e743247645550 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e743247645550 : Closed e743247645550 ∧ code e743247645550 = 9539340667758 := by decide
theorem cert_e743247645550 : check e743247645550 [] .sourceHead = true := by decide
def e743247645558 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e743247645558 : Closed e743247645558 ∧ code e743247645558 = 9539340667766 := by decide
theorem cert_e743247645558 : check e743247645558 [] .sourceHead = true := by decide
def e743247645614 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e743247645614 : Closed e743247645614 ∧ code e743247645614 = 9539340667822 := by decide
theorem cert_e743247645614 : check e743247645614 [] .sourceHead = true := by decide
def e743247645626 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e743247645626 : Closed e743247645626 ∧ code e743247645626 = 9539340667834 := by decide
theorem cert_e743247645626 : check e743247645626 [] .sourceHead = true := by decide
def e743247645654 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e743247645654 : Closed e743247645654 ∧ code e743247645654 = 9539340667862 := by decide
theorem cert_e743247645654 : check e743247645654 [] .sourceHead = true := by decide
def e743247645658 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e743247645658 : Closed e743247645658 ∧ code e743247645658 = 9539340667866 := by decide
theorem cert_e743247645658 : check e743247645658 [] .sourceHead = true := by decide
def e743247645934 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e743247645934 : Closed e743247645934 ∧ code e743247645934 = 9539340668142 := by decide
theorem cert_e743247645934 : check e743247645934 [] .sourceHead = true := by decide
def e743247645942 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e743247645942 : Closed e743247645942 ∧ code e743247645942 = 9539340668150 := by decide
theorem cert_e743247645942 : check e743247645942 [] .sourceHead = true := by decide
def e743247646318 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e743247646318 : Closed e743247646318 ∧ code e743247646318 = 9539340668526 := by decide
theorem cert_e743247646318 : check e743247646318 [] .sourceHead = true := by decide
def e743247646330 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e743247646330 : Closed e743247646330 ∧ code e743247646330 = 9539340668538 := by decide
theorem cert_e743247646330 : check e743247646330 [] .sourceHead = true := by decide
def e743247646518 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e743247646518 : Closed e743247646518 ∧ code e743247646518 = 9539340668726 := by decide
theorem cert_e743247646518 : check e743247646518 [] .sourceHead = true := by decide
def e743247646522 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e743247646522 : Closed e743247646522 ∧ code e743247646522 = 9539340668730 := by decide
theorem cert_e743247646522 : check e743247646522 [] .sourceHead = true := by decide
def e743248235374 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e743248235374 : Closed e743248235374 ∧ code e743248235374 = 9539341257582 := by decide
theorem cert_e743248235374 : check e743248235374 [] .sourceHead = true := by decide
def e743248235382 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e743248235382 : Closed e743248235382 ∧ code e743248235382 = 9539341257590 := by decide
theorem cert_e743248235382 : check e743248235382 [] .sourceHead = true := by decide
def e743248235438 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e743248235438 : Closed e743248235438 ∧ code e743248235438 = 9539341257646 := by decide
theorem cert_e743248235438 : check e743248235438 [] .sourceHead = true := by decide
def e743248235450 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e743248235450 : Closed e743248235450 ∧ code e743248235450 = 9539341257658 := by decide
theorem cert_e743248235450 : check e743248235450 [] .sourceHead = true := by decide
def e743248235478 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e743248235478 : Closed e743248235478 ∧ code e743248235478 = 9539341257686 := by decide
theorem cert_e743248235478 : check e743248235478 [] .sourceHead = true := by decide
def e743248235482 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e743248235482 : Closed e743248235482 ∧ code e743248235482 = 9539341257690 := by decide
theorem cert_e743248235482 : check e743248235482 [] .sourceHead = true := by decide
def e743248235758 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e743248235758 : Closed e743248235758 ∧ code e743248235758 = 9539341257966 := by decide
theorem cert_e743248235758 : check e743248235758 [] .sourceHead = true := by decide
def e743248235766 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e743248235766 : Closed e743248235766 ∧ code e743248235766 = 9539341257974 := by decide
theorem cert_e743248235766 : check e743248235766 [] .sourceHead = true := by decide
def e743248236142 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e743248236142 : Closed e743248236142 ∧ code e743248236142 = 9539341258350 := by decide
theorem cert_e743248236142 : check e743248236142 [] .sourceHead = true := by decide
def e743248236154 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e743248236154 : Closed e743248236154 ∧ code e743248236154 = 9539341258362 := by decide
theorem cert_e743248236154 : check e743248236154 [] .sourceHead = true := by decide
def e743248236342 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e743248236342 : Closed e743248236342 ∧ code e743248236342 = 9539341258550 := by decide
theorem cert_e743248236342 : check e743248236342 [] .sourceHead = true := by decide
def e743248236346 : Term := (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e743248236346 : Closed e743248236346 ∧ code e743248236346 = 9539341258554 := by decide
theorem cert_e743248236346 : check e743248236346 [] .sourceHead = true := by decide
def e755925610010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925610010 : Closed e755925610010 ∧ code e755925610010 = 9552018632218 := by decide
theorem cert_e755925610010 : check e755925610010 [] .sourceHead = true := by decide
def e755925612058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925612058 : Closed e755925612058 ∧ code e755925612058 = 9552018634266 := by decide
theorem cert_e755925612058 : check e755925612058 [] .sourceHead = true := by decide
def e755925626394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925626394 : Closed e755925626394 ∧ code e755925626394 = 9552018648602 := by decide
theorem cert_e755925626394 : check e755925626394 [] .sourceHead = true := by decide
def e755925629466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925629466 : Closed e755925629466 ∧ code e755925629466 = 9552018651674 := by decide
theorem cert_e755925629466 : check e755925629466 [] .sourceHead = true := by decide
def e755925636634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925636634 : Closed e755925636634 ∧ code e755925636634 = 9552018658842 := by decide
theorem cert_e755925636634 : check e755925636634 [] .sourceHead = true := by decide
def e755925637658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925637658 : Closed e755925637658 ∧ code e755925637658 = 9552018659866 := by decide
theorem cert_e755925637658 : check e755925637658 [] .sourceHead = true := by decide
def e755925691930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925691930 : Closed e755925691930 ∧ code e755925691930 = 9552018714138 := by decide
theorem cert_e755925691930 : check e755925691930 [] .sourceHead = true := by decide
def e755925695002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925695002 : Closed e755925695002 ∧ code e755925695002 = 9552018717210 := by decide
theorem cert_e755925695002 : check e755925695002 [] .sourceHead = true := by decide
def e755925707290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925707290 : Closed e755925707290 ∧ code e755925707290 = 9552018729498 := by decide
theorem cert_e755925707290 : check e755925707290 [] .sourceHead = true := by decide
def e755925734938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925734938 : Closed e755925734938 ∧ code e755925734938 = 9552018757146 := by decide
theorem cert_e755925734938 : check e755925734938 [] .sourceHead = true := by decide
def e755925735962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925735962 : Closed e755925735962 ∧ code e755925735962 = 9552018758170 := by decide
theorem cert_e755925735962 : check e755925735962 [] .sourceHead = true := by decide
def e755925740058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755925740058 : Closed e755925740058 ∧ code e755925740058 = 9552018762266 := by decide
theorem cert_e755925740058 : check e755925740058 [] .sourceHead = true := by decide
def e755926003226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926003226 : Closed e755926003226 ∧ code e755926003226 = 9552019025434 := by decide
theorem cert_e755926003226 : check e755926003226 [] .sourceHead = true := by decide
def e755926005274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926005274 : Closed e755926005274 ∧ code e755926005274 = 9552019027482 := by decide
theorem cert_e755926005274 : check e755926005274 [] .sourceHead = true := by decide
def e755926019610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926019610 : Closed e755926019610 ∧ code e755926019610 = 9552019041818 := by decide
theorem cert_e755926019610 : check e755926019610 [] .sourceHead = true := by decide
def e755926022682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926022682 : Closed e755926022682 ∧ code e755926022682 = 9552019044890 := by decide
theorem cert_e755926022682 : check e755926022682 [] .sourceHead = true := by decide
def e755926029850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926029850 : Closed e755926029850 ∧ code e755926029850 = 9552019052058 := by decide
theorem cert_e755926029850 : check e755926029850 [] .sourceHead = true := by decide
def e755926030874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926030874 : Closed e755926030874 ∧ code e755926030874 = 9552019053082 := by decide
theorem cert_e755926030874 : check e755926030874 [] .sourceHead = true := by decide
def e755926101530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926101530 : Closed e755926101530 ∧ code e755926101530 = 9552019123738 := by decide
theorem cert_e755926101530 : check e755926101530 [] .sourceHead = true := by decide
def e755926103578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926103578 : Closed e755926103578 ∧ code e755926103578 = 9552019125786 := by decide
theorem cert_e755926103578 : check e755926103578 [] .sourceHead = true := by decide
def e755926199834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926199834 : Closed e755926199834 ∧ code e755926199834 = 9552019222042 := by decide
theorem cert_e755926199834 : check e755926199834 [] .sourceHead = true := by decide
def e755926202906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926202906 : Closed e755926202906 ∧ code e755926202906 = 9552019225114 := by decide
theorem cert_e755926202906 : check e755926202906 [] .sourceHead = true := by decide
def e755926251034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926251034 : Closed e755926251034 ∧ code e755926251034 = 9552019273242 := by decide
theorem cert_e755926251034 : check e755926251034 [] .sourceHead = true := by decide
def e755926252058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926252058 : Closed e755926252058 ∧ code e755926252058 = 9552019274266 := by decide
theorem cert_e755926252058 : check e755926252058 [] .sourceHead = true := by decide
def e755926412826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926412826 : Closed e755926412826 ∧ code e755926412826 = 9552019435034 := by decide
theorem cert_e755926412826 : check e755926412826 [] .sourceHead = true := by decide
def e755926415898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926415898 : Closed e755926415898 ∧ code e755926415898 = 9552019438106 := by decide
theorem cert_e755926415898 : check e755926415898 [] .sourceHead = true := by decide
def e755926428186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926428186 : Closed e755926428186 ∧ code e755926428186 = 9552019450394 := by decide
theorem cert_e755926428186 : check e755926428186 [] .sourceHead = true := by decide
def e755926461978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926461978 : Closed e755926461978 ∧ code e755926461978 = 9552019484186 := by decide
theorem cert_e755926461978 : check e755926461978 [] .sourceHead = true := by decide
def e755926465050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926465050 : Closed e755926465050 ∧ code e755926465050 = 9552019487258 := by decide
theorem cert_e755926465050 : check e755926465050 [] .sourceHead = true := by decide
def e755926538778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926538778 : Closed e755926538778 ∧ code e755926538778 = 9552019560986 := by decide
theorem cert_e755926538778 : check e755926538778 [] .sourceHead = true := by decide
def e755926619674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926619674 : Closed e755926619674 ∧ code e755926619674 = 9552019641882 := by decide
theorem cert_e755926619674 : check e755926619674 [] .sourceHead = true := by decide
def e755926620698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926620698 : Closed e755926620698 ∧ code e755926620698 = 9552019642906 := by decide
theorem cert_e755926620698 : check e755926620698 [] .sourceHead = true := by decide
def e755926624794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926624794 : Closed e755926624794 ∧ code e755926624794 = 9552019647002 := by decide
theorem cert_e755926624794 : check e755926624794 [] .sourceHead = true := by decide
def e755926644250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926644250 : Closed e755926644250 ∧ code e755926644250 = 9552019666458 := by decide
theorem cert_e755926644250 : check e755926644250 [] .sourceHead = true := by decide
def e755926645274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926645274 : Closed e755926645274 ∧ code e755926645274 = 9552019667482 := by decide
theorem cert_e755926645274 : check e755926645274 [] .sourceHead = true := by decide
def e755926669850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755926669850 : Closed e755926669850 ∧ code e755926669850 = 9552019692058 := by decide
theorem cert_e755926669850 : check e755926669850 [] .sourceHead = true := by decide
def e755927576090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927576090 : Closed e755927576090 ∧ code e755927576090 = 9552020598298 := by decide
theorem cert_e755927576090 : check e755927576090 [] .sourceHead = true := by decide
def e755927578138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927578138 : Closed e755927578138 ∧ code e755927578138 = 9552020600346 := by decide
theorem cert_e755927578138 : check e755927578138 [] .sourceHead = true := by decide
def e755927592474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927592474 : Closed e755927592474 ∧ code e755927592474 = 9552020614682 := by decide
theorem cert_e755927592474 : check e755927592474 [] .sourceHead = true := by decide
def e755927595546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927595546 : Closed e755927595546 ∧ code e755927595546 = 9552020617754 := by decide
theorem cert_e755927595546 : check e755927595546 [] .sourceHead = true := by decide
def e755927602714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927602714 : Closed e755927602714 ∧ code e755927602714 = 9552020624922 := by decide
theorem cert_e755927602714 : check e755927602714 [] .sourceHead = true := by decide
def e755927603738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927603738 : Closed e755927603738 ∧ code e755927603738 = 9552020625946 := by decide
theorem cert_e755927603738 : check e755927603738 [] .sourceHead = true := by decide
def e755927674394 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927674394 : Closed e755927674394 ∧ code e755927674394 = 9552020696602 := by decide
theorem cert_e755927674394 : check e755927674394 [] .sourceHead = true := by decide
def e755927676442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927676442 : Closed e755927676442 ∧ code e755927676442 = 9552020698650 := by decide
theorem cert_e755927676442 : check e755927676442 [] .sourceHead = true := by decide
def e755927772698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927772698 : Closed e755927772698 ∧ code e755927772698 = 9552020794906 := by decide
theorem cert_e755927772698 : check e755927772698 [] .sourceHead = true := by decide
def e755927775770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927775770 : Closed e755927775770 ∧ code e755927775770 = 9552020797978 := by decide
theorem cert_e755927775770 : check e755927775770 [] .sourceHead = true := by decide
def e755927823898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927823898 : Closed e755927823898 ∧ code e755927823898 = 9552020846106 := by decide
theorem cert_e755927823898 : check e755927823898 [] .sourceHead = true := by decide
def e755927824922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755927824922 : Closed e755927824922 ∧ code e755927824922 = 9552020847130 := by decide
theorem cert_e755927824922 : check e755927824922 [] .sourceHead = true := by decide
def e755929296410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929296410 : Closed e755929296410 ∧ code e755929296410 = 9552022318618 := by decide
theorem cert_e755929296410 : check e755929296410 [] .sourceHead = true := by decide
def e755929299482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929299482 : Closed e755929299482 ∧ code e755929299482 = 9552022321690 := by decide
theorem cert_e755929299482 : check e755929299482 [] .sourceHead = true := by decide
def e755929311770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929311770 : Closed e755929311770 ∧ code e755929311770 = 9552022333978 := by decide
theorem cert_e755929311770 : check e755929311770 [] .sourceHead = true := by decide
def e755929345562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929345562 : Closed e755929345562 ∧ code e755929345562 = 9552022367770 := by decide
theorem cert_e755929345562 : check e755929345562 [] .sourceHead = true := by decide
def e755929348634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929348634 : Closed e755929348634 ∧ code e755929348634 = 9552022370842 := by decide
theorem cert_e755929348634 : check e755929348634 [] .sourceHead = true := by decide
def e755929422362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755929422362 : Closed e755929422362 ∧ code e755929422362 = 9552022444570 := by decide
theorem cert_e755929422362 : check e755929422362 [] .sourceHead = true := by decide
def e755930158618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930158618 : Closed e755930158618 ∧ code e755930158618 = 9552023180826 := by decide
theorem cert_e755930158618 : check e755930158618 [] .sourceHead = true := by decide
def e755930159642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930159642 : Closed e755930159642 ∧ code e755930159642 = 9552023181850 := by decide
theorem cert_e755930159642 : check e755930159642 [] .sourceHead = true := by decide
def e755930163738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930163738 : Closed e755930163738 ∧ code e755930163738 = 9552023185946 := by decide
theorem cert_e755930163738 : check e755930163738 [] .sourceHead = true := by decide
def e755930183194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930183194 : Closed e755930183194 ∧ code e755930183194 = 9552023205402 := by decide
theorem cert_e755930183194 : check e755930183194 [] .sourceHead = true := by decide
def e755930184218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930184218 : Closed e755930184218 ∧ code e755930184218 = 9552023206426 := by decide
theorem cert_e755930184218 : check e755930184218 [] .sourceHead = true := by decide
def e755930208794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755930208794 : Closed e755930208794 ∧ code e755930208794 = 9552023231002 := by decide
theorem cert_e755930208794 : check e755930208794 [] .sourceHead = true := by decide
def e755959707674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959707674 : Closed e755959707674 ∧ code e755959707674 = 9552052729882 := by decide
theorem cert_e755959707674 : check e755959707674 [] .sourceHead = true := by decide
def e755959715866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959715866 : Closed e755959715866 ∧ code e755959715866 = 9552052738074 := by decide
theorem cert_e755959715866 : check e755959715866 [] .sourceHead = true := by decide
def e755959717402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959717402 : Closed e755959717402 ∧ code e755959717402 = 9552052739610 := by decide
theorem cert_e755959717402 : check e755959717402 [] .sourceHead = true := by decide
def e755959721498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959721498 : Closed e755959721498 ∧ code e755959721498 = 9552052743706 := by decide
theorem cert_e755959721498 : check e755959721498 [] .sourceHead = true := by decide
def e755959773210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959773210 : Closed e755959773210 ∧ code e755959773210 = 9552052795418 := by decide
theorem cert_e755959773210 : check e755959773210 [] .sourceHead = true := by decide
def e755959782938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959782938 : Closed e755959782938 ∧ code e755959782938 = 9552052805146 := by decide
theorem cert_e755959782938 : check e755959782938 [] .sourceHead = true := by decide
def e755959785498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959785498 : Closed e755959785498 ∧ code e755959785498 = 9552052807706 := by decide
theorem cert_e755959785498 : check e755959785498 [] .sourceHead = true := by decide
def e755959787034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959787034 : Closed e755959787034 ∧ code e755959787034 = 9552052809242 := by decide
theorem cert_e755959787034 : check e755959787034 [] .sourceHead = true := by decide
def e755959789082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959789082 : Closed e755959789082 ∧ code e755959789082 = 9552052811290 := by decide
theorem cert_e755959789082 : check e755959789082 [] .sourceHead = true := by decide
def e755959814170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959814170 : Closed e755959814170 ∧ code e755959814170 = 9552052836378 := by decide
theorem cert_e755959814170 : check e755959814170 [] .sourceHead = true := by decide
def e755959815706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959815706 : Closed e755959815706 ∧ code e755959815706 = 9552052837914 := by decide
theorem cert_e755959815706 : check e755959815706 [] .sourceHead = true := by decide
def e755959818266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755959818266 : Closed e755959818266 ∧ code e755959818266 = 9552052840474 := by decide
theorem cert_e755959818266 : check e755959818266 [] .sourceHead = true := by decide
def e755959819802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959819802 : Closed e755959819802 ∧ code e755959819802 = 9552052842010 := by decide
theorem cert_e755959819802 : check e755959819802 [] .sourceHead = true := by decide
def e755959821850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959821850 : Closed e755959821850 ∧ code e755959821850 = 9552052844058 := by decide
theorem cert_e755959821850 : check e755959821850 [] .sourceHead = true := by decide
def e755959822874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959822874 : Closed e755959822874 ∧ code e755959822874 = 9552052845082 := by decide
theorem cert_e755959822874 : check e755959822874 [] .sourceHead = true := by decide
def e755959836186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959836186 : Closed e755959836186 ∧ code e755959836186 = 9552052858394 := by decide
theorem cert_e755959836186 : check e755959836186 [] .sourceHead = true := by decide
def e755959838234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959838234 : Closed e755959838234 ∧ code e755959838234 = 9552052860442 := by decide
theorem cert_e755959838234 : check e755959838234 [] .sourceHead = true := by decide
def e755959839258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755959839258 : Closed e755959839258 ∧ code e755959839258 = 9552052861466 := by decide
theorem cert_e755959839258 : check e755959839258 [] .sourceHead = true := by decide
def e755960035354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960035354 : Closed e755960035354 ∧ code e755960035354 = 9552053057562 := by decide
theorem cert_e755960035354 : check e755960035354 [] .sourceHead = true := by decide
def e755960045082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960045082 : Closed e755960045082 ∧ code e755960045082 = 9552053067290 := by decide
theorem cert_e755960045082 : check e755960045082 [] .sourceHead = true := by decide
def e755960047642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960047642 : Closed e755960047642 ∧ code e755960047642 = 9552053069850 := by decide
theorem cert_e755960047642 : check e755960047642 [] .sourceHead = true := by decide
def e755960049178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960049178 : Closed e755960049178 ∧ code e755960049178 = 9552053071386 := by decide
theorem cert_e755960049178 : check e755960049178 [] .sourceHead = true := by decide
def e755960051226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960051226 : Closed e755960051226 ∧ code e755960051226 = 9552053073434 := by decide
theorem cert_e755960051226 : check e755960051226 [] .sourceHead = true := by decide
def e755960077850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960077850 : Closed e755960077850 ∧ code e755960077850 = 9552053100058 := by decide
theorem cert_e755960077850 : check e755960077850 [] .sourceHead = true := by decide
def e755960085018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960085018 : Closed e755960085018 ∧ code e755960085018 = 9552053107226 := by decide
theorem cert_e755960085018 : check e755960085018 [] .sourceHead = true := by decide
def e755960096794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960096794 : Closed e755960096794 ∧ code e755960096794 = 9552053119002 := by decide
theorem cert_e755960096794 : check e755960096794 [] .sourceHead = true := by decide
def e755960098330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960098330 : Closed e755960098330 ∧ code e755960098330 = 9552053120538 := by decide
theorem cert_e755960098330 : check e755960098330 [] .sourceHead = true := by decide
def e755960101402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960101402 : Closed e755960101402 ∧ code e755960101402 = 9552053123610 := by decide
theorem cert_e755960101402 : check e755960101402 [] .sourceHead = true := by decide
def e755960108570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960108570 : Closed e755960108570 ∧ code e755960108570 = 9552053130778 := by decide
theorem cert_e755960108570 : check e755960108570 [] .sourceHead = true := by decide
def e755960109594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960109594 : Closed e755960109594 ∧ code e755960109594 = 9552053131802 := by decide
theorem cert_e755960109594 : check e755960109594 [] .sourceHead = true := by decide
def e755960207386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960207386 : Closed e755960207386 ∧ code e755960207386 = 9552053229594 := by decide
theorem cert_e755960207386 : check e755960207386 [] .sourceHead = true := by decide
def e755960208922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960208922 : Closed e755960208922 ∧ code e755960208922 = 9552053231130 := by decide
theorem cert_e755960208922 : check e755960208922 [] .sourceHead = true := by decide
def e755960211482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960211482 : Closed e755960211482 ∧ code e755960211482 = 9552053233690 := by decide
theorem cert_e755960211482 : check e755960211482 [] .sourceHead = true := by decide
def e755960213018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960213018 : Closed e755960213018 ∧ code e755960213018 = 9552053235226 := by decide
theorem cert_e755960213018 : check e755960213018 [] .sourceHead = true := by decide
def e755960215066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960215066 : Closed e755960215066 ∧ code e755960215066 = 9552053237274 := by decide
theorem cert_e755960215066 : check e755960215066 [] .sourceHead = true := by decide
def e755960216090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960216090 : Closed e755960216090 ∧ code e755960216090 = 9552053238298 := by decide
theorem cert_e755960216090 : check e755960216090 [] .sourceHead = true := by decide
def e755960227866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755960227866 : Closed e755960227866 ∧ code e755960227866 = 9552053250074 := by decide
theorem cert_e755960227866 : check e755960227866 [] .sourceHead = true := by decide
def e755960229402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960229402 : Closed e755960229402 ∧ code e755960229402 = 9552053251610 := by decide
theorem cert_e755960229402 : check e755960229402 [] .sourceHead = true := by decide
def e755960232474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960232474 : Closed e755960232474 ∧ code e755960232474 = 9552053254682 := by decide
theorem cert_e755960232474 : check e755960232474 [] .sourceHead = true := by decide
def e755960239642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960239642 : Closed e755960239642 ∧ code e755960239642 = 9552053261850 := by decide
theorem cert_e755960239642 : check e755960239642 [] .sourceHead = true := by decide
def e755960240666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960240666 : Closed e755960240666 ∧ code e755960240666 = 9552053262874 := by decide
theorem cert_e755960240666 : check e755960240666 [] .sourceHead = true := by decide
def e755960244762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960244762 : Closed e755960244762 ∧ code e755960244762 = 9552053266970 := by decide
theorem cert_e755960244762 : check e755960244762 [] .sourceHead = true := by decide
def e755960294938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960294938 : Closed e755960294938 ∧ code e755960294938 = 9552053317146 := by decide
theorem cert_e755960294938 : check e755960294938 [] .sourceHead = true := by decide
def e755960296986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960296986 : Closed e755960296986 ∧ code e755960296986 = 9552053319194 := by decide
theorem cert_e755960296986 : check e755960296986 [] .sourceHead = true := by decide
def e755960298010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960298010 : Closed e755960298010 ∧ code e755960298010 = 9552053320218 := by decide
theorem cert_e755960298010 : check e755960298010 [] .sourceHead = true := by decide
def e755960305178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960305178 : Closed e755960305178 ∧ code e755960305178 = 9552053327386 := by decide
theorem cert_e755960305178 : check e755960305178 [] .sourceHead = true := by decide
def e755960306202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960306202 : Closed e755960306202 ∧ code e755960306202 = 9552053328410 := by decide
theorem cert_e755960306202 : check e755960306202 [] .sourceHead = true := by decide
def e755960310298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755960310298 : Closed e755960310298 ∧ code e755960310298 = 9552053332506 := by decide
theorem cert_e755960310298 : check e755960310298 [] .sourceHead = true := by decide
def e755961280538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961280538 : Closed e755961280538 ∧ code e755961280538 = 9552054302746 := by decide
theorem cert_e755961280538 : check e755961280538 [] .sourceHead = true := by decide
def e755961288730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961288730 : Closed e755961288730 ∧ code e755961288730 = 9552054310938 := by decide
theorem cert_e755961288730 : check e755961288730 [] .sourceHead = true := by decide
def e755961290266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961290266 : Closed e755961290266 ∧ code e755961290266 = 9552054312474 := by decide
theorem cert_e755961290266 : check e755961290266 [] .sourceHead = true := by decide
def e755961294362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961294362 : Closed e755961294362 ∧ code e755961294362 = 9552054316570 := by decide
theorem cert_e755961294362 : check e755961294362 [] .sourceHead = true := by decide
def e755961346074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961346074 : Closed e755961346074 ∧ code e755961346074 = 9552054368282 := by decide
theorem cert_e755961346074 : check e755961346074 [] .sourceHead = true := by decide
def e755961355802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961355802 : Closed e755961355802 ∧ code e755961355802 = 9552054378010 := by decide
theorem cert_e755961355802 : check e755961355802 [] .sourceHead = true := by decide
def e755961358362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961358362 : Closed e755961358362 ∧ code e755961358362 = 9552054380570 := by decide
theorem cert_e755961358362 : check e755961358362 [] .sourceHead = true := by decide
def e755961359898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961359898 : Closed e755961359898 ∧ code e755961359898 = 9552054382106 := by decide
theorem cert_e755961359898 : check e755961359898 [] .sourceHead = true := by decide
def e755961361946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961361946 : Closed e755961361946 ∧ code e755961361946 = 9552054384154 := by decide
theorem cert_e755961361946 : check e755961361946 [] .sourceHead = true := by decide
def e755961387034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961387034 : Closed e755961387034 ∧ code e755961387034 = 9552054409242 := by decide
theorem cert_e755961387034 : check e755961387034 [] .sourceHead = true := by decide
end Blc.Floor43
