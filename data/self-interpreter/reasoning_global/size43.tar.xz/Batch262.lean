import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405976703886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405976703886 : Closed e2405976703886 ∧ code e2405976703886 = 11202069726094 := by decide
theorem cert_e2405976703886 : check e2405976703886 [[]] .width = true := by decide
def e2405976703898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405976703898 : Closed e2405976703898 ∧ code e2405976703898 = 11202069726106 := by decide
theorem cert_e2405976703898 : check e2405976703898 [[]] .width = true := by decide
def e2405976705818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405976705818 : Closed e2405976705818 ∧ code e2405976705818 = 11202069728026 := by decide
theorem cert_e2405976705818 : check e2405976705818 [[]] .width = true := by decide
def e2405976705862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405976705862 : Closed e2405976705862 ∧ code e2405976705862 = 11202069728070 := by decide
private def t_e2405976705862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e2405976705862 : ¬ IsSelfInterpreter e2405976705862 :=
  wSource (t := t_e2405976705862) (replay_sound (ps := []) (t := e2405976705862) (by decide)) (by decide)
def e2405976706102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405976706102 : Closed e2405976706102 ∧ code e2405976706102 = 11202069728310 := by decide
private def t_e2405976706102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e2405976706102 : ¬ IsSelfInterpreter e2405976706102 :=
  wSource (t := t_e2405976706102) (replay_sound (ps := []) (t := e2405976706102) (by decide)) (by decide)
def e2405976706106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405976706106 : Closed e2405976706106 ∧ code e2405976706106 = 11202069728314 := by decide
private def t_e2405976706106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e2405976706106 : ¬ IsSelfInterpreter e2405976706106 :=
  wSource (t := t_e2405976706106) (replay_sound (ps := []) (t := e2405976706106) (by decide)) (by decide)
def e2405976706246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405976706246 : Closed e2405976706246 ∧ code e2405976706246 = 11202069728454 := by decide
theorem cert_e2405976706246 : check e2405976706246 [[]] .width = true := by decide
def e2405976877082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976877082 : Closed e2405976877082 ∧ code e2405976877082 = 11202069899290 := by decide
theorem cert_e2405976877082 : check e2405976877082 [[]] .width = true := by decide
def e2405976878618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976878618 : Closed e2405976878618 ∧ code e2405976878618 = 11202069900826 := by decide
private def t_e2405976878618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976878618 : ¬ IsSelfInterpreter e2405976878618 :=
  wSource (t := t_e2405976878618) (replay_sound (ps := []) (t := e2405976878618) (by decide)) (by decide)
def e2405976881690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976881690 : Closed e2405976881690 ∧ code e2405976881690 = 11202069903898 := by decide
private def t_e2405976881690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976881690 : ¬ IsSelfInterpreter e2405976881690 :=
  wSource (t := t_e2405976881690) (replay_sound (ps := []) (t := e2405976881690) (by decide)) (by decide)
def e2405976893978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976893978 : Closed e2405976893978 ∧ code e2405976893978 = 11202069916186 := by decide
private def t_e2405976893978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976893978 : ¬ IsSelfInterpreter e2405976893978 :=
  wSource (t := t_e2405976893978) (replay_sound (ps := []) (t := e2405976893978) (by decide)) (by decide)
def e2405976901658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976901658 : Closed e2405976901658 ∧ code e2405976901658 = 11202069923866 := by decide
theorem cert_e2405976901658 : check e2405976901658 [[]] .width = true := by decide
def e2405976907802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405976907802 : Closed e2405976907802 ∧ code e2405976907802 = 11202069930010 := by decide
theorem cert_e2405976907802 : check e2405976907802 [[]] .width = true := by decide
def e2405976907894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405976907894 : Closed e2405976907894 ∧ code e2405976907894 = 11202069930102 := by decide
private def t_e2405976907894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405976907894 : ¬ IsSelfInterpreter e2405976907894 :=
  wSource (t := t_e2405976907894) (replay_sound (ps := []) (t := e2405976907894) (by decide)) (by decide)
def e2405976908138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405976908138 : Closed e2405976908138 ∧ code e2405976908138 = 11202069930346 := by decide
private def t_e2405976908138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405976908138 : ¬ IsSelfInterpreter e2405976908138 :=
  wSource (t := t_e2405976908138) (replay_sound (ps := []) (t := e2405976908138) (by decide)) (by decide)
def e2405976908186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405976908186 : Closed e2405976908186 ∧ code e2405976908186 = 11202069930394 := by decide
private def t_e2405976908186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405976908186 : ¬ IsSelfInterpreter e2405976908186 :=
  wSource (t := t_e2405976908186) (replay_sound (ps := []) (t := e2405976908186) (by decide)) (by decide)
def e2405976912070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405976912070 : Closed e2405976912070 ∧ code e2405976912070 = 11202069934278 := by decide
theorem cert_e2405976912070 : check e2405976912070 [[]] .width = true := by decide
def e2405976913946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976913946 : Closed e2405976913946 ∧ code e2405976913946 = 11202069936154 := by decide
theorem cert_e2405976913946 : check e2405976913946 [[]] .width = true := by decide
def e2405976926234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976926234 : Closed e2405976926234 ∧ code e2405976926234 = 11202069948442 := by decide
theorem cert_e2405976926234 : check e2405976926234 [[]] .width = true := by decide
def e2405976927770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976927770 : Closed e2405976927770 ∧ code e2405976927770 = 11202069949978 := by decide
private def t_e2405976927770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976927770 : ¬ IsSelfInterpreter e2405976927770 :=
  wSource (t := t_e2405976927770) (replay_sound (ps := []) (t := e2405976927770) (by decide)) (by decide)
def e2405976930842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405976930842 : Closed e2405976930842 ∧ code e2405976930842 = 11202069953050 := by decide
private def t_e2405976930842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405976930842 : ¬ IsSelfInterpreter e2405976930842 :=
  wSource (t := t_e2405976930842) (replay_sound (ps := []) (t := e2405976930842) (by decide)) (by decide)
def e2405976932378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405976932378 : Closed e2405976932378 ∧ code e2405976932378 = 11202069954586 := by decide
theorem cert_e2405976932378 : check e2405976932378 [[]] .width = true := by decide
def e2405976932470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405976932470 : Closed e2405976932470 ∧ code e2405976932470 = 11202069954678 := by decide
theorem cert_e2405976932470 : check e2405976932470 [[]] .width = true := by decide
def e2405976932714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405976932714 : Closed e2405976932714 ∧ code e2405976932714 = 11202069954922 := by decide
theorem cert_e2405976932714 : check e2405976932714 [[]] .width = true := by decide
def e2405976932762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405976932762 : Closed e2405976932762 ∧ code e2405976932762 = 11202069954970 := by decide
theorem cert_e2405976932762 : check e2405976932762 [[]] .width = true := by decide
def e2405976933770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405976933770 : Closed e2405976933770 ∧ code e2405976933770 = 11202069955978 := by decide
theorem cert_e2405976933770 : check e2405976933770 [[]] .width = true := by decide
def e2405976933794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405976933794 : Closed e2405976933794 ∧ code e2405976933794 = 11202069956002 := by decide
private def t_e2405976933794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405976933794 : ¬ IsSelfInterpreter e2405976933794 :=
  wSource (t := t_e2405976933794) (replay_sound (ps := []) (t := e2405976933794) (by decide)) (by decide)
def e2405976933902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405976933902 : Closed e2405976933902 ∧ code e2405976933902 = 11202069956110 := by decide
theorem cert_e2405976933902 : check e2405976933902 [[]] .width = true := by decide
def e2405976933914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405976933914 : Closed e2405976933914 ∧ code e2405976933914 = 11202069956122 := by decide
private def t_e2405976933914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405976933914 : ¬ IsSelfInterpreter e2405976933914 :=
  wSource (t := t_e2405976933914) (replay_sound (ps := []) (t := e2405976933914) (by decide)) (by decide)
def e2405976933986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405976933986 : Closed e2405976933986 ∧ code e2405976933986 = 11202069956194 := by decide
theorem cert_e2405976933986 : check e2405976933986 [[]] .width = true := by decide
def e2405976948934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405976948934 : Closed e2405976948934 ∧ code e2405976948934 = 11202069971142 := by decide
theorem cert_e2405976948934 : check e2405976948934 [[]] .width = true := by decide
def e2405976956954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405976956954 : Closed e2405976956954 ∧ code e2405976956954 = 11202069979162 := by decide
theorem cert_e2405976956954 : check e2405976956954 [[]] .width = true := by decide
def e2405976957046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405976957046 : Closed e2405976957046 ∧ code e2405976957046 = 11202069979254 := by decide
private def t_e2405976957046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405976957046 : ¬ IsSelfInterpreter e2405976957046 :=
  wSource (t := t_e2405976957046) (replay_sound (ps := []) (t := e2405976957046) (by decide)) (by decide)
def e2405976957290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405976957290 : Closed e2405976957290 ∧ code e2405976957290 = 11202069979498 := by decide
private def t_e2405976957290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405976957290 : ¬ IsSelfInterpreter e2405976957290 :=
  wSource (t := t_e2405976957290) (replay_sound (ps := []) (t := e2405976957290) (by decide)) (by decide)
def e2405976957338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405976957338 : Closed e2405976957338 ∧ code e2405976957338 = 11202069979546 := by decide
private def t_e2405976957338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405976957338 : ¬ IsSelfInterpreter e2405976957338 :=
  wSource (t := t_e2405976957338) (replay_sound (ps := []) (t := e2405976957338) (by decide)) (by decide)
def e2405976971290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405976971290 : Closed e2405976971290 ∧ code e2405976971290 = 11202069993498 := by decide
theorem cert_e2405976971290 : check e2405976971290 [[]] .width = true := by decide
def e2405976981702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405976981702 : Closed e2405976981702 ∧ code e2405976981702 = 11202070003910 := by decide
theorem cert_e2405976981702 : check e2405976981702 [[]] .width = true := by decide
def e2405977004570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977004570 : Closed e2405977004570 ∧ code e2405977004570 = 11202070026778 := by decide
private def t_e2405977004570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977004570 : ¬ IsSelfInterpreter e2405977004570 :=
  wSource (t := t_e2405977004570) (replay_sound (ps := []) (t := e2405977004570) (by decide)) (by decide)
def e2405977006106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405977006106 : Closed e2405977006106 ∧ code e2405977006106 = 11202070028314 := by decide
theorem cert_e2405977006106 : check e2405977006106 [[]] .width = true := by decide
def e2405977006198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405977006198 : Closed e2405977006198 ∧ code e2405977006198 = 11202070028406 := by decide
private def t_e2405977006198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405977006198 : ¬ IsSelfInterpreter e2405977006198 :=
  wSource (t := t_e2405977006198) (replay_sound (ps := []) (t := e2405977006198) (by decide)) (by decide)
def e2405977006442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405977006442 : Closed e2405977006442 ∧ code e2405977006442 = 11202070028650 := by decide
private def t_e2405977006442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405977006442 : ¬ IsSelfInterpreter e2405977006442 :=
  wSource (t := t_e2405977006442) (replay_sound (ps := []) (t := e2405977006442) (by decide)) (by decide)
def e2405977006490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405977006490 : Closed e2405977006490 ∧ code e2405977006490 = 11202070028698 := by decide
private def t_e2405977006490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405977006490 : ¬ IsSelfInterpreter e2405977006490 :=
  wSource (t := t_e2405977006490) (replay_sound (ps := []) (t := e2405977006490) (by decide)) (by decide)
def e2405977030682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405977030682 : Closed e2405977030682 ∧ code e2405977030682 = 11202070052890 := by decide
theorem cert_e2405977030682 : check e2405977030682 [[]] .width = true := by decide
def e2405977030774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405977030774 : Closed e2405977030774 ∧ code e2405977030774 = 11202070052982 := by decide
theorem cert_e2405977030774 : check e2405977030774 [[]] .width = true := by decide
def e2405977031018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405977031018 : Closed e2405977031018 ∧ code e2405977031018 = 11202070053226 := by decide
theorem cert_e2405977031018 : check e2405977031018 [[]] .width = true := by decide
def e2405977031066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405977031066 : Closed e2405977031066 ∧ code e2405977031066 = 11202070053274 := by decide
theorem cert_e2405977031066 : check e2405977031066 [[]] .width = true := by decide
def e2405977031150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405977031150 : Closed e2405977031150 ∧ code e2405977031150 = 11202070053358 := by decide
theorem cert_e2405977031150 : check e2405977031150 [[]] .width = true := by decide
def e2405977032074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405977032074 : Closed e2405977032074 ∧ code e2405977032074 = 11202070054282 := by decide
theorem cert_e2405977032074 : check e2405977032074 [[]] .width = true := by decide
def e2405977032098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405977032098 : Closed e2405977032098 ∧ code e2405977032098 = 11202070054306 := by decide
theorem cert_e2405977032098 : check e2405977032098 [[]] .width = true := by decide
def e2405977032110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405977032110 : Closed e2405977032110 ∧ code e2405977032110 = 11202070054318 := by decide
theorem cert_e2405977032110 : check e2405977032110 [[]] .width = true := by decide
def e2405977032118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405977032118 : Closed e2405977032118 ∧ code e2405977032118 = 11202070054326 := by decide
theorem cert_e2405977032118 : check e2405977032118 [[]] .width = true := by decide
def e2405977032122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405977032122 : Closed e2405977032122 ∧ code e2405977032122 = 11202070054330 := by decide
theorem cert_e2405977032122 : check e2405977032122 [[]] .width = true := by decide
def e2405977032150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405977032150 : Closed e2405977032150 ∧ code e2405977032150 = 11202070054358 := by decide
theorem cert_e2405977032150 : check e2405977032150 [[]] .width = true := by decide
def e2405977032154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405977032154 : Closed e2405977032154 ∧ code e2405977032154 = 11202070054362 := by decide
theorem cert_e2405977032154 : check e2405977032154 [[]] .width = true := by decide
def e2405977032170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405977032170 : Closed e2405977032170 ∧ code e2405977032170 = 11202070054378 := by decide
theorem cert_e2405977032170 : check e2405977032170 [[]] .width = true := by decide
def e2405977032206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405977032206 : Closed e2405977032206 ∧ code e2405977032206 = 11202070054414 := by decide
theorem cert_e2405977032206 : check e2405977032206 [[]] .width = true := by decide
def e2405977032218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405977032218 : Closed e2405977032218 ∧ code e2405977032218 = 11202070054426 := by decide
theorem cert_e2405977032218 : check e2405977032218 [[]] .width = true := by decide
def e2405977032290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405977032290 : Closed e2405977032290 ∧ code e2405977032290 = 11202070054498 := by decide
theorem cert_e2405977032290 : check e2405977032290 [[]] .width = true := by decide
def e2405977032302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405977032302 : Closed e2405977032302 ∧ code e2405977032302 = 11202070054510 := by decide
theorem cert_e2405977032302 : check e2405977032302 [[]] .width = true := by decide
def e2405977032310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405977032310 : Closed e2405977032310 ∧ code e2405977032310 = 11202070054518 := by decide
theorem cert_e2405977032310 : check e2405977032310 [[]] .width = true := by decide
def e2405977032314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405977032314 : Closed e2405977032314 ∧ code e2405977032314 = 11202070054522 := by decide
theorem cert_e2405977032314 : check e2405977032314 [[]] .width = true := by decide
def e2405977032502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405977032502 : Closed e2405977032502 ∧ code e2405977032502 = 11202070054710 := by decide
theorem cert_e2405977032502 : check e2405977032502 [[]] .width = true := by decide
def e2405977032506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405977032506 : Closed e2405977032506 ∧ code e2405977032506 = 11202070054714 := by decide
theorem cert_e2405977032506 : check e2405977032506 [[]] .width = true := by decide
def e2405977032602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405977032602 : Closed e2405977032602 ∧ code e2405977032602 = 11202070054810 := by decide
theorem cert_e2405977032602 : check e2405977032602 [[]] .width = true := by decide
def e2405977036202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405977036202 : Closed e2405977036202 ∧ code e2405977036202 = 11202070058410 := by decide
theorem cert_e2405977036202 : check e2405977036202 [[]] .width = true := by decide
def e2405977036298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405977036298 : Closed e2405977036298 ∧ code e2405977036298 = 11202070058506 := by decide
theorem cert_e2405977036298 : check e2405977036298 [[]] .width = true := by decide
def e2405977036342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405977036342 : Closed e2405977036342 ∧ code e2405977036342 = 11202070058550 := by decide
theorem cert_e2405977036342 : check e2405977036342 [[]] .width = true := by decide
def e2405977036346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405977036346 : Closed e2405977036346 ∧ code e2405977036346 = 11202070058554 := by decide
theorem cert_e2405977036346 : check e2405977036346 [[]] .width = true := by decide
def e2405977036394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405977036394 : Closed e2405977036394 ∧ code e2405977036394 = 11202070058602 := by decide
theorem cert_e2405977036394 : check e2405977036394 [[]] .width = true := by decide
def e2405977036418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405977036418 : Closed e2405977036418 ∧ code e2405977036418 = 11202070058626 := by decide
theorem cert_e2405977036418 : check e2405977036418 [[]] .width = true := by decide
def e2405977036430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405977036430 : Closed e2405977036430 ∧ code e2405977036430 = 11202070058638 := by decide
theorem cert_e2405977036430 : check e2405977036430 [[]] .width = true := by decide
def e2405977036442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405977036442 : Closed e2405977036442 ∧ code e2405977036442 = 11202070058650 := by decide
theorem cert_e2405977036442 : check e2405977036442 [[]] .width = true := by decide
def e2405977036486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405977036486 : Closed e2405977036486 ∧ code e2405977036486 = 11202070058694 := by decide
theorem cert_e2405977036486 : check e2405977036486 [[]] .width = true := by decide
def e2405977036566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405977036566 : Closed e2405977036566 ∧ code e2405977036566 = 11202070058774 := by decide
theorem cert_e2405977036566 : check e2405977036566 [[]] .width = true := by decide
def e2405977036570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405977036570 : Closed e2405977036570 ∧ code e2405977036570 = 11202070058778 := by decide
theorem cert_e2405977036570 : check e2405977036570 [[]] .width = true := by decide
def e2405977036614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405977036614 : Closed e2405977036614 ∧ code e2405977036614 = 11202070058822 := by decide
theorem cert_e2405977036614 : check e2405977036614 [[]] .width = true := by decide
def e2405977036642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405977036642 : Closed e2405977036642 ∧ code e2405977036642 = 11202070058850 := by decide
private def t_e2405977036642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem cert_e2405977036642 : ¬ IsSelfInterpreter e2405977036642 :=
  wSource (t := t_e2405977036642) (replay_sound (ps := []) (t := e2405977036642) (by decide)) (by decide)
def e2405977036826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405977036826 : Closed e2405977036826 ∧ code e2405977036826 = 11202070059034 := by decide
theorem cert_e2405977036826 : check e2405977036826 [[]] .width = true := by decide
def e2405977036918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405977036918 : Closed e2405977036918 ∧ code e2405977036918 = 11202070059126 := by decide
theorem cert_e2405977036918 : check e2405977036918 [[]] .width = true := by decide
def e2405977037162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405977037162 : Closed e2405977037162 ∧ code e2405977037162 = 11202070059370 := by decide
theorem cert_e2405977037162 : check e2405977037162 [[]] .width = true := by decide
def e2405977037186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405977037186 : Closed e2405977037186 ∧ code e2405977037186 = 11202070059394 := by decide
theorem cert_e2405977037186 : check e2405977037186 [[]] .width = true := by decide
def e2405977037198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405977037198 : Closed e2405977037198 ∧ code e2405977037198 = 11202070059406 := by decide
theorem cert_e2405977037198 : check e2405977037198 [[]] .width = true := by decide
def e2405977037210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405977037210 : Closed e2405977037210 ∧ code e2405977037210 = 11202070059418 := by decide
theorem cert_e2405977037210 : check e2405977037210 [[]] .width = true := by decide
def e2405977037254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405977037254 : Closed e2405977037254 ∧ code e2405977037254 = 11202070059462 := by decide
theorem cert_e2405977037254 : check e2405977037254 [[]] .width = true := by decide
def e2405977037854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405977037854 : Closed e2405977037854 ∧ code e2405977037854 = 11202070060062 := by decide
theorem cert_e2405977037854 : check e2405977037854 [[]] .width = true := by decide
def e2405977038022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405977038022 : Closed e2405977038022 ∧ code e2405977038022 = 11202070060230 := by decide
theorem cert_e2405977038022 : check e2405977038022 [[]] .width = true := by decide
def e2405977038050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405977038050 : Closed e2405977038050 ∧ code e2405977038050 = 11202070060258 := by decide
theorem cert_e2405977038050 : check e2405977038050 [[]] .width = true := by decide
def e2405977052714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405977052714 : Closed e2405977052714 ∧ code e2405977052714 = 11202070074922 := by decide
theorem cert_e2405977052714 : check e2405977052714 [[]] .width = true := by decide
def e2405977052810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405977052810 : Closed e2405977052810 ∧ code e2405977052810 = 11202070075018 := by decide
private def t_e2405977052810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem cert_e2405977052810 : ¬ IsSelfInterpreter e2405977052810 :=
  wSource (t := t_e2405977052810) (replay_sound (ps := []) (t := e2405977052810) (by decide)) (by decide)
def e2405977052834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405977052834 : Closed e2405977052834 ∧ code e2405977052834 = 11202070075042 := by decide
private def t_e2405977052834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405977052834 : ¬ IsSelfInterpreter e2405977052834 :=
  wSource (t := t_e2405977052834) (replay_sound (ps := []) (t := e2405977052834) (by decide)) (by decide)
def e2405977053194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405977053194 : Closed e2405977053194 ∧ code e2405977053194 = 11202070075402 := by decide
theorem cert_e2405977053194 : check e2405977053194 [[]] .width = true := by decide
def e2405977053242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405977053242 : Closed e2405977053242 ∧ code e2405977053242 = 11202070075450 := by decide
theorem cert_e2405977053242 : check e2405977053242 [[]] .width = true := by decide
def e2405977053290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405977053290 : Closed e2405977053290 ∧ code e2405977053290 = 11202070075498 := by decide
private def t_e2405977053290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem cert_e2405977053290 : ¬ IsSelfInterpreter e2405977053290 :=
  wSource (t := t_e2405977053290) (replay_sound (ps := []) (t := e2405977053290) (by decide)) (by decide)
def e2405977053338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405977053338 : Closed e2405977053338 ∧ code e2405977053338 = 11202070075546 := by decide
theorem cert_e2405977053338 : check e2405977053338 [[]] .width = true := by decide
def e2405977053382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405977053382 : Closed e2405977053382 ∧ code e2405977053382 = 11202070075590 := by decide
theorem cert_e2405977053382 : check e2405977053382 [[]] .width = true := by decide
def e2405977053578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405977053578 : Closed e2405977053578 ∧ code e2405977053578 = 11202070075786 := by decide
theorem cert_e2405977053578 : check e2405977053578 [[]] .width = true := by decide
def e2405977053602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405977053602 : Closed e2405977053602 ∧ code e2405977053602 = 11202070075810 := by decide
private def t_e2405977053602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem cert_e2405977053602 : ¬ IsSelfInterpreter e2405977053602 :=
  wSource (t := t_e2405977053602) (replay_sound (ps := []) (t := e2405977053602) (by decide)) (by decide)
def e2405977053698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405977053698 : Closed e2405977053698 ∧ code e2405977053698 = 11202070075906 := by decide
private def t_e2405977053698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem cert_e2405977053698 : ¬ IsSelfInterpreter e2405977053698 :=
  wSource (t := t_e2405977053698) (replay_sound (ps := []) (t := e2405977053698) (by decide)) (by decide)
def e2405977053710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405977053710 : Closed e2405977053710 ∧ code e2405977053710 = 11202070075918 := by decide
private def t_e2405977053710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem cert_e2405977053710 : ¬ IsSelfInterpreter e2405977053710 :=
  wSource (t := t_e2405977053710) (replay_sound (ps := []) (t := e2405977053710) (by decide)) (by decide)
def e2405977053722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405977053722 : Closed e2405977053722 ∧ code e2405977053722 = 11202070075930 := by decide
private def t_e2405977053722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405977053722 : ¬ IsSelfInterpreter e2405977053722 :=
  wSource (t := t_e2405977053722) (replay_sound (ps := []) (t := e2405977053722) (by decide)) (by decide)
def e2405977053794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405977053794 : Closed e2405977053794 ∧ code e2405977053794 = 11202070076002 := by decide
private def t_e2405977053794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem cert_e2405977053794 : ¬ IsSelfInterpreter e2405977053794 :=
  wSource (t := t_e2405977053794) (replay_sound (ps := []) (t := e2405977053794) (by decide)) (by decide)
def e2405977055258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405977055258 : Closed e2405977055258 ∧ code e2405977055258 = 11202070077466 := by decide
theorem cert_e2405977055258 : check e2405977055258 [[]] .width = true := by decide
def e2405977055342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405977055342 : Closed e2405977055342 ∧ code e2405977055342 = 11202070077550 := by decide
theorem cert_e2405977055342 : check e2405977055342 [[]] .width = true := by decide
def e2405977055350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405977055350 : Closed e2405977055350 ∧ code e2405977055350 = 11202070077558 := by decide
private def t_e2405977055350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem cert_e2405977055350 : ¬ IsSelfInterpreter e2405977055350 :=
  wSource (t := t_e2405977055350) (replay_sound (ps := []) (t := e2405977055350) (by decide)) (by decide)
def e2405977055354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405977055354 : Closed e2405977055354 ∧ code e2405977055354 = 11202070077562 := by decide
theorem cert_e2405977055354 : check e2405977055354 [[]] .width = true := by decide
def e2405977055594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405977055594 : Closed e2405977055594 ∧ code e2405977055594 = 11202070077802 := by decide
private def t_e2405977055594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem cert_e2405977055594 : ¬ IsSelfInterpreter e2405977055594 :=
  wSource (t := t_e2405977055594) (replay_sound (ps := []) (t := e2405977055594) (by decide)) (by decide)
def e2405977055630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405977055630 : Closed e2405977055630 ∧ code e2405977055630 = 11202070077838 := by decide
theorem cert_e2405977055630 : check e2405977055630 [[]] .width = true := by decide
def e2405977055642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405977055642 : Closed e2405977055642 ∧ code e2405977055642 = 11202070077850 := by decide
private def t_e2405977055642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem cert_e2405977055642 : ¬ IsSelfInterpreter e2405977055642 :=
  wSource (t := t_e2405977055642) (replay_sound (ps := []) (t := e2405977055642) (by decide)) (by decide)
def e2405977055686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405977055686 : Closed e2405977055686 ∧ code e2405977055686 = 11202070077894 := by decide
theorem cert_e2405977055686 : check e2405977055686 [[]] .width = true := by decide
def e2405977056650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405977056650 : Closed e2405977056650 ∧ code e2405977056650 = 11202070078858 := by decide
theorem cert_e2405977056650 : check e2405977056650 [[]] .width = true := by decide
def e2405977056674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405977056674 : Closed e2405977056674 ∧ code e2405977056674 = 11202070078882 := by decide
private def t_e2405977056674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem cert_e2405977056674 : ¬ IsSelfInterpreter e2405977056674 :=
  wSource (t := t_e2405977056674) (replay_sound (ps := []) (t := e2405977056674) (by decide)) (by decide)
def e2405977056770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405977056770 : Closed e2405977056770 ∧ code e2405977056770 = 11202070078978 := by decide
theorem cert_e2405977056770 : check e2405977056770 [[]] .width = true := by decide
def e2405977056782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405977056782 : Closed e2405977056782 ∧ code e2405977056782 = 11202070078990 := by decide
theorem cert_e2405977056782 : check e2405977056782 [[]] .width = true := by decide
def e2405977056794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405977056794 : Closed e2405977056794 ∧ code e2405977056794 = 11202070079002 := by decide
private def t_e2405977056794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem cert_e2405977056794 : ¬ IsSelfInterpreter e2405977056794 :=
  wSource (t := t_e2405977056794) (replay_sound (ps := []) (t := e2405977056794) (by decide)) (by decide)
def e2405977056866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405977056866 : Closed e2405977056866 ∧ code e2405977056866 = 11202070079074 := by decide
theorem cert_e2405977056866 : check e2405977056866 [[]] .width = true := by decide
def e2405977102850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405977102850 : Closed e2405977102850 ∧ code e2405977102850 = 11202070125058 := by decide
theorem cert_e2405977102850 : check e2405977102850 [[]] .width = true := by decide
def e2405977102874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405977102874 : Closed e2405977102874 ∧ code e2405977102874 = 11202070125082 := by decide
private def t_e2405977102874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem cert_e2405977102874 : ¬ IsSelfInterpreter e2405977102874 :=
  wSource (t := t_e2405977102874) (replay_sound (ps := []) (t := e2405977102874) (by decide)) (by decide)
def e2405977615898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977615898 : Closed e2405977615898 ∧ code e2405977615898 = 11202070638106 := by decide
private def t_e2405977615898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977615898 : ¬ IsSelfInterpreter e2405977615898 :=
  wSource (t := t_e2405977615898) (replay_sound (ps := []) (t := e2405977615898) (by decide)) (by decide)
def e2405977617946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977617946 : Closed e2405977617946 ∧ code e2405977617946 = 11202070640154 := by decide
private def t_e2405977617946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977617946 : ¬ IsSelfInterpreter e2405977617946 :=
  wSource (t := t_e2405977617946) (replay_sound (ps := []) (t := e2405977617946) (by decide)) (by decide)
def e2405977740826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977740826 : Closed e2405977740826 ∧ code e2405977740826 = 11202070763034 := by decide
private def t_e2405977740826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977740826 : ¬ IsSelfInterpreter e2405977740826 :=
  wSource (t := t_e2405977740826) (replay_sound (ps := []) (t := e2405977740826) (by decide)) (by decide)
def e2405977741850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977741850 : Closed e2405977741850 ∧ code e2405977741850 = 11202070764058 := by decide
private def t_e2405977741850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977741850 : ¬ IsSelfInterpreter e2405977741850 :=
  wSource (t := t_e2405977741850) (replay_sound (ps := []) (t := e2405977741850) (by decide)) (by decide)
def e2405977745946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977745946 : Closed e2405977745946 ∧ code e2405977745946 = 11202070768154 := by decide
private def t_e2405977745946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977745946 : ¬ IsSelfInterpreter e2405977745946 :=
  wSource (t := t_e2405977745946) (replay_sound (ps := []) (t := e2405977745946) (by decide)) (by decide)
def e2405977765402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977765402 : Closed e2405977765402 ∧ code e2405977765402 = 11202070787610 := by decide
private def t_e2405977765402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977765402 : ¬ IsSelfInterpreter e2405977765402 :=
  wSource (t := t_e2405977765402) (replay_sound (ps := []) (t := e2405977765402) (by decide)) (by decide)
def e2405977766426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977766426 : Closed e2405977766426 ∧ code e2405977766426 = 11202070788634 := by decide
private def t_e2405977766426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977766426 : ¬ IsSelfInterpreter e2405977766426 :=
  wSource (t := t_e2405977766426) (replay_sound (ps := []) (t := e2405977766426) (by decide)) (by decide)
def e2405977776154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405977776154 : Closed e2405977776154 ∧ code e2405977776154 = 11202070798362 := by decide
theorem cert_e2405977776154 : check e2405977776154 [[]] .width = true := by decide
def e2405977776246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405977776246 : Closed e2405977776246 ∧ code e2405977776246 = 11202070798454 := by decide
private def t_e2405977776246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405977776246 : ¬ IsSelfInterpreter e2405977776246 :=
  wSource (t := t_e2405977776246) (replay_sound (ps := []) (t := e2405977776246) (by decide)) (by decide)
def e2405977776490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405977776490 : Closed e2405977776490 ∧ code e2405977776490 = 11202070798698 := by decide
private def t_e2405977776490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405977776490 : ¬ IsSelfInterpreter e2405977776490 :=
  wSource (t := t_e2405977776490) (replay_sound (ps := []) (t := e2405977776490) (by decide)) (by decide)
def e2405977776538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405977776538 : Closed e2405977776538 ∧ code e2405977776538 = 11202070798746 := by decide
private def t_e2405977776538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405977776538 : ¬ IsSelfInterpreter e2405977776538 :=
  wSource (t := t_e2405977776538) (replay_sound (ps := []) (t := e2405977776538) (by decide)) (by decide)
def e2405977791002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405977791002 : Closed e2405977791002 ∧ code e2405977791002 = 11202070813210 := by decide
private def t_e2405977791002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405977791002 : ¬ IsSelfInterpreter e2405977791002 :=
  wSource (t := t_e2405977791002) (replay_sound (ps := []) (t := e2405977791002) (by decide)) (by decide)
def e2405977792538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405977792538 : Closed e2405977792538 ∧ code e2405977792538 = 11202070814746 := by decide
theorem cert_e2405977792538 : check e2405977792538 [[]] .width = true := by decide
def e2405977792630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405977792630 : Closed e2405977792630 ∧ code e2405977792630 = 11202070814838 := by decide
private def t_e2405977792630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405977792630 : ¬ IsSelfInterpreter e2405977792630 :=
  wSource (t := t_e2405977792630) (replay_sound (ps := []) (t := e2405977792630) (by decide)) (by decide)
def e2405977792874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405977792874 : Closed e2405977792874 ∧ code e2405977792874 = 11202070815082 := by decide
private def t_e2405977792874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405977792874 : ¬ IsSelfInterpreter e2405977792874 :=
  wSource (t := t_e2405977792874) (replay_sound (ps := []) (t := e2405977792874) (by decide)) (by decide)
def e2405977792922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405977792922 : Closed e2405977792922 ∧ code e2405977792922 = 11202070815130 := by decide
private def t_e2405977792922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405977792922 : ¬ IsSelfInterpreter e2405977792922 :=
  wSource (t := t_e2405977792922) (replay_sound (ps := []) (t := e2405977792922) (by decide)) (by decide)
def e2405998981318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405998981318 : Closed e2405998981318 ∧ code e2405998981318 = 11202092003526 := by decide
theorem cert_e2405998981318 : check e2405998981318 [[]] .width = true := by decide
def e2405999030470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405999030470 : Closed e2405999030470 ∧ code e2405999030470 = 11202092052678 := by decide
theorem cert_e2405999030470 : check e2405999030470 [[]] .width = true := by decide
def e2405999243462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405999243462 : Closed e2405999243462 ∧ code e2405999243462 = 11202092265670 := by decide
theorem cert_e2405999243462 : check e2405999243462 [[]] .width = true := by decide
def e2405999300806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405999300806 : Closed e2405999300806 ∧ code e2405999300806 = 11202092323014 := by decide
theorem cert_e2405999300806 : check e2405999300806 [[]] .width = true := by decide
def e2405999489222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405999489222 : Closed e2405999489222 ∧ code e2405999489222 = 11202092511430 := by decide
theorem cert_e2405999489222 : check e2405999489222 [[]] .width = true := by decide
def e2405999497414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405999497414 : Closed e2405999497414 ∧ code e2405999497414 = 11202092519622 := by decide
theorem cert_e2405999497414 : check e2405999497414 [[]] .width = true := by decide
def e2406000554182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406000554182 : Closed e2406000554182 ∧ code e2406000554182 = 11202093576390 := by decide
theorem cert_e2406000554182 : check e2406000554182 [[]] .width = true := by decide
def e2406000603334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406000603334 : Closed e2406000603334 ∧ code e2406000603334 = 11202093625542 := by decide
theorem cert_e2406000603334 : check e2406000603334 [[]] .width = true := by decide
def e2406002127046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406002127046 : Closed e2406002127046 ∧ code e2406002127046 = 11202095149254 := by decide
theorem cert_e2406002127046 : check e2406002127046 [[]] .width = true := by decide
def e2406002184390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406002184390 : Closed e2406002184390 ∧ code e2406002184390 = 11202095206598 := by decide
theorem cert_e2406002184390 : check e2406002184390 [[]] .width = true := by decide
def e2406003212314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406003212314 : Closed e2406003212314 ∧ code e2406003212314 = 11202096234522 := by decide
theorem cert_e2406003212314 : check e2406003212314 [[]] .width = true := by decide
def e2406003212406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406003212406 : Closed e2406003212406 ∧ code e2406003212406 = 11202096234614 := by decide
theorem cert_e2406003212406 : check e2406003212406 [[]] .width = true := by decide
def e2406003212650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406003212650 : Closed e2406003212650 ∧ code e2406003212650 = 11202096234858 := by decide
theorem cert_e2406003212650 : check e2406003212650 [[]] .width = true := by decide
def e2406003212698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406003212698 : Closed e2406003212698 ∧ code e2406003212698 = 11202096234906 := by decide
theorem cert_e2406003212698 : check e2406003212698 [[]] .width = true := by decide
def e2406003213706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406003213706 : Closed e2406003213706 ∧ code e2406003213706 = 11202096235914 := by decide
theorem cert_e2406003213706 : check e2406003213706 [[]] .width = true := by decide
def e2406003213730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406003213730 : Closed e2406003213730 ∧ code e2406003213730 = 11202096235938 := by decide
theorem cert_e2406003213730 : check e2406003213730 [[]] .width = true := by decide
def e2406003213838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406003213838 : Closed e2406003213838 ∧ code e2406003213838 = 11202096236046 := by decide
theorem cert_e2406003213838 : check e2406003213838 [[]] .width = true := by decide
def e2406003213850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406003213850 : Closed e2406003213850 ∧ code e2406003213850 = 11202096236058 := by decide
theorem cert_e2406003213850 : check e2406003213850 [[]] .width = true := by decide
def e2406003213922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406003213922 : Closed e2406003213922 ∧ code e2406003213922 = 11202096236130 := by decide
theorem cert_e2406003213922 : check e2406003213922 [[]] .width = true := by decide
def e2406003306694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406003306694 : Closed e2406003306694 ∧ code e2406003306694 = 11202096328902 := by decide
theorem cert_e2406003306694 : check e2406003306694 [[]] .width = true := by decide
def e2406003355846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406003355846 : Closed e2406003355846 ∧ code e2406003355846 = 11202096378054 := by decide
theorem cert_e2406003355846 : check e2406003355846 [[]] .width = true := by decide
def e2406003364038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406003364038 : Closed e2406003364038 ∧ code e2406003364038 = 11202096386246 := by decide
theorem cert_e2406003364038 : check e2406003364038 [[]] .width = true := by decide
def e2406003474458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406003474458 : Closed e2406003474458 ∧ code e2406003474458 = 11202096496666 := by decide
theorem cert_e2406003474458 : check e2406003474458 [[]] .width = true := by decide
def e2406003474550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406003474550 : Closed e2406003474550 ∧ code e2406003474550 = 11202096496758 := by decide
theorem cert_e2406003474550 : check e2406003474550 [[]] .width = true := by decide
def e2406003474794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406003474794 : Closed e2406003474794 ∧ code e2406003474794 = 11202096497002 := by decide
theorem cert_e2406003474794 : check e2406003474794 [[]] .width = true := by decide
def e2406003474842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406003474842 : Closed e2406003474842 ∧ code e2406003474842 = 11202096497050 := by decide
theorem cert_e2406003474842 : check e2406003474842 [[]] .width = true := by decide
def e2406003475850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406003475850 : Closed e2406003475850 ∧ code e2406003475850 = 11202096498058 := by decide
theorem cert_e2406003475850 : check e2406003475850 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405976705862
#print axioms Blc.Floor43.cert_e2405976706102
#print axioms Blc.Floor43.cert_e2405976706106
#print axioms Blc.Floor43.cert_e2405976878618
#print axioms Blc.Floor43.cert_e2405976881690
#print axioms Blc.Floor43.cert_e2405976893978
#print axioms Blc.Floor43.cert_e2405976907894
#print axioms Blc.Floor43.cert_e2405976908138
#print axioms Blc.Floor43.cert_e2405976908186
#print axioms Blc.Floor43.cert_e2405976927770
#print axioms Blc.Floor43.cert_e2405976930842
#print axioms Blc.Floor43.cert_e2405976933794
#print axioms Blc.Floor43.cert_e2405976933914
#print axioms Blc.Floor43.cert_e2405976957046
#print axioms Blc.Floor43.cert_e2405976957290
#print axioms Blc.Floor43.cert_e2405976957338
#print axioms Blc.Floor43.cert_e2405977004570
#print axioms Blc.Floor43.cert_e2405977006198
#print axioms Blc.Floor43.cert_e2405977006442
#print axioms Blc.Floor43.cert_e2405977006490
#print axioms Blc.Floor43.cert_e2405977036642
#print axioms Blc.Floor43.cert_e2405977052810
#print axioms Blc.Floor43.cert_e2405977052834
#print axioms Blc.Floor43.cert_e2405977053290
#print axioms Blc.Floor43.cert_e2405977053602
#print axioms Blc.Floor43.cert_e2405977053698
#print axioms Blc.Floor43.cert_e2405977053710
#print axioms Blc.Floor43.cert_e2405977053722
#print axioms Blc.Floor43.cert_e2405977053794
#print axioms Blc.Floor43.cert_e2405977055350
#print axioms Blc.Floor43.cert_e2405977055594
#print axioms Blc.Floor43.cert_e2405977055642
#print axioms Blc.Floor43.cert_e2405977056674
#print axioms Blc.Floor43.cert_e2405977056794
#print axioms Blc.Floor43.cert_e2405977102874
#print axioms Blc.Floor43.cert_e2405977615898
#print axioms Blc.Floor43.cert_e2405977617946
#print axioms Blc.Floor43.cert_e2405977740826
#print axioms Blc.Floor43.cert_e2405977741850
#print axioms Blc.Floor43.cert_e2405977745946
#print axioms Blc.Floor43.cert_e2405977765402
#print axioms Blc.Floor43.cert_e2405977766426
#print axioms Blc.Floor43.cert_e2405977776246
#print axioms Blc.Floor43.cert_e2405977776490
#print axioms Blc.Floor43.cert_e2405977776538
#print axioms Blc.Floor43.cert_e2405977791002
#print axioms Blc.Floor43.cert_e2405977792630
#print axioms Blc.Floor43.cert_e2405977792874
#print axioms Blc.Floor43.cert_e2405977792922
