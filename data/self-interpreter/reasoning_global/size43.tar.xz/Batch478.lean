import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407304878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2))))))
theorem wire_e2422407304878 : Closed e2422407304878 ∧ code e2422407304878 = 11218500327086 := by decide
theorem cert_e2422407304878 : check e2422407304878 [[],[]] .sourceHead = true := by decide
def e2422407305454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422407305454 : Closed e2422407305454 ∧ code e2422407305454 = 11218500327662 := by decide
theorem cert_e2422407305454 : check e2422407305454 [[],[]] .chain = true := by decide
def e2422407305466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407305466 : Closed e2422407305466 ∧ code e2422407305466 = 11218500327674 := by decide
theorem cert_e2422407305466 : check e2422407305466 [[],[]] .chain = true := by decide
def e2422407305646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422407305646 : Closed e2422407305646 ∧ code e2422407305646 = 11218500327854 := by decide
theorem cert_e2422407305646 : check e2422407305646 [[],[]] .sourceHead = true := by decide
def e2422407305838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407305838 : Closed e2422407305838 ∧ code e2422407305838 = 11218500328046 := by decide
theorem cert_e2422407305838 : check e2422407305838 [[],[]] .sourceHead = true := by decide
def e2422407305850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407305850 : Closed e2422407305850 ∧ code e2422407305850 = 11218500328058 := by decide
theorem cert_e2422407305850 : check e2422407305850 [[],[]] .sourceHead = true := by decide
def e2422407306014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422407306014 : Closed e2422407306014 ∧ code e2422407306014 = 11218500328222 := by decide
theorem cert_e2422407306014 : check e2422407306014 [[],[]] .chain = true := by decide
def e2422407306182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407306182 : Closed e2422407306182 ∧ code e2422407306182 = 11218500328390 := by decide
theorem cert_e2422407306182 : check e2422407306182 [[],[]] .chain = true := by decide
def e2422407306350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407306350 : Closed e2422407306350 ∧ code e2422407306350 = 11218500328558 := by decide
theorem cert_e2422407306350 : check e2422407306350 [[],[]] .chain = true := by decide
def e2422407306526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407306526 : Closed e2422407306526 ∧ code e2422407306526 = 11218500328734 := by decide
theorem cert_e2422407306526 : check e2422407306526 [[],[]] .chain = true := by decide
def e2422407306722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422407306722 : Closed e2422407306722 ∧ code e2422407306722 = 11218500328930 := by decide
theorem cert_e2422407306722 : check e2422407306722 [[],[]] .chain = true := by decide
def e2422407306734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e2422407306734 : Closed e2422407306734 ∧ code e2422407306734 = 11218500328942 := by decide
theorem cert_e2422407306734 : check e2422407306734 [[],[]] .sourceHead = true := by decide
def e2422407306798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407306798 : Closed e2422407306798 ∧ code e2422407306798 = 11218500329006 := by decide
theorem cert_e2422407306798 : check e2422407306798 [[],[]] .chain = true := by decide
def e2422407306990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 2)))) (.var 2))))))
theorem wire_e2422407306990 : Closed e2422407306990 ∧ code e2422407306990 = 11218500329198 := by decide
theorem cert_e2422407306990 : check e2422407306990 [[],[]] .chain = true := by decide
def e2422407306998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 1))))))
theorem wire_e2422407306998 : Closed e2422407306998 ∧ code e2422407306998 = 11218500329206 := by decide
theorem cert_e2422407306998 : check e2422407306998 [[],[]] .chain = true := by decide
def e2422407307030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407307030 : Closed e2422407307030 ∧ code e2422407307030 = 11218500329238 := by decide
theorem cert_e2422407307030 : check e2422407307030 [[],[]] .chain = true := by decide
def e2422407307034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407307034 : Closed e2422407307034 ∧ code e2422407307034 = 11218500329242 := by decide
theorem cert_e2422407307034 : check e2422407307034 [[],[]] .chain = true := by decide
def e2422407307078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407307078 : Closed e2422407307078 ∧ code e2422407307078 = 11218500329286 := by decide
theorem cert_e2422407307078 : check e2422407307078 [[],[]] .chain = true := by decide
def e2422407307106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407307106 : Closed e2422407307106 ∧ code e2422407307106 = 11218500329314 := by decide
theorem cert_e2422407307106 : check e2422407307106 [[],[]] .chain = true := by decide
def e2422407307118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e2422407307118 : Closed e2422407307118 ∧ code e2422407307118 = 11218500329326 := by decide
theorem cert_e2422407307118 : check e2422407307118 [[],[]] .sourceHead = true := by decide
def e2422407307126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 1))))))
theorem wire_e2422407307126 : Closed e2422407307126 ∧ code e2422407307126 = 11218500329334 := by decide
theorem cert_e2422407307126 : check e2422407307126 [[],[]] .chain = true := by decide
def e2422407307130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e2422407307130 : Closed e2422407307130 ∧ code e2422407307130 = 11218500329338 := by decide
theorem cert_e2422407307130 : check e2422407307130 [[],[]] .sourceHead = true := by decide
def e2422407307742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407307742 : Closed e2422407307742 ∧ code e2422407307742 = 11218500329950 := by decide
theorem cert_e2422407307742 : check e2422407307742 [[],[]] .chain = true := by decide
def e2422407307766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407307766 : Closed e2422407307766 ∧ code e2422407307766 = 11218500329974 := by decide
theorem cert_e2422407307766 : check e2422407307766 [[],[]] .chain = true := by decide
def e2422407308718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407308718 : Closed e2422407308718 ∧ code e2422407308718 = 11218500330926 := by decide
theorem cert_e2422407308718 : check e2422407308718 [[],[]] .chain = true := by decide
def e2422407308730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407308730 : Closed e2422407308730 ∧ code e2422407308730 = 11218500330938 := by decide
theorem cert_e2422407308730 : check e2422407308730 [[],[]] .chain = true := by decide
def e2422407308778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407308778 : Closed e2422407308778 ∧ code e2422407308778 = 11218500330986 := by decide
theorem cert_e2422407308778 : check e2422407308778 [[],[]] .chain = true := by decide
def e2422407308910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407308910 : Closed e2422407308910 ∧ code e2422407308910 = 11218500331118 := by decide
theorem cert_e2422407308910 : check e2422407308910 [[],[]] .chain = true := by decide
def e2422407308922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407308922 : Closed e2422407308922 ∧ code e2422407308922 = 11218500331130 := by decide
theorem cert_e2422407308922 : check e2422407308922 [[],[]] .chain = true := by decide
def e2422407309086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407309086 : Closed e2422407309086 ∧ code e2422407309086 = 11218500331294 := by decide
theorem cert_e2422407309086 : check e2422407309086 [[],[]] .chain = true := by decide
def e2422407309198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407309198 : Closed e2422407309198 ∧ code e2422407309198 = 11218500331406 := by decide
theorem cert_e2422407309198 : check e2422407309198 [[],[]] .chain = true := by decide
def e2422407309210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407309210 : Closed e2422407309210 ∧ code e2422407309210 = 11218500331418 := by decide
theorem cert_e2422407309210 : check e2422407309210 [[],[]] .chain = true := by decide
def e2422407311582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422407311582 : Closed e2422407311582 ∧ code e2422407311582 = 11218500333790 := by decide
theorem cert_e2422407311582 : check e2422407311582 [[],[]] .chain = true := by decide
def e2422407311610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422407311610 : Closed e2422407311610 ∧ code e2422407311610 = 11218500333818 := by decide
theorem cert_e2422407311610 : check e2422407311610 [[],[]] .chain = true := by decide
def e2422407312158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407312158 : Closed e2422407312158 ∧ code e2422407312158 = 11218500334366 := by decide
theorem cert_e2422407312158 : check e2422407312158 [[],[]] .chain = true := by decide
def e2422407312326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407312326 : Closed e2422407312326 ∧ code e2422407312326 = 11218500334534 := by decide
theorem cert_e2422407312326 : check e2422407312326 [[],[]] .chain = true := by decide
def e2422407313470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407313470 : Closed e2422407313470 ∧ code e2422407313470 = 11218500335678 := by decide
theorem cert_e2422407313470 : check e2422407313470 [[],[]] .chain = true := by decide
def e2422407313890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407313890 : Closed e2422407313890 ∧ code e2422407313890 = 11218500336098 := by decide
theorem cert_e2422407313890 : check e2422407313890 [[],[]] .chain = true := by decide
def e2422407313902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407313902 : Closed e2422407313902 ∧ code e2422407313902 = 11218500336110 := by decide
theorem cert_e2422407313902 : check e2422407313902 [[],[]] .sourceHead = true := by decide
def e2422407314462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407314462 : Closed e2422407314462 ∧ code e2422407314462 = 11218500336670 := by decide
theorem cert_e2422407314462 : check e2422407314462 [[],[]] .chain = true := by decide
def e2422407314486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407314486 : Closed e2422407314486 ∧ code e2422407314486 = 11218500336694 := by decide
theorem cert_e2422407314486 : check e2422407314486 [[],[]] .chain = true := by decide
def e2422407314490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407314490 : Closed e2422407314490 ∧ code e2422407314490 = 11218500336698 := by decide
theorem cert_e2422407314490 : check e2422407314490 [[],[]] .chain = true := by decide
def e2422407314630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407314630 : Closed e2422407314630 ∧ code e2422407314630 = 11218500336838 := by decide
theorem cert_e2422407314630 : check e2422407314630 [[],[]] .chain = true := by decide
def e2422407314658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407314658 : Closed e2422407314658 ∧ code e2422407314658 = 11218500336866 := by decide
theorem cert_e2422407314658 : check e2422407314658 [[],[]] .chain = true := by decide
def e2422407314670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407314670 : Closed e2422407314670 ∧ code e2422407314670 = 11218500336878 := by decide
theorem cert_e2422407314670 : check e2422407314670 [[],[]] .sourceHead = true := by decide
def e2422407314678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407314678 : Closed e2422407314678 ∧ code e2422407314678 = 11218500336886 := by decide
theorem cert_e2422407314678 : check e2422407314678 [[],[]] .sourceHead = true := by decide
def e2422407321774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422407321774 : Closed e2422407321774 ∧ code e2422407321774 = 11218500343982 := by decide
theorem cert_e2422407321774 : check e2422407321774 [[],[]] .chain = true := by decide
def e2422407321786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422407321786 : Closed e2422407321786 ∧ code e2422407321786 = 11218500343994 := by decide
theorem cert_e2422407321786 : check e2422407321786 [[],[]] .chain = true := by decide
def e2422407322158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407322158 : Closed e2422407322158 ∧ code e2422407322158 = 11218500344366 := by decide
theorem cert_e2422407322158 : check e2422407322158 [[],[]] .chain = true := by decide
def e2422407322338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407322338 : Closed e2422407322338 ∧ code e2422407322338 = 11218500344546 := by decide
theorem cert_e2422407322338 : check e2422407322338 [[],[]] .chain = true := by decide
def e2422407322350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2422407322350 : Closed e2422407322350 ∧ code e2422407322350 = 11218500344558 := by decide
theorem cert_e2422407322350 : check e2422407322350 [[],[]] .sourceHead = true := by decide
def e2422407322478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2422407322478 : Closed e2422407322478 ∧ code e2422407322478 = 11218500344686 := by decide
theorem cert_e2422407322478 : check e2422407322478 [[],[]] .chain = true := by decide
def e2422407322486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2422407322486 : Closed e2422407322486 ∧ code e2422407322486 = 11218500344694 := by decide
theorem cert_e2422407322486 : check e2422407322486 [[],[]] .chain = true := by decide
def e2422407322506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407322506 : Closed e2422407322506 ∧ code e2422407322506 = 11218500344714 := by decide
theorem cert_e2422407322506 : check e2422407322506 [[],[]] .chain = true := by decide
def e2422407322530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407322530 : Closed e2422407322530 ∧ code e2422407322530 = 11218500344738 := by decide
theorem cert_e2422407322530 : check e2422407322530 [[],[]] .chain = true := by decide
def e2422407322542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2422407322542 : Closed e2422407322542 ∧ code e2422407322542 = 11218500344750 := by decide
theorem cert_e2422407322542 : check e2422407322542 [[],[]] .sourceHead = true := by decide
def e2422407322550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2422407322550 : Closed e2422407322550 ∧ code e2422407322550 = 11218500344758 := by decide
theorem cert_e2422407322550 : check e2422407322550 [[],[]] .chain = true := by decide
def e2422407322554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2422407322554 : Closed e2422407322554 ∧ code e2422407322554 = 11218500344762 := by decide
theorem cert_e2422407322554 : check e2422407322554 [[],[]] .sourceHead = true := by decide
def e2422407322990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422407322990 : Closed e2422407322990 ∧ code e2422407322990 = 11218500345198 := by decide
theorem cert_e2422407322990 : check e2422407322990 [[],[]] .chain = true := by decide
def e2422407322998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422407322998 : Closed e2422407322998 ∧ code e2422407322998 = 11218500345206 := by decide
theorem cert_e2422407322998 : check e2422407322998 [[],[]] .chain = true := by decide
def e2422407323054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422407323054 : Closed e2422407323054 ∧ code e2422407323054 = 11218500345262 := by decide
theorem cert_e2422407323054 : check e2422407323054 [[],[]] .chain = true := by decide
def e2422407323066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422407323066 : Closed e2422407323066 ∧ code e2422407323066 = 11218500345274 := by decide
theorem cert_e2422407323066 : check e2422407323066 [[],[]] .chain = true := by decide
def e2422407323094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422407323094 : Closed e2422407323094 ∧ code e2422407323094 = 11218500345302 := by decide
theorem cert_e2422407323094 : check e2422407323094 [[],[]] .chain = true := by decide
def e2422407323098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422407323098 : Closed e2422407323098 ∧ code e2422407323098 = 11218500345306 := by decide
theorem cert_e2422407323098 : check e2422407323098 [[],[]] .chain = true := by decide
def e2422407323178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407323178 : Closed e2422407323178 ∧ code e2422407323178 = 11218500345386 := by decide
theorem cert_e2422407323178 : check e2422407323178 [[],[]] .chain = true := by decide
def e2422407323274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407323274 : Closed e2422407323274 ∧ code e2422407323274 = 11218500345482 := by decide
theorem cert_e2422407323274 : check e2422407323274 [[],[]] .chain = true := by decide
def e2422407323298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407323298 : Closed e2422407323298 ∧ code e2422407323298 = 11218500345506 := by decide
theorem cert_e2422407323298 : check e2422407323298 [[],[]] .chain = true := by decide
def e2422407323310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407323310 : Closed e2422407323310 ∧ code e2422407323310 = 11218500345518 := by decide
theorem cert_e2422407323310 : check e2422407323310 [[],[]] .sourceHead = true := by decide
def e2422407323318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407323318 : Closed e2422407323318 ∧ code e2422407323318 = 11218500345526 := by decide
theorem cert_e2422407323318 : check e2422407323318 [[],[]] .chain = true := by decide
def e2422407323322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407323322 : Closed e2422407323322 ∧ code e2422407323322 = 11218500345530 := by decide
theorem cert_e2422407323322 : check e2422407323322 [[],[]] .sourceHead = true := by decide
def e2422407323350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407323350 : Closed e2422407323350 ∧ code e2422407323350 = 11218500345558 := by decide
theorem cert_e2422407323350 : check e2422407323350 [[],[]] .chain = true := by decide
def e2422407323354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407323354 : Closed e2422407323354 ∧ code e2422407323354 = 11218500345562 := by decide
theorem cert_e2422407323354 : check e2422407323354 [[],[]] .chain = true := by decide
def e2422407323370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407323370 : Closed e2422407323370 ∧ code e2422407323370 = 11218500345578 := by decide
theorem cert_e2422407323370 : check e2422407323370 [[],[]] .sourceHead = true := by decide
def e2422407323694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422407323694 : Closed e2422407323694 ∧ code e2422407323694 = 11218500345902 := by decide
theorem cert_e2422407323694 : check e2422407323694 [[],[]] .chain = true := by decide
def e2422407323886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2422407323886 : Closed e2422407323886 ∧ code e2422407323886 = 11218500346094 := by decide
theorem cert_e2422407323886 : check e2422407323886 [[],[]] .chain = true := by decide
def e2422407323898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407323898 : Closed e2422407323898 ∧ code e2422407323898 = 11218500346106 := by decide
theorem cert_e2422407323898 : check e2422407323898 [[],[]] .chain = true := by decide
def e2422407324078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2422407324078 : Closed e2422407324078 ∧ code e2422407324078 = 11218500346286 := by decide
theorem cert_e2422407324078 : check e2422407324078 [[],[]] .sourceHead = true := by decide
def e2422407324270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407324270 : Closed e2422407324270 ∧ code e2422407324270 = 11218500346478 := by decide
theorem cert_e2422407324270 : check e2422407324270 [[],[]] .chain = true := by decide
def e2422407324282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407324282 : Closed e2422407324282 ∧ code e2422407324282 = 11218500346490 := by decide
theorem cert_e2422407324282 : check e2422407324282 [[],[]] .chain = true := by decide
def e2422407324446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2422407324446 : Closed e2422407324446 ∧ code e2422407324446 = 11218500346654 := by decide
theorem cert_e2422407324446 : check e2422407324446 [[],[]] .chain = true := by decide
def e2422407324614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407324614 : Closed e2422407324614 ∧ code e2422407324614 = 11218500346822 := by decide
theorem cert_e2422407324614 : check e2422407324614 [[],[]] .chain = true := by decide
def e2422407325230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407325230 : Closed e2422407325230 ∧ code e2422407325230 = 11218500347438 := by decide
theorem cert_e2422407325230 : check e2422407325230 [[],[]] .chain = true := by decide
def e2422407325410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407325410 : Closed e2422407325410 ∧ code e2422407325410 = 11218500347618 := by decide
theorem cert_e2422407325410 : check e2422407325410 [[],[]] .chain = true := by decide
def e2422407325422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2422407325422 : Closed e2422407325422 ∧ code e2422407325422 = 11218500347630 := by decide
theorem cert_e2422407325422 : check e2422407325422 [[],[]] .sourceHead = true := by decide
def e2422407325550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422407325550 : Closed e2422407325550 ∧ code e2422407325550 = 11218500347758 := by decide
theorem cert_e2422407325550 : check e2422407325550 [[],[]] .chain = true := by decide
def e2422407325558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422407325558 : Closed e2422407325558 ∧ code e2422407325558 = 11218500347766 := by decide
theorem cert_e2422407325558 : check e2422407325558 [[],[]] .chain = true := by decide
def e2422407325578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407325578 : Closed e2422407325578 ∧ code e2422407325578 = 11218500347786 := by decide
theorem cert_e2422407325578 : check e2422407325578 [[],[]] .chain = true := by decide
def e2422407325602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407325602 : Closed e2422407325602 ∧ code e2422407325602 = 11218500347810 := by decide
theorem cert_e2422407325602 : check e2422407325602 [[],[]] .chain = true := by decide
def e2422407325614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2422407325614 : Closed e2422407325614 ∧ code e2422407325614 = 11218500347822 := by decide
theorem cert_e2422407325614 : check e2422407325614 [[],[]] .sourceHead = true := by decide
def e2422407325622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422407325622 : Closed e2422407325622 ∧ code e2422407325622 = 11218500347830 := by decide
theorem cert_e2422407325622 : check e2422407325622 [[],[]] .chain = true := by decide
def e2422407325626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422407325626 : Closed e2422407325626 ∧ code e2422407325626 = 11218500347834 := by decide
theorem cert_e2422407325626 : check e2422407325626 [[],[]] .sourceHead = true := by decide
def e2422407325758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407325758 : Closed e2422407325758 ∧ code e2422407325758 = 11218500347966 := by decide
theorem cert_e2422407325758 : check e2422407325758 [[],[]] .chain = true := by decide
def e2422407326178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407326178 : Closed e2422407326178 ∧ code e2422407326178 = 11218500348386 := by decide
theorem cert_e2422407326178 : check e2422407326178 [[],[]] .chain = true := by decide
def e2422407326190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407326190 : Closed e2422407326190 ∧ code e2422407326190 = 11218500348398 := by decide
theorem cert_e2422407326190 : check e2422407326190 [[],[]] .sourceHead = true := by decide
def e2422407326958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407326958 : Closed e2422407326958 ∧ code e2422407326958 = 11218500349166 := by decide
theorem cert_e2422407326958 : check e2422407326958 [[],[]] .chain = true := by decide
def e2422407326966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407326966 : Closed e2422407326966 ∧ code e2422407326966 = 11218500349174 := by decide
theorem cert_e2422407326966 : check e2422407326966 [[],[]] .chain = true := by decide
def e2422407327234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407327234 : Closed e2422407327234 ∧ code e2422407327234 = 11218500349442 := by decide
theorem cert_e2422407327234 : check e2422407327234 [[],[]] .chain = true := by decide
def e2422407327246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407327246 : Closed e2422407327246 ∧ code e2422407327246 = 11218500349454 := by decide
theorem cert_e2422407327246 : check e2422407327246 [[],[]] .chain = true := by decide
def e2422407327258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407327258 : Closed e2422407327258 ∧ code e2422407327258 = 11218500349466 := by decide
theorem cert_e2422407327258 : check e2422407327258 [[],[]] .sourceHead = true := by decide
def e2422407327330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407327330 : Closed e2422407327330 ∧ code e2422407327330 = 11218500349538 := by decide
theorem cert_e2422407327330 : check e2422407327330 [[],[]] .chain = true := by decide
def e2422407327342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407327342 : Closed e2422407327342 ∧ code e2422407327342 = 11218500349550 := by decide
theorem cert_e2422407327342 : check e2422407327342 [[],[]] .sourceHead = true := by decide
def e2422407327350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407327350 : Closed e2422407327350 ∧ code e2422407327350 = 11218500349558 := by decide
theorem cert_e2422407327350 : check e2422407327350 [[],[]] .chain = true := by decide
def e2422407327354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407327354 : Closed e2422407327354 ∧ code e2422407327354 = 11218500349562 := by decide
theorem cert_e2422407327354 : check e2422407327354 [[],[]] .sourceHead = true := by decide
def e2422407327854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407327854 : Closed e2422407327854 ∧ code e2422407327854 = 11218500350062 := by decide
theorem cert_e2422407327854 : check e2422407327854 [[],[]] .chain = true := by decide
def e2422407328030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407328030 : Closed e2422407328030 ∧ code e2422407328030 = 11218500350238 := by decide
theorem cert_e2422407328030 : check e2422407328030 [[],[]] .chain = true := by decide
def e2422407328226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422407328226 : Closed e2422407328226 ∧ code e2422407328226 = 11218500350434 := by decide
theorem cert_e2422407328226 : check e2422407328226 [[],[]] .chain = true := by decide
def e2422407328238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422407328238 : Closed e2422407328238 ∧ code e2422407328238 = 11218500350446 := by decide
theorem cert_e2422407328238 : check e2422407328238 [[],[]] .sourceHead = true := by decide
def e2422407328622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407328622 : Closed e2422407328622 ∧ code e2422407328622 = 11218500350830 := by decide
theorem cert_e2422407328622 : check e2422407328622 [[],[]] .chain = true := by decide
def e2422407328630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422407328630 : Closed e2422407328630 ∧ code e2422407328630 = 11218500350838 := by decide
theorem cert_e2422407328630 : check e2422407328630 [[],[]] .chain = true := by decide
def e2422407328686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407328686 : Closed e2422407328686 ∧ code e2422407328686 = 11218500350894 := by decide
theorem cert_e2422407328686 : check e2422407328686 [[],[]] .chain = true := by decide
def e2422407328698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407328698 : Closed e2422407328698 ∧ code e2422407328698 = 11218500350906 := by decide
theorem cert_e2422407328698 : check e2422407328698 [[],[]] .chain = true := by decide
def e2422407328726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422407328726 : Closed e2422407328726 ∧ code e2422407328726 = 11218500350934 := by decide
theorem cert_e2422407328726 : check e2422407328726 [[],[]] .chain = true := by decide
def e2422407328730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407328730 : Closed e2422407328730 ∧ code e2422407328730 = 11218500350938 := by decide
theorem cert_e2422407328730 : check e2422407328730 [[],[]] .chain = true := by decide
def e2422407329006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407329006 : Closed e2422407329006 ∧ code e2422407329006 = 11218500351214 := by decide
theorem cert_e2422407329006 : check e2422407329006 [[],[]] .chain = true := by decide
def e2422407329014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407329014 : Closed e2422407329014 ∧ code e2422407329014 = 11218500351222 := by decide
theorem cert_e2422407329014 : check e2422407329014 [[],[]] .chain = true := by decide
def e2422407329390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407329390 : Closed e2422407329390 ∧ code e2422407329390 = 11218500351598 := by decide
theorem cert_e2422407329390 : check e2422407329390 [[],[]] .chain = true := by decide
def e2422407329402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407329402 : Closed e2422407329402 ∧ code e2422407329402 = 11218500351610 := by decide
theorem cert_e2422407329402 : check e2422407329402 [[],[]] .chain = true := by decide
def e2422407329542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407329542 : Closed e2422407329542 ∧ code e2422407329542 = 11218500351750 := by decide
theorem cert_e2422407329542 : check e2422407329542 [[],[]] .chain = true := by decide
def e2422407329566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422407329566 : Closed e2422407329566 ∧ code e2422407329566 = 11218500351774 := by decide
theorem cert_e2422407329566 : check e2422407329566 [[],[]] .sourceHead = true := by decide
def e2422407329590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407329590 : Closed e2422407329590 ∧ code e2422407329590 = 11218500351798 := by decide
theorem cert_e2422407329590 : check e2422407329590 [[],[]] .chain = true := by decide
def e2422407329594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407329594 : Closed e2422407329594 ∧ code e2422407329594 = 11218500351802 := by decide
theorem cert_e2422407329594 : check e2422407329594 [[],[]] .chain = true := by decide
def e2422407329802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407329802 : Closed e2422407329802 ∧ code e2422407329802 = 11218500352010 := by decide
theorem cert_e2422407329802 : check e2422407329802 [[],[]] .chain = true := by decide
def e2422407329838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407329838 : Closed e2422407329838 ∧ code e2422407329838 = 11218500352046 := by decide
theorem cert_e2422407329838 : check e2422407329838 [[],[]] .sourceHead = true := by decide
def e2422407329846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407329846 : Closed e2422407329846 ∧ code e2422407329846 = 11218500352054 := by decide
theorem cert_e2422407329846 : check e2422407329846 [[],[]] .chain = true := by decide
def e2422407329850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407329850 : Closed e2422407329850 ∧ code e2422407329850 = 11218500352058 := by decide
theorem cert_e2422407329850 : check e2422407329850 [[],[]] .chain = true := by decide
def e2422407329898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407329898 : Closed e2422407329898 ∧ code e2422407329898 = 11218500352106 := by decide
theorem cert_e2422407329898 : check e2422407329898 [[],[]] .sourceHead = true := by decide
def e2422407329934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407329934 : Closed e2422407329934 ∧ code e2422407329934 = 11218500352142 := by decide
theorem cert_e2422407329934 : check e2422407329934 [[],[]] .chain = true := by decide
def e2422407329946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407329946 : Closed e2422407329946 ∧ code e2422407329946 = 11218500352154 := by decide
theorem cert_e2422407329946 : check e2422407329946 [[],[]] .chain = true := by decide
def e2422407329990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407329990 : Closed e2422407329990 ∧ code e2422407329990 = 11218500352198 := by decide
theorem cert_e2422407329990 : check e2422407329990 [[],[]] .chain = true := by decide
def e2422407330018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407330018 : Closed e2422407330018 ∧ code e2422407330018 = 11218500352226 := by decide
theorem cert_e2422407330018 : check e2422407330018 [[],[]] .chain = true := by decide
def e2422407330030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407330030 : Closed e2422407330030 ∧ code e2422407330030 = 11218500352238 := by decide
theorem cert_e2422407330030 : check e2422407330030 [[],[]] .sourceHead = true := by decide
def e2422407330038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407330038 : Closed e2422407330038 ∧ code e2422407330038 = 11218500352246 := by decide
theorem cert_e2422407330038 : check e2422407330038 [[],[]] .sourceHead = true := by decide
def e2422407330186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407330186 : Closed e2422407330186 ∧ code e2422407330186 = 11218500352394 := by decide
theorem cert_e2422407330186 : check e2422407330186 [[],[]] .chain = true := by decide
def e2422407330210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407330210 : Closed e2422407330210 ∧ code e2422407330210 = 11218500352418 := by decide
theorem cert_e2422407330210 : check e2422407330210 [[],[]] .chain = true := by decide
def e2422407330222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407330222 : Closed e2422407330222 ∧ code e2422407330222 = 11218500352430 := by decide
theorem cert_e2422407330222 : check e2422407330222 [[],[]] .sourceHead = true := by decide
def e2422407330230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407330230 : Closed e2422407330230 ∧ code e2422407330230 = 11218500352438 := by decide
theorem cert_e2422407330230 : check e2422407330230 [[],[]] .chain = true := by decide
def e2422407330234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407330234 : Closed e2422407330234 ∧ code e2422407330234 = 11218500352442 := by decide
theorem cert_e2422407330234 : check e2422407330234 [[],[]] .sourceHead = true := by decide
def e2422407330262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407330262 : Closed e2422407330262 ∧ code e2422407330262 = 11218500352470 := by decide
theorem cert_e2422407330262 : check e2422407330262 [[],[]] .chain = true := by decide
def e2422407330266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407330266 : Closed e2422407330266 ∧ code e2422407330266 = 11218500352474 := by decide
theorem cert_e2422407330266 : check e2422407330266 [[],[]] .chain = true := by decide
def e2422407330282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407330282 : Closed e2422407330282 ∧ code e2422407330282 = 11218500352490 := by decide
theorem cert_e2422407330282 : check e2422407330282 [[],[]] .sourceHead = true := by decide
def e2422407330306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407330306 : Closed e2422407330306 ∧ code e2422407330306 = 11218500352514 := by decide
theorem cert_e2422407330306 : check e2422407330306 [[],[]] .chain = true := by decide
def e2422407330318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407330318 : Closed e2422407330318 ∧ code e2422407330318 = 11218500352526 := by decide
theorem cert_e2422407330318 : check e2422407330318 [[],[]] .chain = true := by decide
def e2422407330330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407330330 : Closed e2422407330330 ∧ code e2422407330330 = 11218500352538 := by decide
theorem cert_e2422407330330 : check e2422407330330 [[],[]] .sourceHead = true := by decide
def e2422407330402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407330402 : Closed e2422407330402 ∧ code e2422407330402 = 11218500352610 := by decide
theorem cert_e2422407330402 : check e2422407330402 [[],[]] .chain = true := by decide
def e2422407330414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407330414 : Closed e2422407330414 ∧ code e2422407330414 = 11218500352622 := by decide
theorem cert_e2422407330414 : check e2422407330414 [[],[]] .sourceHead = true := by decide
def e2422407330422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407330422 : Closed e2422407330422 ∧ code e2422407330422 = 11218500352630 := by decide
theorem cert_e2422407330422 : check e2422407330422 [[],[]] .chain = true := by decide
def e2422407330426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407330426 : Closed e2422407330426 ∧ code e2422407330426 = 11218500352634 := by decide
theorem cert_e2422407330426 : check e2422407330426 [[],[]] .sourceHead = true := by decide
def e2422407330566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407330566 : Closed e2422407330566 ∧ code e2422407330566 = 11218500352774 := by decide
theorem cert_e2422407330566 : check e2422407330566 [[],[]] .chain = true := by decide
def e2422407330590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407330590 : Closed e2422407330590 ∧ code e2422407330590 = 11218500352798 := by decide
theorem cert_e2422407330590 : check e2422407330590 [[],[]] .sourceHead = true := by decide
def e2422407330614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407330614 : Closed e2422407330614 ∧ code e2422407330614 = 11218500352822 := by decide
theorem cert_e2422407330614 : check e2422407330614 [[],[]] .chain = true := by decide
def e2422407330618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407330618 : Closed e2422407330618 ∧ code e2422407330618 = 11218500352826 := by decide
theorem cert_e2422407330618 : check e2422407330618 [[],[]] .chain = true := by decide
def e2422407330690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407330690 : Closed e2422407330690 ∧ code e2422407330690 = 11218500352898 := by decide
theorem cert_e2422407330690 : check e2422407330690 [[],[]] .sourceHead = true := by decide
def e2422407330702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407330702 : Closed e2422407330702 ∧ code e2422407330702 = 11218500352910 := by decide
theorem cert_e2422407330702 : check e2422407330702 [[],[]] .sourceHead = true := by decide
def e2422407330714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407330714 : Closed e2422407330714 ∧ code e2422407330714 = 11218500352922 := by decide
theorem cert_e2422407330714 : check e2422407330714 [[],[]] .sourceHead = true := by decide
def e2422407332286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422407332286 : Closed e2422407332286 ∧ code e2422407332286 = 11218500354494 := by decide
theorem cert_e2422407332286 : check e2422407332286 [[],[]] .chain = true := by decide
def e2422407332346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422407332346 : Closed e2422407332346 ∧ code e2422407332346 = 11218500354554 := by decide
theorem cert_e2422407332346 : check e2422407332346 [[],[]] .chain = true := by decide
def e2422407333438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422407333438 : Closed e2422407333438 ∧ code e2422407333438 = 11218500355646 := by decide
theorem cert_e2422407333438 : check e2422407333438 [[],[]] .chain = true := by decide
def e2422407333830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422407333830 : Closed e2422407333830 ∧ code e2422407333830 = 11218500356038 := by decide
theorem cert_e2422407333830 : check e2422407333830 [[],[]] .chain = true := by decide
def e2422407333854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2422407333854 : Closed e2422407333854 ∧ code e2422407333854 = 11218500356062 := by decide
theorem cert_e2422407333854 : check e2422407333854 [[],[]] .sourceHead = true := by decide
def e2422407337518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422407337518 : Closed e2422407337518 ∧ code e2422407337518 = 11218500359726 := by decide
theorem cert_e2422407337518 : check e2422407337518 [[],[]] .chain = true := by decide
end Blc.Floor43
