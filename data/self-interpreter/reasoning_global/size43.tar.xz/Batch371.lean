import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364364470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422364364470 : Closed e2422364364470 ∧ code e2422364364470 = 11218457386678 := by decide
theorem cert_e2422364364470 : check e2422364364470 [[],[]] .smaller = true := by decide
def e2422364364474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422364364474 : Closed e2422364364474 ∧ code e2422364364474 = 11218457386682 := by decide
theorem cert_e2422364364474 : check e2422364364474 [[],[]] .smaller = true := by decide
def e2422364364502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422364364502 : Closed e2422364364502 ∧ code e2422364364502 = 11218457386710 := by decide
theorem cert_e2422364364502 : check e2422364364502 [[],[]] .smaller = true := by decide
def e2422364364506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422364364506 : Closed e2422364364506 ∧ code e2422364364506 = 11218457386714 := by decide
theorem cert_e2422364364506 : check e2422364364506 [[],[]] .smaller = true := by decide
def e2422364364522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422364364522 : Closed e2422364364522 ∧ code e2422364364522 = 11218457386730 := by decide
theorem cert_e2422364364522 : check e2422364364522 [[],[]] .smaller = true := by decide
def e2422364364630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364364630 : Closed e2422364364630 ∧ code e2422364364630 = 11218457386838 := by decide
theorem cert_e2422364364630 : check e2422364364630 [[],[]] .three = true := by decide
def e2422364364634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364364634 : Closed e2422364364634 ∧ code e2422364364634 = 11218457386842 := by decide
theorem cert_e2422364364634 : check e2422364364634 [[],[]] .three = true := by decide
def e2422364364650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364364650 : Closed e2422364364650 ∧ code e2422364364650 = 11218457386858 := by decide
theorem cert_e2422364364650 : check e2422364364650 [[],[]] .three = true := by decide
def e2422364365486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422364365486 : Closed e2422364365486 ∧ code e2422364365486 = 11218457387694 := by decide
theorem cert_e2422364365486 : check e2422364365486 [[],[]] .smaller = true := by decide
def e2422364365498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422364365498 : Closed e2422364365498 ∧ code e2422364365498 = 11218457387706 := by decide
theorem cert_e2422364365498 : check e2422364365498 [[],[]] .smaller = true := by decide
def e2422364365546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422364365546 : Closed e2422364365546 ∧ code e2422364365546 = 11218457387754 := by decide
theorem cert_e2422364365546 : check e2422364365546 [[],[]] .smaller = true := by decide
def e2422364367022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364367022 : Closed e2422364367022 ∧ code e2422364367022 = 11218457389230 := by decide
theorem cert_e2422364367022 : check e2422364367022 [[],[]] .smaller = true := by decide
def e2422364367034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364367034 : Closed e2422364367034 ∧ code e2422364367034 = 11218457389242 := by decide
theorem cert_e2422364367034 : check e2422364367034 [[],[]] .smaller = true := by decide
def e2422364367406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364367406 : Closed e2422364367406 ∧ code e2422364367406 = 11218457389614 := by decide
theorem cert_e2422364367406 : check e2422364367406 [[],[]] .smaller = true := by decide
def e2422364367550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2422364367550 : Closed e2422364367550 ∧ code e2422364367550 = 11218457389758 := by decide
theorem cert_e2422364367550 : check e2422364367550 [[],[]] .three = true := by decide
def e2422364367582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422364367582 : Closed e2422364367582 ∧ code e2422364367582 = 11218457389790 := by decide
theorem cert_e2422364367582 : check e2422364367582 [[],[]] .smaller = true := by decide
def e2422364367586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364367586 : Closed e2422364367586 ∧ code e2422364367586 = 11218457389794 := by decide
theorem cert_e2422364367586 : check e2422364367586 [[],[]] .smaller = true := by decide
def e2422364367598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422364367598 : Closed e2422364367598 ∧ code e2422364367598 = 11218457389806 := by decide
theorem cert_e2422364367598 : check e2422364367598 [[],[]] .smaller = true := by decide
def e2422364367606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422364367606 : Closed e2422364367606 ∧ code e2422364367606 = 11218457389814 := by decide
theorem cert_e2422364367606 : check e2422364367606 [[],[]] .smaller = true := by decide
def e2422364367610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2422364367610 : Closed e2422364367610 ∧ code e2422364367610 = 11218457389818 := by decide
theorem cert_e2422364367610 : check e2422364367610 [[],[]] .three = true := by decide
def e2422364367710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422364367710 : Closed e2422364367710 ∧ code e2422364367710 = 11218457389918 := by decide
theorem cert_e2422364367710 : check e2422364367710 [[],[]] .smaller = true := by decide
def e2422364367726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2422364367726 : Closed e2422364367726 ∧ code e2422364367726 = 11218457389934 := by decide
theorem cert_e2422364367726 : check e2422364367726 [[],[]] .smaller = true := by decide
def e2422364367734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2422364367734 : Closed e2422364367734 ∧ code e2422364367734 = 11218457389942 := by decide
theorem cert_e2422364367734 : check e2422364367734 [[],[]] .smaller = true := by decide
def e2422364367738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422364367738 : Closed e2422364367738 ∧ code e2422364367738 = 11218457389946 := by decide
theorem cert_e2422364367738 : check e2422364367738 [[],[]] .smaller = true := by decide
def e2422364367754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364367754 : Closed e2422364367754 ∧ code e2422364367754 = 11218457389962 := by decide
theorem cert_e2422364367754 : check e2422364367754 [[],[]] .smaller = true := by decide
def e2422364367778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364367778 : Closed e2422364367778 ∧ code e2422364367778 = 11218457389986 := by decide
theorem cert_e2422364367778 : check e2422364367778 [[],[]] .smaller = true := by decide
def e2422364367790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422364367790 : Closed e2422364367790 ∧ code e2422364367790 = 11218457389998 := by decide
theorem cert_e2422364367790 : check e2422364367790 [[],[]] .smaller = true := by decide
def e2422364367798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2422364367798 : Closed e2422364367798 ∧ code e2422364367798 = 11218457390006 := by decide
theorem cert_e2422364367798 : check e2422364367798 [[],[]] .smaller = true := by decide
def e2422364367802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422364367802 : Closed e2422364367802 ∧ code e2422364367802 = 11218457390010 := by decide
theorem cert_e2422364367802 : check e2422364367802 [[],[]] .smaller = true := by decide
def e2422364367830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422364367830 : Closed e2422364367830 ∧ code e2422364367830 = 11218457390038 := by decide
theorem cert_e2422364367830 : check e2422364367830 [[],[]] .smaller = true := by decide
def e2422364367834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422364367834 : Closed e2422364367834 ∧ code e2422364367834 = 11218457390042 := by decide
theorem cert_e2422364367834 : check e2422364367834 [[],[]] .smaller = true := by decide
def e2422364367850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2422364367850 : Closed e2422364367850 ∧ code e2422364367850 = 11218457390058 := by decide
theorem cert_e2422364367850 : check e2422364367850 [[],[]] .three = true := by decide
def e2422364368222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422364368222 : Closed e2422364368222 ∧ code e2422364368222 = 11218457390430 := by decide
theorem cert_e2422364368222 : check e2422364368222 [[],[]] .smaller = true := by decide
def e2422364368238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422364368238 : Closed e2422364368238 ∧ code e2422364368238 = 11218457390446 := by decide
theorem cert_e2422364368238 : check e2422364368238 [[],[]] .smaller = true := by decide
def e2422364368246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422364368246 : Closed e2422364368246 ∧ code e2422364368246 = 11218457390454 := by decide
theorem cert_e2422364368246 : check e2422364368246 [[],[]] .smaller = true := by decide
def e2422364368250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422364368250 : Closed e2422364368250 ∧ code e2422364368250 = 11218457390458 := by decide
theorem cert_e2422364368250 : check e2422364368250 [[],[]] .smaller = true := by decide
def e2422364368302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422364368302 : Closed e2422364368302 ∧ code e2422364368302 = 11218457390510 := by decide
theorem cert_e2422364368302 : check e2422364368302 [[],[]] .smaller = true := by decide
def e2422364368314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422364368314 : Closed e2422364368314 ∧ code e2422364368314 = 11218457390522 := by decide
theorem cert_e2422364368314 : check e2422364368314 [[],[]] .smaller = true := by decide
def e2422364368342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422364368342 : Closed e2422364368342 ∧ code e2422364368342 = 11218457390550 := by decide
theorem cert_e2422364368342 : check e2422364368342 [[],[]] .smaller = true := by decide
def e2422364368346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422364368346 : Closed e2422364368346 ∧ code e2422364368346 = 11218457390554 := by decide
theorem cert_e2422364368346 : check e2422364368346 [[],[]] .smaller = true := by decide
def e2422364368362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422364368362 : Closed e2422364368362 ∧ code e2422364368362 = 11218457390570 := by decide
theorem cert_e2422364368362 : check e2422364368362 [[],[]] .smaller = true := by decide
def e2422364368426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364368426 : Closed e2422364368426 ∧ code e2422364368426 = 11218457390634 := by decide
theorem cert_e2422364368426 : check e2422364368426 [[],[]] .smaller = true := by decide
def e2422364368522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364368522 : Closed e2422364368522 ∧ code e2422364368522 = 11218457390730 := by decide
theorem cert_e2422364368522 : check e2422364368522 [[],[]] .smaller = true := by decide
def e2422364368546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364368546 : Closed e2422364368546 ∧ code e2422364368546 = 11218457390754 := by decide
theorem cert_e2422364368546 : check e2422364368546 [[],[]] .smaller = true := by decide
def e2422364368558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422364368558 : Closed e2422364368558 ∧ code e2422364368558 = 11218457390766 := by decide
theorem cert_e2422364368558 : check e2422364368558 [[],[]] .smaller = true := by decide
def e2422364368566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422364368566 : Closed e2422364368566 ∧ code e2422364368566 = 11218457390774 := by decide
theorem cert_e2422364368566 : check e2422364368566 [[],[]] .smaller = true := by decide
def e2422364368570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422364368570 : Closed e2422364368570 ∧ code e2422364368570 = 11218457390778 := by decide
theorem cert_e2422364368570 : check e2422364368570 [[],[]] .smaller = true := by decide
def e2422364368598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422364368598 : Closed e2422364368598 ∧ code e2422364368598 = 11218457390806 := by decide
theorem cert_e2422364368598 : check e2422364368598 [[],[]] .smaller = true := by decide
def e2422364368602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422364368602 : Closed e2422364368602 ∧ code e2422364368602 = 11218457390810 := by decide
theorem cert_e2422364368602 : check e2422364368602 [[],[]] .smaller = true := by decide
def e2422364368618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422364368618 : Closed e2422364368618 ∧ code e2422364368618 = 11218457390826 := by decide
theorem cert_e2422364368618 : check e2422364368618 [[],[]] .smaller = true := by decide
def e2422364368726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364368726 : Closed e2422364368726 ∧ code e2422364368726 = 11218457390934 := by decide
theorem cert_e2422364368726 : check e2422364368726 [[],[]] .smaller = true := by decide
def e2422364368730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364368730 : Closed e2422364368730 ∧ code e2422364368730 = 11218457390938 := by decide
theorem cert_e2422364368730 : check e2422364368730 [[],[]] .smaller = true := by decide
def e2422364368746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364368746 : Closed e2422364368746 ∧ code e2422364368746 = 11218457390954 := by decide
theorem cert_e2422364368746 : check e2422364368746 [[],[]] .smaller = true := by decide
def e2422364368810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422364368810 : Closed e2422364368810 ∧ code e2422364368810 = 11218457391018 := by decide
theorem cert_e2422364368810 : check e2422364368810 [[],[]] .three = true := by decide
def e2422364369238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364369238 : Closed e2422364369238 ∧ code e2422364369238 = 11218457391446 := by decide
theorem cert_e2422364369238 : check e2422364369238 [[],[]] .smaller = true := by decide
def e2422364369242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364369242 : Closed e2422364369242 ∧ code e2422364369242 = 11218457391450 := by decide
theorem cert_e2422364369242 : check e2422364369242 [[],[]] .smaller = true := by decide
def e2422364369258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364369258 : Closed e2422364369258 ∧ code e2422364369258 = 11218457391466 := by decide
theorem cert_e2422364369258 : check e2422364369258 [[],[]] .smaller = true := by decide
def e2422364370006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364370006 : Closed e2422364370006 ∧ code e2422364370006 = 11218457392214 := by decide
theorem cert_e2422364370006 : check e2422364370006 [[],[]] .smaller = true := by decide
def e2422364370010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364370010 : Closed e2422364370010 ∧ code e2422364370010 = 11218457392218 := by decide
theorem cert_e2422364370010 : check e2422364370010 [[],[]] .smaller = true := by decide
def e2422364370198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364370198 : Closed e2422364370198 ∧ code e2422364370198 = 11218457392406 := by decide
theorem cert_e2422364370198 : check e2422364370198 [[],[]] .smaller = true := by decide
def e2422364370270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422364370270 : Closed e2422364370270 ∧ code e2422364370270 = 11218457392478 := by decide
theorem cert_e2422364370270 : check e2422364370270 [[],[]] .smaller = true := by decide
def e2422364370274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364370274 : Closed e2422364370274 ∧ code e2422364370274 = 11218457392482 := by decide
theorem cert_e2422364370274 : check e2422364370274 [[],[]] .smaller = true := by decide
def e2422364370286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422364370286 : Closed e2422364370286 ∧ code e2422364370286 = 11218457392494 := by decide
theorem cert_e2422364370286 : check e2422364370286 [[],[]] .smaller = true := by decide
def e2422364370294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422364370294 : Closed e2422364370294 ∧ code e2422364370294 = 11218457392502 := by decide
theorem cert_e2422364370294 : check e2422364370294 [[],[]] .smaller = true := by decide
def e2422364370298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422364370298 : Closed e2422364370298 ∧ code e2422364370298 = 11218457392506 := by decide
theorem cert_e2422364370298 : check e2422364370298 [[],[]] .smaller = true := by decide
def e2422364370314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364370314 : Closed e2422364370314 ∧ code e2422364370314 = 11218457392522 := by decide
theorem cert_e2422364370314 : check e2422364370314 [[],[]] .smaller = true := by decide
def e2422364370338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364370338 : Closed e2422364370338 ∧ code e2422364370338 = 11218457392546 := by decide
theorem cert_e2422364370338 : check e2422364370338 [[],[]] .smaller = true := by decide
def e2422364370350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422364370350 : Closed e2422364370350 ∧ code e2422364370350 = 11218457392558 := by decide
theorem cert_e2422364370350 : check e2422364370350 [[],[]] .smaller = true := by decide
def e2422364370358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))))
theorem wire_e2422364370358 : Closed e2422364370358 ∧ code e2422364370358 = 11218457392566 := by decide
theorem cert_e2422364370358 : check e2422364370358 [[],[]] .smaller = true := by decide
def e2422364370362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422364370362 : Closed e2422364370362 ∧ code e2422364370362 = 11218457392570 := by decide
theorem cert_e2422364370362 : check e2422364370362 [[],[]] .smaller = true := by decide
def e2422364370390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422364370390 : Closed e2422364370390 ∧ code e2422364370390 = 11218457392598 := by decide
theorem cert_e2422364370390 : check e2422364370390 [[],[]] .smaller = true := by decide
def e2422364370394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422364370394 : Closed e2422364370394 ∧ code e2422364370394 = 11218457392602 := by decide
theorem cert_e2422364370394 : check e2422364370394 [[],[]] .smaller = true := by decide
def e2422364370410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422364370410 : Closed e2422364370410 ∧ code e2422364370410 = 11218457392618 := by decide
theorem cert_e2422364370410 : check e2422364370410 [[],[]] .smaller = true := by decide
def e2422364370474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364370474 : Closed e2422364370474 ∧ code e2422364370474 = 11218457392682 := by decide
theorem cert_e2422364370474 : check e2422364370474 [[],[]] .smaller = true := by decide
def e2422364370570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364370570 : Closed e2422364370570 ∧ code e2422364370570 = 11218457392778 := by decide
theorem cert_e2422364370570 : check e2422364370570 [[],[]] .smaller = true := by decide
def e2422364370594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364370594 : Closed e2422364370594 ∧ code e2422364370594 = 11218457392802 := by decide
theorem cert_e2422364370594 : check e2422364370594 [[],[]] .smaller = true := by decide
def e2422364370606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422364370606 : Closed e2422364370606 ∧ code e2422364370606 = 11218457392814 := by decide
theorem cert_e2422364370606 : check e2422364370606 [[],[]] .smaller = true := by decide
def e2422364370614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422364370614 : Closed e2422364370614 ∧ code e2422364370614 = 11218457392822 := by decide
theorem cert_e2422364370614 : check e2422364370614 [[],[]] .smaller = true := by decide
def e2422364370618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422364370618 : Closed e2422364370618 ∧ code e2422364370618 = 11218457392826 := by decide
theorem cert_e2422364370618 : check e2422364370618 [[],[]] .smaller = true := by decide
def e2422364370646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422364370646 : Closed e2422364370646 ∧ code e2422364370646 = 11218457392854 := by decide
theorem cert_e2422364370646 : check e2422364370646 [[],[]] .smaller = true := by decide
def e2422364370650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422364370650 : Closed e2422364370650 ∧ code e2422364370650 = 11218457392858 := by decide
theorem cert_e2422364370650 : check e2422364370650 [[],[]] .smaller = true := by decide
def e2422364370666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422364370666 : Closed e2422364370666 ∧ code e2422364370666 = 11218457392874 := by decide
theorem cert_e2422364370666 : check e2422364370666 [[],[]] .smaller = true := by decide
def e2422364370774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364370774 : Closed e2422364370774 ∧ code e2422364370774 = 11218457392982 := by decide
theorem cert_e2422364370774 : check e2422364370774 [[],[]] .smaller = true := by decide
def e2422364370778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364370778 : Closed e2422364370778 ∧ code e2422364370778 = 11218457392986 := by decide
theorem cert_e2422364370778 : check e2422364370778 [[],[]] .smaller = true := by decide
def e2422364370794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364370794 : Closed e2422364370794 ∧ code e2422364370794 = 11218457393002 := by decide
theorem cert_e2422364370794 : check e2422364370794 [[],[]] .smaller = true := by decide
def e2422364370858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422364370858 : Closed e2422364370858 ∧ code e2422364370858 = 11218457393066 := by decide
theorem cert_e2422364370858 : check e2422364370858 [[],[]] .smaller = true := by decide
def e2422364371630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422364371630 : Closed e2422364371630 ∧ code e2422364371630 = 11218457393838 := by decide
theorem cert_e2422364371630 : check e2422364371630 [[],[]] .smaller = true := by decide
def e2422364371638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422364371638 : Closed e2422364371638 ∧ code e2422364371638 = 11218457393846 := by decide
theorem cert_e2422364371638 : check e2422364371638 [[],[]] .smaller = true := by decide
def e2422364371642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422364371642 : Closed e2422364371642 ∧ code e2422364371642 = 11218457393850 := by decide
theorem cert_e2422364371642 : check e2422364371642 [[],[]] .smaller = true := by decide
def e2422364371670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422364371670 : Closed e2422364371670 ∧ code e2422364371670 = 11218457393878 := by decide
theorem cert_e2422364371670 : check e2422364371670 [[],[]] .smaller = true := by decide
def e2422364371674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422364371674 : Closed e2422364371674 ∧ code e2422364371674 = 11218457393882 := by decide
theorem cert_e2422364371674 : check e2422364371674 [[],[]] .smaller = true := by decide
def e2422364371690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422364371690 : Closed e2422364371690 ∧ code e2422364371690 = 11218457393898 := by decide
theorem cert_e2422364371690 : check e2422364371690 [[],[]] .smaller = true := by decide
def e2422364371798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364371798 : Closed e2422364371798 ∧ code e2422364371798 = 11218457394006 := by decide
theorem cert_e2422364371798 : check e2422364371798 [[],[]] .smaller = true := by decide
def e2422364371802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364371802 : Closed e2422364371802 ∧ code e2422364371802 = 11218457394010 := by decide
theorem cert_e2422364371802 : check e2422364371802 [[],[]] .smaller = true := by decide
def e2422364371818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364371818 : Closed e2422364371818 ∧ code e2422364371818 = 11218457394026 := by decide
theorem cert_e2422364371818 : check e2422364371818 [[],[]] .smaller = true := by decide
def e2422364371882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422364371882 : Closed e2422364371882 ∧ code e2422364371882 = 11218457394090 := by decide
theorem cert_e2422364371882 : check e2422364371882 [[],[]] .smaller = true := by decide
def e2422364372310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422364372310 : Closed e2422364372310 ∧ code e2422364372310 = 11218457394518 := by decide
theorem cert_e2422364372310 : check e2422364372310 [[],[]] .three = true := by decide
def e2422364372314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422364372314 : Closed e2422364372314 ∧ code e2422364372314 = 11218457394522 := by decide
theorem cert_e2422364372314 : check e2422364372314 [[],[]] .three = true := by decide
def e2422364372330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422364372330 : Closed e2422364372330 ∧ code e2422364372330 = 11218457394538 := by decide
theorem cert_e2422364372330 : check e2422364372330 [[],[]] .three = true := by decide
def e2422364372394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422364372394 : Closed e2422364372394 ∧ code e2422364372394 = 11218457394602 := by decide
theorem cert_e2422364372394 : check e2422364372394 [[],[]] .three = true := by decide
def e2422364374894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))))
theorem wire_e2422364374894 : Closed e2422364374894 ∧ code e2422364374894 = 11218457397102 := by decide
theorem cert_e2422364374894 : check e2422364374894 [[],[]] .smaller = true := by decide
def e2422364374902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))))
theorem wire_e2422364374902 : Closed e2422364374902 ∧ code e2422364374902 = 11218457397110 := by decide
theorem cert_e2422364374902 : check e2422364374902 [[],[]] .smaller = true := by decide
def e2422364374958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))))
theorem wire_e2422364374958 : Closed e2422364374958 ∧ code e2422364374958 = 11218457397166 := by decide
theorem cert_e2422364374958 : check e2422364374958 [[],[]] .smaller = true := by decide
def e2422364374970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))))
theorem wire_e2422364374970 : Closed e2422364374970 ∧ code e2422364374970 = 11218457397178 := by decide
theorem cert_e2422364374970 : check e2422364374970 [[],[]] .smaller = true := by decide
def e2422364374998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))))
theorem wire_e2422364374998 : Closed e2422364374998 ∧ code e2422364374998 = 11218457397206 := by decide
theorem cert_e2422364374998 : check e2422364374998 [[],[]] .smaller = true := by decide
def e2422364375002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))))
theorem wire_e2422364375002 : Closed e2422364375002 ∧ code e2422364375002 = 11218457397210 := by decide
theorem cert_e2422364375002 : check e2422364375002 [[],[]] .smaller = true := by decide
def e2422364376430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))))
theorem wire_e2422364376430 : Closed e2422364376430 ∧ code e2422364376430 = 11218457398638 := by decide
theorem cert_e2422364376430 : check e2422364376430 [[],[]] .smaller = true := by decide
def e2422364376438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))))
theorem wire_e2422364376438 : Closed e2422364376438 ∧ code e2422364376438 = 11218457398646 := by decide
theorem cert_e2422364376438 : check e2422364376438 [[],[]] .smaller = true := by decide
def e2422364377966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422364377966 : Closed e2422364377966 ∧ code e2422364377966 = 11218457400174 := by decide
theorem cert_e2422364377966 : check e2422364377966 [[],[]] .smaller = true := by decide
def e2422364377974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422364377974 : Closed e2422364377974 ∧ code e2422364377974 = 11218457400182 := by decide
theorem cert_e2422364377974 : check e2422364377974 [[],[]] .smaller = true := by decide
def e2422364378030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422364378030 : Closed e2422364378030 ∧ code e2422364378030 = 11218457400238 := by decide
theorem cert_e2422364378030 : check e2422364378030 [[],[]] .smaller = true := by decide
def e2422364378042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422364378042 : Closed e2422364378042 ∧ code e2422364378042 = 11218457400250 := by decide
theorem cert_e2422364378042 : check e2422364378042 [[],[]] .smaller = true := by decide
def e2422364378070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422364378070 : Closed e2422364378070 ∧ code e2422364378070 = 11218457400278 := by decide
theorem cert_e2422364378070 : check e2422364378070 [[],[]] .smaller = true := by decide
def e2422364378074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422364378074 : Closed e2422364378074 ∧ code e2422364378074 = 11218457400282 := by decide
theorem cert_e2422364378074 : check e2422364378074 [[],[]] .smaller = true := by decide
def e2422364378350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364378350 : Closed e2422364378350 ∧ code e2422364378350 = 11218457400558 := by decide
theorem cert_e2422364378350 : check e2422364378350 [[],[]] .smaller = true := by decide
def e2422364378358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364378358 : Closed e2422364378358 ∧ code e2422364378358 = 11218457400566 := by decide
theorem cert_e2422364378358 : check e2422364378358 [[],[]] .smaller = true := by decide
def e2422364378734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364378734 : Closed e2422364378734 ∧ code e2422364378734 = 11218457400942 := by decide
theorem cert_e2422364378734 : check e2422364378734 [[],[]] .smaller = true := by decide
def e2422364378746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364378746 : Closed e2422364378746 ∧ code e2422364378746 = 11218457400954 := by decide
theorem cert_e2422364378746 : check e2422364378746 [[],[]] .smaller = true := by decide
def e2422364378934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364378934 : Closed e2422364378934 ∧ code e2422364378934 = 11218457401142 := by decide
theorem cert_e2422364378934 : check e2422364378934 [[],[]] .smaller = true := by decide
def e2422364378938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364378938 : Closed e2422364378938 ∧ code e2422364378938 = 11218457401146 := by decide
theorem cert_e2422364378938 : check e2422364378938 [[],[]] .smaller = true := by decide
def e2422364379374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422364379374 : Closed e2422364379374 ∧ code e2422364379374 = 11218457401582 := by decide
theorem cert_e2422364379374 : check e2422364379374 [[],[]] .smaller = true := by decide
def e2422364379382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422364379382 : Closed e2422364379382 ∧ code e2422364379382 = 11218457401590 := by decide
theorem cert_e2422364379382 : check e2422364379382 [[],[]] .smaller = true := by decide
def e2422364379934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422364379934 : Closed e2422364379934 ∧ code e2422364379934 = 11218457402142 := by decide
theorem cert_e2422364379934 : check e2422364379934 [[],[]] .smaller = true := by decide
def e2422364380046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422364380046 : Closed e2422364380046 ∧ code e2422364380046 = 11218457402254 := by decide
theorem cert_e2422364380046 : check e2422364380046 [[],[]] .smaller = true := by decide
def e2422364380094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 4))))))))
theorem wire_e2422364380094 : Closed e2422364380094 ∧ code e2422364380094 = 11218457402302 := by decide
theorem cert_e2422364380094 : check e2422364380094 [[],[]] .three = true := by decide
def e2422364380142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 4)) (.var 2))))))))
theorem wire_e2422364380142 : Closed e2422364380142 ∧ code e2422364380142 = 11218457402350 := by decide
theorem cert_e2422364380142 : check e2422364380142 [[],[]] .three = true := by decide
def e2422364380270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422364380270 : Closed e2422364380270 ∧ code e2422364380270 = 11218457402478 := by decide
theorem cert_e2422364380270 : check e2422364380270 [[],[]] .smaller = true := by decide
def e2422364380282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422364380282 : Closed e2422364380282 ∧ code e2422364380282 = 11218457402490 := by decide
theorem cert_e2422364380282 : check e2422364380282 [[],[]] .smaller = true := by decide
def e2422364380446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422364380446 : Closed e2422364380446 ∧ code e2422364380446 = 11218457402654 := by decide
theorem cert_e2422364380446 : check e2422364380446 [[],[]] .smaller = true := by decide
def e2422364380606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 4))))))))
theorem wire_e2422364380606 : Closed e2422364380606 ∧ code e2422364380606 = 11218457402814 := by decide
theorem cert_e2422364380606 : check e2422364380606 [[],[]] .three = true := by decide
def e2422364380614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422364380614 : Closed e2422364380614 ∧ code e2422364380614 = 11218457402822 := by decide
theorem cert_e2422364380614 : check e2422364380614 [[],[]] .smaller = true := by decide
def e2422364380662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 4)) (.var 1))))))))
theorem wire_e2422364380662 : Closed e2422364380662 ∧ code e2422364380662 = 11218457402870 := by decide
theorem cert_e2422364380662 : check e2422364380662 [[],[]] .three = true := by decide
def e2422364380726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422364380726 : Closed e2422364380726 ∧ code e2422364380726 = 11218457402934 := by decide
theorem cert_e2422364380726 : check e2422364380726 [[],[]] .smaller = true := by decide
def e2422364380730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422364380730 : Closed e2422364380730 ∧ code e2422364380730 = 11218457402938 := by decide
theorem cert_e2422364380730 : check e2422364380730 [[],[]] .smaller = true := by decide
def e2422364380814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422364380814 : Closed e2422364380814 ∧ code e2422364380814 = 11218457403022 := by decide
theorem cert_e2422364380814 : check e2422364380814 [[],[]] .smaller = true := by decide
def e2422364380862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 4))))))))
theorem wire_e2422364380862 : Closed e2422364380862 ∧ code e2422364380862 = 11218457403070 := by decide
theorem cert_e2422364380862 : check e2422364380862 [[],[]] .three = true := by decide
def e2422364380870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422364380870 : Closed e2422364380870 ∧ code e2422364380870 = 11218457403078 := by decide
theorem cert_e2422364380870 : check e2422364380870 [[],[]] .smaller = true := by decide
def e2422364380922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 4)) (.var 0))))))))
theorem wire_e2422364380922 : Closed e2422364380922 ∧ code e2422364380922 = 11218457403130 := by decide
theorem cert_e2422364380922 : check e2422364380922 [[],[]] .three = true := by decide
def e2422364381102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 5))) (.var 0)) (.var 2))))))))
theorem wire_e2422364381102 : Closed e2422364381102 ∧ code e2422364381102 = 11218457403310 := by decide
theorem cert_e2422364381102 : check e2422364381102 [[],[]] .three = true := by decide
def e2422364381110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 5))) (.var 1)) (.var 1))))))))
theorem wire_e2422364381110 : Closed e2422364381110 ∧ code e2422364381110 = 11218457403318 := by decide
theorem cert_e2422364381110 : check e2422364381110 [[],[]] .three = true := by decide
def e2422364381114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 5))) (.var 2)) (.var 0))))))))
theorem wire_e2422364381114 : Closed e2422364381114 ∧ code e2422364381114 = 11218457403322 := by decide
theorem cert_e2422364381114 : check e2422364381114 [[],[]] .three = true := by decide
def e2422364385646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))))
theorem wire_e2422364385646 : Closed e2422364385646 ∧ code e2422364385646 = 11218457407854 := by decide
theorem cert_e2422364385646 : check e2422364385646 [[],[]] .smaller = true := by decide
def e2422364385654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))))
theorem wire_e2422364385654 : Closed e2422364385654 ∧ code e2422364385654 = 11218457407862 := by decide
theorem cert_e2422364385654 : check e2422364385654 [[],[]] .smaller = true := by decide
def e2422364386750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 4))))))))
theorem wire_e2422364386750 : Closed e2422364386750 ∧ code e2422364386750 = 11218457408958 := by decide
theorem cert_e2422364386750 : check e2422364386750 [[],[]] .three = true := by decide
def e2422364386782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 3))))))))
theorem wire_e2422364386782 : Closed e2422364386782 ∧ code e2422364386782 = 11218457408990 := by decide
theorem cert_e2422364386782 : check e2422364386782 [[],[]] .smaller = true := by decide
def e2422364386798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.var 2))))))))
theorem wire_e2422364386798 : Closed e2422364386798 ∧ code e2422364386798 = 11218457409006 := by decide
theorem cert_e2422364386798 : check e2422364386798 [[],[]] .smaller = true := by decide
def e2422364386806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 4)) (.var 1))))))))
theorem wire_e2422364386806 : Closed e2422364386806 ∧ code e2422364386806 = 11218457409014 := by decide
theorem cert_e2422364386806 : check e2422364386806 [[],[]] .three = true := by decide
def e2422364386862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422364386862 : Closed e2422364386862 ∧ code e2422364386862 = 11218457409070 := by decide
theorem cert_e2422364386862 : check e2422364386862 [[],[]] .smaller = true := by decide
def e2422364387006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 4))))))))
theorem wire_e2422364387006 : Closed e2422364387006 ∧ code e2422364387006 = 11218457409214 := by decide
theorem cert_e2422364387006 : check e2422364387006 [[],[]] .three = true := by decide
def e2422364387038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 3))))))))
theorem wire_e2422364387038 : Closed e2422364387038 ∧ code e2422364387038 = 11218457409246 := by decide
theorem cert_e2422364387038 : check e2422364387038 [[],[]] .smaller = true := by decide
def e2422364387042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422364387042 : Closed e2422364387042 ∧ code e2422364387042 = 11218457409250 := by decide
theorem cert_e2422364387042 : check e2422364387042 [[],[]] .smaller = true := by decide
def e2422364387054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))))
theorem wire_e2422364387054 : Closed e2422364387054 ∧ code e2422364387054 = 11218457409262 := by decide
theorem cert_e2422364387054 : check e2422364387054 [[],[]] .smaller = true := by decide
def e2422364387062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 1))))))))
theorem wire_e2422364387062 : Closed e2422364387062 ∧ code e2422364387062 = 11218457409270 := by decide
theorem cert_e2422364387062 : check e2422364387062 [[],[]] .smaller = true := by decide
def e2422364387066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4)) (.var 0))))))))
theorem wire_e2422364387066 : Closed e2422364387066 ∧ code e2422364387066 = 11218457409274 := by decide
theorem cert_e2422364387066 : check e2422364387066 [[],[]] .three = true := by decide
def e2422364387094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364387094 : Closed e2422364387094 ∧ code e2422364387094 = 11218457409302 := by decide
theorem cert_e2422364387094 : check e2422364387094 [[],[]] .smaller = true := by decide
def e2422364387166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 3))))))))
theorem wire_e2422364387166 : Closed e2422364387166 ∧ code e2422364387166 = 11218457409374 := by decide
theorem cert_e2422364387166 : check e2422364387166 [[],[]] .smaller = true := by decide
def e2422364387170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364387170 : Closed e2422364387170 ∧ code e2422364387170 = 11218457409378 := by decide
theorem cert_e2422364387170 : check e2422364387170 [[],[]] .smaller = true := by decide
def e2422364387182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e2422364387182 : Closed e2422364387182 ∧ code e2422364387182 = 11218457409390 := by decide
theorem cert_e2422364387182 : check e2422364387182 [[],[]] .smaller = true := by decide
def e2422364387190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e2422364387190 : Closed e2422364387190 ∧ code e2422364387190 = 11218457409398 := by decide
theorem cert_e2422364387190 : check e2422364387190 [[],[]] .smaller = true := by decide
def e2422364387194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.var 0))))))))
theorem wire_e2422364387194 : Closed e2422364387194 ∧ code e2422364387194 = 11218457409402 := by decide
theorem cert_e2422364387194 : check e2422364387194 [[],[]] .smaller = true := by decide
end Blc.Floor43
