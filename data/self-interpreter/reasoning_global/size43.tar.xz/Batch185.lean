import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2384043339290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043339290 : Closed e2384043339290 ∧ code e2384043339290 = 11180136361498 := by decide
theorem cert_e2384043339290 : check e2384043339290 [[]] .width = true := by decide
def e2384043342362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043342362 : Closed e2384043342362 ∧ code e2384043342362 = 11180136364570 := by decide
theorem cert_e2384043342362 : check e2384043342362 [[]] .width = true := by decide
def e2384043390490 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043390490 : Closed e2384043390490 ∧ code e2384043390490 = 11180136412698 := by decide
theorem cert_e2384043390490 : check e2384043390490 [[]] .width = true := by decide
def e2384043391514 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384043391514 : Closed e2384043391514 ∧ code e2384043391514 = 11180136413722 := by decide
theorem cert_e2384043391514 : check e2384043391514 [[]] .width = true := by decide
def e2384059215214 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2384059215214 : Closed e2384059215214 ∧ code e2384059215214 = 11180152237422 := by decide
theorem cert_e2384059215214 : check e2384059215214 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384059215222 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2384059215222 : Closed e2384059215222 ∧ code e2384059215222 = 11180152237430 := by decide
theorem cert_e2384059215222 : check e2384059215222 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384059215278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2384059215278 : Closed e2384059215278 ∧ code e2384059215278 = 11180152237486 := by decide
theorem cert_e2384059215278 : check e2384059215278 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384059215290 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2384059215290 : Closed e2384059215290 ∧ code e2384059215290 = 11180152237498 := by decide
def e2384059215318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2384059215318 : Closed e2384059215318 ∧ code e2384059215318 = 11180152237526 := by decide
def e2384059215322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2384059215322 : Closed e2384059215322 ∧ code e2384059215322 = 11180152237530 := by decide
def e2384059215534 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2384059215534 : Closed e2384059215534 ∧ code e2384059215534 = 11180152237742 := by decide
theorem cert_e2384059215534 : check e2384059215534 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2384059215546 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2384059215546 : Closed e2384059215546 ∧ code e2384059215546 = 11180152237754 := by decide
theorem cert_e2384059215546 : check e2384059215546 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2384059215594 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2384059215594 : Closed e2384059215594 ∧ code e2384059215594 = 11180152237802 := by decide
def e2384059215702 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2384059215702 : Closed e2384059215702 ∧ code e2384059215702 = 11180152237910 := by decide
theorem cert_e2384059215702 : check e2384059215702 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2384059215706 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2384059215706 : Closed e2384059215706 ∧ code e2384059215706 = 11180152237914 := by decide
theorem cert_e2384059215706 : check e2384059215706 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2384059215722 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2384059215722 : Closed e2384059215722 ∧ code e2384059215722 = 11180152237930 := by decide
theorem cert_e2384059215722 : check e2384059215722 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2384059216750 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2384059216750 : Closed e2384059216750 ∧ code e2384059216750 = 11180152238958 := by decide
theorem cert_e2384059216750 : check e2384059216750 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059216758 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2384059216758 : Closed e2384059216758 ∧ code e2384059216758 = 11180152238966 := by decide
theorem cert_e2384059216758 : check e2384059216758 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059216814 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2384059216814 : Closed e2384059216814 ∧ code e2384059216814 = 11180152239022 := by decide
theorem cert_e2384059216814 : check e2384059216814 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059216826 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2384059216826 : Closed e2384059216826 ∧ code e2384059216826 = 11180152239034 := by decide
theorem cert_e2384059216826 : check e2384059216826 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059216854 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2384059216854 : Closed e2384059216854 ∧ code e2384059216854 = 11180152239062 := by decide
theorem cert_e2384059216854 : check e2384059216854 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059216858 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2384059216858 : Closed e2384059216858 ∧ code e2384059216858 = 11180152239066 := by decide
theorem cert_e2384059216858 : check e2384059216858 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217134 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2384059217134 : Closed e2384059217134 ∧ code e2384059217134 = 11180152239342 := by decide
theorem cert_e2384059217134 : check e2384059217134 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217142 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2384059217142 : Closed e2384059217142 ∧ code e2384059217142 = 11180152239350 := by decide
theorem cert_e2384059217142 : check e2384059217142 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217518 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2384059217518 : Closed e2384059217518 ∧ code e2384059217518 = 11180152239726 := by decide
theorem cert_e2384059217518 : check e2384059217518 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217530 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2384059217530 : Closed e2384059217530 ∧ code e2384059217530 = 11180152239738 := by decide
theorem cert_e2384059217530 : check e2384059217530 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217718 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2384059217718 : Closed e2384059217718 ∧ code e2384059217718 = 11180152239926 := by decide
theorem cert_e2384059217718 : check e2384059217718 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059217722 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2384059217722 : Closed e2384059217722 ∧ code e2384059217722 = 11180152239930 := by decide
theorem cert_e2384059217722 : check e2384059217722 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059218350 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2384059218350 : Closed e2384059218350 ∧ code e2384059218350 = 11180152240558 := by decide
theorem cert_e2384059218350 : check e2384059218350 [[],[.left,.left],[.left],[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2384059218362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2384059218362 : Closed e2384059218362 ∧ code e2384059218362 = 11180152240570 := by decide
theorem cert_e2384059218362 : check e2384059218362 [[],[.left,.left],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e2384059218410 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2384059218410 : Closed e2384059218410 ∧ code e2384059218410 = 11180152240618 := by decide
theorem cert_e2384059218410 : check e2384059218410 [[],[.left,.left],[.left],[],[.left],[],[.under,.left]] .chain = true := by decide
def e2384059218542 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2384059218542 : Closed e2384059218542 ∧ code e2384059218542 = 11180152240750 := by decide
theorem cert_e2384059218542 : check e2384059218542 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2384059218554 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2384059218554 : Closed e2384059218554 ∧ code e2384059218554 = 11180152240762 := by decide
theorem cert_e2384059218554 : check e2384059218554 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2384059218842 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2384059218842 : Closed e2384059218842 ∧ code e2384059218842 = 11180152241050 := by decide
theorem cert_e2384059218842 : check e2384059218842 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2384059219158 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2384059219158 : Closed e2384059219158 ∧ code e2384059219158 = 11180152241366 := by decide
theorem cert_e2384059219158 : check e2384059219158 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2384059219162 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2384059219162 : Closed e2384059219162 ∧ code e2384059219162 = 11180152241370 := by decide
theorem cert_e2384059219162 : check e2384059219162 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2384059219178 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2384059219178 : Closed e2384059219178 ∧ code e2384059219178 = 11180152241386 := by decide
theorem cert_e2384059219178 : check e2384059219178 [[],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2384059219254 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2384059219254 : Closed e2384059219254 ∧ code e2384059219254 = 11180152241462 := by decide
theorem cert_e2384059219254 : check e2384059219254 [[],[.left,.left],[.left],[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2384059219258 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2384059219258 : Closed e2384059219258 ∧ code e2384059219258 = 11180152241466 := by decide
theorem cert_e2384059219258 : check e2384059219258 [[],[.left,.left],[.left],[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2384059219354 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2384059219354 : Closed e2384059219354 ∧ code e2384059219354 = 11180152241562 := by decide
theorem cert_e2384059219354 : check e2384059219354 [[],[.left,.left],[.left],[],[.left],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2384059222894 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384059222894 : Closed e2384059222894 ∧ code e2384059222894 = 11180152245102 := by decide
theorem cert_e2384059222894 : check e2384059222894 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2384059222902 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384059222902 : Closed e2384059222902 ∧ code e2384059222902 = 11180152245110 := by decide
theorem cert_e2384059222902 : checkPay e2384059222902 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2384059222958 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384059222958 : Closed e2384059222958 ∧ code e2384059222958 = 11180152245166 := by decide
theorem cert_e2384059222958 : check e2384059222958 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384059222970 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384059222970 : Closed e2384059222970 ∧ code e2384059222970 = 11180152245178 := by decide
theorem cert_e2384059222970 : check e2384059222970 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384059222998 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384059222998 : Closed e2384059222998 ∧ code e2384059222998 = 11180152245206 := by decide
theorem cert_e2384059222998 : check e2384059222998 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2384059223002 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384059223002 : Closed e2384059223002 ∧ code e2384059223002 = 11180152245210 := by decide
theorem cert_e2384059223002 : check e2384059223002 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2384059223278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384059223278 : Closed e2384059223278 ∧ code e2384059223278 = 11180152245486 := by decide
theorem cert_e2384059223278 : check e2384059223278 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2384059223286 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384059223286 : Closed e2384059223286 ∧ code e2384059223286 = 11180152245494 := by decide
theorem cert_e2384059223286 : check e2384059223286 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2384059223662 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384059223662 : Closed e2384059223662 ∧ code e2384059223662 = 11180152245870 := by decide
theorem cert_e2384059223662 : check e2384059223662 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384059223674 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384059223674 : Closed e2384059223674 ∧ code e2384059223674 = 11180152245882 := by decide
theorem cert_e2384059223674 : check e2384059223674 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2384059223862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384059223862 : Closed e2384059223862 ∧ code e2384059223862 = 11180152246070 := by decide
theorem cert_e2384059223862 : check e2384059223862 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2384059223866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384059223866 : Closed e2384059223866 ∧ code e2384059223866 = 11180152246074 := by decide
theorem cert_e2384059223866 : check e2384059223866 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2384059229614 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2384059229614 : Closed e2384059229614 ∧ code e2384059229614 = 11180152251822 := by decide
theorem cert_e2384059229614 : check e2384059229614 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059229626 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2384059229626 : Closed e2384059229626 ∧ code e2384059229626 = 11180152251834 := by decide
theorem cert_e2384059229626 : check e2384059229626 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059229674 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2384059229674 : Closed e2384059229674 ∧ code e2384059229674 = 11180152251882 := by decide
theorem cert_e2384059229674 : check e2384059229674 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059229806 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2384059229806 : Closed e2384059229806 ∧ code e2384059229806 = 11180152252014 := by decide
theorem cert_e2384059229806 : check e2384059229806 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059229818 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2384059229818 : Closed e2384059229818 ∧ code e2384059229818 = 11180152252026 := by decide
theorem cert_e2384059229818 : check e2384059229818 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059230106 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2384059230106 : Closed e2384059230106 ∧ code e2384059230106 = 11180152252314 := by decide
theorem cert_e2384059230106 : check e2384059230106 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059232982 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2384059232982 : Closed e2384059232982 ∧ code e2384059232982 = 11180152255190 := by decide
theorem cert_e2384059232982 : check e2384059232982 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384059232986 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2384059232986 : Closed e2384059232986 ∧ code e2384059232986 = 11180152255194 := by decide
theorem cert_e2384059232986 : check e2384059232986 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384059233002 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2384059233002 : Closed e2384059233002 ∧ code e2384059233002 = 11180152255210 := by decide
theorem cert_e2384059233002 : check e2384059233002 [[],[.left,.left],[.left],[],[],[.left],[],[.under]] .three = true := by decide
def e2384059233078 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2384059233078 : Closed e2384059233078 ∧ code e2384059233078 = 11180152255286 := by decide
theorem cert_e2384059233078 : check e2384059233078 [[],[.left,.left],[.left],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e2384059233082 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2384059233082 : Closed e2384059233082 ∧ code e2384059233082 = 11180152255290 := by decide
theorem cert_e2384059233082 : check e2384059233082 [[],[.left,.left],[.left],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e2384059233178 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2384059233178 : Closed e2384059233178 ∧ code e2384059233178 = 11180152255386 := by decide
theorem cert_e2384059233178 : check e2384059233178 [[],[.left,.left],[.left],[],[],[],[.under,.under,.left]] .chain = true := by decide
def e2384059370350 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384059370350 : Closed e2384059370350 ∧ code e2384059370350 = 11180152392558 := by decide
theorem cert_e2384059370350 : check e2384059370350 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370358 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384059370358 : Closed e2384059370358 ∧ code e2384059370358 = 11180152392566 := by decide
theorem cert_e2384059370358 : check e2384059370358 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370414 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384059370414 : Closed e2384059370414 ∧ code e2384059370414 = 11180152392622 := by decide
theorem cert_e2384059370414 : check e2384059370414 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370426 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384059370426 : Closed e2384059370426 ∧ code e2384059370426 = 11180152392634 := by decide
theorem cert_e2384059370426 : check e2384059370426 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370454 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384059370454 : Closed e2384059370454 ∧ code e2384059370454 = 11180152392662 := by decide
theorem cert_e2384059370454 : check e2384059370454 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370458 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384059370458 : Closed e2384059370458 ∧ code e2384059370458 = 11180152392666 := by decide
theorem cert_e2384059370458 : check e2384059370458 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370734 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384059370734 : Closed e2384059370734 ∧ code e2384059370734 = 11180152392942 := by decide
theorem cert_e2384059370734 : check e2384059370734 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059370742 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384059370742 : Closed e2384059370742 ∧ code e2384059370742 = 11180152392950 := by decide
theorem cert_e2384059370742 : check e2384059370742 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059371118 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384059371118 : Closed e2384059371118 ∧ code e2384059371118 = 11180152393326 := by decide
theorem cert_e2384059371118 : check e2384059371118 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059371130 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384059371130 : Closed e2384059371130 ∧ code e2384059371130 = 11180152393338 := by decide
theorem cert_e2384059371130 : check e2384059371130 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059371318 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384059371318 : Closed e2384059371318 ∧ code e2384059371318 = 11180152393526 := by decide
theorem cert_e2384059371318 : check e2384059371318 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059371322 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384059371322 : Closed e2384059371322 ∧ code e2384059371322 = 11180152393530 := by decide
theorem cert_e2384059371322 : check e2384059371322 [[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2384059960174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2384059960174 : Closed e2384059960174 ∧ code e2384059960174 = 11180152982382 := by decide
theorem cert_e2384059960174 : check e2384059960174 [[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384059960182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2384059960182 : Closed e2384059960182 ∧ code e2384059960182 = 11180152982390 := by decide
theorem cert_e2384059960182 : check e2384059960182 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2384059960238 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2384059960238 : Closed e2384059960238 ∧ code e2384059960238 = 11180152982446 := by decide
theorem cert_e2384059960238 : check e2384059960238 [[],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2384059960250 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2384059960250 : Closed e2384059960250 ∧ code e2384059960250 = 11180152982458 := by decide
theorem cert_e2384059960250 : check e2384059960250 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2384059960278 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2384059960278 : Closed e2384059960278 ∧ code e2384059960278 = 11180152982486 := by decide
theorem cert_e2384059960278 : check e2384059960278 [[],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e2384059960282 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2384059960282 : Closed e2384059960282 ∧ code e2384059960282 = 11180152982490 := by decide
private def t_e2384059960282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2384059960282 : ¬ IsSelfInterpreter e2384059960282 :=
  wSource (t := t_e2384059960282) (replay_sound (ps := [[],[.left,.left],[.left,.left],[.left],[],[.left]]) (t := e2384059960282) (by decide)) (by decide)
def e2384059960558 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2384059960558 : Closed e2384059960558 ∧ code e2384059960558 = 11180152982766 := by decide
theorem cert_e2384059960558 : check e2384059960558 [[],[.left,.left],[.left,.left],[.left],[],[],[.left]] .chain = true := by decide
def e2384059960566 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2384059960566 : Closed e2384059960566 ∧ code e2384059960566 = 11180152982774 := by decide
theorem cert_e2384059960566 : check e2384059960566 [[],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2384059960942 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2384059960942 : Closed e2384059960942 ∧ code e2384059960942 = 11180152983150 := by decide
theorem cert_e2384059960942 : check e2384059960942 [[],[.left,.left],[.left,.left],[.left],[],[],[.left]] .chain = true := by decide
def e2384059960954 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2384059960954 : Closed e2384059960954 ∧ code e2384059960954 = 11180152983162 := by decide
theorem cert_e2384059960954 : check e2384059960954 [[],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2384059961142 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2384059961142 : Closed e2384059961142 ∧ code e2384059961142 = 11180152983350 := by decide
theorem cert_e2384059961142 : check e2384059961142 [[],[.left,.left],[.left,.left],[.left],[],[],[],[],[],[.under]] .sourceHead = true := by decide
def e2384059961146 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2384059961146 : Closed e2384059961146 ∧ code e2384059961146 = 11180152983354 := by decide
theorem cert_e2384059961146 : check e2384059961146 [[],[.left,.left],[.left,.left],[.left],[],[],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e2384783587866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783587866 : Closed e2384783587866 ∧ code e2384783587866 = 11180876610074 := by decide
private def t_e2384783587866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783587866 : ¬ IsSelfInterpreter e2384783587866 :=
  wSource (t := t_e2384783587866) (replay_sound (ps := []) (t := e2384783587866) (by decide)) (by decide)
def e2384783596058 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783596058 : Closed e2384783596058 ∧ code e2384783596058 = 11180876618266 := by decide
private def t_e2384783596058 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783596058 : ¬ IsSelfInterpreter e2384783596058 :=
  wSource (t := t_e2384783596058) (replay_sound (ps := []) (t := e2384783596058) (by decide)) (by decide)
def e2384783653402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783653402 : Closed e2384783653402 ∧ code e2384783653402 = 11180876675610 := by decide
private def t_e2384783653402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783653402 : ¬ IsSelfInterpreter e2384783653402 :=
  wSource (t := t_e2384783653402) (replay_sound (ps := []) (t := e2384783653402) (by decide)) (by decide)
def e2384783665690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783665690 : Closed e2384783665690 ∧ code e2384783665690 = 11180876687898 := by decide
private def t_e2384783665690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783665690 : ¬ IsSelfInterpreter e2384783665690 :=
  wSource (t := t_e2384783665690) (replay_sound (ps := []) (t := e2384783665690) (by decide)) (by decide)
def e2384783694362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783694362 : Closed e2384783694362 ∧ code e2384783694362 = 11180876716570 := by decide
private def t_e2384783694362 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783694362 : ¬ IsSelfInterpreter e2384783694362 :=
  wSource (t := t_e2384783694362) (replay_sound (ps := []) (t := e2384783694362) (by decide)) (by decide)
def e2384783698458 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783698458 : Closed e2384783698458 ∧ code e2384783698458 = 11180876720666 := by decide
private def t_e2384783698458 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783698458 : ¬ IsSelfInterpreter e2384783698458 :=
  wSource (t := t_e2384783698458) (replay_sound (ps := []) (t := e2384783698458) (by decide)) (by decide)
def e2384783981082 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783981082 : Closed e2384783981082 ∧ code e2384783981082 = 11180877003290 := by decide
private def t_e2384783981082 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783981082 : ¬ IsSelfInterpreter e2384783981082 :=
  wSource (t := t_e2384783981082) (replay_sound (ps := []) (t := e2384783981082) (by decide)) (by decide)
def e2384783989274 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384783989274 : Closed e2384783989274 ∧ code e2384783989274 = 11180877011482 := by decide
private def t_e2384783989274 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384783989274 : ¬ IsSelfInterpreter e2384783989274 :=
  wSource (t := t_e2384783989274) (replay_sound (ps := []) (t := e2384783989274) (by decide)) (by decide)
def e2384784374298 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384784374298 : Closed e2384784374298 ∧ code e2384784374298 = 11180877396506 := by decide
private def t_e2384784374298 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384784374298 : ¬ IsSelfInterpreter e2384784374298 :=
  wSource (t := t_e2384784374298) (replay_sound (ps := []) (t := e2384784374298) (by decide)) (by decide)
def e2384784386586 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384784386586 : Closed e2384784386586 ∧ code e2384784386586 = 11180877408794 := by decide
private def t_e2384784386586 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384784386586 : ¬ IsSelfInterpreter e2384784386586 :=
  wSource (t := t_e2384784386586) (replay_sound (ps := []) (t := e2384784386586) (by decide)) (by decide)
def e2384784579098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384784579098 : Closed e2384784579098 ∧ code e2384784579098 = 11180877601306 := by decide
private def t_e2384784579098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384784579098 : ¬ IsSelfInterpreter e2384784579098 :=
  wSource (t := t_e2384784579098) (replay_sound (ps := []) (t := e2384784579098) (by decide)) (by decide)
def e2384784583194 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384784583194 : Closed e2384784583194 ∧ code e2384784583194 = 11180877605402 := by decide
private def t_e2384784583194 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384784583194 : ¬ IsSelfInterpreter e2384784583194 :=
  wSource (t := t_e2384784583194) (replay_sound (ps := []) (t := e2384784583194) (by decide)) (by decide)
def e2384792576538 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384792576538 : Closed e2384792576538 ∧ code e2384792576538 = 11180885598746 := by decide
private def t_e2384792576538 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384792576538 : ¬ IsSelfInterpreter e2384792576538 :=
  wSource (t := t_e2384792576538) (replay_sound (ps := []) (t := e2384792576538) (by decide)) (by decide)
def e2384792578074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384792578074 : Closed e2384792578074 ∧ code e2384792578074 = 11180885600282 := by decide
theorem cert_e2384792578074 : check e2384792578074 [[]] .width = true := by decide
def e2384792609306 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384792609306 : Closed e2384792609306 ∧ code e2384792609306 = 11180885631514 := by decide
private def t_e2384792609306 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384792609306 : ¬ IsSelfInterpreter e2384792609306 :=
  wSource (t := t_e2384792609306) (replay_sound (ps := []) (t := e2384792609306) (by decide)) (by decide)
def e2384792610842 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384792610842 : Closed e2384792610842 ∧ code e2384792610842 = 11180885633050 := by decide
theorem cert_e2384792610842 : check e2384792610842 [[]] .width = true := by decide
def e2384792838682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384792838682 : Closed e2384792838682 ∧ code e2384792838682 = 11180885860890 := by decide
private def t_e2384792838682 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384792838682 : ¬ IsSelfInterpreter e2384792838682 :=
  wSource (t := t_e2384792838682) (replay_sound (ps := []) (t := e2384792838682) (by decide)) (by decide)
def e2384792840218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384792840218 : Closed e2384792840218 ∧ code e2384792840218 = 11180885862426 := by decide
theorem cert_e2384792840218 : check e2384792840218 [[]] .width = true := by decide
def e2384792887834 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384792887834 : Closed e2384792887834 ∧ code e2384792887834 = 11180885910042 := by decide
private def t_e2384792887834 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384792887834 : ¬ IsSelfInterpreter e2384792887834 :=
  wSource (t := t_e2384792887834) (replay_sound (ps := []) (t := e2384792887834) (by decide)) (by decide)
def e2384792889370 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384792889370 : Closed e2384792889370 ∧ code e2384792889370 = 11180885911578 := by decide
theorem cert_e2384792889370 : check e2384792889370 [[]] .width = true := by decide
def e2384793002522 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384793002522 : Closed e2384793002522 ∧ code e2384793002522 = 11180886024730 := by decide
private def t_e2384793002522 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384793002522 : ¬ IsSelfInterpreter e2384793002522 :=
  wSource (t := t_e2384793002522) (replay_sound (ps := []) (t := e2384793002522) (by decide)) (by decide)
def e2384793004058 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384793004058 : Closed e2384793004058 ∧ code e2384793004058 = 11180886026266 := by decide
theorem cert_e2384793004058 : check e2384793004058 [[]] .width = true := by decide
def e2384793018906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384793018906 : Closed e2384793018906 ∧ code e2384793018906 = 11180886041114 := by decide
private def t_e2384793018906 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384793018906 : ¬ IsSelfInterpreter e2384793018906 :=
  wSource (t := t_e2384793018906) (replay_sound (ps := []) (t := e2384793018906) (by decide)) (by decide)
def e2384793020442 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384793020442 : Closed e2384793020442 ∧ code e2384793020442 = 11180886042650 := by decide
theorem cert_e2384793020442 : check e2384793020442 [[]] .width = true := by decide
def e2384794149402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384794149402 : Closed e2384794149402 ∧ code e2384794149402 = 11180887171610 := by decide
private def t_e2384794149402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384794149402 : ¬ IsSelfInterpreter e2384794149402 :=
  wSource (t := t_e2384794149402) (replay_sound (ps := []) (t := e2384794149402) (by decide)) (by decide)
def e2384794150938 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384794150938 : Closed e2384794150938 ∧ code e2384794150938 = 11180887173146 := by decide
theorem cert_e2384794150938 : check e2384794150938 [[]] .width = true := by decide
def e2384794182170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384794182170 : Closed e2384794182170 ∧ code e2384794182170 = 11180887204378 := by decide
private def t_e2384794182170 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384794182170 : ¬ IsSelfInterpreter e2384794182170 :=
  wSource (t := t_e2384794182170) (replay_sound (ps := []) (t := e2384794182170) (by decide)) (by decide)
def e2384794183706 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384794183706 : Closed e2384794183706 ∧ code e2384794183706 = 11180887205914 := by decide
theorem cert_e2384794183706 : check e2384794183706 [[]] .width = true := by decide
def e2384795722266 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384795722266 : Closed e2384795722266 ∧ code e2384795722266 = 11180888744474 := by decide
private def t_e2384795722266 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384795722266 : ¬ IsSelfInterpreter e2384795722266 :=
  wSource (t := t_e2384795722266) (replay_sound (ps := []) (t := e2384795722266) (by decide)) (by decide)
def e2384795723802 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384795723802 : Closed e2384795723802 ∧ code e2384795723802 = 11180888746010 := by decide
theorem cert_e2384795723802 : check e2384795723802 [[]] .width = true := by decide
def e2384795771418 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384795771418 : Closed e2384795771418 ∧ code e2384795771418 = 11180888793626 := by decide
private def t_e2384795771418 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384795771418 : ¬ IsSelfInterpreter e2384795771418 :=
  wSource (t := t_e2384795771418) (replay_sound (ps := []) (t := e2384795771418) (by decide)) (by decide)
def e2384795772954 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384795772954 : Closed e2384795772954 ∧ code e2384795772954 = 11180888795162 := by decide
theorem cert_e2384795772954 : check e2384795772954 [[]] .width = true := by decide
def e2384796541466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384796541466 : Closed e2384796541466 ∧ code e2384796541466 = 11180889563674 := by decide
private def t_e2384796541466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384796541466 : ¬ IsSelfInterpreter e2384796541466 :=
  wSource (t := t_e2384796541466) (replay_sound (ps := []) (t := e2384796541466) (by decide)) (by decide)
def e2384796543002 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384796543002 : Closed e2384796543002 ∧ code e2384796543002 = 11180889565210 := by decide
theorem cert_e2384796543002 : check e2384796543002 [[]] .width = true := by decide
def e2384796557850 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384796557850 : Closed e2384796557850 ∧ code e2384796557850 = 11180889580058 := by decide
private def t_e2384796557850 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384796557850 : ¬ IsSelfInterpreter e2384796557850 :=
  wSource (t := t_e2384796557850) (replay_sound (ps := []) (t := e2384796557850) (by decide)) (by decide)
def e2384796559386 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2384796559386 : Closed e2384796559386 ∧ code e2384796559386 = 11180889581594 := by decide
theorem cert_e2384796559386 : check e2384796559386 [[]] .width = true := by decide
def e2384848449050 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848449050 : Closed e2384848449050 ∧ code e2384848449050 = 11180941471258 := by decide
private def t_e2384848449050 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848449050 : ¬ IsSelfInterpreter e2384848449050 :=
  wSource (t := t_e2384848449050) (replay_sound (ps := []) (t := e2384848449050) (by decide)) (by decide)
def e2384848451098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848451098 : Closed e2384848451098 ∧ code e2384848451098 = 11180941473306 := by decide
private def t_e2384848451098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848451098 : ¬ IsSelfInterpreter e2384848451098 :=
  wSource (t := t_e2384848451098) (replay_sound (ps := []) (t := e2384848451098) (by decide)) (by decide)
def e2384848465434 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848465434 : Closed e2384848465434 ∧ code e2384848465434 = 11180941487642 := by decide
private def t_e2384848465434 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848465434 : ¬ IsSelfInterpreter e2384848465434 :=
  wSource (t := t_e2384848465434) (replay_sound (ps := []) (t := e2384848465434) (by decide)) (by decide)
def e2384848468506 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848468506 : Closed e2384848468506 ∧ code e2384848468506 = 11180941490714 := by decide
private def t_e2384848468506 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848468506 : ¬ IsSelfInterpreter e2384848468506 :=
  wSource (t := t_e2384848468506) (replay_sound (ps := []) (t := e2384848468506) (by decide)) (by decide)
def e2384848475674 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848475674 : Closed e2384848475674 ∧ code e2384848475674 = 11180941497882 := by decide
private def t_e2384848475674 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848475674 : ¬ IsSelfInterpreter e2384848475674 :=
  wSource (t := t_e2384848475674) (replay_sound (ps := []) (t := e2384848475674) (by decide)) (by decide)
def e2384848476698 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848476698 : Closed e2384848476698 ∧ code e2384848476698 = 11180941498906 := by decide
private def t_e2384848476698 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848476698 : ¬ IsSelfInterpreter e2384848476698 :=
  wSource (t := t_e2384848476698) (replay_sound (ps := []) (t := e2384848476698) (by decide)) (by decide)
def e2384848547354 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848547354 : Closed e2384848547354 ∧ code e2384848547354 = 11180941569562 := by decide
private def t_e2384848547354 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848547354 : ¬ IsSelfInterpreter e2384848547354 :=
  wSource (t := t_e2384848547354) (replay_sound (ps := []) (t := e2384848547354) (by decide)) (by decide)
def e2384848549402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848549402 : Closed e2384848549402 ∧ code e2384848549402 = 11180941571610 := by decide
private def t_e2384848549402 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848549402 : ¬ IsSelfInterpreter e2384848549402 :=
  wSource (t := t_e2384848549402) (replay_sound (ps := []) (t := e2384848549402) (by decide)) (by decide)
def e2384848645658 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848645658 : Closed e2384848645658 ∧ code e2384848645658 = 11180941667866 := by decide
private def t_e2384848645658 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848645658 : ¬ IsSelfInterpreter e2384848645658 :=
  wSource (t := t_e2384848645658) (replay_sound (ps := []) (t := e2384848645658) (by decide)) (by decide)
def e2384848648730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848648730 : Closed e2384848648730 ∧ code e2384848648730 = 11180941670938 := by decide
private def t_e2384848648730 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848648730 : ¬ IsSelfInterpreter e2384848648730 :=
  wSource (t := t_e2384848648730) (replay_sound (ps := []) (t := e2384848648730) (by decide)) (by decide)
def e2384848696858 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848696858 : Closed e2384848696858 ∧ code e2384848696858 = 11180941719066 := by decide
private def t_e2384848696858 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848696858 : ¬ IsSelfInterpreter e2384848696858 :=
  wSource (t := t_e2384848696858) (replay_sound (ps := []) (t := e2384848696858) (by decide)) (by decide)
def e2384848697882 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2384848697882 : Closed e2384848697882 ∧ code e2384848697882 = 11180941720090 := by decide
private def t_e2384848697882 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2384848697882 : ¬ IsSelfInterpreter e2384848697882 :=
  wSource (t := t_e2384848697882) (replay_sound (ps := []) (t := e2384848697882) (by decide)) (by decide)
def e2384864521582 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2384864521582 : Closed e2384864521582 ∧ code e2384864521582 = 11180957543790 := by decide
def e2384864521590 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2384864521590 : Closed e2384864521590 ∧ code e2384864521590 = 11180957543798 := by decide
theorem cert_e2384864521590 : check e2384864521590 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384864521646 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2384864521646 : Closed e2384864521646 ∧ code e2384864521646 = 11180957543854 := by decide
theorem cert_e2384864521646 : check e2384864521646 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384864521658 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2384864521658 : Closed e2384864521658 ∧ code e2384864521658 = 11180957543866 := by decide
def e2384864521686 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2384864521686 : Closed e2384864521686 ∧ code e2384864521686 = 11180957543894 := by decide
theorem cert_e2384864521686 : check e2384864521686 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] .smaller = true := by decide
def e2384864521690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2384864521690 : Closed e2384864521690 ∧ code e2384864521690 = 11180957543898 := by decide
def e2384864521902 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2384864521902 : Closed e2384864521902 ∧ code e2384864521902 = 11180957544110 := by decide
theorem cert_e2384864521902 : check e2384864521902 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2384864521914 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2384864521914 : Closed e2384864521914 ∧ code e2384864521914 = 11180957544122 := by decide
theorem cert_e2384864521914 : check e2384864521914 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2384864521962 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2384864521962 : Closed e2384864521962 ∧ code e2384864521962 = 11180957544170 := by decide
theorem cert_e2384864521962 : check e2384864521962 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2384864522070 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2384864522070 : Closed e2384864522070 ∧ code e2384864522070 = 11180957544278 := by decide
theorem cert_e2384864522070 : check e2384864522070 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left]] .chain = true := by decide
def e2384864522074 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2384864522074 : Closed e2384864522074 ∧ code e2384864522074 = 11180957544282 := by decide
def e2384864522090 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2384864522090 : Closed e2384864522090 ∧ code e2384864522090 = 11180957544298 := by decide
theorem cert_e2384864522090 : check e2384864522090 [[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2384864523118 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2384864523118 : Closed e2384864523118 ∧ code e2384864523118 = 11180957545326 := by decide
theorem cert_e2384864523118 : check e2384864523118 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523126 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2384864523126 : Closed e2384864523126 ∧ code e2384864523126 = 11180957545334 := by decide
theorem cert_e2384864523126 : check e2384864523126 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2384864523182 : Closed e2384864523182 ∧ code e2384864523182 = 11180957545390 := by decide
theorem cert_e2384864523182 : check e2384864523182 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523194 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2384864523194 : Closed e2384864523194 ∧ code e2384864523194 = 11180957545402 := by decide
theorem cert_e2384864523194 : check e2384864523194 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523222 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2384864523222 : Closed e2384864523222 ∧ code e2384864523222 = 11180957545430 := by decide
theorem cert_e2384864523222 : check e2384864523222 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523226 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2384864523226 : Closed e2384864523226 ∧ code e2384864523226 = 11180957545434 := by decide
theorem cert_e2384864523226 : check e2384864523226 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523502 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2384864523502 : Closed e2384864523502 ∧ code e2384864523502 = 11180957545710 := by decide
theorem cert_e2384864523502 : check e2384864523502 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523510 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2384864523510 : Closed e2384864523510 ∧ code e2384864523510 = 11180957545718 := by decide
theorem cert_e2384864523510 : check e2384864523510 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523886 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2384864523886 : Closed e2384864523886 ∧ code e2384864523886 = 11180957546094 := by decide
theorem cert_e2384864523886 : check e2384864523886 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864523898 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2384864523898 : Closed e2384864523898 ∧ code e2384864523898 = 11180957546106 := by decide
theorem cert_e2384864523898 : check e2384864523898 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864524086 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2384864524086 : Closed e2384864524086 ∧ code e2384864524086 = 11180957546294 := by decide
theorem cert_e2384864524086 : check e2384864524086 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2384864524090 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2384864524090 : Closed e2384864524090 ∧ code e2384864524090 = 11180957546298 := by decide
theorem cert_e2384864524090 : check e2384864524090 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2384059960282
#print axioms Blc.Floor43.cert_e2384783587866
#print axioms Blc.Floor43.cert_e2384783596058
#print axioms Blc.Floor43.cert_e2384783653402
#print axioms Blc.Floor43.cert_e2384783665690
#print axioms Blc.Floor43.cert_e2384783694362
#print axioms Blc.Floor43.cert_e2384783698458
#print axioms Blc.Floor43.cert_e2384783981082
#print axioms Blc.Floor43.cert_e2384783989274
#print axioms Blc.Floor43.cert_e2384784374298
#print axioms Blc.Floor43.cert_e2384784386586
#print axioms Blc.Floor43.cert_e2384784579098
#print axioms Blc.Floor43.cert_e2384784583194
#print axioms Blc.Floor43.cert_e2384792576538
#print axioms Blc.Floor43.cert_e2384792609306
#print axioms Blc.Floor43.cert_e2384792838682
#print axioms Blc.Floor43.cert_e2384792887834
#print axioms Blc.Floor43.cert_e2384793002522
#print axioms Blc.Floor43.cert_e2384793018906
#print axioms Blc.Floor43.cert_e2384794149402
#print axioms Blc.Floor43.cert_e2384794182170
#print axioms Blc.Floor43.cert_e2384795722266
#print axioms Blc.Floor43.cert_e2384795771418
#print axioms Blc.Floor43.cert_e2384796541466
#print axioms Blc.Floor43.cert_e2384796557850
#print axioms Blc.Floor43.cert_e2384848449050
#print axioms Blc.Floor43.cert_e2384848451098
#print axioms Blc.Floor43.cert_e2384848465434
#print axioms Blc.Floor43.cert_e2384848468506
#print axioms Blc.Floor43.cert_e2384848475674
#print axioms Blc.Floor43.cert_e2384848476698
#print axioms Blc.Floor43.cert_e2384848547354
#print axioms Blc.Floor43.cert_e2384848549402
#print axioms Blc.Floor43.cert_e2384848645658
#print axioms Blc.Floor43.cert_e2384848648730
#print axioms Blc.Floor43.cert_e2384848696858
#print axioms Blc.Floor43.cert_e2384848697882
