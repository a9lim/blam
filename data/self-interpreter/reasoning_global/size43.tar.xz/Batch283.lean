import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408807160942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2408807160942 : Closed e2408807160942 ∧ code e2408807160942 = 11204900183150 := by decide
theorem cert_e2408807160942 : check e2408807160942 [[],[]] .chain = true := by decide
def e2408807160954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2408807160954 : Closed e2408807160954 ∧ code e2408807160954 = 11204900183162 := by decide
theorem cert_e2408807160954 : check e2408807160954 [[],[]] .chain = true := by decide
def e2408807161118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2408807161118 : Closed e2408807161118 ∧ code e2408807161118 = 11204900183326 := by decide
theorem cert_e2408807161118 : check e2408807161118 [[],[]] .chain = true := by decide
def e2408807161286 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2408807161286 : Closed e2408807161286 ∧ code e2408807161286 = 11204900183494 := by decide
theorem cert_e2408807161286 : check e2408807161286 [[],[]] .chain = true := by decide
def e2408807161398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2408807161398 : Closed e2408807161398 ∧ code e2408807161398 = 11204900183606 := by decide
theorem cert_e2408807161398 : check e2408807161398 [[],[]] .chain = true := by decide
def e2408807161402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2408807161402 : Closed e2408807161402 ∧ code e2408807161402 = 11204900183610 := by decide
theorem cert_e2408807161402 : check e2408807161402 [[],[]] .chain = true := by decide
def e2408807161486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2408807161486 : Closed e2408807161486 ∧ code e2408807161486 = 11204900183694 := by decide
theorem cert_e2408807161486 : check e2408807161486 [[],[]] .chain = true := by decide
def e2408807161542 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2408807161542 : Closed e2408807161542 ∧ code e2408807161542 = 11204900183750 := by decide
theorem cert_e2408807161542 : check e2408807161542 [[],[]] .chain = true := by decide
def e2408807163678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2408807163678 : Closed e2408807163678 ∧ code e2408807163678 = 11204900185886 := by decide
theorem cert_e2408807163678 : check e2408807163678 [[],[]] .chain = true := by decide
def e2408807163790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2408807163790 : Closed e2408807163790 ∧ code e2408807163790 = 11204900185998 := by decide
theorem cert_e2408807163790 : check e2408807163790 [[],[]] .chain = true := by decide
def e2408807166750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2408807166750 : Closed e2408807166750 ∧ code e2408807166750 = 11204900188958 := by decide
theorem cert_e2408807166750 : check e2408807166750 [[],[]] .chain = true := by decide
def e2408807166918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2408807166918 : Closed e2408807166918 ∧ code e2408807166918 = 11204900189126 := by decide
theorem cert_e2408807166918 : check e2408807166918 [[],[]] .chain = true := by decide
def e2408807168398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2408807168398 : Closed e2408807168398 ∧ code e2408807168398 = 11204900190606 := by decide
theorem cert_e2408807168398 : check e2408807168398 [[],[]] .chain = true := by decide
def e2408807168454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2408807168454 : Closed e2408807168454 ∧ code e2408807168454 = 11204900190662 := by decide
theorem cert_e2408807168454 : check e2408807168454 [[],[]] .chain = true := by decide
def e2408811861726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2408811861726 : Closed e2408811861726 ∧ code e2408811861726 = 11204904883934 := by decide
theorem cert_e2408811861726 : check e2408811861726 [[],[],[],[]] .chain = true := by decide
def e2408811861750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2408811861750 : Closed e2408811861750 ∧ code e2408811861750 = 11204904883958 := by decide
theorem cert_e2408811861750 : check e2408811861750 [[],[],[],[]] .chain = true := by decide
def e2408811861854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2408811861854 : Closed e2408811861854 ∧ code e2408811861854 = 11204904884062 := by decide
theorem cert_e2408811861854 : check e2408811861854 [[],[],[],[]] .chain = true := by decide
def e2408811861882 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2408811861882 : Closed e2408811861882 ∧ code e2408811861882 = 11204904884090 := by decide
theorem cert_e2408811861882 : check e2408811861882 [[],[],[],[]] .chain = true := by decide
def e2408811861974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2408811861974 : Closed e2408811861974 ∧ code e2408811861974 = 11204904884182 := by decide
theorem cert_e2408811861974 : check e2408811861974 [[],[],[],[]] .chain = true := by decide
def e2408811861978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2408811861978 : Closed e2408811861978 ∧ code e2408811861978 = 11204904884186 := by decide
theorem cert_e2408811861978 : check e2408811861978 [[],[],[],[]] .chain = true := by decide
def e2408811862494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2408811862494 : Closed e2408811862494 ∧ code e2408811862494 = 11204904884702 := by decide
theorem cert_e2408811862494 : check e2408811862494 [[],[],[],[]] .chain = true := by decide
def e2408811862518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2408811862518 : Closed e2408811862518 ∧ code e2408811862518 = 11204904884726 := by decide
theorem cert_e2408811862518 : check e2408811862518 [[],[],[],[]] .chain = true := by decide
def e2408811863262 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2408811863262 : Closed e2408811863262 ∧ code e2408811863262 = 11204904885470 := by decide
theorem cert_e2408811863262 : check e2408811863262 [[],[],[],[]] .chain = true := by decide
def e2408811863290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2408811863290 : Closed e2408811863290 ∧ code e2408811863290 = 11204904885498 := by decide
theorem cert_e2408811863290 : check e2408811863290 [[],[],[],[]] .chain = true := by decide
def e2408811863862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2408811863862 : Closed e2408811863862 ∧ code e2408811863862 = 11204904886070 := by decide
theorem cert_e2408811863862 : check e2408811863862 [[],[],[],[]] .chain = true := by decide
def e2408811863866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2408811863866 : Closed e2408811863866 ∧ code e2408811863866 = 11204904886074 := by decide
theorem cert_e2408811863866 : check e2408811863866 [[],[],[],[]] .chain = true := by decide
def e2408811878638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2408811878638 : Closed e2408811878638 ∧ code e2408811878638 = 11204904900846 := by decide
theorem cert_e2408811878638 : check e2408811878638 [[],[],[],[]] .sourceHead = true := by decide
def e2408811878646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2408811878646 : Closed e2408811878646 ∧ code e2408811878646 = 11204904900854 := by decide
theorem cert_e2408811878646 : check e2408811878646 [[],[],[],[]] .sourceHead = true := by decide
def e2408811879198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2408811879198 : Closed e2408811879198 ∧ code e2408811879198 = 11204904901406 := by decide
theorem cert_e2408811879198 : check e2408811879198 [[],[],[],[]] .sourceHead = true := by decide
def e2408811879310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2408811879310 : Closed e2408811879310 ∧ code e2408811879310 = 11204904901518 := by decide
theorem cert_e2408811879310 : check e2408811879310 [[],[],[],[]] .sourceHead = true := by decide
def e2408811879534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2408811879534 : Closed e2408811879534 ∧ code e2408811879534 = 11204904901742 := by decide
theorem cert_e2408811879534 : check e2408811879534 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e2408811879546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2408811879546 : Closed e2408811879546 ∧ code e2408811879546 = 11204904901754 := by decide
theorem cert_e2408811879546 : check e2408811879546 [[],[],[],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2408811879710 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2408811879710 : Closed e2408811879710 ∧ code e2408811879710 = 11204904901918 := by decide
theorem cert_e2408811879710 : check e2408811879710 [[],[],[],[],[.under,.left]] .chain = true := by decide
def e2408811879878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2408811879878 : Closed e2408811879878 ∧ code e2408811879878 = 11204904902086 := by decide
private def t_e2408811879878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e2408811879878 : ¬ IsSelfInterpreter e2408811879878 :=
  wSource (t := t_e2408811879878) (replay_sound (ps := []) (t := e2408811879878) (by decide)) (by decide)
def e2408811879990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2408811879990 : Closed e2408811879990 ∧ code e2408811879990 = 11204904902198 := by decide
theorem cert_e2408811879990 : check e2408811879990 [[],[],[],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2408811879994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2408811879994 : Closed e2408811879994 ∧ code e2408811879994 = 11204904902202 := by decide
theorem cert_e2408811879994 : check e2408811879994 [[],[],[],[],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2408811880078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2408811880078 : Closed e2408811880078 ∧ code e2408811880078 = 11204904902286 := by decide
theorem cert_e2408811880078 : check e2408811880078 [[],[],[],[],[.under,.left]] .sourceHead = true := by decide
def e2408811880134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2408811880134 : Closed e2408811880134 ∧ code e2408811880134 = 11204904902342 := by decide
private def t_e2408811880134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e2408811880134 : ¬ IsSelfInterpreter e2408811880134 :=
  wSource (t := t_e2408811880134) (replay_sound (ps := []) (t := e2408811880134) (by decide)) (by decide)
def e2408811882270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2408811882270 : Closed e2408811882270 ∧ code e2408811882270 = 11204904904478 := by decide
theorem cert_e2408811882270 : check e2408811882270 [[],[],[],[]] .sourceHead = true := by decide
def e2408811882382 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2408811882382 : Closed e2408811882382 ∧ code e2408811882382 = 11204904904590 := by decide
theorem cert_e2408811882382 : check e2408811882382 [[],[],[],[]] .sourceHead = true := by decide
def e2408811885342 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2408811885342 : Closed e2408811885342 ∧ code e2408811885342 = 11204904907550 := by decide
theorem cert_e2408811885342 : check e2408811885342 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e2408811885510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2408811885510 : Closed e2408811885510 ∧ code e2408811885510 = 11204904907718 := by decide
theorem cert_e2408811885510 : check e2408811885510 [[],[],[],[],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e2408811886990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2408811886990 : Closed e2408811886990 ∧ code e2408811886990 = 11204904909198 := by decide
theorem cert_e2408811886990 : check e2408811886990 [[],[],[],[],[.under]] .sourceHead = true := by decide
def e2408811887046 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2408811887046 : Closed e2408811887046 ∧ code e2408811887046 = 11204904909254 := by decide
theorem cert_e2408811887046 : check e2408811887046 [[],[],[],[],[.under],[.under,.left]] .chain = true := by decide
def e2408945774790 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945774790 : Closed e2408945774790 ∧ code e2408945774790 = 11205038796998 := by decide
theorem cert_e2408945774790 : check e2408945774790 [[],[],[],[],[]] .sourceHead = true := by decide
def e2408945776666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408945776666 : Closed e2408945776666 ∧ code e2408945776666 = 11205038798874 := by decide
theorem cert_e2408945776666 : check e2408945776666 [[]] .width = true := by decide
def e2408945791174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945791174 : Closed e2408945791174 ∧ code e2408945791174 = 11205038813382 := by decide
theorem cert_e2408945791174 : check e2408945791174 [[],[],[],[],[]] .sourceHead = true := by decide
def e2408945801242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408945801242 : Closed e2408945801242 ∧ code e2408945801242 = 11205038823450 := by decide
theorem cert_e2408945801242 : check e2408945801242 [[]] .width = true := by decide
def e2408945905862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945905862 : Closed e2408945905862 ∧ code e2408945905862 = 11205038928070 := by decide
theorem cert_e2408945905862 : check e2408945905862 [[],[],[],[],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2408945907738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408945907738 : Closed e2408945907738 ∧ code e2408945907738 = 11205038929946 := by decide
theorem cert_e2408945907738 : check e2408945907738 [[]] .width = true := by decide
def e2408945930438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945930438 : Closed e2408945930438 ∧ code e2408945930438 = 11205038952646 := by decide
theorem cert_e2408945930438 : check e2408945930438 [[],[],[],[],[],[.under,.left]] .chain = true := by decide
def e2408945933850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408945933850 : Closed e2408945933850 ∧ code e2408945933850 = 11205038956058 := by decide
private def t_e2408945933850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408945933850 : ¬ IsSelfInterpreter e2408945933850 :=
  wSource (t := t_e2408945933850) (replay_sound (ps := []) (t := e2408945933850) (by decide)) (by decide)
def e2408945936410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408945936410 : Closed e2408945936410 ∧ code e2408945936410 = 11205038958618 := by decide
theorem cert_e2408945936410 : check e2408945936410 [[]] .width = true := by decide
def e2408945937946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408945937946 : Closed e2408945937946 ∧ code e2408945937946 = 11205038960154 := by decide
private def t_e2408945937946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408945937946 : ¬ IsSelfInterpreter e2408945937946 :=
  wSource (t := t_e2408945937946) (replay_sound (ps := []) (t := e2408945937946) (by decide)) (by decide)
def e2408945987782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945987782 : Closed e2408945987782 ∧ code e2408945987782 = 11205039009990 := by decide
theorem cert_e2408945987782 : check e2408945987782 [[],[],[],[],[],[.under,.left],[.under],[.under],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2408945995974 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408945995974 : Closed e2408945995974 ∧ code e2408945995974 = 11205039018182 := by decide
theorem cert_e2408945995974 : check e2408945995974 [[],[],[],[],[],[.under,.left]] .smaller = true := by decide
def e2408945999386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408945999386 : Closed e2408945999386 ∧ code e2408945999386 = 11205039021594 := by decide
private def t_e2408945999386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408945999386 : ¬ IsSelfInterpreter e2408945999386 :=
  wSource (t := t_e2408945999386) (replay_sound (ps := []) (t := e2408945999386) (by decide)) (by decide)
def e2408946005530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408946005530 : Closed e2408946005530 ∧ code e2408946005530 = 11205039027738 := by decide
private def t_e2408946005530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408946005530 : ¬ IsSelfInterpreter e2408946005530 :=
  wSource (t := t_e2408946005530) (replay_sound (ps := []) (t := e2408946005530) (by decide)) (by decide)
def e2408946030618 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408946030618 : Closed e2408946030618 ∧ code e2408946030618 = 11205039052826 := by decide
theorem cert_e2408946030618 : check e2408946030618 [[]] .width = true := by decide
def e2408946034714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408946034714 : Closed e2408946034714 ∧ code e2408946034714 = 11205039056922 := by decide
theorem cert_e2408946034714 : check e2408946034714 [[]] .width = true := by decide
def e2408946036250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408946036250 : Closed e2408946036250 ∧ code e2408946036250 = 11205039058458 := by decide
private def t_e2408946036250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408946036250 : ¬ IsSelfInterpreter e2408946036250 :=
  wSource (t := t_e2408946036250) (replay_sound (ps := []) (t := e2408946036250) (by decide)) (by decide)
def e2408946038298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408946038298 : Closed e2408946038298 ∧ code e2408946038298 = 11205039060506 := by decide
private def t_e2408946038298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408946038298 : ¬ IsSelfInterpreter e2408946038298 :=
  wSource (t := t_e2408946038298) (replay_sound (ps := []) (t := e2408946038298) (by decide)) (by decide)
def e2408946561222 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408946561222 : Closed e2408946561222 ∧ code e2408946561222 = 11205039583430 := by decide
theorem cert_e2408946561222 : check e2408946561222 [[],[],[],[],[]] .sourceHead = true := by decide
def e2408946563098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408946563098 : Closed e2408946563098 ∧ code e2408946563098 = 11205039585306 := by decide
theorem cert_e2408946563098 : check e2408946563098 [[]] .width = true := by decide
def e2408946577606 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408946577606 : Closed e2408946577606 ∧ code e2408946577606 = 11205039599814 := by decide
theorem cert_e2408946577606 : check e2408946577606 [[],[],[],[],[]] .sourceHead = true := by decide
def e2408946587674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408946587674 : Closed e2408946587674 ∧ code e2408946587674 = 11205039609882 := by decide
theorem cert_e2408946587674 : check e2408946587674 [[]] .width = true := by decide
def e2408947347654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408947347654 : Closed e2408947347654 ∧ code e2408947347654 = 11205040369862 := by decide
theorem cert_e2408947347654 : check e2408947347654 [[],[],[],[],[],[.under]] .three = true := by decide
def e2408947349530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408947349530 : Closed e2408947349530 ∧ code e2408947349530 = 11205040371738 := by decide
theorem cert_e2408947349530 : check e2408947349530 [[]] .width = true := by decide
def e2408947372230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408947372230 : Closed e2408947372230 ∧ code e2408947372230 = 11205040394438 := by decide
theorem cert_e2408947372230 : check e2408947372230 [[],[],[],[],[],[.under]] .three = true := by decide
def e2408947375642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947375642 : Closed e2408947375642 ∧ code e2408947375642 = 11205040397850 := by decide
private def t_e2408947375642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947375642 : ¬ IsSelfInterpreter e2408947375642 :=
  wSource (t := t_e2408947375642) (replay_sound (ps := []) (t := e2408947375642) (by decide)) (by decide)
def e2408947378202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408947378202 : Closed e2408947378202 ∧ code e2408947378202 = 11205040400410 := by decide
theorem cert_e2408947378202 : check e2408947378202 [[]] .width = true := by decide
def e2408947379738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947379738 : Closed e2408947379738 ∧ code e2408947379738 = 11205040401946 := by decide
private def t_e2408947379738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947379738 : ¬ IsSelfInterpreter e2408947379738 :=
  wSource (t := t_e2408947379738) (replay_sound (ps := []) (t := e2408947379738) (by decide)) (by decide)
def e2408947757254 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408947757254 : Closed e2408947757254 ∧ code e2408947757254 = 11205040779462 := by decide
theorem cert_e2408947757254 : check e2408947757254 [[],[],[],[],[],[.under]] .smaller = true := by decide
def e2408947765446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408947765446 : Closed e2408947765446 ∧ code e2408947765446 = 11205040787654 := by decide
theorem cert_e2408947765446 : check e2408947765446 [[],[],[],[],[],[.under]] .smaller = true := by decide
def e2408947768858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947768858 : Closed e2408947768858 ∧ code e2408947768858 = 11205040791066 := by decide
private def t_e2408947768858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947768858 : ¬ IsSelfInterpreter e2408947768858 :=
  wSource (t := t_e2408947768858) (replay_sound (ps := []) (t := e2408947768858) (by decide)) (by decide)
def e2408947775002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947775002 : Closed e2408947775002 ∧ code e2408947775002 = 11205040797210 := by decide
private def t_e2408947775002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947775002 : ¬ IsSelfInterpreter e2408947775002 :=
  wSource (t := t_e2408947775002) (replay_sound (ps := []) (t := e2408947775002) (by decide)) (by decide)
def e2408947963930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408947963930 : Closed e2408947963930 ∧ code e2408947963930 = 11205040986138 := by decide
theorem cert_e2408947963930 : check e2408947963930 [[]] .width = true := by decide
def e2408947968026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408947968026 : Closed e2408947968026 ∧ code e2408947968026 = 11205040990234 := by decide
theorem cert_e2408947968026 : check e2408947968026 [[]] .width = true := by decide
def e2408947969562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947969562 : Closed e2408947969562 ∧ code e2408947969562 = 11205040991770 := by decide
private def t_e2408947969562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947969562 : ¬ IsSelfInterpreter e2408947969562 :=
  wSource (t := t_e2408947969562) (replay_sound (ps := []) (t := e2408947969562) (by decide)) (by decide)
def e2408947971610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408947971610 : Closed e2408947971610 ∧ code e2408947971610 = 11205040993818 := by decide
private def t_e2408947971610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408947971610 : ¬ IsSelfInterpreter e2408947971610 :=
  wSource (t := t_e2408947971610) (replay_sound (ps := []) (t := e2408947971610) (by decide)) (by decide)
def e2408962551322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962551322 : Closed e2408962551322 ∧ code e2408962551322 = 11205055573530 := by decide
private def t_e2408962551322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962551322 : ¬ IsSelfInterpreter e2408962551322 :=
  wSource (t := t_e2408962551322) (replay_sound (ps := []) (t := e2408962551322) (by decide)) (by decide)
def e2408962553370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962553370 : Closed e2408962553370 ∧ code e2408962553370 = 11205055575578 := by decide
private def t_e2408962553370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962553370 : ¬ IsSelfInterpreter e2408962553370 :=
  wSource (t := t_e2408962553370) (replay_sound (ps := []) (t := e2408962553370) (by decide)) (by decide)
def e2408962569754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962569754 : Closed e2408962569754 ∧ code e2408962569754 = 11205055591962 := by decide
private def t_e2408962569754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962569754 : ¬ IsSelfInterpreter e2408962569754 :=
  wSource (t := t_e2408962569754) (replay_sound (ps := []) (t := e2408962569754) (by decide)) (by decide)
def e2408962682394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962682394 : Closed e2408962682394 ∧ code e2408962682394 = 11205055704602 := by decide
private def t_e2408962682394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962682394 : ¬ IsSelfInterpreter e2408962682394 :=
  wSource (t := t_e2408962682394) (replay_sound (ps := []) (t := e2408962682394) (by decide)) (by decide)
def e2408962684442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962684442 : Closed e2408962684442 ∧ code e2408962684442 = 11205055706650 := by decide
private def t_e2408962684442 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962684442 : ¬ IsSelfInterpreter e2408962684442 :=
  wSource (t := t_e2408962684442) (replay_sound (ps := []) (t := e2408962684442) (by decide)) (by decide)
def e2408962698778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962698778 : Closed e2408962698778 ∧ code e2408962698778 = 11205055720986 := by decide
private def t_e2408962698778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962698778 : ¬ IsSelfInterpreter e2408962698778 :=
  wSource (t := t_e2408962698778) (replay_sound (ps := []) (t := e2408962698778) (by decide)) (by decide)
def e2408962701850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962701850 : Closed e2408962701850 ∧ code e2408962701850 = 11205055724058 := by decide
private def t_e2408962701850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962701850 : ¬ IsSelfInterpreter e2408962701850 :=
  wSource (t := t_e2408962701850) (replay_sound (ps := []) (t := e2408962701850) (by decide)) (by decide)
def e2408962709018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962709018 : Closed e2408962709018 ∧ code e2408962709018 = 11205055731226 := by decide
private def t_e2408962709018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962709018 : ¬ IsSelfInterpreter e2408962709018 :=
  wSource (t := t_e2408962709018) (replay_sound (ps := []) (t := e2408962709018) (by decide)) (by decide)
def e2408962710042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962710042 : Closed e2408962710042 ∧ code e2408962710042 = 11205055732250 := by decide
private def t_e2408962710042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962710042 : ¬ IsSelfInterpreter e2408962710042 :=
  wSource (t := t_e2408962710042) (replay_sound (ps := []) (t := e2408962710042) (by decide)) (by decide)
def e2408962766362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962766362 : Closed e2408962766362 ∧ code e2408962766362 = 11205055788570 := by decide
private def t_e2408962766362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962766362 : ¬ IsSelfInterpreter e2408962766362 :=
  wSource (t := t_e2408962766362) (replay_sound (ps := []) (t := e2408962766362) (by decide)) (by decide)
def e2408962774554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962774554 : Closed e2408962774554 ∧ code e2408962774554 = 11205055796762 := by decide
private def t_e2408962774554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962774554 : ¬ IsSelfInterpreter e2408962774554 :=
  wSource (t := t_e2408962774554) (replay_sound (ps := []) (t := e2408962774554) (by decide)) (by decide)
def e2408962775578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408962775578 : Closed e2408962775578 ∧ code e2408962775578 = 11205055797786 := by decide
private def t_e2408962775578 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408962775578 : ¬ IsSelfInterpreter e2408962775578 :=
  wSource (t := t_e2408962775578) (replay_sound (ps := []) (t := e2408962775578) (by decide)) (by decide)
def e2408963094554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408963094554 : Closed e2408963094554 ∧ code e2408963094554 = 11205056116762 := by decide
theorem cert_e2408963094554 : check e2408963094554 [[]] .width = true := by decide
def e2408963102746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408963102746 : Closed e2408963102746 ∧ code e2408963102746 = 11205056124954 := by decide
theorem cert_e2408963102746 : check e2408963102746 [[]] .width = true := by decide
def e2408963337754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963337754 : Closed e2408963337754 ∧ code e2408963337754 = 11205056359962 := by decide
private def t_e2408963337754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963337754 : ¬ IsSelfInterpreter e2408963337754 :=
  wSource (t := t_e2408963337754) (replay_sound (ps := []) (t := e2408963337754) (by decide)) (by decide)
def e2408963339802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963339802 : Closed e2408963339802 ∧ code e2408963339802 = 11205056362010 := by decide
private def t_e2408963339802 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963339802 : ¬ IsSelfInterpreter e2408963339802 :=
  wSource (t := t_e2408963339802) (replay_sound (ps := []) (t := e2408963339802) (by decide)) (by decide)
def e2408963356186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963356186 : Closed e2408963356186 ∧ code e2408963356186 = 11205056378394 := by decide
private def t_e2408963356186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963356186 : ¬ IsSelfInterpreter e2408963356186 :=
  wSource (t := t_e2408963356186) (replay_sound (ps := []) (t := e2408963356186) (by decide)) (by decide)
def e2408963667994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408963667994 : Closed e2408963667994 ∧ code e2408963667994 = 11205056690202 := by decide
theorem cert_e2408963667994 : check e2408963667994 [[]] .width = true := by decide
def e2408963698202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963698202 : Closed e2408963698202 ∧ code e2408963698202 = 11205056720410 := by decide
private def t_e2408963698202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963698202 : ¬ IsSelfInterpreter e2408963698202 :=
  wSource (t := t_e2408963698202) (replay_sound (ps := []) (t := e2408963698202) (by decide)) (by decide)
def e2408963700250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963700250 : Closed e2408963700250 ∧ code e2408963700250 = 11205056722458 := by decide
private def t_e2408963700250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963700250 : ¬ IsSelfInterpreter e2408963700250 :=
  wSource (t := t_e2408963700250) (replay_sound (ps := []) (t := e2408963700250) (by decide)) (by decide)
def e2408963752134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408963752134 : Closed e2408963752134 ∧ code e2408963752134 = 11205056774342 := by decide
theorem cert_e2408963752134 : check e2408963752134 [[]] .width = true := by decide
def e2408963782682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408963782682 : Closed e2408963782682 ∧ code e2408963782682 = 11205056804890 := by decide
theorem cert_e2408963782682 : check e2408963782682 [[]] .width = true := by decide
def e2408963798554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408963798554 : Closed e2408963798554 ∧ code e2408963798554 = 11205056820762 := by decide
private def t_e2408963798554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408963798554 : ¬ IsSelfInterpreter e2408963798554 :=
  wSource (t := t_e2408963798554) (replay_sound (ps := []) (t := e2408963798554) (by decide)) (by decide)
def e2408963817670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408963817670 : Closed e2408963817670 ∧ code e2408963817670 = 11205056839878 := by decide
theorem cert_e2408963817670 : check e2408963817670 [[]] .width = true := by decide
def e2408964012058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964012058 : Closed e2408964012058 ∧ code e2408964012058 = 11205057034266 := by decide
theorem cert_e2408964012058 : check e2408964012058 [[]] .width = true := by decide
def e2408964024346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964024346 : Closed e2408964024346 ∧ code e2408964024346 = 11205057046554 := by decide
theorem cert_e2408964024346 : check e2408964024346 [[]] .width = true := by decide
def e2408964124186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964124186 : Closed e2408964124186 ∧ code e2408964124186 = 11205057146394 := by decide
private def t_e2408964124186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964124186 : ¬ IsSelfInterpreter e2408964124186 :=
  wSource (t := t_e2408964124186) (replay_sound (ps := []) (t := e2408964124186) (by decide)) (by decide)
def e2408964126234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964126234 : Closed e2408964126234 ∧ code e2408964126234 = 11205057148442 := by decide
private def t_e2408964126234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964126234 : ¬ IsSelfInterpreter e2408964126234 :=
  wSource (t := t_e2408964126234) (replay_sound (ps := []) (t := e2408964126234) (by decide)) (by decide)
def e2408964140570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964140570 : Closed e2408964140570 ∧ code e2408964140570 = 11205057162778 := by decide
private def t_e2408964140570 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964140570 : ¬ IsSelfInterpreter e2408964140570 :=
  wSource (t := t_e2408964140570) (replay_sound (ps := []) (t := e2408964140570) (by decide)) (by decide)
def e2408964143642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964143642 : Closed e2408964143642 ∧ code e2408964143642 = 11205057165850 := by decide
private def t_e2408964143642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964143642 : ¬ IsSelfInterpreter e2408964143642 :=
  wSource (t := t_e2408964143642) (replay_sound (ps := []) (t := e2408964143642) (by decide)) (by decide)
def e2408964150810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964150810 : Closed e2408964150810 ∧ code e2408964150810 = 11205057173018 := by decide
private def t_e2408964150810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964150810 : ¬ IsSelfInterpreter e2408964150810 :=
  wSource (t := t_e2408964150810) (replay_sound (ps := []) (t := e2408964150810) (by decide)) (by decide)
def e2408964151834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964151834 : Closed e2408964151834 ∧ code e2408964151834 = 11205057174042 := by decide
private def t_e2408964151834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964151834 : ¬ IsSelfInterpreter e2408964151834 :=
  wSource (t := t_e2408964151834) (replay_sound (ps := []) (t := e2408964151834) (by decide)) (by decide)
def e2408964192282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964192282 : Closed e2408964192282 ∧ code e2408964192282 = 11205057214490 := by decide
theorem cert_e2408964192282 : check e2408964192282 [[]] .width = true := by decide
def e2408964222490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964222490 : Closed e2408964222490 ∧ code e2408964222490 = 11205057244698 := by decide
private def t_e2408964222490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964222490 : ¬ IsSelfInterpreter e2408964222490 :=
  wSource (t := t_e2408964222490) (replay_sound (ps := []) (t := e2408964222490) (by decide)) (by decide)
def e2408964224538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964224538 : Closed e2408964224538 ∧ code e2408964224538 = 11205057246746 := by decide
private def t_e2408964224538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964224538 : ¬ IsSelfInterpreter e2408964224538 :=
  wSource (t := t_e2408964224538) (replay_sound (ps := []) (t := e2408964224538) (by decide)) (by decide)
def e2408964276422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408964276422 : Closed e2408964276422 ∧ code e2408964276422 = 11205057298630 := by decide
theorem cert_e2408964276422 : check e2408964276422 [[]] .width = true := by decide
def e2408964320794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964320794 : Closed e2408964320794 ∧ code e2408964320794 = 11205057343002 := by decide
private def t_e2408964320794 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964320794 : ¬ IsSelfInterpreter e2408964320794 :=
  wSource (t := t_e2408964320794) (replay_sound (ps := []) (t := e2408964320794) (by decide)) (by decide)
def e2408964323866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964323866 : Closed e2408964323866 ∧ code e2408964323866 = 11205057346074 := by decide
private def t_e2408964323866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964323866 : ¬ IsSelfInterpreter e2408964323866 :=
  wSource (t := t_e2408964323866) (replay_sound (ps := []) (t := e2408964323866) (by decide)) (by decide)
def e2408964364314 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964364314 : Closed e2408964364314 ∧ code e2408964364314 = 11205057386522 := by decide
theorem cert_e2408964364314 : check e2408964364314 [[]] .width = true := by decide
def e2408964371994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964371994 : Closed e2408964371994 ∧ code e2408964371994 = 11205057394202 := by decide
private def t_e2408964371994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964371994 : ¬ IsSelfInterpreter e2408964371994 :=
  wSource (t := t_e2408964371994) (replay_sound (ps := []) (t := e2408964371994) (by decide)) (by decide)
def e2408964373018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964373018 : Closed e2408964373018 ∧ code e2408964373018 = 11205057395226 := by decide
private def t_e2408964373018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964373018 : ¬ IsSelfInterpreter e2408964373018 :=
  wSource (t := t_e2408964373018) (replay_sound (ps := []) (t := e2408964373018) (by decide)) (by decide)
def e2408964374726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408964374726 : Closed e2408964374726 ∧ code e2408964374726 = 11205057396934 := by decide
theorem cert_e2408964374726 : check e2408964374726 [[]] .width = true := by decide
def e2408964479002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964479002 : Closed e2408964479002 ∧ code e2408964479002 = 11205057501210 := by decide
theorem cert_e2408964479002 : check e2408964479002 [[]] .width = true := by decide
def e2408964483098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964483098 : Closed e2408964483098 ∧ code e2408964483098 = 11205057505306 := by decide
theorem cert_e2408964483098 : check e2408964483098 [[]] .width = true := by decide
def e2408964535834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964535834 : Closed e2408964535834 ∧ code e2408964535834 = 11205057558042 := by decide
private def t_e2408964535834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964535834 : ¬ IsSelfInterpreter e2408964535834 :=
  wSource (t := t_e2408964535834) (replay_sound (ps := []) (t := e2408964535834) (by decide)) (by decide)
def e2408964544026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964544026 : Closed e2408964544026 ∧ code e2408964544026 = 11205057566234 := by decide
private def t_e2408964544026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964544026 : ¬ IsSelfInterpreter e2408964544026 :=
  wSource (t := t_e2408964544026) (replay_sound (ps := []) (t := e2408964544026) (by decide)) (by decide)
def e2408964545050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964545050 : Closed e2408964545050 ∧ code e2408964545050 = 11205057567258 := by decide
private def t_e2408964545050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964545050 : ¬ IsSelfInterpreter e2408964545050 :=
  wSource (t := t_e2408964545050) (replay_sound (ps := []) (t := e2408964545050) (by decide)) (by decide)
def e2408964569114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964569114 : Closed e2408964569114 ∧ code e2408964569114 = 11205057591322 := by decide
theorem cert_e2408964569114 : check e2408964569114 [[]] .width = true := by decide
def e2408964584986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964584986 : Closed e2408964584986 ∧ code e2408964584986 = 11205057607194 := by decide
private def t_e2408964584986 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964584986 : ¬ IsSelfInterpreter e2408964584986 :=
  wSource (t := t_e2408964584986) (replay_sound (ps := []) (t := e2408964584986) (by decide)) (by decide)
def e2408964604102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408964604102 : Closed e2408964604102 ∧ code e2408964604102 = 11205057626310 := by decide
theorem cert_e2408964604102 : check e2408964604102 [[]] .width = true := by decide
def e2408964626458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408964626458 : Closed e2408964626458 ∧ code e2408964626458 = 11205057648666 := by decide
theorem cert_e2408964626458 : check e2408964626458 [[]] .width = true := by decide
def e2408964634138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964634138 : Closed e2408964634138 ∧ code e2408964634138 = 11205057656346 := by decide
private def t_e2408964634138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964634138 : ¬ IsSelfInterpreter e2408964634138 :=
  wSource (t := t_e2408964634138) (replay_sound (ps := []) (t := e2408964634138) (by decide)) (by decide)
def e2408964635162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408964635162 : Closed e2408964635162 ∧ code e2408964635162 = 11205057657370 := by decide
private def t_e2408964635162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408964635162 : ¬ IsSelfInterpreter e2408964635162 :=
  wSource (t := t_e2408964635162) (replay_sound (ps := []) (t := e2408964635162) (by decide)) (by decide)
def e2408964636870 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408964636870 : Closed e2408964636870 ∧ code e2408964636870 = 11205057659078 := by decide
theorem cert_e2408964636870 : check e2408964636870 [[]] .width = true := by decide
def e2408966483482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966483482 : Closed e2408966483482 ∧ code e2408966483482 = 11205059505690 := by decide
private def t_e2408966483482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966483482 : ¬ IsSelfInterpreter e2408966483482 :=
  wSource (t := t_e2408966483482) (replay_sound (ps := []) (t := e2408966483482) (by decide)) (by decide)
def e2408966485530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966485530 : Closed e2408966485530 ∧ code e2408966485530 = 11205059507738 := by decide
private def t_e2408966485530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966485530 : ¬ IsSelfInterpreter e2408966485530 :=
  wSource (t := t_e2408966485530) (replay_sound (ps := []) (t := e2408966485530) (by decide)) (by decide)
def e2408966501914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966501914 : Closed e2408966501914 ∧ code e2408966501914 = 11205059524122 := by decide
private def t_e2408966501914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966501914 : ¬ IsSelfInterpreter e2408966501914 :=
  wSource (t := t_e2408966501914) (replay_sound (ps := []) (t := e2408966501914) (by decide)) (by decide)
def e2408966813722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408966813722 : Closed e2408966813722 ∧ code e2408966813722 = 11205059835930 := by decide
theorem cert_e2408966813722 : check e2408966813722 [[]] .width = true := by decide
def e2408966843930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966843930 : Closed e2408966843930 ∧ code e2408966843930 = 11205059866138 := by decide
private def t_e2408966843930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966843930 : ¬ IsSelfInterpreter e2408966843930 :=
  wSource (t := t_e2408966843930) (replay_sound (ps := []) (t := e2408966843930) (by decide)) (by decide)
def e2408966845978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966845978 : Closed e2408966845978 ∧ code e2408966845978 = 11205059868186 := by decide
private def t_e2408966845978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966845978 : ¬ IsSelfInterpreter e2408966845978 :=
  wSource (t := t_e2408966845978) (replay_sound (ps := []) (t := e2408966845978) (by decide)) (by decide)
def e2408966897862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408966897862 : Closed e2408966897862 ∧ code e2408966897862 = 11205059920070 := by decide
theorem cert_e2408966897862 : check e2408966897862 [[]] .width = true := by decide
def e2408966928410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408966928410 : Closed e2408966928410 ∧ code e2408966928410 = 11205059950618 := by decide
theorem cert_e2408966928410 : check e2408966928410 [[]] .width = true := by decide
def e2408966944282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408966944282 : Closed e2408966944282 ∧ code e2408966944282 = 11205059966490 := by decide
private def t_e2408966944282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408966944282 : ¬ IsSelfInterpreter e2408966944282 :=
  wSource (t := t_e2408966944282) (replay_sound (ps := []) (t := e2408966944282) (by decide)) (by decide)
def e2408966963398 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408966963398 : Closed e2408966963398 ∧ code e2408966963398 = 11205059985606 := by decide
theorem cert_e2408966963398 : check e2408966963398 [[]] .width = true := by decide
def e2408969891354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969891354 : Closed e2408969891354 ∧ code e2408969891354 = 11205062913562 := by decide
private def t_e2408969891354 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969891354 : ¬ IsSelfInterpreter e2408969891354 :=
  wSource (t := t_e2408969891354) (replay_sound (ps := []) (t := e2408969891354) (by decide)) (by decide)
def e2408969893402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969893402 : Closed e2408969893402 ∧ code e2408969893402 = 11205062915610 := by decide
private def t_e2408969893402 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969893402 : ¬ IsSelfInterpreter e2408969893402 :=
  wSource (t := t_e2408969893402) (replay_sound (ps := []) (t := e2408969893402) (by decide)) (by decide)
def e2408969907738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969907738 : Closed e2408969907738 ∧ code e2408969907738 = 11205062929946 := by decide
private def t_e2408969907738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969907738 : ¬ IsSelfInterpreter e2408969907738 :=
  wSource (t := t_e2408969907738) (replay_sound (ps := []) (t := e2408969907738) (by decide)) (by decide)
def e2408969910810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969910810 : Closed e2408969910810 ∧ code e2408969910810 = 11205062933018 := by decide
private def t_e2408969910810 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969910810 : ¬ IsSelfInterpreter e2408969910810 :=
  wSource (t := t_e2408969910810) (replay_sound (ps := []) (t := e2408969910810) (by decide)) (by decide)
def e2408969917978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969917978 : Closed e2408969917978 ∧ code e2408969917978 = 11205062940186 := by decide
private def t_e2408969917978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969917978 : ¬ IsSelfInterpreter e2408969917978 :=
  wSource (t := t_e2408969917978) (replay_sound (ps := []) (t := e2408969917978) (by decide)) (by decide)
def e2408969919002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969919002 : Closed e2408969919002 ∧ code e2408969919002 = 11205062941210 := by decide
private def t_e2408969919002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969919002 : ¬ IsSelfInterpreter e2408969919002 :=
  wSource (t := t_e2408969919002) (replay_sound (ps := []) (t := e2408969919002) (by decide)) (by decide)
def e2408969959450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408969959450 : Closed e2408969959450 ∧ code e2408969959450 = 11205062981658 := by decide
theorem cert_e2408969959450 : check e2408969959450 [[]] .width = true := by decide
def e2408969989658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969989658 : Closed e2408969989658 ∧ code e2408969989658 = 11205063011866 := by decide
private def t_e2408969989658 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969989658 : ¬ IsSelfInterpreter e2408969989658 :=
  wSource (t := t_e2408969989658) (replay_sound (ps := []) (t := e2408969989658) (by decide)) (by decide)
def e2408969991706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408969991706 : Closed e2408969991706 ∧ code e2408969991706 = 11205063013914 := by decide
private def t_e2408969991706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408969991706 : ¬ IsSelfInterpreter e2408969991706 :=
  wSource (t := t_e2408969991706) (replay_sound (ps := []) (t := e2408969991706) (by decide)) (by decide)
def e2408970043590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408970043590 : Closed e2408970043590 ∧ code e2408970043590 = 11205063065798 := by decide
theorem cert_e2408970043590 : check e2408970043590 [[]] .width = true := by decide
def e2408970087962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408970087962 : Closed e2408970087962 ∧ code e2408970087962 = 11205063110170 := by decide
private def t_e2408970087962 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408970087962 : ¬ IsSelfInterpreter e2408970087962 :=
  wSource (t := t_e2408970087962) (replay_sound (ps := []) (t := e2408970087962) (by decide)) (by decide)
def e2408970091034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408970091034 : Closed e2408970091034 ∧ code e2408970091034 = 11205063113242 := by decide
private def t_e2408970091034 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408970091034 : ¬ IsSelfInterpreter e2408970091034 :=
  wSource (t := t_e2408970091034) (replay_sound (ps := []) (t := e2408970091034) (by decide)) (by decide)
def e2408970131482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408970131482 : Closed e2408970131482 ∧ code e2408970131482 = 11205063153690 := by decide
theorem cert_e2408970131482 : check e2408970131482 [[]] .width = true := by decide
def e2408970139162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408970139162 : Closed e2408970139162 ∧ code e2408970139162 = 11205063161370 := by decide
private def t_e2408970139162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408970139162 : ¬ IsSelfInterpreter e2408970139162 :=
  wSource (t := t_e2408970139162) (replay_sound (ps := []) (t := e2408970139162) (by decide)) (by decide)
def e2408970140186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408970140186 : Closed e2408970140186 ∧ code e2408970140186 = 11205063162394 := by decide
private def t_e2408970140186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408970140186 : ¬ IsSelfInterpreter e2408970140186 :=
  wSource (t := t_e2408970140186) (replay_sound (ps := []) (t := e2408970140186) (by decide)) (by decide)
def e2408970141894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2408970141894 : Closed e2408970141894 ∧ code e2408970141894 = 11205063164102 := by decide
theorem cert_e2408970141894 : check e2408970141894 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2408811879878
#print axioms Blc.Floor43.cert_e2408811880134
#print axioms Blc.Floor43.cert_e2408945933850
#print axioms Blc.Floor43.cert_e2408945937946
#print axioms Blc.Floor43.cert_e2408945999386
#print axioms Blc.Floor43.cert_e2408946005530
#print axioms Blc.Floor43.cert_e2408946036250
#print axioms Blc.Floor43.cert_e2408946038298
#print axioms Blc.Floor43.cert_e2408947375642
#print axioms Blc.Floor43.cert_e2408947379738
#print axioms Blc.Floor43.cert_e2408947768858
#print axioms Blc.Floor43.cert_e2408947775002
#print axioms Blc.Floor43.cert_e2408947969562
#print axioms Blc.Floor43.cert_e2408947971610
#print axioms Blc.Floor43.cert_e2408962551322
#print axioms Blc.Floor43.cert_e2408962553370
#print axioms Blc.Floor43.cert_e2408962569754
#print axioms Blc.Floor43.cert_e2408962682394
#print axioms Blc.Floor43.cert_e2408962684442
#print axioms Blc.Floor43.cert_e2408962698778
#print axioms Blc.Floor43.cert_e2408962701850
#print axioms Blc.Floor43.cert_e2408962709018
#print axioms Blc.Floor43.cert_e2408962710042
#print axioms Blc.Floor43.cert_e2408962766362
#print axioms Blc.Floor43.cert_e2408962774554
#print axioms Blc.Floor43.cert_e2408962775578
#print axioms Blc.Floor43.cert_e2408963337754
#print axioms Blc.Floor43.cert_e2408963339802
#print axioms Blc.Floor43.cert_e2408963356186
#print axioms Blc.Floor43.cert_e2408963698202
#print axioms Blc.Floor43.cert_e2408963700250
#print axioms Blc.Floor43.cert_e2408963798554
#print axioms Blc.Floor43.cert_e2408964124186
#print axioms Blc.Floor43.cert_e2408964126234
#print axioms Blc.Floor43.cert_e2408964140570
#print axioms Blc.Floor43.cert_e2408964143642
#print axioms Blc.Floor43.cert_e2408964150810
#print axioms Blc.Floor43.cert_e2408964151834
#print axioms Blc.Floor43.cert_e2408964222490
#print axioms Blc.Floor43.cert_e2408964224538
#print axioms Blc.Floor43.cert_e2408964320794
#print axioms Blc.Floor43.cert_e2408964323866
#print axioms Blc.Floor43.cert_e2408964371994
#print axioms Blc.Floor43.cert_e2408964373018
#print axioms Blc.Floor43.cert_e2408964535834
#print axioms Blc.Floor43.cert_e2408964544026
#print axioms Blc.Floor43.cert_e2408964545050
#print axioms Blc.Floor43.cert_e2408964584986
#print axioms Blc.Floor43.cert_e2408964634138
#print axioms Blc.Floor43.cert_e2408964635162
#print axioms Blc.Floor43.cert_e2408966483482
#print axioms Blc.Floor43.cert_e2408966485530
#print axioms Blc.Floor43.cert_e2408966501914
#print axioms Blc.Floor43.cert_e2408966843930
#print axioms Blc.Floor43.cert_e2408966845978
#print axioms Blc.Floor43.cert_e2408966944282
#print axioms Blc.Floor43.cert_e2408969891354
#print axioms Blc.Floor43.cert_e2408969893402
#print axioms Blc.Floor43.cert_e2408969907738
#print axioms Blc.Floor43.cert_e2408969910810
#print axioms Blc.Floor43.cert_e2408969917978
#print axioms Blc.Floor43.cert_e2408969919002
#print axioms Blc.Floor43.cert_e2408969989658
#print axioms Blc.Floor43.cert_e2408969991706
#print axioms Blc.Floor43.cert_e2408970087962
#print axioms Blc.Floor43.cert_e2408970091034
#print axioms Blc.Floor43.cert_e2408970139162
#print axioms Blc.Floor43.cert_e2408970140186
