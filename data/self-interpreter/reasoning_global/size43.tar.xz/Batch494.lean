import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408460826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408460826 : Closed e2422408460826 ∧ code e2422408460826 = 11218501483034 := by decide
theorem cert_e2422408460826 : check e2422408460826 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408460898 : Closed e2422408460898 ∧ code e2422408460898 = 11218501483106 := by decide
theorem cert_e2422408460898 : check e2422408460898 [[],[]] .chain = true := by decide
def e2422408460910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408460910 : Closed e2422408460910 ∧ code e2422408460910 = 11218501483118 := by decide
theorem cert_e2422408460910 : check e2422408460910 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408460918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408460918 : Closed e2422408460918 ∧ code e2422408460918 = 11218501483126 := by decide
theorem cert_e2422408460918 : check e2422408460918 [[],[]] .chain = true := by decide
def e2422408460922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408460922 : Closed e2422408460922 ∧ code e2422408460922 = 11218501483130 := by decide
theorem cert_e2422408460922 : check e2422408460922 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408461062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408461062 : Closed e2422408461062 ∧ code e2422408461062 = 11218501483270 := by decide
theorem cert_e2422408461062 : check e2422408461062 [[],[]] .chain = true := by decide
def e2422408461086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422408461086 : Closed e2422408461086 ∧ code e2422408461086 = 11218501483294 := by decide
theorem cert_e2422408461086 : check e2422408461086 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408461110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408461110 : Closed e2422408461110 ∧ code e2422408461110 = 11218501483318 := by decide
theorem cert_e2422408461110 : check e2422408461110 [[],[]] .chain = true := by decide
def e2422408461114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408461114 : Closed e2422408461114 ∧ code e2422408461114 = 11218501483322 := by decide
theorem cert_e2422408461114 : check e2422408461114 [[],[]] .chain = true := by decide
def e2422408461186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408461186 : Closed e2422408461186 ∧ code e2422408461186 = 11218501483394 := by decide
theorem cert_e2422408461186 : check e2422408461186 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408461198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422408461198 : Closed e2422408461198 ∧ code e2422408461198 = 11218501483406 := by decide
theorem cert_e2422408461198 : check e2422408461198 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408461210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408461210 : Closed e2422408461210 ∧ code e2422408461210 = 11218501483418 := by decide
theorem cert_e2422408461210 : check e2422408461210 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2422408462422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.var 1))))))
theorem wire_e2422408462422 : Closed e2422408462422 ∧ code e2422408462422 = 11218501484630 := by decide
theorem cert_e2422408462422 : check e2422408462422 [[],[]] .chain = true := by decide
def e2422408462426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 1))) (.var 0))))))
theorem wire_e2422408462426 : Closed e2422408462426 ∧ code e2422408462426 = 11218501484634 := by decide
theorem cert_e2422408462426 : check e2422408462426 [[],[]] .chain = true := by decide
def e2422408462702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1))) (.var 2))))))
theorem wire_e2422408462702 : Closed e2422408462702 ∧ code e2422408462702 = 11218501484910 := by decide
theorem cert_e2422408462702 : checkPay e2422408462702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422408462710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2))) (.var 1))))))
theorem wire_e2422408462710 : Closed e2422408462710 ∧ code e2422408462710 = 11218501484918 := by decide
theorem cert_e2422408462710 : check e2422408462710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408462774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1))) (.var 1))))))
theorem wire_e2422408462774 : Closed e2422408462774 ∧ code e2422408462774 = 11218501484982 := by decide
theorem cert_e2422408462774 : check e2422408462774 [[],[]] .chain = true := by decide
def e2422408462806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0))) (.var 1))))))
theorem wire_e2422408462806 : Closed e2422408462806 ∧ code e2422408462806 = 11218501485014 := by decide
theorem cert_e2422408462806 : check e2422408462806 [[],[]] .chain = true := by decide
def e2422408462810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))) (.var 0))))))
theorem wire_e2422408462810 : Closed e2422408462810 ∧ code e2422408462810 = 11218501485018 := by decide
theorem cert_e2422408462810 : check e2422408462810 [[],[]] .chain = true := by decide
def e2422408462826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))) (.var 0))))))
theorem wire_e2422408462826 : Closed e2422408462826 ∧ code e2422408462826 = 11218501485034 := by decide
theorem cert_e2422408462826 : check e2422408462826 [[],[]] .chain = true := by decide
def e2422408463190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e2422408463190 : Closed e2422408463190 ∧ code e2422408463190 = 11218501485398 := by decide
private def t_e2422408463190 : Term := (.app (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))))) (.var 1))
theorem cert_e2422408463190 : ¬ IsSelfInterpreter e2422408463190 :=
  wIdentity (t := t_e2422408463190) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]]) (t := (inv e2422408463190)) (by decide)) (by decide)
def e2422408463194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e2422408463194 : Closed e2422408463194 ∧ code e2422408463194 = 11218501485402 := by decide
private def t_e2422408463194 : Term := (.app (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 2))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))))))))
theorem cert_e2422408463194 : ¬ IsSelfInterpreter e2422408463194 :=
  wIdentity (t := t_e2422408463194) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]]) (t := (inv e2422408463194)) (by decide)) (by decide)
def e2422408463478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422408463478 : Closed e2422408463478 ∧ code e2422408463478 = 11218501485686 := by decide
theorem cert_e2422408463478 : check e2422408463478 [[],[]] .chain = true := by decide
def e2422408463574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422408463574 : Closed e2422408463574 ∧ code e2422408463574 = 11218501485782 := by decide
theorem cert_e2422408463574 : check e2422408463574 [[],[]] .chain = true := by decide
def e2422408463578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422408463578 : Closed e2422408463578 ∧ code e2422408463578 = 11218501485786 := by decide
theorem cert_e2422408463578 : check e2422408463578 [[],[]] .chain = true := by decide
def e2422408463594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422408463594 : Closed e2422408463594 ∧ code e2422408463594 = 11218501485802 := by decide
theorem cert_e2422408463594 : check e2422408463594 [[],[]] .chain = true := by decide
def e2422408463670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408463670 : Closed e2422408463670 ∧ code e2422408463670 = 11218501485878 := by decide
theorem cert_e2422408463670 : check e2422408463670 [[],[]] .chain = true := by decide
def e2422408463674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408463674 : Closed e2422408463674 ∧ code e2422408463674 = 11218501485882 := by decide
theorem cert_e2422408463674 : check e2422408463674 [[],[]] .chain = true := by decide
def e2422408463758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422408463758 : Closed e2422408463758 ∧ code e2422408463758 = 11218501485966 := by decide
theorem cert_e2422408463758 : check e2422408463758 [[],[]] .chain = true := by decide
def e2422408463770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408463770 : Closed e2422408463770 ∧ code e2422408463770 = 11218501485978 := by decide
theorem cert_e2422408463770 : check e2422408463770 [[],[]] .chain = true := by decide
def e2422408463926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422408463926 : Closed e2422408463926 ∧ code e2422408463926 = 11218501486134 := by decide
theorem cert_e2422408463926 : check e2422408463926 [[],[]] .chain = true := by decide
def e2422408463930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422408463930 : Closed e2422408463930 ∧ code e2422408463930 = 11218501486138 := by decide
theorem cert_e2422408463930 : check e2422408463930 [[],[]] .chain = true := by decide
def e2422408464014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422408464014 : Closed e2422408464014 ∧ code e2422408464014 = 11218501486222 := by decide
theorem cert_e2422408464014 : check e2422408464014 [[],[]] .chain = true := by decide
def e2422408464070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422408464070 : Closed e2422408464070 ∧ code e2422408464070 = 11218501486278 := by decide
theorem cert_e2422408464070 : check e2422408464070 [[],[]] .chain = true := by decide
def e2422408464150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408464150 : Closed e2422408464150 ∧ code e2422408464150 = 11218501486358 := by decide
theorem cert_e2422408464150 : check e2422408464150 [[],[]] .chain = true := by decide
def e2422408464154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422408464154 : Closed e2422408464154 ∧ code e2422408464154 = 11218501486362 := by decide
theorem cert_e2422408464154 : check e2422408464154 [[],[]] .chain = true := by decide
def e2422408464198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422408464198 : Closed e2422408464198 ∧ code e2422408464198 = 11218501486406 := by decide
theorem cert_e2422408464198 : check e2422408464198 [[],[]] .chain = true := by decide
def e2422408464226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408464226 : Closed e2422408464226 ∧ code e2422408464226 = 11218501486434 := by decide
theorem cert_e2422408464226 : check e2422408464226 [[],[]] .chain = true := by decide
def e2422408464238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))) (.var 2))))))
theorem wire_e2422408464238 : Closed e2422408464238 ∧ code e2422408464238 = 11218501486446 := by decide
theorem cert_e2422408464238 : check e2422408464238 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408464246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 2))) (.var 1))))))
theorem wire_e2422408464246 : Closed e2422408464246 ∧ code e2422408464246 = 11218501486454 := by decide
theorem cert_e2422408464246 : check e2422408464246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408464310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.var 1))) (.var 1))))))
theorem wire_e2422408464310 : Closed e2422408464310 ∧ code e2422408464310 = 11218501486518 := by decide
theorem cert_e2422408464310 : checkPay e2422408464310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422408465494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.var 1))))))
theorem wire_e2422408465494 : Closed e2422408465494 ∧ code e2422408465494 = 11218501487702 := by decide
theorem cert_e2422408465494 : check e2422408465494 [[],[]] .chain = true := by decide
def e2422408465498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))) (.var 0))))))
theorem wire_e2422408465498 : Closed e2422408465498 ∧ code e2422408465498 = 11218501487706 := by decide
theorem cert_e2422408465498 : check e2422408465498 [[],[]] .chain = true := by decide
def e2422408465686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422408465686 : Closed e2422408465686 ∧ code e2422408465686 = 11218501487894 := by decide
theorem cert_e2422408465686 : check e2422408465686 [[],[]] .chain = true := by decide
def e2422408465762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422408465762 : Closed e2422408465762 ∧ code e2422408465762 = 11218501487970 := by decide
theorem cert_e2422408465762 : check e2422408465762 [[],[]] .chain = true := by decide
def e2422408465774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2422408465774 : Closed e2422408465774 ∧ code e2422408465774 = 11218501487982 := by decide
theorem cert_e2422408465774 : check e2422408465774 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408465782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2422408465782 : Closed e2422408465782 ∧ code e2422408465782 = 11218501487990 := by decide
theorem cert_e2422408465782 : checkPay e2422408465782 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422408465802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408465802 : Closed e2422408465802 ∧ code e2422408465802 = 11218501488010 := by decide
theorem cert_e2422408465802 : check e2422408465802 [[],[]] .chain = true := by decide
def e2422408465826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408465826 : Closed e2422408465826 ∧ code e2422408465826 = 11218501488034 := by decide
theorem cert_e2422408465826 : check e2422408465826 [[],[]] .chain = true := by decide
def e2422408465838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.var 2))))))
theorem wire_e2422408465838 : Closed e2422408465838 ∧ code e2422408465838 = 11218501488046 := by decide
theorem cert_e2422408465838 : check e2422408465838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408465846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))) (.var 1))))))
theorem wire_e2422408465846 : Closed e2422408465846 ∧ code e2422408465846 = 11218501488054 := by decide
theorem cert_e2422408465846 : check e2422408465846 [[],[]] .chain = true := by decide
def e2422408465850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))) (.var 0))))))
theorem wire_e2422408465850 : Closed e2422408465850 ∧ code e2422408465850 = 11218501488058 := by decide
theorem cert_e2422408465850 : check e2422408465850 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408465878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0))) (.var 1))))))
theorem wire_e2422408465878 : Closed e2422408465878 ∧ code e2422408465878 = 11218501488086 := by decide
theorem cert_e2422408465878 : check e2422408465878 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408465882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))) (.var 0))))))
theorem wire_e2422408465882 : Closed e2422408465882 ∧ code e2422408465882 = 11218501488090 := by decide
def e2422408465962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))) (.var 0))))))
theorem wire_e2422408465962 : Closed e2422408465962 ∧ code e2422408465962 = 11218501488170 := by decide
theorem cert_e2422408465962 : check e2422408465962 [[],[]] .chain = true := by decide
def e2422408466058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422408466058 : Closed e2422408466058 ∧ code e2422408466058 = 11218501488266 := by decide
theorem cert_e2422408466058 : check e2422408466058 [[],[]] .chain = true := by decide
def e2422408466082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422408466082 : Closed e2422408466082 ∧ code e2422408466082 = 11218501488290 := by decide
theorem cert_e2422408466082 : check e2422408466082 [[],[]] .chain = true := by decide
def e2422408466094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422408466094 : Closed e2422408466094 ∧ code e2422408466094 = 11218501488302 := by decide
theorem cert_e2422408466094 : check e2422408466094 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408466102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e2422408466102 : Closed e2422408466102 ∧ code e2422408466102 = 11218501488310 := by decide
theorem cert_e2422408466102 : check e2422408466102 [[],[]] .chain = true := by decide
def e2422408466106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422408466106 : Closed e2422408466106 ∧ code e2422408466106 = 11218501488314 := by decide
theorem cert_e2422408466106 : check e2422408466106 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408466134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e2422408466134 : Closed e2422408466134 ∧ code e2422408466134 = 11218501488342 := by decide
theorem cert_e2422408466134 : check e2422408466134 [[],[]] .chain = true := by decide
def e2422408466138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e2422408466138 : Closed e2422408466138 ∧ code e2422408466138 = 11218501488346 := by decide
theorem cert_e2422408466138 : check e2422408466138 [[],[]] .chain = true := by decide
def e2422408466154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e2422408466154 : Closed e2422408466154 ∧ code e2422408466154 = 11218501488362 := by decide
theorem cert_e2422408466154 : check e2422408466154 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408466262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422408466262 : Closed e2422408466262 ∧ code e2422408466262 = 11218501488470 := by decide
theorem cert_e2422408466262 : check e2422408466262 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408466266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422408466266 : Closed e2422408466266 ∧ code e2422408466266 = 11218501488474 := by decide
theorem cert_e2422408466266 : check e2422408466266 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408466282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e2422408466282 : Closed e2422408466282 ∧ code e2422408466282 = 11218501488490 := by decide
theorem cert_e2422408466282 : check e2422408466282 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408466454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408466454 : Closed e2422408466454 ∧ code e2422408466454 = 11218501488662 := by decide
theorem cert_e2422408466454 : check e2422408466454 [[],[]] .chain = true := by decide
def e2422408466550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422408466550 : Closed e2422408466550 ∧ code e2422408466550 = 11218501488758 := by decide
theorem cert_e2422408466550 : check e2422408466550 [[],[]] .chain = true := by decide
def e2422408466554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422408466554 : Closed e2422408466554 ∧ code e2422408466554 = 11218501488762 := by decide
theorem cert_e2422408466554 : check e2422408466554 [[],[]] .chain = true := by decide
def e2422408466646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422408466646 : Closed e2422408466646 ∧ code e2422408466646 = 11218501488854 := by decide
theorem cert_e2422408466646 : check e2422408466646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408466742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408466742 : Closed e2422408466742 ∧ code e2422408466742 = 11218501488950 := by decide
theorem cert_e2422408466742 : check e2422408466742 [[],[]] .chain = true := by decide
def e2422408466746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408466746 : Closed e2422408466746 ∧ code e2422408466746 = 11218501488954 := by decide
theorem cert_e2422408466746 : check e2422408466746 [[],[]] .chain = true := by decide
def e2422408466830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422408466830 : Closed e2422408466830 ∧ code e2422408466830 = 11218501489038 := by decide
theorem cert_e2422408466830 : check e2422408466830 [[],[]] .chain = true := by decide
def e2422408466886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422408466886 : Closed e2422408466886 ∧ code e2422408466886 = 11218501489094 := by decide
theorem cert_e2422408466886 : check e2422408466886 [[],[]] .chain = true := by decide
def e2422408467222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408467222 : Closed e2422408467222 ∧ code e2422408467222 = 11218501489430 := by decide
theorem cert_e2422408467222 : check e2422408467222 [[],[]] .chain = true := by decide
def e2422408467298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408467298 : Closed e2422408467298 ∧ code e2422408467298 = 11218501489506 := by decide
theorem cert_e2422408467298 : check e2422408467298 [[],[]] .chain = true := by decide
def e2422408467310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422408467310 : Closed e2422408467310 ∧ code e2422408467310 = 11218501489518 := by decide
theorem cert_e2422408467310 : checkPay e2422408467310 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e2422408467318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422408467318 : Closed e2422408467318 ∧ code e2422408467318 = 11218501489526 := by decide
theorem cert_e2422408467318 : check e2422408467318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422408467338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408467338 : Closed e2422408467338 ∧ code e2422408467338 = 11218501489546 := by decide
theorem cert_e2422408467338 : check e2422408467338 [[],[]] .chain = true := by decide
def e2422408467362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408467362 : Closed e2422408467362 ∧ code e2422408467362 = 11218501489570 := by decide
theorem cert_e2422408467362 : check e2422408467362 [[],[]] .chain = true := by decide
def e2422408467374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422408467374 : Closed e2422408467374 ∧ code e2422408467374 = 11218501489582 := by decide
theorem cert_e2422408467374 : check e2422408467374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408467382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422408467382 : Closed e2422408467382 ∧ code e2422408467382 = 11218501489590 := by decide
theorem cert_e2422408467382 : check e2422408467382 [[],[]] .chain = true := by decide
def e2422408467386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422408467386 : Closed e2422408467386 ∧ code e2422408467386 = 11218501489594 := by decide
theorem cert_e2422408467386 : check e2422408467386 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408467414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422408467414 : Closed e2422408467414 ∧ code e2422408467414 = 11218501489622 := by decide
theorem cert_e2422408467414 : check e2422408467414 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408467418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422408467418 : Closed e2422408467418 ∧ code e2422408467418 = 11218501489626 := by decide
theorem cert_e2422408467418 : check e2422408467418 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408467486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408467486 : Closed e2422408467486 ∧ code e2422408467486 = 11218501489694 := by decide
theorem cert_e2422408467486 : check e2422408467486 [[],[]] .chain = true := by decide
def e2422408467682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408467682 : Closed e2422408467682 ∧ code e2422408467682 = 11218501489890 := by decide
theorem cert_e2422408467682 : check e2422408467682 [[],[]] .chain = true := by decide
def e2422408467694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408467694 : Closed e2422408467694 ∧ code e2422408467694 = 11218501489902 := by decide
theorem cert_e2422408467694 : check e2422408467694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408467702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408467702 : Closed e2422408467702 ∧ code e2422408467702 = 11218501489910 := by decide
theorem cert_e2422408467702 : check e2422408467702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408467970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408467970 : Closed e2422408467970 ∧ code e2422408467970 = 11218501490178 := by decide
theorem cert_e2422408467970 : check e2422408467970 [[],[]] .chain = true := by decide
def e2422408467982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408467982 : Closed e2422408467982 ∧ code e2422408467982 = 11218501490190 := by decide
theorem cert_e2422408467982 : check e2422408467982 [[],[]] .chain = true := by decide
def e2422408467994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408467994 : Closed e2422408467994 ∧ code e2422408467994 = 11218501490202 := by decide
theorem cert_e2422408467994 : check e2422408467994 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408468066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408468066 : Closed e2422408468066 ∧ code e2422408468066 = 11218501490274 := by decide
theorem cert_e2422408468066 : check e2422408468066 [[],[]] .chain = true := by decide
def e2422408468078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408468078 : Closed e2422408468078 ∧ code e2422408468078 = 11218501490286 := by decide
theorem cert_e2422408468078 : check e2422408468078 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408468086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408468086 : Closed e2422408468086 ∧ code e2422408468086 = 11218501490294 := by decide
theorem cert_e2422408468086 : check e2422408468086 [[],[]] .chain = true := by decide
def e2422408468090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408468090 : Closed e2422408468090 ∧ code e2422408468090 = 11218501490298 := by decide
theorem cert_e2422408468090 : check e2422408468090 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422408468278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408468278 : Closed e2422408468278 ∧ code e2422408468278 = 11218501490486 := by decide
theorem cert_e2422408468278 : check e2422408468278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422408468282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408468282 : Closed e2422408468282 ∧ code e2422408468282 = 11218501490490 := by decide
theorem cert_e2422408468282 : check e2422408468282 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408468490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408468490 : Closed e2422408468490 ∧ code e2422408468490 = 11218501490698 := by decide
theorem cert_e2422408468490 : check e2422408468490 [[],[]] .chain = true := by decide
def e2422408468526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408468526 : Closed e2422408468526 ∧ code e2422408468526 = 11218501490734 := by decide
theorem cert_e2422408468526 : check e2422408468526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422408468534 : Closed e2422408468534 ∧ code e2422408468534 = 11218501490742 := by decide
theorem cert_e2422408468534 : check e2422408468534 [[],[]] .chain = true := by decide
def e2422408468538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422408468538 : Closed e2422408468538 ∧ code e2422408468538 = 11218501490746 := by decide
theorem cert_e2422408468538 : check e2422408468538 [[],[]] .chain = true := by decide
def e2422408468586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422408468586 : Closed e2422408468586 ∧ code e2422408468586 = 11218501490794 := by decide
theorem cert_e2422408468586 : check e2422408468586 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422408468622 : Closed e2422408468622 ∧ code e2422408468622 = 11218501490830 := by decide
theorem cert_e2422408468622 : check e2422408468622 [[],[]] .chain = true := by decide
def e2422408468634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408468634 : Closed e2422408468634 ∧ code e2422408468634 = 11218501490842 := by decide
theorem cert_e2422408468634 : check e2422408468634 [[],[]] .chain = true := by decide
def e2422408468678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422408468678 : Closed e2422408468678 ∧ code e2422408468678 = 11218501490886 := by decide
theorem cert_e2422408468678 : check e2422408468678 [[],[]] .chain = true := by decide
def e2422408468706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408468706 : Closed e2422408468706 ∧ code e2422408468706 = 11218501490914 := by decide
theorem cert_e2422408468706 : check e2422408468706 [[],[]] .chain = true := by decide
def e2422408468718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422408468718 : Closed e2422408468718 ∧ code e2422408468718 = 11218501490926 := by decide
theorem cert_e2422408468718 : check e2422408468718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422408468726 : Closed e2422408468726 ∧ code e2422408468726 = 11218501490934 := by decide
theorem cert_e2422408468726 : check e2422408468726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408468874 : Closed e2422408468874 ∧ code e2422408468874 = 11218501491082 := by decide
theorem cert_e2422408468874 : check e2422408468874 [[],[]] .chain = true := by decide
def e2422408468898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408468898 : Closed e2422408468898 ∧ code e2422408468898 = 11218501491106 := by decide
theorem cert_e2422408468898 : check e2422408468898 [[],[]] .chain = true := by decide
def e2422408468910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422408468910 : Closed e2422408468910 ∧ code e2422408468910 = 11218501491118 := by decide
theorem cert_e2422408468910 : check e2422408468910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422408468918 : Closed e2422408468918 ∧ code e2422408468918 = 11218501491126 := by decide
theorem cert_e2422408468918 : check e2422408468918 [[],[]] .chain = true := by decide
def e2422408468922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422408468922 : Closed e2422408468922 ∧ code e2422408468922 = 11218501491130 := by decide
theorem cert_e2422408468922 : check e2422408468922 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422408468950 : Closed e2422408468950 ∧ code e2422408468950 = 11218501491158 := by decide
theorem cert_e2422408468950 : check e2422408468950 [[],[]] .chain = true := by decide
def e2422408468954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422408468954 : Closed e2422408468954 ∧ code e2422408468954 = 11218501491162 := by decide
theorem cert_e2422408468954 : check e2422408468954 [[],[]] .chain = true := by decide
def e2422408468970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422408468970 : Closed e2422408468970 ∧ code e2422408468970 = 11218501491178 := by decide
theorem cert_e2422408468970 : check e2422408468970 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408468994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408468994 : Closed e2422408468994 ∧ code e2422408468994 = 11218501491202 := by decide
theorem cert_e2422408468994 : check e2422408468994 [[],[]] .chain = true := by decide
def e2422408469006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408469006 : Closed e2422408469006 ∧ code e2422408469006 = 11218501491214 := by decide
theorem cert_e2422408469006 : check e2422408469006 [[],[]] .chain = true := by decide
def e2422408469018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408469018 : Closed e2422408469018 ∧ code e2422408469018 = 11218501491226 := by decide
theorem cert_e2422408469018 : check e2422408469018 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408469090 : Closed e2422408469090 ∧ code e2422408469090 = 11218501491298 := by decide
theorem cert_e2422408469090 : check e2422408469090 [[],[]] .chain = true := by decide
def e2422408469102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408469102 : Closed e2422408469102 ∧ code e2422408469102 = 11218501491310 := by decide
theorem cert_e2422408469102 : check e2422408469102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408469110 : Closed e2422408469110 ∧ code e2422408469110 = 11218501491318 := by decide
theorem cert_e2422408469110 : check e2422408469110 [[],[]] .chain = true := by decide
def e2422408469114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408469114 : Closed e2422408469114 ∧ code e2422408469114 = 11218501491322 := by decide
theorem cert_e2422408469114 : check e2422408469114 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422408469254 : Closed e2422408469254 ∧ code e2422408469254 = 11218501491462 := by decide
theorem cert_e2422408469254 : check e2422408469254 [[],[]] .chain = true := by decide
def e2422408469278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422408469278 : Closed e2422408469278 ∧ code e2422408469278 = 11218501491486 := by decide
theorem cert_e2422408469278 : check e2422408469278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408469302 : Closed e2422408469302 ∧ code e2422408469302 = 11218501491510 := by decide
theorem cert_e2422408469302 : check e2422408469302 [[],[]] .chain = true := by decide
def e2422408469306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408469306 : Closed e2422408469306 ∧ code e2422408469306 = 11218501491514 := by decide
theorem cert_e2422408469306 : check e2422408469306 [[],[]] .chain = true := by decide
def e2422408469378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408469378 : Closed e2422408469378 ∧ code e2422408469378 = 11218501491586 := by decide
theorem cert_e2422408469378 : check e2422408469378 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422408469390 : Closed e2422408469390 ∧ code e2422408469390 = 11218501491598 := by decide
theorem cert_e2422408469390 : check e2422408469390 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408469402 : Closed e2422408469402 ∧ code e2422408469402 = 11218501491610 := by decide
theorem cert_e2422408469402 : check e2422408469402 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408469526 : Closed e2422408469526 ∧ code e2422408469526 = 11218501491734 := by decide
theorem cert_e2422408469526 : check e2422408469526 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408469622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422408469622 : Closed e2422408469622 ∧ code e2422408469622 = 11218501491830 := by decide
theorem cert_e2422408469622 : check e2422408469622 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408469718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422408469718 : Closed e2422408469718 ∧ code e2422408469718 = 11218501491926 := by decide
theorem cert_e2422408469718 : check e2422408469718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408469722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422408469722 : Closed e2422408469722 ∧ code e2422408469722 = 11218501491930 := by decide
theorem cert_e2422408469722 : check e2422408469722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422408469738 : Closed e2422408469738 ∧ code e2422408469738 = 11218501491946 := by decide
theorem cert_e2422408469738 : check e2422408469738 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408469814 : Closed e2422408469814 ∧ code e2422408469814 = 11218501492022 := by decide
theorem cert_e2422408469814 : check e2422408469814 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408469818 : Closed e2422408469818 ∧ code e2422408469818 = 11218501492026 := by decide
theorem cert_e2422408469818 : check e2422408469818 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408469890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408469890 : Closed e2422408469890 ∧ code e2422408469890 = 11218501492098 := by decide
theorem cert_e2422408469890 : check e2422408469890 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408469902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422408469902 : Closed e2422408469902 ∧ code e2422408469902 = 11218501492110 := by decide
theorem cert_e2422408469902 : check e2422408469902 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408469914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408469914 : Closed e2422408469914 ∧ code e2422408469914 = 11218501492122 := by decide
theorem cert_e2422408469914 : check e2422408469914 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408479982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408479982 : Closed e2422408479982 ∧ code e2422408479982 = 11218501502190 := by decide
theorem cert_e2422408479982 : check e2422408479982 [[],[]] .chain = true := by decide
def e2422408479990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408479990 : Closed e2422408479990 ∧ code e2422408479990 = 11218501502198 := by decide
theorem cert_e2422408479990 : check e2422408479990 [[],[]] .chain = true := by decide
def e2422408482286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3)))))) (.var 2))))))
theorem wire_e2422408482286 : Closed e2422408482286 ∧ code e2422408482286 = 11218501504494 := by decide
theorem cert_e2422408482286 : check e2422408482286 [[],[]] .chain = true := by decide
def e2422408482294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4)))))) (.var 1))))))
theorem wire_e2422408482294 : Closed e2422408482294 ∧ code e2422408482294 = 11218501504502 := by decide
theorem cert_e2422408482294 : check e2422408482294 [[],[]] .chain = true := by decide
def e2422408482734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 0)))))) (.var 2))))))
theorem wire_e2422408482734 : Closed e2422408482734 ∧ code e2422408482734 = 11218501504942 := by decide
theorem cert_e2422408482734 : check e2422408482734 [[],[]] .chain = true := by decide
def e2422408482774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 0)))))) (.var 1))))))
theorem wire_e2422408482774 : Closed e2422408482774 ∧ code e2422408482774 = 11218501504982 := by decide
theorem cert_e2422408482774 : check e2422408482774 [[],[]] .chain = true := by decide
def e2422408486126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408486126 : Closed e2422408486126 ∧ code e2422408486126 = 11218501508334 := by decide
theorem cert_e2422408486126 : check e2422408486126 [[],[]] .chain = true := by decide
def e2422408486134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408486134 : Closed e2422408486134 ∧ code e2422408486134 = 11218501508342 := by decide
theorem cert_e2422408486134 : check e2422408486134 [[],[]] .chain = true := by decide
def e2422408486510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408486510 : Closed e2422408486510 ∧ code e2422408486510 = 11218501508718 := by decide
theorem cert_e2422408486510 : check e2422408486510 [[],[]] .chain = true := by decide
def e2422408486522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408486522 : Closed e2422408486522 ∧ code e2422408486522 = 11218501508730 := by decide
theorem cert_e2422408486522 : check e2422408486522 [[],[]] .chain = true := by decide
def e2422408486710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408486710 : Closed e2422408486710 ∧ code e2422408486710 = 11218501508918 := by decide
theorem cert_e2422408486710 : check e2422408486710 [[],[]] .chain = true := by decide
def e2422408486714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408486714 : Closed e2422408486714 ∧ code e2422408486714 = 11218501508922 := by decide
theorem cert_e2422408486714 : check e2422408486714 [[],[]] .chain = true := by decide
def e2422408490426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e2422408490426 : Closed e2422408490426 ∧ code e2422408490426 = 11218501512634 := by decide
theorem cert_e2422408490426 : check e2422408490426 [[],[]] .smaller = true := by decide
def e2422408490458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e2422408490458 : Closed e2422408490458 ∧ code e2422408490458 = 11218501512666 := by decide
theorem cert_e2422408490458 : check e2422408490458 [[],[]] .smaller = true := by decide
def e2422408490682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e2422408490682 : Closed e2422408490682 ∧ code e2422408490682 = 11218501512890 := by decide
theorem cert_e2422408490682 : check e2422408490682 [[],[]] .smaller = true := by decide
def e2422408490730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e2422408490730 : Closed e2422408490730 ∧ code e2422408490730 = 11218501512938 := by decide
theorem cert_e2422408490730 : check e2422408490730 [[],[]] .smaller = true := by decide
def e2422408490842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e2422408490842 : Closed e2422408490842 ∧ code e2422408490842 = 11218501513050 := by decide
theorem cert_e2422408490842 : check e2422408490842 [[],[]] .smaller = true := by decide
def e2422408490858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e2422408490858 : Closed e2422408490858 ∧ code e2422408490858 = 11218501513066 := by decide
theorem cert_e2422408490858 : check e2422408490858 [[],[]] .smaller = true := by decide
def e2422408491502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3)))))) (.var 2))))))
theorem wire_e2422408491502 : Closed e2422408491502 ∧ code e2422408491502 = 11218501513710 := by decide
theorem cert_e2422408491502 : check e2422408491502 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422408463190
#print axioms Blc.Floor43.cert_e2422408463194
