import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377907834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377907834 : Closed e2422377907834 ∧ code e2422377907834 = 11218470930042 := by decide
theorem cert_e2422377907834 : check e2422377907834 [[],[]] .three = true := by decide
def e2422377907998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422377907998 : Closed e2422377907998 ∧ code e2422377907998 = 11218470930206 := by decide
theorem cert_e2422377907998 : check e2422377907998 [[],[]] .three = true := by decide
def e2422377908110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422377908110 : Closed e2422377908110 ∧ code e2422377908110 = 11218470930318 := by decide
theorem cert_e2422377908110 : check e2422377908110 [[],[]] .three = true := by decide
def e2422377908122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377908122 : Closed e2422377908122 ∧ code e2422377908122 = 11218470930330 := by decide
theorem cert_e2422377908122 : check e2422377908122 [[],[]] .three = true := by decide
def e2422377908158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422377908158 : Closed e2422377908158 ∧ code e2422377908158 = 11218470930366 := by decide
theorem cert_e2422377908158 : check e2422377908158 [[],[]] .three = true := by decide
def e2422377908190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e2422377908190 : Closed e2422377908190 ∧ code e2422377908190 = 11218470930398 := by decide
theorem cert_e2422377908190 : check e2422377908190 [[],[]] .three = true := by decide
def e2422377908206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422377908206 : Closed e2422377908206 ∧ code e2422377908206 = 11218470930414 := by decide
theorem cert_e2422377908206 : check e2422377908206 [[],[]] .three = true := by decide
def e2422377911854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422377911854 : Closed e2422377911854 ∧ code e2422377911854 = 11218470934062 := by decide
theorem cert_e2422377911854 : check e2422377911854 [[],[]] .three = true := by decide
def e2422377911862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422377911862 : Closed e2422377911862 ∧ code e2422377911862 = 11218470934070 := by decide
theorem cert_e2422377911862 : check e2422377911862 [[],[]] .three = true := by decide
def e2422377911866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422377911866 : Closed e2422377911866 ∧ code e2422377911866 = 11218470934074 := by decide
theorem cert_e2422377911866 : check e2422377911866 [[],[]] .three = true := by decide
def e2422377911950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422377911950 : Closed e2422377911950 ∧ code e2422377911950 = 11218470934158 := by decide
theorem cert_e2422377911950 : check e2422377911950 [[],[]] .three = true := by decide
def e2422377912006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422377912006 : Closed e2422377912006 ∧ code e2422377912006 = 11218470934214 := by decide
theorem cert_e2422377912006 : check e2422377912006 [[],[]] .three = true := by decide
def e2422377912030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422377912030 : Closed e2422377912030 ∧ code e2422377912030 = 11218470934238 := by decide
theorem cert_e2422377912030 : check e2422377912030 [[],[]] .three = true := by decide
def e2422377912034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422377912034 : Closed e2422377912034 ∧ code e2422377912034 = 11218470934242 := by decide
theorem cert_e2422377912034 : check e2422377912034 [[],[]] .three = true := by decide
def e2422377912046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422377912046 : Closed e2422377912046 ∧ code e2422377912046 = 11218470934254 := by decide
theorem cert_e2422377912046 : check e2422377912046 [[],[]] .three = true := by decide
def e2422377912054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422377912054 : Closed e2422377912054 ∧ code e2422377912054 = 11218470934262 := by decide
theorem cert_e2422377912054 : check e2422377912054 [[],[]] .three = true := by decide
def e2422377912086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422377912086 : Closed e2422377912086 ∧ code e2422377912086 = 11218470934294 := by decide
theorem cert_e2422377912086 : check e2422377912086 [[],[]] .three = true := by decide
def e2422377912090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422377912090 : Closed e2422377912090 ∧ code e2422377912090 = 11218470934298 := by decide
theorem cert_e2422377912090 : check e2422377912090 [[],[]] .three = true := by decide
def e2422377912134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422377912134 : Closed e2422377912134 ∧ code e2422377912134 = 11218470934342 := by decide
theorem cert_e2422377912134 : check e2422377912134 [[],[]] .three = true := by decide
def e2422377912158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422377912158 : Closed e2422377912158 ∧ code e2422377912158 = 11218470934366 := by decide
theorem cert_e2422377912158 : check e2422377912158 [[],[]] .three = true := by decide
def e2422377912162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422377912162 : Closed e2422377912162 ∧ code e2422377912162 = 11218470934370 := by decide
theorem cert_e2422377912162 : check e2422377912162 [[],[]] .three = true := by decide
def e2422377912174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2422377912174 : Closed e2422377912174 ∧ code e2422377912174 = 11218470934382 := by decide
theorem cert_e2422377912174 : check e2422377912174 [[],[]] .three = true := by decide
def e2422377912182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2422377912182 : Closed e2422377912182 ∧ code e2422377912182 = 11218470934390 := by decide
theorem cert_e2422377912182 : check e2422377912182 [[],[]] .three = true := by decide
def e2422377912186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422377912186 : Closed e2422377912186 ∧ code e2422377912186 = 11218470934394 := by decide
theorem cert_e2422377912186 : check e2422377912186 [[],[]] .three = true := by decide
def e2422377912202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377912202 : Closed e2422377912202 ∧ code e2422377912202 = 11218470934410 := by decide
theorem cert_e2422377912202 : check e2422377912202 [[],[]] .three = true := by decide
def e2422377912226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377912226 : Closed e2422377912226 ∧ code e2422377912226 = 11218470934434 := by decide
theorem cert_e2422377912226 : check e2422377912226 [[],[]] .three = true := by decide
def e2422377912238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422377912238 : Closed e2422377912238 ∧ code e2422377912238 = 11218470934446 := by decide
theorem cert_e2422377912238 : check e2422377912238 [[],[]] .three = true := by decide
def e2422377912246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2422377912246 : Closed e2422377912246 ∧ code e2422377912246 = 11218470934454 := by decide
theorem cert_e2422377912246 : check e2422377912246 [[],[]] .three = true := by decide
def e2422377912250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422377912250 : Closed e2422377912250 ∧ code e2422377912250 = 11218470934458 := by decide
theorem cert_e2422377912250 : check e2422377912250 [[],[]] .three = true := by decide
def e2422377912278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422377912278 : Closed e2422377912278 ∧ code e2422377912278 = 11218470934486 := by decide
theorem cert_e2422377912278 : check e2422377912278 [[],[]] .three = true := by decide
def e2422377912282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422377912282 : Closed e2422377912282 ∧ code e2422377912282 = 11218470934490 := by decide
theorem cert_e2422377912282 : check e2422377912282 [[],[]] .three = true := by decide
def e2422377912382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422377912382 : Closed e2422377912382 ∧ code e2422377912382 = 11218470934590 := by decide
theorem cert_e2422377912382 : check e2422377912382 [[],[]] .three = true := by decide
def e2422377912430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422377912430 : Closed e2422377912430 ∧ code e2422377912430 = 11218470934638 := by decide
theorem cert_e2422377912430 : check e2422377912430 [[],[]] .three = true := by decide
def e2422377912442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422377912442 : Closed e2422377912442 ∧ code e2422377912442 = 11218470934650 := by decide
theorem cert_e2422377912442 : check e2422377912442 [[],[]] .three = true := by decide
def e2422377912718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422377912718 : Closed e2422377912718 ∧ code e2422377912718 = 11218470934926 := by decide
theorem cert_e2422377912718 : check e2422377912718 [[],[]] .three = true := by decide
def e2422377912774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422377912774 : Closed e2422377912774 ∧ code e2422377912774 = 11218470934982 := by decide
theorem cert_e2422377912774 : check e2422377912774 [[],[]] .three = true := by decide
def e2422377912798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422377912798 : Closed e2422377912798 ∧ code e2422377912798 = 11218470935006 := by decide
theorem cert_e2422377912798 : check e2422377912798 [[],[]] .three = true := by decide
def e2422377912802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422377912802 : Closed e2422377912802 ∧ code e2422377912802 = 11218470935010 := by decide
theorem cert_e2422377912802 : check e2422377912802 [[],[]] .three = true := by decide
def e2422377912814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422377912814 : Closed e2422377912814 ∧ code e2422377912814 = 11218470935022 := by decide
theorem cert_e2422377912814 : check e2422377912814 [[],[]] .three = true := by decide
def e2422377912822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422377912822 : Closed e2422377912822 ∧ code e2422377912822 = 11218470935030 := by decide
theorem cert_e2422377912822 : check e2422377912822 [[],[]] .three = true := by decide
def e2422377913374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422377913374 : Closed e2422377913374 ∧ code e2422377913374 = 11218470935582 := by decide
theorem cert_e2422377913374 : check e2422377913374 [[],[]] .three = true := by decide
def e2422377913398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377913398 : Closed e2422377913398 ∧ code e2422377913398 = 11218470935606 := by decide
theorem cert_e2422377913398 : check e2422377913398 [[],[]] .three = true := by decide
def e2422377913402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377913402 : Closed e2422377913402 ∧ code e2422377913402 = 11218470935610 := by decide
theorem cert_e2422377913402 : check e2422377913402 [[],[]] .three = true := by decide
def e2422377913542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422377913542 : Closed e2422377913542 ∧ code e2422377913542 = 11218470935750 := by decide
theorem cert_e2422377913542 : check e2422377913542 [[],[]] .three = true := by decide
def e2422377913566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377913566 : Closed e2422377913566 ∧ code e2422377913566 = 11218470935774 := by decide
theorem cert_e2422377913566 : check e2422377913566 [[],[]] .three = true := by decide
def e2422377913570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422377913570 : Closed e2422377913570 ∧ code e2422377913570 = 11218470935778 := by decide
theorem cert_e2422377913570 : check e2422377913570 [[],[]] .three = true := by decide
def e2422377913582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377913582 : Closed e2422377913582 ∧ code e2422377913582 = 11218470935790 := by decide
theorem cert_e2422377913582 : check e2422377913582 [[],[]] .three = true := by decide
def e2422377913590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377913590 : Closed e2422377913590 ∧ code e2422377913590 = 11218470935798 := by decide
theorem cert_e2422377913590 : check e2422377913590 [[],[]] .three = true := by decide
def e2422377913594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377913594 : Closed e2422377913594 ∧ code e2422377913594 = 11218470935802 := by decide
theorem cert_e2422377913594 : check e2422377913594 [[],[]] .three = true := by decide
def e2422377913870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377913870 : Closed e2422377913870 ∧ code e2422377913870 = 11218470936078 := by decide
theorem cert_e2422377913870 : check e2422377913870 [[],[]] .three = true := by decide
def e2422377913882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377913882 : Closed e2422377913882 ∧ code e2422377913882 = 11218470936090 := by decide
theorem cert_e2422377913882 : check e2422377913882 [[],[]] .three = true := by decide
def e2422377913918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422377913918 : Closed e2422377913918 ∧ code e2422377913918 = 11218470936126 := by decide
theorem cert_e2422377913918 : check e2422377913918 [[],[]] .three = true := by decide
def e2422377913954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377913954 : Closed e2422377913954 ∧ code e2422377913954 = 11218470936162 := by decide
theorem cert_e2422377913954 : check e2422377913954 [[],[]] .three = true := by decide
def e2422377913966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377913966 : Closed e2422377913966 ∧ code e2422377913966 = 11218470936174 := by decide
theorem cert_e2422377913966 : check e2422377913966 [[],[]] .three = true := by decide
def e2422377913974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377913974 : Closed e2422377913974 ∧ code e2422377913974 = 11218470936182 := by decide
theorem cert_e2422377913974 : check e2422377913974 [[],[]] .three = true := by decide
def e2422377913978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377913978 : Closed e2422377913978 ∧ code e2422377913978 = 11218470936186 := by decide
theorem cert_e2422377913978 : check e2422377913978 [[],[]] .three = true := by decide
def e2422377914142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422377914142 : Closed e2422377914142 ∧ code e2422377914142 = 11218470936350 := by decide
theorem cert_e2422377914142 : check e2422377914142 [[],[]] .three = true := by decide
def e2422377914166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377914166 : Closed e2422377914166 ∧ code e2422377914166 = 11218470936374 := by decide
theorem cert_e2422377914166 : check e2422377914166 [[],[]] .three = true := by decide
def e2422377914170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377914170 : Closed e2422377914170 ∧ code e2422377914170 = 11218470936378 := by decide
theorem cert_e2422377914170 : check e2422377914170 [[],[]] .three = true := by decide
def e2422377923286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422377923286 : Closed e2422377923286 ∧ code e2422377923286 = 11218470945494 := by decide
theorem cert_e2422377923286 : check e2422377923286 [[],[]] .three = true := by decide
def e2422377923290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422377923290 : Closed e2422377923290 ∧ code e2422377923290 = 11218470945498 := by decide
theorem cert_e2422377923290 : check e2422377923290 [[],[]] .three = true := by decide
def e2422377923306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422377923306 : Closed e2422377923306 ∧ code e2422377923306 = 11218470945514 := by decide
theorem cert_e2422377923306 : check e2422377923306 [[],[]] .three = true := by decide
def e2422377923382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377923382 : Closed e2422377923382 ∧ code e2422377923382 = 11218470945590 := by decide
theorem cert_e2422377923382 : check e2422377923382 [[],[]] .three = true := by decide
def e2422377923386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377923386 : Closed e2422377923386 ∧ code e2422377923386 = 11218470945594 := by decide
theorem cert_e2422377923386 : check e2422377923386 [[],[]] .three = true := by decide
def e2422377923470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422377923470 : Closed e2422377923470 ∧ code e2422377923470 = 11218470945678 := by decide
theorem cert_e2422377923470 : check e2422377923470 [[],[]] .three = true := by decide
def e2422377923482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377923482 : Closed e2422377923482 ∧ code e2422377923482 = 11218470945690 := by decide
theorem cert_e2422377923482 : check e2422377923482 [[],[]] .three = true := by decide
def e2422377923518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 4))))))))))
theorem wire_e2422377923518 : Closed e2422377923518 ∧ code e2422377923518 = 11218470945726 := by decide
theorem cert_e2422377923518 : check e2422377923518 [[],[]] .three = true := by decide
def e2422377923550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422377923550 : Closed e2422377923550 ∧ code e2422377923550 = 11218470945758 := by decide
theorem cert_e2422377923550 : check e2422377923550 [[],[]] .three = true := by decide
def e2422377923566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422377923566 : Closed e2422377923566 ∧ code e2422377923566 = 11218470945774 := by decide
theorem cert_e2422377923566 : check e2422377923566 [[],[]] .three = true := by decide
def e2422377923574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 4) (.var 1))))))))))
theorem wire_e2422377923574 : Closed e2422377923574 ∧ code e2422377923574 = 11218470945782 := by decide
theorem cert_e2422377923574 : check e2422377923574 [[],[]] .three = true := by decide
def e2422377925398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422377925398 : Closed e2422377925398 ∧ code e2422377925398 = 11218470947606 := by decide
theorem cert_e2422377925398 : check e2422377925398 [[],[]] .three = true := by decide
def e2422377925402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422377925402 : Closed e2422377925402 ∧ code e2422377925402 = 11218470947610 := by decide
theorem cert_e2422377925402 : check e2422377925402 [[],[]] .three = true := by decide
def e2422377925446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422377925446 : Closed e2422377925446 ∧ code e2422377925446 = 11218470947654 := by decide
theorem cert_e2422377925446 : check e2422377925446 [[],[]] .three = true := by decide
def e2422377925470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2422377925470 : Closed e2422377925470 ∧ code e2422377925470 = 11218470947678 := by decide
theorem cert_e2422377925470 : check e2422377925470 [[],[]] .three = true := by decide
def e2422377925474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422377925474 : Closed e2422377925474 ∧ code e2422377925474 = 11218470947682 := by decide
theorem cert_e2422377925474 : check e2422377925474 [[],[]] .three = true := by decide
def e2422377925486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422377925486 : Closed e2422377925486 ∧ code e2422377925486 = 11218470947694 := by decide
theorem cert_e2422377925486 : check e2422377925486 [[],[]] .three = true := by decide
def e2422377925494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422377925494 : Closed e2422377925494 ∧ code e2422377925494 = 11218470947702 := by decide
theorem cert_e2422377925494 : check e2422377925494 [[],[]] .three = true := by decide
def e2422377925498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2422377925498 : Closed e2422377925498 ∧ code e2422377925498 = 11218470947706 := by decide
theorem cert_e2422377925498 : check e2422377925498 [[],[]] .three = true := by decide
def e2422377925514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377925514 : Closed e2422377925514 ∧ code e2422377925514 = 11218470947722 := by decide
theorem cert_e2422377925514 : check e2422377925514 [[],[]] .three = true := by decide
def e2422377925538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377925538 : Closed e2422377925538 ∧ code e2422377925538 = 11218470947746 := by decide
theorem cert_e2422377925538 : check e2422377925538 [[],[]] .three = true := by decide
def e2422377925550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422377925550 : Closed e2422377925550 ∧ code e2422377925550 = 11218470947758 := by decide
theorem cert_e2422377925550 : check e2422377925550 [[],[]] .three = true := by decide
def e2422377925562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422377925562 : Closed e2422377925562 ∧ code e2422377925562 = 11218470947770 := by decide
theorem cert_e2422377925562 : check e2422377925562 [[],[]] .three = true := by decide
def e2422377925590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422377925590 : Closed e2422377925590 ∧ code e2422377925590 = 11218470947798 := by decide
theorem cert_e2422377925590 : check e2422377925590 [[],[]] .three = true := by decide
def e2422377925594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422377925594 : Closed e2422377925594 ∧ code e2422377925594 = 11218470947802 := by decide
theorem cert_e2422377925594 : check e2422377925594 [[],[]] .three = true := by decide
def e2422377925610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2422377925610 : Closed e2422377925610 ∧ code e2422377925610 = 11218470947818 := by decide
theorem cert_e2422377925610 : check e2422377925610 [[],[]] .three = true := by decide
def e2422377925662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422377925662 : Closed e2422377925662 ∧ code e2422377925662 = 11218470947870 := by decide
theorem cert_e2422377925662 : check e2422377925662 [[],[]] .three = true := by decide
def e2422377925686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422377925686 : Closed e2422377925686 ∧ code e2422377925686 = 11218470947894 := by decide
theorem cert_e2422377925686 : check e2422377925686 [[],[]] .three = true := by decide
def e2422377925690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422377925690 : Closed e2422377925690 ∧ code e2422377925690 = 11218470947898 := by decide
theorem cert_e2422377925690 : check e2422377925690 [[],[]] .three = true := by decide
def e2422377925830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422377925830 : Closed e2422377925830 ∧ code e2422377925830 = 11218470948038 := by decide
theorem cert_e2422377925830 : check e2422377925830 [[],[]] .three = true := by decide
def e2422377925854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422377925854 : Closed e2422377925854 ∧ code e2422377925854 = 11218470948062 := by decide
theorem cert_e2422377925854 : check e2422377925854 [[],[]] .three = true := by decide
def e2422377925858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422377925858 : Closed e2422377925858 ∧ code e2422377925858 = 11218470948066 := by decide
theorem cert_e2422377925858 : check e2422377925858 [[],[]] .three = true := by decide
def e2422377925870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377925870 : Closed e2422377925870 ∧ code e2422377925870 = 11218470948078 := by decide
theorem cert_e2422377925870 : check e2422377925870 [[],[]] .three = true := by decide
def e2422377925878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377925878 : Closed e2422377925878 ∧ code e2422377925878 = 11218470948086 := by decide
theorem cert_e2422377925878 : check e2422377925878 [[],[]] .three = true := by decide
def e2422377925882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422377925882 : Closed e2422377925882 ∧ code e2422377925882 = 11218470948090 := by decide
theorem cert_e2422377925882 : check e2422377925882 [[],[]] .three = true := by decide
def e2422377926158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377926158 : Closed e2422377926158 ∧ code e2422377926158 = 11218470948366 := by decide
theorem cert_e2422377926158 : check e2422377926158 [[],[]] .three = true := by decide
def e2422377926242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377926242 : Closed e2422377926242 ∧ code e2422377926242 = 11218470948450 := by decide
theorem cert_e2422377926242 : check e2422377926242 [[],[]] .three = true := by decide
def e2422377926254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377926254 : Closed e2422377926254 ∧ code e2422377926254 = 11218470948462 := by decide
theorem cert_e2422377926254 : check e2422377926254 [[],[]] .three = true := by decide
def e2422377926266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377926266 : Closed e2422377926266 ∧ code e2422377926266 = 11218470948474 := by decide
theorem cert_e2422377926266 : check e2422377926266 [[],[]] .three = true := by decide
def e2422377926430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2422377926430 : Closed e2422377926430 ∧ code e2422377926430 = 11218470948638 := by decide
theorem cert_e2422377926430 : check e2422377926430 [[],[]] .three = true := by decide
def e2422377926454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377926454 : Closed e2422377926454 ∧ code e2422377926454 = 11218470948662 := by decide
theorem cert_e2422377926454 : check e2422377926454 [[],[]] .three = true := by decide
def e2422377926458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377926458 : Closed e2422377926458 ∧ code e2422377926458 = 11218470948666 := by decide
theorem cert_e2422377926458 : check e2422377926458 [[],[]] .three = true := by decide
def e2422377926554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377926554 : Closed e2422377926554 ∧ code e2422377926554 = 11218470948762 := by decide
theorem cert_e2422377926554 : check e2422377926554 [[],[]] .three = true := by decide
def e2422377931230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422377931230 : Closed e2422377931230 ∧ code e2422377931230 = 11218470953438 := by decide
theorem cert_e2422377931230 : check e2422377931230 [[],[]] .three = true := by decide
def e2422377931246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422377931246 : Closed e2422377931246 ∧ code e2422377931246 = 11218470953454 := by decide
theorem cert_e2422377931246 : check e2422377931246 [[],[]] .three = true := by decide
def e2422377931254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422377931254 : Closed e2422377931254 ∧ code e2422377931254 = 11218470953462 := by decide
theorem cert_e2422377931254 : check e2422377931254 [[],[]] .three = true := by decide
def e2422377932170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422377932170 : Closed e2422377932170 ∧ code e2422377932170 = 11218470954378 := by decide
theorem cert_e2422377932170 : check e2422377932170 [[],[]] .three = true := by decide
def e2422377932194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422377932194 : Closed e2422377932194 ∧ code e2422377932194 = 11218470954402 := by decide
theorem cert_e2422377932194 : check e2422377932194 [[],[]] .three = true := by decide
def e2422377932206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422377932206 : Closed e2422377932206 ∧ code e2422377932206 = 11218470954414 := by decide
theorem cert_e2422377932206 : check e2422377932206 [[],[]] .three = true := by decide
def e2422377932214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422377932214 : Closed e2422377932214 ∧ code e2422377932214 = 11218470954422 := by decide
theorem cert_e2422377932214 : check e2422377932214 [[],[]] .three = true := by decide
def e2422377932218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422377932218 : Closed e2422377932218 ∧ code e2422377932218 = 11218470954426 := by decide
theorem cert_e2422377932218 : check e2422377932218 [[],[]] .three = true := by decide
def e2422377932246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422377932246 : Closed e2422377932246 ∧ code e2422377932246 = 11218470954454 := by decide
theorem cert_e2422377932246 : check e2422377932246 [[],[]] .three = true := by decide
def e2422377932250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422377932250 : Closed e2422377932250 ∧ code e2422377932250 = 11218470954458 := by decide
theorem cert_e2422377932250 : check e2422377932250 [[],[]] .three = true := by decide
def e2422377932266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422377932266 : Closed e2422377932266 ∧ code e2422377932266 = 11218470954474 := by decide
theorem cert_e2422377932266 : check e2422377932266 [[],[]] .three = true := by decide
def e2422377932302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422377932302 : Closed e2422377932302 ∧ code e2422377932302 = 11218470954510 := by decide
theorem cert_e2422377932302 : check e2422377932302 [[],[]] .three = true := by decide
def e2422377932314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422377932314 : Closed e2422377932314 ∧ code e2422377932314 = 11218470954522 := by decide
theorem cert_e2422377932314 : check e2422377932314 [[],[]] .three = true := by decide
def e2422377932350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422377932350 : Closed e2422377932350 ∧ code e2422377932350 = 11218470954558 := by decide
theorem cert_e2422377932350 : check e2422377932350 [[],[]] .three = true := by decide
def e2422377932386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422377932386 : Closed e2422377932386 ∧ code e2422377932386 = 11218470954594 := by decide
theorem cert_e2422377932386 : check e2422377932386 [[],[]] .three = true := by decide
def e2422377932398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422377932398 : Closed e2422377932398 ∧ code e2422377932398 = 11218470954606 := by decide
theorem cert_e2422377932398 : check e2422377932398 [[],[]] .three = true := by decide
def e2422377932406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422377932406 : Closed e2422377932406 ∧ code e2422377932406 = 11218470954614 := by decide
theorem cert_e2422377932406 : check e2422377932406 [[],[]] .three = true := by decide
def e2422377932410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422377932410 : Closed e2422377932410 ∧ code e2422377932410 = 11218470954618 := by decide
theorem cert_e2422377932410 : check e2422377932410 [[],[]] .three = true := by decide
def e2422377932574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422377932574 : Closed e2422377932574 ∧ code e2422377932574 = 11218470954782 := by decide
theorem cert_e2422377932574 : check e2422377932574 [[],[]] .three = true := by decide
def e2422377932598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377932598 : Closed e2422377932598 ∧ code e2422377932598 = 11218470954806 := by decide
theorem cert_e2422377932598 : check e2422377932598 [[],[]] .three = true := by decide
def e2422377932602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377932602 : Closed e2422377932602 ∧ code e2422377932602 = 11218470954810 := by decide
theorem cert_e2422377932602 : check e2422377932602 [[],[]] .three = true := by decide
def e2422377932686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422377932686 : Closed e2422377932686 ∧ code e2422377932686 = 11218470954894 := by decide
theorem cert_e2422377932686 : check e2422377932686 [[],[]] .three = true := by decide
def e2422377932698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377932698 : Closed e2422377932698 ∧ code e2422377932698 = 11218470954906 := by decide
theorem cert_e2422377932698 : check e2422377932698 [[],[]] .three = true := by decide
def e2422377932742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422377932742 : Closed e2422377932742 ∧ code e2422377932742 = 11218470954950 := by decide
theorem cert_e2422377932742 : check e2422377932742 [[],[]] .three = true := by decide
def e2422377935086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422377935086 : Closed e2422377935086 ∧ code e2422377935086 = 11218470957294 := by decide
theorem cert_e2422377935086 : check e2422377935086 [[],[]] .three = true := by decide
def e2422377935094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422377935094 : Closed e2422377935094 ∧ code e2422377935094 = 11218470957302 := by decide
theorem cert_e2422377935094 : check e2422377935094 [[],[]] .three = true := by decide
def e2422377935574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422377935574 : Closed e2422377935574 ∧ code e2422377935574 = 11218470957782 := by decide
theorem cert_e2422377935574 : check e2422377935574 [[],[]] .three = true := by decide
def e2422377935578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422377935578 : Closed e2422377935578 ∧ code e2422377935578 = 11218470957786 := by decide
theorem cert_e2422377935578 : check e2422377935578 [[],[]] .three = true := by decide
def e2422377935594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422377935594 : Closed e2422377935594 ∧ code e2422377935594 = 11218470957802 := by decide
theorem cert_e2422377935594 : check e2422377935594 [[],[]] .three = true := by decide
def e2422377935646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422377935646 : Closed e2422377935646 ∧ code e2422377935646 = 11218470957854 := by decide
theorem cert_e2422377935646 : check e2422377935646 [[],[]] .three = true := by decide
def e2422377935670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422377935670 : Closed e2422377935670 ∧ code e2422377935670 = 11218470957878 := by decide
theorem cert_e2422377935670 : check e2422377935670 [[],[]] .three = true := by decide
def e2422377935674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422377935674 : Closed e2422377935674 ∧ code e2422377935674 = 11218470957882 := by decide
theorem cert_e2422377935674 : check e2422377935674 [[],[]] .three = true := by decide
def e2422377935770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422377935770 : Closed e2422377935770 ∧ code e2422377935770 = 11218470957978 := by decide
theorem cert_e2422377935770 : check e2422377935770 [[],[]] .three = true := by decide
def e2422377935814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422377935814 : Closed e2422377935814 ∧ code e2422377935814 = 11218470958022 := by decide
theorem cert_e2422377935814 : check e2422377935814 [[],[]] .three = true := by decide
def e2422396078958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422396078958 : Closed e2422396078958 ∧ code e2422396078958 = 11218489101166 := by decide
theorem cert_e2422396078958 : check e2422396078958 [[],[],[.under,.under]] .three = true := by decide
def e2422396078966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422396078966 : Closed e2422396078966 ∧ code e2422396078966 = 11218489101174 := by decide
theorem cert_e2422396078966 : check e2422396078966 [[],[],[.under,.under]] .three = true := by decide
def e2422396079022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422396079022 : Closed e2422396079022 ∧ code e2422396079022 = 11218489101230 := by decide
theorem cert_e2422396079022 : check e2422396079022 [[],[],[.under,.under]] .three = true := by decide
def e2422396079034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422396079034 : Closed e2422396079034 ∧ code e2422396079034 = 11218489101242 := by decide
theorem cert_e2422396079034 : check e2422396079034 [[],[],[.under,.under]] .three = true := by decide
def e2422396079062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422396079062 : Closed e2422396079062 ∧ code e2422396079062 = 11218489101270 := by decide
theorem cert_e2422396079062 : check e2422396079062 [[],[],[.under,.under]] .three = true := by decide
def e2422396079066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422396079066 : Closed e2422396079066 ∧ code e2422396079066 = 11218489101274 := by decide
theorem cert_e2422396079066 : check e2422396079066 [[],[],[.under,.under]] .three = true := by decide
def e2422396079342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422396079342 : Closed e2422396079342 ∧ code e2422396079342 = 11218489101550 := by decide
theorem cert_e2422396079342 : check e2422396079342 [[],[],[.under,.under]] .three = true := by decide
def e2422396079350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422396079350 : Closed e2422396079350 ∧ code e2422396079350 = 11218489101558 := by decide
theorem cert_e2422396079350 : check e2422396079350 [[],[],[.under,.under]] .three = true := by decide
def e2422396079726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422396079726 : Closed e2422396079726 ∧ code e2422396079726 = 11218489101934 := by decide
theorem cert_e2422396079726 : check e2422396079726 [[],[],[.under,.under]] .three = true := by decide
def e2422396079738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422396079738 : Closed e2422396079738 ∧ code e2422396079738 = 11218489101946 := by decide
theorem cert_e2422396079738 : check e2422396079738 [[],[],[.under,.under]] .three = true := by decide
def e2422396079926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422396079926 : Closed e2422396079926 ∧ code e2422396079926 = 11218489102134 := by decide
theorem cert_e2422396079926 : check e2422396079926 [[],[],[.under,.under]] .three = true := by decide
def e2422396079930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422396079930 : Closed e2422396079930 ∧ code e2422396079930 = 11218489102138 := by decide
theorem cert_e2422396079930 : check e2422396079930 [[],[],[.under,.under]] .three = true := by decide
def e2422398020846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398020846 : Closed e2422398020846 ∧ code e2422398020846 = 11218491043054 := by decide
theorem cert_e2422398020846 : check e2422398020846 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398020854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398020854 : Closed e2422398020854 ∧ code e2422398020854 = 11218491043062 := by decide
theorem cert_e2422398020854 : check e2422398020854 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398021230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422398021230 : Closed e2422398021230 ∧ code e2422398021230 = 11218491043438 := by decide
def e2422398021242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422398021242 : Closed e2422398021242 ∧ code e2422398021242 = 11218491043450 := by decide
theorem cert_e2422398021242 : check e2422398021242 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422398022894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398022894 : Closed e2422398022894 ∧ code e2422398022894 = 11218491045102 := by decide
theorem cert_e2422398022894 : check e2422398022894 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398022902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398022902 : Closed e2422398022902 ∧ code e2422398022902 = 11218491045110 := by decide
theorem cert_e2422398022902 : check e2422398022902 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .chain = true := by decide
def e2422398065902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422398065902 : Closed e2422398065902 ∧ code e2422398065902 = 11218491088110 := by decide
theorem cert_e2422398065902 : check e2422398065902 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398065910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422398065910 : Closed e2422398065910 ∧ code e2422398065910 = 11218491088118 := by decide
theorem cert_e2422398065910 : check e2422398065910 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .sourceHead = true := by decide
def e2422398077806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422398077806 : Closed e2422398077806 ∧ code e2422398077806 = 11218491100014 := by decide
theorem cert_e2422398077806 : check e2422398077806 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422398077814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422398077814 : Closed e2422398077814 ∧ code e2422398077814 = 11218491100022 := by decide
theorem cert_e2422398077814 : check e2422398077814 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422398077870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422398077870 : Closed e2422398077870 ∧ code e2422398077870 = 11218491100078 := by decide
theorem cert_e2422398077870 : check e2422398077870 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2422398077882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422398077882 : Closed e2422398077882 ∧ code e2422398077882 = 11218491100090 := by decide
theorem cert_e2422398077882 : check e2422398077882 [[],[],[.under,.under]] .sourceHead = true := by decide
end Blc.Floor43
