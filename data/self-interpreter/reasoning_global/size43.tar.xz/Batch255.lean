import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405940690970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405940690970 : Closed e2405940690970 ∧ code e2405940690970 = 11202033713178 := by decide
theorem cert_e2405940690970 : check e2405940690970 [[]] .width = true := by decide
def e2405940691062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405940691062 : Closed e2405940691062 ∧ code e2405940691062 = 11202033713270 := by decide
theorem cert_e2405940691062 : check e2405940691062 [[]] .width = true := by decide
def e2405940691306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405940691306 : Closed e2405940691306 ∧ code e2405940691306 = 11202033713514 := by decide
theorem cert_e2405940691306 : check e2405940691306 [[]] .width = true := by decide
def e2405940691354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405940691354 : Closed e2405940691354 ∧ code e2405940691354 = 11202033713562 := by decide
theorem cert_e2405940691354 : check e2405940691354 [[]] .width = true := by decide
def e2405940692362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405940692362 : Closed e2405940692362 ∧ code e2405940692362 = 11202033714570 := by decide
theorem cert_e2405940692362 : check e2405940692362 [[]] .width = true := by decide
def e2405940692386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405940692386 : Closed e2405940692386 ∧ code e2405940692386 = 11202033714594 := by decide
theorem cert_e2405940692386 : check e2405940692386 [[]] .width = true := by decide
def e2405940692494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405940692494 : Closed e2405940692494 ∧ code e2405940692494 = 11202033714702 := by decide
theorem cert_e2405940692494 : check e2405940692494 [[]] .width = true := by decide
def e2405940692506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405940692506 : Closed e2405940692506 ∧ code e2405940692506 = 11202033714714 := by decide
theorem cert_e2405940692506 : check e2405940692506 [[]] .width = true := by decide
def e2405940692578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405940692578 : Closed e2405940692578 ∧ code e2405940692578 = 11202033714786 := by decide
theorem cert_e2405940692578 : check e2405940692578 [[]] .width = true := by decide
def e2405945303066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405945303066 : Closed e2405945303066 ∧ code e2405945303066 = 11202038325274 := by decide
theorem cert_e2405945303066 : check e2405945303066 [[]] .width = true := by decide
def e2405945303158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405945303158 : Closed e2405945303158 ∧ code e2405945303158 = 11202038325366 := by decide
theorem cert_e2405945303158 : check e2405945303158 [[]] .width = true := by decide
def e2405945303402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405945303402 : Closed e2405945303402 ∧ code e2405945303402 = 11202038325610 := by decide
theorem cert_e2405945303402 : check e2405945303402 [[]] .width = true := by decide
def e2405945303450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405945303450 : Closed e2405945303450 ∧ code e2405945303450 = 11202038325658 := by decide
theorem cert_e2405945303450 : check e2405945303450 [[]] .width = true := by decide
def e2405945503942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405945503942 : Closed e2405945503942 ∧ code e2405945503942 = 11202038526150 := by decide
theorem cert_e2405945503942 : check e2405945503942 [[]] .width = true := by decide
def e2405945561286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405945561286 : Closed e2405945561286 ∧ code e2405945561286 = 11202038583494 := by decide
theorem cert_e2405945561286 : check e2405945561286 [[]] .width = true := by decide
def e2405945564698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405945564698 : Closed e2405945564698 ∧ code e2405945564698 = 11202038586906 := by decide
theorem cert_e2405945564698 : check e2405945564698 [[]] .width = true := by decide
def e2405946032326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405946032326 : Closed e2405946032326 ∧ code e2405946032326 = 11202039054534 := by decide
theorem cert_e2405946032326 : check e2405946032326 [[]] .width = true := by decide
def e2405946032854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405946032854 : Closed e2405946032854 ∧ code e2405946032854 = 11202039055062 := by decide
theorem cert_e2405946032854 : check e2405946032854 [[]] .width = true := by decide
def e2405946032858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405946032858 : Closed e2405946032858 ∧ code e2405946032858 = 11202039055066 := by decide
theorem cert_e2405946032858 : check e2405946032858 [[]] .width = true := by decide
def e2405946032874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405946032874 : Closed e2405946032874 ∧ code e2405946032874 = 11202039055082 := by decide
theorem cert_e2405946032874 : check e2405946032874 [[]] .width = true := by decide
def e2405946032950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405946032950 : Closed e2405946032950 ∧ code e2405946032950 = 11202039055158 := by decide
theorem cert_e2405946032950 : check e2405946032950 [[]] .width = true := by decide
def e2405946032954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405946032954 : Closed e2405946032954 ∧ code e2405946032954 = 11202039055162 := by decide
theorem cert_e2405946032954 : check e2405946032954 [[]] .width = true := by decide
def e2405946033038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405946033038 : Closed e2405946033038 ∧ code e2405946033038 = 11202039055246 := by decide
theorem cert_e2405946033038 : check e2405946033038 [[]] .width = true := by decide
def e2405946033050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405946033050 : Closed e2405946033050 ∧ code e2405946033050 = 11202039055258 := by decide
theorem cert_e2405946033050 : check e2405946033050 [[]] .width = true := by decide
def e2405946034970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405946034970 : Closed e2405946034970 ∧ code e2405946034970 = 11202039057178 := by decide
theorem cert_e2405946034970 : check e2405946034970 [[]] .width = true := by decide
def e2405946035014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405946035014 : Closed e2405946035014 ∧ code e2405946035014 = 11202039057222 := by decide
theorem cert_e2405946035014 : check e2405946035014 [[]] .width = true := by decide
def e2405946035254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405946035254 : Closed e2405946035254 ∧ code e2405946035254 = 11202039057462 := by decide
theorem cert_e2405946035254 : check e2405946035254 [[]] .width = true := by decide
def e2405946035258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405946035258 : Closed e2405946035258 ∧ code e2405946035258 = 11202039057466 := by decide
theorem cert_e2405946035258 : check e2405946035258 [[]] .width = true := by decide
def e2405946035398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405946035398 : Closed e2405946035398 ∧ code e2405946035398 = 11202039057606 := by decide
theorem cert_e2405946035398 : check e2405946035398 [[]] .width = true := by decide
def e2405946538010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405946538010 : Closed e2405946538010 ∧ code e2405946538010 = 11202039560218 := by decide
theorem cert_e2405946538010 : check e2405946538010 [[]] .width = true := by decide
def e2405946550298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405946550298 : Closed e2405946550298 ∧ code e2405946550298 = 11202039572506 := by decide
theorem cert_e2405946550298 : check e2405946550298 [[]] .width = true := by decide
def e2405946551834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405946551834 : Closed e2405946551834 ∧ code e2405946551834 = 11202039574042 := by decide
theorem cert_e2405946551834 : check e2405946551834 [[]] .width = true := by decide
def e2405946599450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405946599450 : Closed e2405946599450 ∧ code e2405946599450 = 11202039621658 := by decide
theorem cert_e2405946599450 : check e2405946599450 [[]] .width = true := by decide
def e2405946600986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405946600986 : Closed e2405946600986 ∧ code e2405946600986 = 11202039623194 := by decide
theorem cert_e2405946600986 : check e2405946600986 [[]] .width = true := by decide
def e2405946604058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405946604058 : Closed e2405946604058 ∧ code e2405946604058 = 11202039626266 := by decide
theorem cert_e2405946604058 : check e2405946604058 [[]] .width = true := by decide
def e2405946683590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405946683590 : Closed e2405946683590 ∧ code e2405946683590 = 11202039705798 := by decide
theorem cert_e2405946683590 : check e2405946683590 [[]] .width = true := by decide
def e2405946734618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405946734618 : Closed e2405946734618 ∧ code e2405946734618 = 11202039756826 := by decide
theorem cert_e2405946734618 : check e2405946734618 [[]] .width = true := by decide
def e2405946746906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405946746906 : Closed e2405946746906 ∧ code e2405946746906 = 11202039769114 := by decide
theorem cert_e2405946746906 : check e2405946746906 [[]] .width = true := by decide
def e2405946748442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405946748442 : Closed e2405946748442 ∧ code e2405946748442 = 11202039770650 := by decide
theorem cert_e2405946748442 : check e2405946748442 [[]] .width = true := by decide
def e2405946851354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405946851354 : Closed e2405946851354 ∧ code e2405946851354 = 11202039873562 := by decide
theorem cert_e2405946851354 : check e2405946851354 [[]] .width = true := by decide
def e2405946851446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405946851446 : Closed e2405946851446 ∧ code e2405946851446 = 11202039873654 := by decide
theorem cert_e2405946851446 : check e2405946851446 [[]] .width = true := by decide
def e2405946851690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405946851690 : Closed e2405946851690 ∧ code e2405946851690 = 11202039873898 := by decide
theorem cert_e2405946851690 : check e2405946851690 [[]] .width = true := by decide
def e2405946851738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405946851738 : Closed e2405946851738 ∧ code e2405946851738 = 11202039873946 := by decide
theorem cert_e2405946851738 : check e2405946851738 [[]] .width = true := by decide
def e2405946852746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405946852746 : Closed e2405946852746 ∧ code e2405946852746 = 11202039874954 := by decide
theorem cert_e2405946852746 : check e2405946852746 [[]] .width = true := by decide
def e2405946852770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405946852770 : Closed e2405946852770 ∧ code e2405946852770 = 11202039874978 := by decide
theorem cert_e2405946852770 : check e2405946852770 [[]] .width = true := by decide
def e2405946852878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405946852878 : Closed e2405946852878 ∧ code e2405946852878 = 11202039875086 := by decide
theorem cert_e2405946852878 : check e2405946852878 [[]] .width = true := by decide
def e2405946852890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405946852890 : Closed e2405946852890 ∧ code e2405946852890 = 11202039875098 := by decide
theorem cert_e2405946852890 : check e2405946852890 [[]] .width = true := by decide
def e2405946852962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405946852962 : Closed e2405946852962 ∧ code e2405946852962 = 11202039875170 := by decide
theorem cert_e2405946852962 : check e2405946852962 [[]] .width = true := by decide
def e2405946998982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405946998982 : Closed e2405946998982 ∧ code e2405946998982 = 11202040021190 := by decide
theorem cert_e2405946998982 : check e2405946998982 [[]] .width = true := by decide
def e2405947017242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405947017242 : Closed e2405947017242 ∧ code e2405947017242 = 11202040039450 := by decide
theorem cert_e2405947017242 : check e2405947017242 [[]] .width = true := by decide
def e2405947023386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405947023386 : Closed e2405947023386 ∧ code e2405947023386 = 11202040045594 := by decide
theorem cert_e2405947023386 : check e2405947023386 [[]] .width = true := by decide
def e2405947023478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405947023478 : Closed e2405947023478 ∧ code e2405947023478 = 11202040045686 := by decide
theorem cert_e2405947023478 : check e2405947023478 [[]] .width = true := by decide
def e2405947023722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405947023722 : Closed e2405947023722 ∧ code e2405947023722 = 11202040045930 := by decide
theorem cert_e2405947023722 : check e2405947023722 [[]] .width = true := by decide
def e2405947023770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405947023770 : Closed e2405947023770 ∧ code e2405947023770 = 11202040045978 := by decide
theorem cert_e2405947023770 : check e2405947023770 [[]] .width = true := by decide
def e2405947027654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405947027654 : Closed e2405947027654 ∧ code e2405947027654 = 11202040049862 := by decide
theorem cert_e2405947027654 : check e2405947027654 [[]] .width = true := by decide
def e2405947029530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405947029530 : Closed e2405947029530 ∧ code e2405947029530 = 11202040051738 := by decide
theorem cert_e2405947029530 : check e2405947029530 [[]] .width = true := by decide
def e2405947041818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405947041818 : Closed e2405947041818 ∧ code e2405947041818 = 11202040064026 := by decide
theorem cert_e2405947041818 : check e2405947041818 [[]] .width = true := by decide
def e2405947043354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405947043354 : Closed e2405947043354 ∧ code e2405947043354 = 11202040065562 := by decide
theorem cert_e2405947043354 : check e2405947043354 [[]] .width = true := by decide
def e2405947046426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405947046426 : Closed e2405947046426 ∧ code e2405947046426 = 11202040068634 := by decide
theorem cert_e2405947046426 : check e2405947046426 [[]] .width = true := by decide
def e2405947047962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405947047962 : Closed e2405947047962 ∧ code e2405947047962 = 11202040070170 := by decide
theorem cert_e2405947047962 : check e2405947047962 [[]] .width = true := by decide
def e2405947048054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405947048054 : Closed e2405947048054 ∧ code e2405947048054 = 11202040070262 := by decide
theorem cert_e2405947048054 : check e2405947048054 [[]] .width = true := by decide
def e2405947048298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405947048298 : Closed e2405947048298 ∧ code e2405947048298 = 11202040070506 := by decide
theorem cert_e2405947048298 : check e2405947048298 [[]] .width = true := by decide
def e2405947048346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405947048346 : Closed e2405947048346 ∧ code e2405947048346 = 11202040070554 := by decide
theorem cert_e2405947048346 : check e2405947048346 [[]] .width = true := by decide
def e2405947049354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405947049354 : Closed e2405947049354 ∧ code e2405947049354 = 11202040071562 := by decide
theorem cert_e2405947049354 : check e2405947049354 [[]] .width = true := by decide
def e2405947049378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405947049378 : Closed e2405947049378 ∧ code e2405947049378 = 11202040071586 := by decide
theorem cert_e2405947049378 : check e2405947049378 [[]] .width = true := by decide
def e2405947049486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405947049486 : Closed e2405947049486 ∧ code e2405947049486 = 11202040071694 := by decide
theorem cert_e2405947049486 : check e2405947049486 [[]] .width = true := by decide
def e2405947049498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405947049498 : Closed e2405947049498 ∧ code e2405947049498 = 11202040071706 := by decide
theorem cert_e2405947049498 : check e2405947049498 [[]] .width = true := by decide
def e2405947049570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405947049570 : Closed e2405947049570 ∧ code e2405947049570 = 11202040071778 := by decide
theorem cert_e2405947049570 : check e2405947049570 [[]] .width = true := by decide
def e2405947064518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405947064518 : Closed e2405947064518 ∧ code e2405947064518 = 11202040086726 := by decide
theorem cert_e2405947064518 : check e2405947064518 [[]] .width = true := by decide
def e2405947072538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405947072538 : Closed e2405947072538 ∧ code e2405947072538 = 11202040094746 := by decide
theorem cert_e2405947072538 : check e2405947072538 [[]] .width = true := by decide
def e2405947072630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405947072630 : Closed e2405947072630 ∧ code e2405947072630 = 11202040094838 := by decide
theorem cert_e2405947072630 : check e2405947072630 [[]] .width = true := by decide
def e2405947072874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405947072874 : Closed e2405947072874 ∧ code e2405947072874 = 11202040095082 := by decide
theorem cert_e2405947072874 : check e2405947072874 [[]] .width = true := by decide
def e2405947072922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405947072922 : Closed e2405947072922 ∧ code e2405947072922 = 11202040095130 := by decide
theorem cert_e2405947072922 : check e2405947072922 [[]] .width = true := by decide
def e2405948719130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405948719130 : Closed e2405948719130 ∧ code e2405948719130 = 11202041741338 := by decide
theorem cert_e2405948719130 : check e2405948719130 [[]] .width = true := by decide
def e2405948719222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405948719222 : Closed e2405948719222 ∧ code e2405948719222 = 11202041741430 := by decide
theorem cert_e2405948719222 : check e2405948719222 [[]] .width = true := by decide
def e2405948719466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405948719466 : Closed e2405948719466 ∧ code e2405948719466 = 11202041741674 := by decide
theorem cert_e2405948719466 : check e2405948719466 [[]] .width = true := by decide
def e2405948719514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405948719514 : Closed e2405948719514 ∧ code e2405948719514 = 11202041741722 := by decide
theorem cert_e2405948719514 : check e2405948719514 [[]] .width = true := by decide
def e2405948719598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405948719598 : Closed e2405948719598 ∧ code e2405948719598 = 11202041741806 := by decide
theorem cert_e2405948719598 : check e2405948719598 [[]] .width = true := by decide
def e2405948720522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405948720522 : Closed e2405948720522 ∧ code e2405948720522 = 11202041742730 := by decide
theorem cert_e2405948720522 : check e2405948720522 [[]] .width = true := by decide
def e2405948720546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405948720546 : Closed e2405948720546 ∧ code e2405948720546 = 11202041742754 := by decide
theorem cert_e2405948720546 : check e2405948720546 [[]] .width = true := by decide
def e2405948720558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405948720558 : Closed e2405948720558 ∧ code e2405948720558 = 11202041742766 := by decide
theorem cert_e2405948720558 : check e2405948720558 [[]] .width = true := by decide
def e2405948720566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405948720566 : Closed e2405948720566 ∧ code e2405948720566 = 11202041742774 := by decide
theorem cert_e2405948720566 : check e2405948720566 [[]] .width = true := by decide
def e2405948720570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405948720570 : Closed e2405948720570 ∧ code e2405948720570 = 11202041742778 := by decide
theorem cert_e2405948720570 : check e2405948720570 [[]] .width = true := by decide
def e2405948720598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405948720598 : Closed e2405948720598 ∧ code e2405948720598 = 11202041742806 := by decide
theorem cert_e2405948720598 : check e2405948720598 [[]] .width = true := by decide
def e2405948720602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405948720602 : Closed e2405948720602 ∧ code e2405948720602 = 11202041742810 := by decide
theorem cert_e2405948720602 : check e2405948720602 [[]] .width = true := by decide
def e2405948720618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405948720618 : Closed e2405948720618 ∧ code e2405948720618 = 11202041742826 := by decide
theorem cert_e2405948720618 : check e2405948720618 [[]] .width = true := by decide
def e2405948720654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405948720654 : Closed e2405948720654 ∧ code e2405948720654 = 11202041742862 := by decide
theorem cert_e2405948720654 : check e2405948720654 [[]] .width = true := by decide
def e2405948720666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405948720666 : Closed e2405948720666 ∧ code e2405948720666 = 11202041742874 := by decide
theorem cert_e2405948720666 : check e2405948720666 [[]] .width = true := by decide
def e2405948720738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405948720738 : Closed e2405948720738 ∧ code e2405948720738 = 11202041742946 := by decide
theorem cert_e2405948720738 : check e2405948720738 [[]] .width = true := by decide
def e2405948720750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405948720750 : Closed e2405948720750 ∧ code e2405948720750 = 11202041742958 := by decide
theorem cert_e2405948720750 : check e2405948720750 [[]] .width = true := by decide
def e2405948720758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405948720758 : Closed e2405948720758 ∧ code e2405948720758 = 11202041742966 := by decide
theorem cert_e2405948720758 : check e2405948720758 [[]] .width = true := by decide
def e2405948720762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405948720762 : Closed e2405948720762 ∧ code e2405948720762 = 11202041742970 := by decide
theorem cert_e2405948720762 : check e2405948720762 [[]] .width = true := by decide
def e2405948720950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405948720950 : Closed e2405948720950 ∧ code e2405948720950 = 11202041743158 := by decide
theorem cert_e2405948720950 : check e2405948720950 [[]] .width = true := by decide
def e2405948720954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405948720954 : Closed e2405948720954 ∧ code e2405948720954 = 11202041743162 := by decide
theorem cert_e2405948720954 : check e2405948720954 [[]] .width = true := by decide
def e2405948721050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405948721050 : Closed e2405948721050 ∧ code e2405948721050 = 11202041743258 := by decide
theorem cert_e2405948721050 : check e2405948721050 [[]] .width = true := by decide
def e2405948724650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405948724650 : Closed e2405948724650 ∧ code e2405948724650 = 11202041746858 := by decide
theorem cert_e2405948724650 : check e2405948724650 [[]] .width = true := by decide
def e2405948724746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405948724746 : Closed e2405948724746 ∧ code e2405948724746 = 11202041746954 := by decide
theorem cert_e2405948724746 : check e2405948724746 [[]] .width = true := by decide
def e2405948724790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405948724790 : Closed e2405948724790 ∧ code e2405948724790 = 11202041746998 := by decide
theorem cert_e2405948724790 : check e2405948724790 [[]] .width = true := by decide
def e2405948724794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405948724794 : Closed e2405948724794 ∧ code e2405948724794 = 11202041747002 := by decide
theorem cert_e2405948724794 : check e2405948724794 [[]] .width = true := by decide
def e2405948724842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405948724842 : Closed e2405948724842 ∧ code e2405948724842 = 11202041747050 := by decide
theorem cert_e2405948724842 : check e2405948724842 [[]] .width = true := by decide
def e2405948724866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405948724866 : Closed e2405948724866 ∧ code e2405948724866 = 11202041747074 := by decide
theorem cert_e2405948724866 : check e2405948724866 [[]] .width = true := by decide
def e2405948724878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405948724878 : Closed e2405948724878 ∧ code e2405948724878 = 11202041747086 := by decide
theorem cert_e2405948724878 : check e2405948724878 [[]] .width = true := by decide
def e2405948724890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405948724890 : Closed e2405948724890 ∧ code e2405948724890 = 11202041747098 := by decide
theorem cert_e2405948724890 : check e2405948724890 [[]] .width = true := by decide
def e2405948724934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405948724934 : Closed e2405948724934 ∧ code e2405948724934 = 11202041747142 := by decide
theorem cert_e2405948724934 : check e2405948724934 [[]] .width = true := by decide
def e2405948725014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405948725014 : Closed e2405948725014 ∧ code e2405948725014 = 11202041747222 := by decide
theorem cert_e2405948725014 : check e2405948725014 [[]] .width = true := by decide
def e2405948725018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405948725018 : Closed e2405948725018 ∧ code e2405948725018 = 11202041747226 := by decide
theorem cert_e2405948725018 : check e2405948725018 [[]] .width = true := by decide
def e2405948725062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405948725062 : Closed e2405948725062 ∧ code e2405948725062 = 11202041747270 := by decide
theorem cert_e2405948725062 : check e2405948725062 [[]] .width = true := by decide
def e2405948725090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405948725090 : Closed e2405948725090 ∧ code e2405948725090 = 11202041747298 := by decide
theorem cert_e2405948725090 : check e2405948725090 [[]] .width = true := by decide
def e2405948725274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405948725274 : Closed e2405948725274 ∧ code e2405948725274 = 11202041747482 := by decide
theorem cert_e2405948725274 : check e2405948725274 [[]] .width = true := by decide
def e2405948725366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405948725366 : Closed e2405948725366 ∧ code e2405948725366 = 11202041747574 := by decide
theorem cert_e2405948725366 : check e2405948725366 [[]] .width = true := by decide
def e2405948725610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405948725610 : Closed e2405948725610 ∧ code e2405948725610 = 11202041747818 := by decide
theorem cert_e2405948725610 : check e2405948725610 [[]] .width = true := by decide
def e2405948725634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405948725634 : Closed e2405948725634 ∧ code e2405948725634 = 11202041747842 := by decide
theorem cert_e2405948725634 : check e2405948725634 [[]] .width = true := by decide
def e2405948725646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405948725646 : Closed e2405948725646 ∧ code e2405948725646 = 11202041747854 := by decide
theorem cert_e2405948725646 : check e2405948725646 [[]] .width = true := by decide
def e2405948725658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405948725658 : Closed e2405948725658 ∧ code e2405948725658 = 11202041747866 := by decide
theorem cert_e2405948725658 : check e2405948725658 [[]] .width = true := by decide
def e2405948725702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405948725702 : Closed e2405948725702 ∧ code e2405948725702 = 11202041747910 := by decide
theorem cert_e2405948725702 : check e2405948725702 [[]] .width = true := by decide
def e2405948726302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405948726302 : Closed e2405948726302 ∧ code e2405948726302 = 11202041748510 := by decide
theorem cert_e2405948726302 : check e2405948726302 [[]] .width = true := by decide
def e2405948726470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405948726470 : Closed e2405948726470 ∧ code e2405948726470 = 11202041748678 := by decide
theorem cert_e2405948726470 : check e2405948726470 [[]] .width = true := by decide
def e2405948726498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405948726498 : Closed e2405948726498 ∧ code e2405948726498 = 11202041748706 := by decide
theorem cert_e2405948726498 : check e2405948726498 [[]] .width = true := by decide
def e2405948741162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405948741162 : Closed e2405948741162 ∧ code e2405948741162 = 11202041763370 := by decide
theorem cert_e2405948741162 : check e2405948741162 [[]] .width = true := by decide
def e2405948741258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405948741258 : Closed e2405948741258 ∧ code e2405948741258 = 11202041763466 := by decide
theorem cert_e2405948741258 : check e2405948741258 [[]] .width = true := by decide
def e2405948741282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405948741282 : Closed e2405948741282 ∧ code e2405948741282 = 11202041763490 := by decide
theorem cert_e2405948741282 : check e2405948741282 [[]] .width = true := by decide
def e2405948741642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405948741642 : Closed e2405948741642 ∧ code e2405948741642 = 11202041763850 := by decide
theorem cert_e2405948741642 : check e2405948741642 [[]] .width = true := by decide
def e2405948741690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405948741690 : Closed e2405948741690 ∧ code e2405948741690 = 11202041763898 := by decide
theorem cert_e2405948741690 : check e2405948741690 [[]] .width = true := by decide
def e2405948741738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405948741738 : Closed e2405948741738 ∧ code e2405948741738 = 11202041763946 := by decide
theorem cert_e2405948741738 : check e2405948741738 [[]] .width = true := by decide
def e2405948741786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405948741786 : Closed e2405948741786 ∧ code e2405948741786 = 11202041763994 := by decide
theorem cert_e2405948741786 : check e2405948741786 [[]] .width = true := by decide
def e2405948741830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405948741830 : Closed e2405948741830 ∧ code e2405948741830 = 11202041764038 := by decide
theorem cert_e2405948741830 : check e2405948741830 [[]] .width = true := by decide
def e2405948742026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405948742026 : Closed e2405948742026 ∧ code e2405948742026 = 11202041764234 := by decide
theorem cert_e2405948742026 : check e2405948742026 [[]] .width = true := by decide
def e2405948742050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405948742050 : Closed e2405948742050 ∧ code e2405948742050 = 11202041764258 := by decide
theorem cert_e2405948742050 : check e2405948742050 [[]] .width = true := by decide
def e2405948742146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405948742146 : Closed e2405948742146 ∧ code e2405948742146 = 11202041764354 := by decide
theorem cert_e2405948742146 : check e2405948742146 [[]] .width = true := by decide
def e2405948742158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405948742158 : Closed e2405948742158 ∧ code e2405948742158 = 11202041764366 := by decide
theorem cert_e2405948742158 : check e2405948742158 [[]] .width = true := by decide
def e2405948742170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405948742170 : Closed e2405948742170 ∧ code e2405948742170 = 11202041764378 := by decide
theorem cert_e2405948742170 : check e2405948742170 [[]] .width = true := by decide
def e2405948742242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405948742242 : Closed e2405948742242 ∧ code e2405948742242 = 11202041764450 := by decide
theorem cert_e2405948742242 : check e2405948742242 [[]] .width = true := by decide
def e2405948743706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405948743706 : Closed e2405948743706 ∧ code e2405948743706 = 11202041765914 := by decide
theorem cert_e2405948743706 : check e2405948743706 [[]] .width = true := by decide
def e2405948743790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405948743790 : Closed e2405948743790 ∧ code e2405948743790 = 11202041765998 := by decide
theorem cert_e2405948743790 : check e2405948743790 [[]] .width = true := by decide
def e2405948743798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405948743798 : Closed e2405948743798 ∧ code e2405948743798 = 11202041766006 := by decide
theorem cert_e2405948743798 : check e2405948743798 [[]] .width = true := by decide
def e2405948743802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405948743802 : Closed e2405948743802 ∧ code e2405948743802 = 11202041766010 := by decide
theorem cert_e2405948743802 : check e2405948743802 [[]] .width = true := by decide
def e2405948744042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405948744042 : Closed e2405948744042 ∧ code e2405948744042 = 11202041766250 := by decide
theorem cert_e2405948744042 : check e2405948744042 [[]] .width = true := by decide
def e2405948744078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405948744078 : Closed e2405948744078 ∧ code e2405948744078 = 11202041766286 := by decide
theorem cert_e2405948744078 : check e2405948744078 [[]] .width = true := by decide
def e2405948744090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405948744090 : Closed e2405948744090 ∧ code e2405948744090 = 11202041766298 := by decide
theorem cert_e2405948744090 : check e2405948744090 [[]] .width = true := by decide
def e2405948744134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405948744134 : Closed e2405948744134 ∧ code e2405948744134 = 11202041766342 := by decide
theorem cert_e2405948744134 : check e2405948744134 [[]] .width = true := by decide
def e2405948745098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405948745098 : Closed e2405948745098 ∧ code e2405948745098 = 11202041767306 := by decide
theorem cert_e2405948745098 : check e2405948745098 [[]] .width = true := by decide
def e2405948745122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405948745122 : Closed e2405948745122 ∧ code e2405948745122 = 11202041767330 := by decide
theorem cert_e2405948745122 : check e2405948745122 [[]] .width = true := by decide
def e2405948745218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405948745218 : Closed e2405948745218 ∧ code e2405948745218 = 11202041767426 := by decide
theorem cert_e2405948745218 : check e2405948745218 [[]] .width = true := by decide
def e2405948745230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405948745230 : Closed e2405948745230 ∧ code e2405948745230 = 11202041767438 := by decide
theorem cert_e2405948745230 : check e2405948745230 [[]] .width = true := by decide
def e2405948745242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405948745242 : Closed e2405948745242 ∧ code e2405948745242 = 11202041767450 := by decide
theorem cert_e2405948745242 : check e2405948745242 [[]] .width = true := by decide
def e2405948745314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405948745314 : Closed e2405948745314 ∧ code e2405948745314 = 11202041767522 := by decide
theorem cert_e2405948745314 : check e2405948745314 [[]] .width = true := by decide
def e2405948791298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405948791298 : Closed e2405948791298 ∧ code e2405948791298 = 11202041813506 := by decide
theorem cert_e2405948791298 : check e2405948791298 [[]] .width = true := by decide
def e2405948791322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405948791322 : Closed e2405948791322 ∧ code e2405948791322 = 11202041813530 := by decide
theorem cert_e2405948791322 : check e2405948791322 [[]] .width = true := by decide
def e2405949366298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405949366298 : Closed e2405949366298 ∧ code e2405949366298 = 11202042388506 := by decide
theorem cert_e2405949366298 : check e2405949366298 [[]] .width = true := by decide
def e2405949366390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405949366390 : Closed e2405949366390 ∧ code e2405949366390 = 11202042388598 := by decide
theorem cert_e2405949366390 : check e2405949366390 [[]] .width = true := by decide
def e2405949366634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405949366634 : Closed e2405949366634 ∧ code e2405949366634 = 11202042388842 := by decide
theorem cert_e2405949366634 : check e2405949366634 [[]] .width = true := by decide
def e2405949366682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405949366682 : Closed e2405949366682 ∧ code e2405949366682 = 11202042388890 := by decide
theorem cert_e2405949366682 : check e2405949366682 [[]] .width = true := by decide
def e2405949468870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405949468870 : Closed e2405949468870 ∧ code e2405949468870 = 11202042491078 := by decide
theorem cert_e2405949468870 : check e2405949468870 [[]] .width = true := by decide
def e2405949487130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405949487130 : Closed e2405949487130 ∧ code e2405949487130 = 11202042509338 := by decide
theorem cert_e2405949487130 : check e2405949487130 [[]] .width = true := by decide
def e2405949493446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405949493446 : Closed e2405949493446 ∧ code e2405949493446 = 11202042515654 := by decide
theorem cert_e2405949493446 : check e2405949493446 [[]] .width = true := by decide
def e2405949495322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405949495322 : Closed e2405949495322 ∧ code e2405949495322 = 11202042517530 := by decide
theorem cert_e2405949495322 : check e2405949495322 [[]] .width = true := by decide
def e2405949496858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405949496858 : Closed e2405949496858 ∧ code e2405949496858 = 11202042519066 := by decide
theorem cert_e2405949496858 : check e2405949496858 [[]] .width = true := by decide
def e2405949500954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405949500954 : Closed e2405949500954 ∧ code e2405949500954 = 11202042523162 := by decide
theorem cert_e2405949500954 : check e2405949500954 [[]] .width = true := by decide
def e2405949702342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405949702342 : Closed e2405949702342 ∧ code e2405949702342 = 11202042724550 := by decide
theorem cert_e2405949702342 : check e2405949702342 [[]] .width = true := by decide
def e2405949702870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405949702870 : Closed e2405949702870 ∧ code e2405949702870 = 11202042725078 := by decide
theorem cert_e2405949702870 : check e2405949702870 [[]] .width = true := by decide
end Blc.Floor43
