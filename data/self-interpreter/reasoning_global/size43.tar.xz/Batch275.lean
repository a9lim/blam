import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407061452342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2407061452342 : Closed e2407061452342 ∧ code e2407061452342 = 11203154474550 := by decide
theorem cert_e2407061452342 : check e2407061452342 [[],[]] .chain = true := by decide
def e2407061452346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2407061452346 : Closed e2407061452346 ∧ code e2407061452346 = 11203154474554 := by decide
theorem cert_e2407061452346 : check e2407061452346 [[],[]] .chain = true := by decide
def e2407061452394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2407061452394 : Closed e2407061452394 ∧ code e2407061452394 = 11203154474602 := by decide
theorem cert_e2407061452394 : check e2407061452394 [[],[]] .chain = true := by decide
def e2407061452430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2407061452430 : Closed e2407061452430 ∧ code e2407061452430 = 11203154474638 := by decide
theorem cert_e2407061452430 : check e2407061452430 [[],[]] .chain = true := by decide
def e2407061452442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061452442 : Closed e2407061452442 ∧ code e2407061452442 = 11203154474650 := by decide
theorem cert_e2407061452442 : check e2407061452442 [[],[]] .chain = true := by decide
def e2407061452486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2407061452486 : Closed e2407061452486 ∧ code e2407061452486 = 11203154474694 := by decide
theorem cert_e2407061452486 : check e2407061452486 [[],[]] .chain = true := by decide
def e2407061458670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2407061458670 : Closed e2407061458670 ∧ code e2407061458670 = 11203154480878 := by decide
theorem cert_e2407061458670 : check e2407061458670 [[],[]] .chain = true := by decide
def e2407061458678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2407061458678 : Closed e2407061458678 ∧ code e2407061458678 = 11203154480886 := by decide
theorem cert_e2407061458678 : check e2407061458678 [[],[]] .chain = true := by decide
def e2407061458798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2407061458798 : Closed e2407061458798 ∧ code e2407061458798 = 11203154481006 := by decide
theorem cert_e2407061458798 : check e2407061458798 [[],[]] .chain = true := by decide
def e2407061458810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2407061458810 : Closed e2407061458810 ∧ code e2407061458810 = 11203154481018 := by decide
theorem cert_e2407061458810 : check e2407061458810 [[],[]] .chain = true := by decide
def e2407061458870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2407061458870 : Closed e2407061458870 ∧ code e2407061458870 = 11203154481078 := by decide
theorem cert_e2407061458870 : check e2407061458870 [[],[]] .chain = true := by decide
def e2407061458874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2407061458874 : Closed e2407061458874 ∧ code e2407061458874 = 11203154481082 := by decide
theorem cert_e2407061458874 : check e2407061458874 [[],[]] .chain = true := by decide
def e2407061462254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2407061462254 : Closed e2407061462254 ∧ code e2407061462254 = 11203154484462 := by decide
theorem cert_e2407061462254 : check e2407061462254 [[],[]] .chain = true := by decide
def e2407061462262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2407061462262 : Closed e2407061462262 ∧ code e2407061462262 = 11203154484470 := by decide
theorem cert_e2407061462262 : check e2407061462262 [[],[]] .chain = true := by decide
def e2407061462646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))
theorem wire_e2407061462646 : Closed e2407061462646 ∧ code e2407061462646 = 11203154484854 := by decide
theorem cert_e2407061462646 : check e2407061462646 [[],[]] .chain = true := by decide
def e2407061466478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2407061466478 : Closed e2407061466478 ∧ code e2407061466478 = 11203154488686 := by decide
theorem cert_e2407061466478 : check e2407061466478 [[],[]] .chain = true := by decide
def e2407061466486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2407061466486 : Closed e2407061466486 ∧ code e2407061466486 = 11203154488694 := by decide
theorem cert_e2407061466486 : check e2407061466486 [[],[]] .chain = true := by decide
def e2407061466542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2407061466542 : Closed e2407061466542 ∧ code e2407061466542 = 11203154488750 := by decide
theorem cert_e2407061466542 : check e2407061466542 [[],[]] .chain = true := by decide
def e2407061466554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2407061466554 : Closed e2407061466554 ∧ code e2407061466554 = 11203154488762 := by decide
theorem cert_e2407061466554 : check e2407061466554 [[],[]] .chain = true := by decide
def e2407061466582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2407061466582 : Closed e2407061466582 ∧ code e2407061466582 = 11203154488790 := by decide
theorem cert_e2407061466582 : check e2407061466582 [[],[]] .chain = true := by decide
def e2407061466586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2407061466586 : Closed e2407061466586 ∧ code e2407061466586 = 11203154488794 := by decide
theorem cert_e2407061466586 : check e2407061466586 [[],[]] .chain = true := by decide
def e2407061466798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2407061466798 : Closed e2407061466798 ∧ code e2407061466798 = 11203154489006 := by decide
theorem cert_e2407061466798 : check e2407061466798 [[],[]] .chain = true := by decide
def e2407061466810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2407061466810 : Closed e2407061466810 ∧ code e2407061466810 = 11203154489018 := by decide
theorem cert_e2407061466810 : check e2407061466810 [[],[]] .chain = true := by decide
def e2407061466858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2407061466858 : Closed e2407061466858 ∧ code e2407061466858 = 11203154489066 := by decide
theorem cert_e2407061466858 : check e2407061466858 [[],[]] .chain = true := by decide
def e2407061466966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2407061466966 : Closed e2407061466966 ∧ code e2407061466966 = 11203154489174 := by decide
theorem cert_e2407061466966 : check e2407061466966 [[],[]] .chain = true := by decide
def e2407061466970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2407061466970 : Closed e2407061466970 ∧ code e2407061466970 = 11203154489178 := by decide
theorem cert_e2407061466970 : check e2407061466970 [[],[]] .chain = true := by decide
def e2407061466986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2407061466986 : Closed e2407061466986 ∧ code e2407061466986 = 11203154489194 := by decide
theorem cert_e2407061466986 : check e2407061466986 [[],[]] .chain = true := by decide
def e2407061468014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2407061468014 : Closed e2407061468014 ∧ code e2407061468014 = 11203154490222 := by decide
theorem cert_e2407061468014 : check e2407061468014 [[],[]] .chain = true := by decide
def e2407061468022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2407061468022 : Closed e2407061468022 ∧ code e2407061468022 = 11203154490230 := by decide
theorem cert_e2407061468022 : check e2407061468022 [[],[]] .chain = true := by decide
def e2407061468078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2407061468078 : Closed e2407061468078 ∧ code e2407061468078 = 11203154490286 := by decide
theorem cert_e2407061468078 : check e2407061468078 [[],[]] .chain = true := by decide
def e2407061468090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2407061468090 : Closed e2407061468090 ∧ code e2407061468090 = 11203154490298 := by decide
theorem cert_e2407061468090 : check e2407061468090 [[],[]] .chain = true := by decide
def e2407061468118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2407061468118 : Closed e2407061468118 ∧ code e2407061468118 = 11203154490326 := by decide
theorem cert_e2407061468118 : check e2407061468118 [[],[]] .chain = true := by decide
def e2407061468122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2407061468122 : Closed e2407061468122 ∧ code e2407061468122 = 11203154490330 := by decide
theorem cert_e2407061468122 : check e2407061468122 [[],[]] .chain = true := by decide
def e2407061468398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2407061468398 : Closed e2407061468398 ∧ code e2407061468398 = 11203154490606 := by decide
theorem cert_e2407061468398 : check e2407061468398 [[],[]] .chain = true := by decide
def e2407061468406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2407061468406 : Closed e2407061468406 ∧ code e2407061468406 = 11203154490614 := by decide
theorem cert_e2407061468406 : check e2407061468406 [[],[]] .chain = true := by decide
def e2407061468782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061468782 : Closed e2407061468782 ∧ code e2407061468782 = 11203154490990 := by decide
theorem cert_e2407061468782 : check e2407061468782 [[],[]] .chain = true := by decide
def e2407061468794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061468794 : Closed e2407061468794 ∧ code e2407061468794 = 11203154491002 := by decide
theorem cert_e2407061468794 : check e2407061468794 [[],[]] .chain = true := by decide
def e2407061468982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061468982 : Closed e2407061468982 ∧ code e2407061468982 = 11203154491190 := by decide
theorem cert_e2407061468982 : check e2407061468982 [[],[]] .chain = true := by decide
def e2407061468986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061468986 : Closed e2407061468986 ∧ code e2407061468986 = 11203154491194 := by decide
theorem cert_e2407061468986 : check e2407061468986 [[],[]] .chain = true := by decide
def e2407061469422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2407061469422 : Closed e2407061469422 ∧ code e2407061469422 = 11203154491630 := by decide
theorem cert_e2407061469422 : check e2407061469422 [[],[]] .chain = true := by decide
def e2407061469430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2407061469430 : Closed e2407061469430 ∧ code e2407061469430 = 11203154491638 := by decide
theorem cert_e2407061469430 : check e2407061469430 [[],[]] .chain = true := by decide
def e2407061469614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2407061469614 : Closed e2407061469614 ∧ code e2407061469614 = 11203154491822 := by decide
theorem cert_e2407061469614 : check e2407061469614 [[],[]] .chain = true := by decide
def e2407061469626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2407061469626 : Closed e2407061469626 ∧ code e2407061469626 = 11203154491834 := by decide
theorem cert_e2407061469626 : check e2407061469626 [[],[]] .chain = true := by decide
def e2407061469674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2407061469674 : Closed e2407061469674 ∧ code e2407061469674 = 11203154491882 := by decide
theorem cert_e2407061469674 : check e2407061469674 [[],[]] .chain = true := by decide
def e2407061469806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061469806 : Closed e2407061469806 ∧ code e2407061469806 = 11203154492014 := by decide
theorem cert_e2407061469806 : check e2407061469806 [[],[]] .chain = true := by decide
def e2407061469818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061469818 : Closed e2407061469818 ∧ code e2407061469818 = 11203154492026 := by decide
theorem cert_e2407061469818 : check e2407061469818 [[],[]] .chain = true := by decide
def e2407061469982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2407061469982 : Closed e2407061469982 ∧ code e2407061469982 = 11203154492190 := by decide
theorem cert_e2407061469982 : check e2407061469982 [[],[]] .chain = true := by decide
def e2407061470094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2407061470094 : Closed e2407061470094 ∧ code e2407061470094 = 11203154492302 := by decide
theorem cert_e2407061470094 : check e2407061470094 [[],[]] .chain = true := by decide
def e2407061470106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061470106 : Closed e2407061470106 ∧ code e2407061470106 = 11203154492314 := by decide
theorem cert_e2407061470106 : check e2407061470106 [[],[]] .chain = true := by decide
def e2407061470326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2407061470326 : Closed e2407061470326 ∧ code e2407061470326 = 11203154492534 := by decide
theorem cert_e2407061470326 : check e2407061470326 [[],[]] .chain = true := by decide
def e2407061470422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2407061470422 : Closed e2407061470422 ∧ code e2407061470422 = 11203154492630 := by decide
theorem cert_e2407061470422 : check e2407061470422 [[],[]] .chain = true := by decide
def e2407061470426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2407061470426 : Closed e2407061470426 ∧ code e2407061470426 = 11203154492634 := by decide
theorem cert_e2407061470426 : check e2407061470426 [[],[]] .chain = true := by decide
def e2407061470442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2407061470442 : Closed e2407061470442 ∧ code e2407061470442 = 11203154492650 := by decide
theorem cert_e2407061470442 : check e2407061470442 [[],[]] .chain = true := by decide
def e2407061470518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061470518 : Closed e2407061470518 ∧ code e2407061470518 = 11203154492726 := by decide
theorem cert_e2407061470518 : check e2407061470518 [[],[]] .chain = true := by decide
def e2407061470522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061470522 : Closed e2407061470522 ∧ code e2407061470522 = 11203154492730 := by decide
theorem cert_e2407061470522 : check e2407061470522 [[],[]] .chain = true := by decide
def e2407061470606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2407061470606 : Closed e2407061470606 ∧ code e2407061470606 = 11203154492814 := by decide
theorem cert_e2407061470606 : check e2407061470606 [[],[]] .chain = true := by decide
def e2407061470618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061470618 : Closed e2407061470618 ∧ code e2407061470618 = 11203154492826 := by decide
theorem cert_e2407061470618 : check e2407061470618 [[],[]] .chain = true := by decide
def e2407061472222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2407061472222 : Closed e2407061472222 ∧ code e2407061472222 = 11203154494430 := by decide
theorem cert_e2407061472222 : check e2407061472222 [[],[]] .chain = true := by decide
def e2407061472238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2407061472238 : Closed e2407061472238 ∧ code e2407061472238 = 11203154494446 := by decide
theorem cert_e2407061472238 : check e2407061472238 [[],[]] .chain = true := by decide
def e2407061474158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2407061474158 : Closed e2407061474158 ∧ code e2407061474158 = 11203154496366 := by decide
theorem cert_e2407061474158 : check e2407061474158 [[],[]] .chain = true := by decide
def e2407061474166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2407061474166 : Closed e2407061474166 ∧ code e2407061474166 = 11203154496374 := by decide
theorem cert_e2407061474166 : check e2407061474166 [[],[]] .chain = true := by decide
def e2407061474222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2407061474222 : Closed e2407061474222 ∧ code e2407061474222 = 11203154496430 := by decide
theorem cert_e2407061474222 : check e2407061474222 [[],[]] .chain = true := by decide
def e2407061474234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2407061474234 : Closed e2407061474234 ∧ code e2407061474234 = 11203154496442 := by decide
theorem cert_e2407061474234 : check e2407061474234 [[],[]] .chain = true := by decide
def e2407061474262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2407061474262 : Closed e2407061474262 ∧ code e2407061474262 = 11203154496470 := by decide
theorem cert_e2407061474262 : check e2407061474262 [[],[]] .chain = true := by decide
def e2407061474266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2407061474266 : Closed e2407061474266 ∧ code e2407061474266 = 11203154496474 := by decide
theorem cert_e2407061474266 : check e2407061474266 [[],[]] .chain = true := by decide
def e2407061474542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2407061474542 : Closed e2407061474542 ∧ code e2407061474542 = 11203154496750 := by decide
theorem cert_e2407061474542 : check e2407061474542 [[],[]] .chain = true := by decide
def e2407061474550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2407061474550 : Closed e2407061474550 ∧ code e2407061474550 = 11203154496758 := by decide
theorem cert_e2407061474550 : check e2407061474550 [[],[]] .chain = true := by decide
def e2407061474926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061474926 : Closed e2407061474926 ∧ code e2407061474926 = 11203154497134 := by decide
theorem cert_e2407061474926 : check e2407061474926 [[],[]] .chain = true := by decide
def e2407061474938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061474938 : Closed e2407061474938 ∧ code e2407061474938 = 11203154497146 := by decide
theorem cert_e2407061474938 : check e2407061474938 [[],[]] .chain = true := by decide
def e2407061475126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061475126 : Closed e2407061475126 ∧ code e2407061475126 = 11203154497334 := by decide
theorem cert_e2407061475126 : check e2407061475126 [[],[]] .chain = true := by decide
def e2407061475130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061475130 : Closed e2407061475130 ∧ code e2407061475130 = 11203154497338 := by decide
theorem cert_e2407061475130 : check e2407061475130 [[],[]] .chain = true := by decide
def e2407061479902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2407061479902 : Closed e2407061479902 ∧ code e2407061479902 = 11203154502110 := by decide
theorem cert_e2407061479902 : check e2407061479902 [[],[]] .chain = true := by decide
def e2407061479926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2407061479926 : Closed e2407061479926 ∧ code e2407061479926 = 11203154502134 := by decide
theorem cert_e2407061479926 : check e2407061479926 [[],[]] .chain = true := by decide
def e2407061480878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2407061480878 : Closed e2407061480878 ∧ code e2407061480878 = 11203154503086 := by decide
theorem cert_e2407061480878 : check e2407061480878 [[],[]] .chain = true := by decide
def e2407061480890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2407061480890 : Closed e2407061480890 ∧ code e2407061480890 = 11203154503098 := by decide
theorem cert_e2407061480890 : check e2407061480890 [[],[]] .chain = true := by decide
def e2407061480938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2407061480938 : Closed e2407061480938 ∧ code e2407061480938 = 11203154503146 := by decide
theorem cert_e2407061480938 : check e2407061480938 [[],[]] .chain = true := by decide
def e2407061481070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061481070 : Closed e2407061481070 ∧ code e2407061481070 = 11203154503278 := by decide
theorem cert_e2407061481070 : check e2407061481070 [[],[]] .chain = true := by decide
def e2407061481082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061481082 : Closed e2407061481082 ∧ code e2407061481082 = 11203154503290 := by decide
theorem cert_e2407061481082 : check e2407061481082 [[],[]] .chain = true := by decide
def e2407061481246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2407061481246 : Closed e2407061481246 ∧ code e2407061481246 = 11203154503454 := by decide
theorem cert_e2407061481246 : check e2407061481246 [[],[]] .chain = true := by decide
def e2407061481358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2407061481358 : Closed e2407061481358 ∧ code e2407061481358 = 11203154503566 := by decide
theorem cert_e2407061481358 : check e2407061481358 [[],[]] .chain = true := by decide
def e2407061481370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061481370 : Closed e2407061481370 ∧ code e2407061481370 = 11203154503578 := by decide
theorem cert_e2407061481370 : check e2407061481370 [[],[]] .chain = true := by decide
def e2407061483758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2407061483758 : Closed e2407061483758 ∧ code e2407061483758 = 11203154505966 := by decide
theorem cert_e2407061483758 : check e2407061483758 [[],[]] .chain = true := by decide
def e2407061483766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2407061483766 : Closed e2407061483766 ∧ code e2407061483766 = 11203154505974 := by decide
theorem cert_e2407061483766 : check e2407061483766 [[],[]] .chain = true := by decide
def e2407061484246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2407061484246 : Closed e2407061484246 ∧ code e2407061484246 = 11203154506454 := by decide
theorem cert_e2407061484246 : check e2407061484246 [[],[]] .chain = true := by decide
def e2407061484250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2407061484250 : Closed e2407061484250 ∧ code e2407061484250 = 11203154506458 := by decide
theorem cert_e2407061484250 : check e2407061484250 [[],[]] .chain = true := by decide
def e2407061484266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2407061484266 : Closed e2407061484266 ∧ code e2407061484266 = 11203154506474 := by decide
theorem cert_e2407061484266 : check e2407061484266 [[],[]] .chain = true := by decide
def e2407061484342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061484342 : Closed e2407061484342 ∧ code e2407061484342 = 11203154506550 := by decide
theorem cert_e2407061484342 : check e2407061484342 [[],[]] .chain = true := by decide
def e2407061484346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061484346 : Closed e2407061484346 ∧ code e2407061484346 = 11203154506554 := by decide
theorem cert_e2407061484346 : check e2407061484346 [[],[]] .chain = true := by decide
def e2407061484430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2407061484430 : Closed e2407061484430 ∧ code e2407061484430 = 11203154506638 := by decide
theorem cert_e2407061484430 : check e2407061484430 [[],[]] .chain = true := by decide
def e2407061484442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061484442 : Closed e2407061484442 ∧ code e2407061484442 = 11203154506650 := by decide
theorem cert_e2407061484442 : check e2407061484442 [[],[]] .chain = true := by decide
def e2407061489518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2407061489518 : Closed e2407061489518 ∧ code e2407061489518 = 11203154511726 := by decide
theorem cert_e2407061489518 : check e2407061489518 [[],[]] .chain = true := by decide
def e2407061489530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2407061489530 : Closed e2407061489530 ∧ code e2407061489530 = 11203154511738 := by decide
theorem cert_e2407061489530 : check e2407061489530 [[],[]] .chain = true := by decide
def e2407061489626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2407061489626 : Closed e2407061489626 ∧ code e2407061489626 = 11203154511834 := by decide
theorem cert_e2407061489626 : check e2407061489626 [[],[]] .chain = true := by decide
def e2407061490926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2407061490926 : Closed e2407061490926 ∧ code e2407061490926 = 11203154513134 := by decide
theorem cert_e2407061490926 : check e2407061490926 [[],[]] .chain = true := by decide
def e2407061490934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2407061490934 : Closed e2407061490934 ∧ code e2407061490934 = 11203154513142 := by decide
theorem cert_e2407061490934 : check e2407061490934 [[],[]] .chain = true := by decide
def e2407061491310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061491310 : Closed e2407061491310 ∧ code e2407061491310 = 11203154513518 := by decide
theorem cert_e2407061491310 : check e2407061491310 [[],[]] .chain = true := by decide
def e2407061491322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061491322 : Closed e2407061491322 ∧ code e2407061491322 = 11203154513530 := by decide
theorem cert_e2407061491322 : check e2407061491322 [[],[]] .chain = true := by decide
def e2407061491510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061491510 : Closed e2407061491510 ∧ code e2407061491510 = 11203154513718 := by decide
theorem cert_e2407061491510 : check e2407061491510 [[],[]] .chain = true := by decide
def e2407061491514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061491514 : Closed e2407061491514 ∧ code e2407061491514 = 11203154513722 := by decide
theorem cert_e2407061491514 : check e2407061491514 [[],[]] .chain = true := by decide
def e2407061493422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2407061493422 : Closed e2407061493422 ∧ code e2407061493422 = 11203154515630 := by decide
theorem cert_e2407061493422 : check e2407061493422 [[],[]] .chain = true := by decide
def e2407061493434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2407061493434 : Closed e2407061493434 ∧ code e2407061493434 = 11203154515642 := by decide
theorem cert_e2407061493434 : check e2407061493434 [[],[]] .chain = true := by decide
def e2407061493482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2407061493482 : Closed e2407061493482 ∧ code e2407061493482 = 11203154515690 := by decide
theorem cert_e2407061493482 : check e2407061493482 [[],[]] .chain = true := by decide
def e2407061493674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2407061493674 : Closed e2407061493674 ∧ code e2407061493674 = 11203154515882 := by decide
theorem cert_e2407061493674 : check e2407061493674 [[],[]] .chain = true := by decide
def e2407061493998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2407061493998 : Closed e2407061493998 ∧ code e2407061493998 = 11203154516206 := by decide
theorem cert_e2407061493998 : check e2407061493998 [[],[]] .chain = true := by decide
def e2407061494006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2407061494006 : Closed e2407061494006 ∧ code e2407061494006 = 11203154516214 := by decide
theorem cert_e2407061494006 : check e2407061494006 [[],[]] .chain = true := by decide
def e2407061494190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2407061494190 : Closed e2407061494190 ∧ code e2407061494190 = 11203154516398 := by decide
theorem cert_e2407061494190 : check e2407061494190 [[],[]] .chain = true := by decide
def e2407061494202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2407061494202 : Closed e2407061494202 ∧ code e2407061494202 = 11203154516410 := by decide
theorem cert_e2407061494202 : check e2407061494202 [[],[]] .chain = true := by decide
def e2407061494250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2407061494250 : Closed e2407061494250 ∧ code e2407061494250 = 11203154516458 := by decide
theorem cert_e2407061494250 : check e2407061494250 [[],[]] .chain = true := by decide
def e2407061494382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2407061494382 : Closed e2407061494382 ∧ code e2407061494382 = 11203154516590 := by decide
theorem cert_e2407061494382 : check e2407061494382 [[],[]] .chain = true := by decide
def e2407061494394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2407061494394 : Closed e2407061494394 ∧ code e2407061494394 = 11203154516602 := by decide
theorem cert_e2407061494394 : check e2407061494394 [[],[]] .chain = true := by decide
def e2407061494558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2407061494558 : Closed e2407061494558 ∧ code e2407061494558 = 11203154516766 := by decide
theorem cert_e2407061494558 : check e2407061494558 [[],[]] .chain = true := by decide
def e2407061494670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2407061494670 : Closed e2407061494670 ∧ code e2407061494670 = 11203154516878 := by decide
theorem cert_e2407061494670 : check e2407061494670 [[],[]] .chain = true := by decide
def e2407061494682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061494682 : Closed e2407061494682 ∧ code e2407061494682 = 11203154516890 := by decide
theorem cert_e2407061494682 : check e2407061494682 [[],[]] .chain = true := by decide
def e2407061494894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2407061494894 : Closed e2407061494894 ∧ code e2407061494894 = 11203154517102 := by decide
theorem cert_e2407061494894 : check e2407061494894 [[],[]] .chain = true := by decide
def e2407061494906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2407061494906 : Closed e2407061494906 ∧ code e2407061494906 = 11203154517114 := by decide
theorem cert_e2407061494906 : check e2407061494906 [[],[]] .chain = true := by decide
def e2407061495070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2407061495070 : Closed e2407061495070 ∧ code e2407061495070 = 11203154517278 := by decide
theorem cert_e2407061495070 : check e2407061495070 [[],[]] .chain = true := by decide
def e2407061495238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2407061495238 : Closed e2407061495238 ∧ code e2407061495238 = 11203154517446 := by decide
theorem cert_e2407061495238 : check e2407061495238 [[],[]] .chain = true := by decide
def e2407061495350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2407061495350 : Closed e2407061495350 ∧ code e2407061495350 = 11203154517558 := by decide
theorem cert_e2407061495350 : check e2407061495350 [[],[]] .chain = true := by decide
def e2407061495354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2407061495354 : Closed e2407061495354 ∧ code e2407061495354 = 11203154517562 := by decide
theorem cert_e2407061495354 : check e2407061495354 [[],[]] .chain = true := by decide
def e2407061495402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2407061495402 : Closed e2407061495402 ∧ code e2407061495402 = 11203154517610 := by decide
theorem cert_e2407061495402 : check e2407061495402 [[],[]] .chain = true := by decide
def e2407061495438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2407061495438 : Closed e2407061495438 ∧ code e2407061495438 = 11203154517646 := by decide
theorem cert_e2407061495438 : check e2407061495438 [[],[]] .chain = true := by decide
def e2407061495450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061495450 : Closed e2407061495450 ∧ code e2407061495450 = 11203154517658 := by decide
theorem cert_e2407061495450 : check e2407061495450 [[],[]] .chain = true := by decide
def e2407061495494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2407061495494 : Closed e2407061495494 ∧ code e2407061495494 = 11203154517702 := by decide
theorem cert_e2407061495494 : check e2407061495494 [[],[]] .chain = true := by decide
def e2407061496286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2407061496286 : Closed e2407061496286 ∧ code e2407061496286 = 11203154518494 := by decide
theorem cert_e2407061496286 : check e2407061496286 [[],[]] .chain = true := by decide
def e2407061496310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2407061496310 : Closed e2407061496310 ∧ code e2407061496310 = 11203154518518 := by decide
theorem cert_e2407061496310 : check e2407061496310 [[],[]] .chain = true := by decide
def e2407061497262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2407061497262 : Closed e2407061497262 ∧ code e2407061497262 = 11203154519470 := by decide
theorem cert_e2407061497262 : check e2407061497262 [[],[]] .chain = true := by decide
def e2407061497274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2407061497274 : Closed e2407061497274 ∧ code e2407061497274 = 11203154519482 := by decide
theorem cert_e2407061497274 : check e2407061497274 [[],[]] .chain = true := by decide
def e2407061497322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2407061497322 : Closed e2407061497322 ∧ code e2407061497322 = 11203154519530 := by decide
theorem cert_e2407061497322 : check e2407061497322 [[],[]] .chain = true := by decide
def e2407061497454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061497454 : Closed e2407061497454 ∧ code e2407061497454 = 11203154519662 := by decide
theorem cert_e2407061497454 : check e2407061497454 [[],[]] .chain = true := by decide
def e2407061497466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061497466 : Closed e2407061497466 ∧ code e2407061497466 = 11203154519674 := by decide
theorem cert_e2407061497466 : check e2407061497466 [[],[]] .chain = true := by decide
def e2407061497630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2407061497630 : Closed e2407061497630 ∧ code e2407061497630 = 11203154519838 := by decide
theorem cert_e2407061497630 : check e2407061497630 [[],[]] .chain = true := by decide
def e2407061497742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2407061497742 : Closed e2407061497742 ∧ code e2407061497742 = 11203154519950 := by decide
theorem cert_e2407061497742 : check e2407061497742 [[],[]] .chain = true := by decide
def e2407061497754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061497754 : Closed e2407061497754 ∧ code e2407061497754 = 11203154519962 := by decide
theorem cert_e2407061497754 : check e2407061497754 [[],[]] .chain = true := by decide
def e2407061500702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2407061500702 : Closed e2407061500702 ∧ code e2407061500702 = 11203154522910 := by decide
theorem cert_e2407061500702 : check e2407061500702 [[],[]] .chain = true := by decide
def e2407061500870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2407061500870 : Closed e2407061500870 ∧ code e2407061500870 = 11203154523078 := by decide
theorem cert_e2407061500870 : check e2407061500870 [[],[]] .chain = true := by decide
def e2407061502070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2407061502070 : Closed e2407061502070 ∧ code e2407061502070 = 11203154524278 := by decide
theorem cert_e2407061502070 : check e2407061502070 [[],[]] .chain = true := by decide
def e2407061502314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2407061502314 : Closed e2407061502314 ∧ code e2407061502314 = 11203154524522 := by decide
theorem cert_e2407061502314 : check e2407061502314 [[],[]] .chain = true := by decide
def e2407061502350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2407061502350 : Closed e2407061502350 ∧ code e2407061502350 = 11203154524558 := by decide
theorem cert_e2407061502350 : check e2407061502350 [[],[]] .chain = true := by decide
def e2407061502362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061502362 : Closed e2407061502362 ∧ code e2407061502362 = 11203154524570 := by decide
theorem cert_e2407061502362 : check e2407061502362 [[],[]] .chain = true := by decide
def e2407061502406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2407061502406 : Closed e2407061502406 ∧ code e2407061502406 = 11203154524614 := by decide
theorem cert_e2407061502406 : check e2407061502406 [[],[]] .chain = true := by decide
def e2407061504950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2407061504950 : Closed e2407061504950 ∧ code e2407061504950 = 11203154527158 := by decide
theorem cert_e2407061504950 : check e2407061504950 [[],[]] .chain = true := by decide
def e2407061504954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2407061504954 : Closed e2407061504954 ∧ code e2407061504954 = 11203154527162 := by decide
theorem cert_e2407061504954 : check e2407061504954 [[],[]] .chain = true := by decide
def e2407061504986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2407061504986 : Closed e2407061504986 ∧ code e2407061504986 = 11203154527194 := by decide
theorem cert_e2407061504986 : check e2407061504986 [[],[]] .chain = true := by decide
def e2407061505654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2407061505654 : Closed e2407061505654 ∧ code e2407061505654 = 11203154527862 := by decide
theorem cert_e2407061505654 : check e2407061505654 [[],[]] .chain = true := by decide
def e2407061505846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061505846 : Closed e2407061505846 ∧ code e2407061505846 = 11203154528054 := by decide
theorem cert_e2407061505846 : check e2407061505846 [[],[]] .chain = true := by decide
def e2407061505850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061505850 : Closed e2407061505850 ∧ code e2407061505850 = 11203154528058 := by decide
theorem cert_e2407061505850 : check e2407061505850 [[],[]] .chain = true := by decide
def e2407061506902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2407061506902 : Closed e2407061506902 ∧ code e2407061506902 = 11203154529110 := by decide
theorem cert_e2407061506902 : check e2407061506902 [[],[]] .chain = true := by decide
def e2407061506906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2407061506906 : Closed e2407061506906 ∧ code e2407061506906 = 11203154529114 := by decide
theorem cert_e2407061506906 : check e2407061506906 [[],[]] .chain = true := by decide
def e2407061506922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2407061506922 : Closed e2407061506922 ∧ code e2407061506922 = 11203154529130 := by decide
theorem cert_e2407061506922 : check e2407061506922 [[],[]] .chain = true := by decide
def e2407061506986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2407061506986 : Closed e2407061506986 ∧ code e2407061506986 = 11203154529194 := by decide
theorem cert_e2407061506986 : check e2407061506986 [[],[]] .chain = true := by decide
def e2407061507190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2407061507190 : Closed e2407061507190 ∧ code e2407061507190 = 11203154529398 := by decide
theorem cert_e2407061507190 : check e2407061507190 [[],[]] .chain = true := by decide
def e2407061507286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2407061507286 : Closed e2407061507286 ∧ code e2407061507286 = 11203154529494 := by decide
theorem cert_e2407061507286 : check e2407061507286 [[],[]] .chain = true := by decide
def e2407061507290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2407061507290 : Closed e2407061507290 ∧ code e2407061507290 = 11203154529498 := by decide
theorem cert_e2407061507290 : check e2407061507290 [[],[]] .chain = true := by decide
def e2407061507306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2407061507306 : Closed e2407061507306 ∧ code e2407061507306 = 11203154529514 := by decide
theorem cert_e2407061507306 : check e2407061507306 [[],[]] .chain = true := by decide
def e2407061507382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2407061507382 : Closed e2407061507382 ∧ code e2407061507382 = 11203154529590 := by decide
theorem cert_e2407061507382 : check e2407061507382 [[],[]] .chain = true := by decide
def e2407061507386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2407061507386 : Closed e2407061507386 ∧ code e2407061507386 = 11203154529594 := by decide
theorem cert_e2407061507386 : check e2407061507386 [[],[]] .chain = true := by decide
def e2407061507470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2407061507470 : Closed e2407061507470 ∧ code e2407061507470 = 11203154529678 := by decide
theorem cert_e2407061507470 : check e2407061507470 [[],[]] .chain = true := by decide
def e2407061507482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061507482 : Closed e2407061507482 ∧ code e2407061507482 = 11203154529690 := by decide
theorem cert_e2407061507482 : check e2407061507482 [[],[]] .chain = true := by decide
def e2407061507638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2407061507638 : Closed e2407061507638 ∧ code e2407061507638 = 11203154529846 := by decide
theorem cert_e2407061507638 : check e2407061507638 [[],[]] .chain = true := by decide
def e2407061507642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2407061507642 : Closed e2407061507642 ∧ code e2407061507642 = 11203154529850 := by decide
theorem cert_e2407061507642 : check e2407061507642 [[],[]] .chain = true := by decide
end Blc.Floor43
