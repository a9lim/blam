import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701154191034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701154191034 : Closed e701154191034 ∧ code e701154191034 = 9497247213242 := by decide
theorem cert_e701154191034 : check e701154191034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e701154191066 : Closed e701154191066 ∧ code e701154191066 = 9497247213274 := by decide
theorem cert_e701154191066 : check e701154191066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701154191082 : Closed e701154191082 ∧ code e701154191082 = 9497247213290 := by decide
theorem cert_e701154191082 : check e701154191082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701154191194 : Closed e701154191194 ∧ code e701154191194 = 9497247213402 := by decide
theorem cert_e701154191194 : check e701154191194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701154191210 : Closed e701154191210 ∧ code e701154191210 = 9497247213418 := by decide
theorem cert_e701154191210 : check e701154191210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701154191274 : Closed e701154191274 ∧ code e701154191274 = 9497247213482 := by decide
theorem cert_e701154191274 : check e701154191274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701154191802 : Closed e701154191802 ∧ code e701154191802 = 9497247214010 := by decide
theorem cert_e701154191802 : check e701154191802 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e701154191834 : Closed e701154191834 ∧ code e701154191834 = 9497247214042 := by decide
theorem cert_e701154191834 : check e701154191834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154191850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701154191850 : Closed e701154191850 ∧ code e701154191850 = 9497247214058 := by decide
theorem cert_e701154191850 : check e701154191850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154192602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701154192602 : Closed e701154192602 ∧ code e701154192602 = 9497247214810 := by decide
theorem cert_e701154192602 : check e701154192602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154192618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701154192618 : Closed e701154192618 ∧ code e701154192618 = 9497247214826 := by decide
theorem cert_e701154192618 : check e701154192618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154193002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701154193002 : Closed e701154193002 ∧ code e701154193002 = 9497247215210 := by decide
theorem cert_e701154193002 : check e701154193002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154209210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.var 0)))
theorem wire_e701154209210 : Closed e701154209210 ∧ code e701154209210 = 9497247231418 := by decide
theorem cert_e701154209210 : check e701154209210 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154209242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.var 0)))
theorem wire_e701154209242 : Closed e701154209242 ∧ code e701154209242 = 9497247231450 := by decide
theorem cert_e701154209242 : check e701154209242 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154209466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.var 0)))
theorem wire_e701154209466 : Closed e701154209466 ∧ code e701154209466 = 9497247231674 := by decide
theorem cert_e701154209466 : check e701154209466 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154209514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.var 0)))
theorem wire_e701154209514 : Closed e701154209514 ∧ code e701154209514 = 9497247231722 := by decide
theorem cert_e701154209514 : check e701154209514 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154209626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.var 0)))
theorem wire_e701154209626 : Closed e701154209626 ∧ code e701154209626 = 9497247231834 := by decide
theorem cert_e701154209626 : check e701154209626 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154209642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.var 0)))
theorem wire_e701154209642 : Closed e701154209642 ∧ code e701154209642 = 9497247231850 := by decide
theorem cert_e701154209642 : check e701154209642 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154210746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.var 0)))
theorem wire_e701154210746 : Closed e701154210746 ∧ code e701154210746 = 9497247232954 := by decide
theorem cert_e701154210746 : check e701154210746 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154210778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.var 0)))
theorem wire_e701154210778 : Closed e701154210778 ∧ code e701154210778 = 9497247232986 := by decide
theorem cert_e701154210778 : check e701154210778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154212282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.var 0)))
theorem wire_e701154212282 : Closed e701154212282 ∧ code e701154212282 = 9497247234490 := by decide
theorem cert_e701154212282 : check e701154212282 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154212330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.var 0)))
theorem wire_e701154212330 : Closed e701154212330 ∧ code e701154212330 = 9497247234538 := by decide
theorem cert_e701154212330 : check e701154212330 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154213082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.var 0)))
theorem wire_e701154213082 : Closed e701154213082 ∧ code e701154213082 = 9497247235290 := by decide
theorem cert_e701154213082 : check e701154213082 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154213098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.var 0)))
theorem wire_e701154213098 : Closed e701154213098 ∧ code e701154213098 = 9497247235306 := by decide
theorem cert_e701154213098 : check e701154213098 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154244474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.var 0)))
theorem wire_e701154244474 : Closed e701154244474 ∧ code e701154244474 = 9497247266682 := by decide
theorem cert_e701154244474 : check e701154244474 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154244538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.var 0)))
theorem wire_e701154244538 : Closed e701154244538 ∧ code e701154244538 = 9497247266746 := by decide
theorem cert_e701154244538 : check e701154244538 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154245498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e701154245498 : Closed e701154245498 ∧ code e701154245498 = 9497247267706 := by decide
theorem cert_e701154245498 : check e701154245498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154245562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.var 0)))
theorem wire_e701154245562 : Closed e701154245562 ∧ code e701154245562 = 9497247267770 := by decide
theorem cert_e701154245562 : check e701154245562 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154245594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e701154245594 : Closed e701154245594 ∧ code e701154245594 = 9497247267802 := by decide
theorem cert_e701154245594 : check e701154245594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154246010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701154246010 : Closed e701154246010 ∧ code e701154246010 = 9497247268218 := by decide
theorem cert_e701154246010 : check e701154246010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154246074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701154246074 : Closed e701154246074 ∧ code e701154246074 = 9497247268282 := by decide
theorem cert_e701154246074 : check e701154246074 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154246106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701154246106 : Closed e701154246106 ∧ code e701154246106 = 9497247268314 := by decide
theorem cert_e701154246106 : check e701154246106 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154246122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701154246122 : Closed e701154246122 ∧ code e701154246122 = 9497247268330 := by decide
theorem cert_e701154246122 : check e701154246122 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154246330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701154246330 : Closed e701154246330 ∧ code e701154246330 = 9497247268538 := by decide
theorem cert_e701154246330 : check e701154246330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154246362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))) (.var 0)))
theorem wire_e701154246362 : Closed e701154246362 ∧ code e701154246362 = 9497247268570 := by decide
theorem cert_e701154246362 : check e701154246362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154246378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701154246378 : Closed e701154246378 ∧ code e701154246378 = 9497247268586 := by decide
theorem cert_e701154246378 : check e701154246378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154250618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701154250618 : Closed e701154250618 ∧ code e701154250618 = 9497247272826 := by decide
theorem cert_e701154250618 : check e701154250618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154250682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701154250682 : Closed e701154250682 ∧ code e701154250682 = 9497247272890 := by decide
theorem cert_e701154250682 : check e701154250682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154256762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701154256762 : Closed e701154256762 ∧ code e701154256762 = 9497247278970 := by decide
theorem cert_e701154256762 : check e701154256762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154256826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.var 0)))
theorem wire_e701154256826 : Closed e701154256826 ∧ code e701154256826 = 9497247279034 := by decide
theorem cert_e701154256826 : check e701154256826 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154256858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701154256858 : Closed e701154256858 ∧ code e701154256858 = 9497247279066 := by decide
theorem cert_e701154256858 : check e701154256858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154259834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701154259834 : Closed e701154259834 ∧ code e701154259834 = 9497247282042 := by decide
theorem cert_e701154259834 : check e701154259834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154259898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701154259898 : Closed e701154259898 ∧ code e701154259898 = 9497247282106 := by decide
theorem cert_e701154259898 : check e701154259898 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154259930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701154259930 : Closed e701154259930 ∧ code e701154259930 = 9497247282138 := by decide
theorem cert_e701154259930 : check e701154259930 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154259946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701154259946 : Closed e701154259946 ∧ code e701154259946 = 9497247282154 := by decide
theorem cert_e701154259946 : check e701154259946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154261434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701154261434 : Closed e701154261434 ∧ code e701154261434 = 9497247283642 := by decide
theorem cert_e701154261434 : check e701154261434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154261466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e701154261466 : Closed e701154261466 ∧ code e701154261466 = 9497247283674 := by decide
theorem cert_e701154261466 : check e701154261466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154261482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701154261482 : Closed e701154261482 ∧ code e701154261482 = 9497247283690 := by decide
theorem cert_e701154261482 : check e701154261482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154351994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.var 0)))
theorem wire_e701154351994 : Closed e701154351994 ∧ code e701154351994 = 9497247374202 := by decide
theorem cert_e701154351994 : check e701154351994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154352058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.var 0)))
theorem wire_e701154352058 : Closed e701154352058 ∧ code e701154352058 = 9497247374266 := by decide
theorem cert_e701154352058 : check e701154352058 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154352090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.var 0)))
theorem wire_e701154352090 : Closed e701154352090 ∧ code e701154352090 = 9497247374298 := by decide
theorem cert_e701154352090 : check e701154352090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154352506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701154352506 : Closed e701154352506 ∧ code e701154352506 = 9497247374714 := by decide
theorem cert_e701154352506 : check e701154352506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154352618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701154352618 : Closed e701154352618 ∧ code e701154352618 = 9497247374826 := by decide
theorem cert_e701154352618 : check e701154352618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154352826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701154352826 : Closed e701154352826 ∧ code e701154352826 = 9497247375034 := by decide
theorem cert_e701154352826 : check e701154352826 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154352874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701154352874 : Closed e701154352874 ∧ code e701154352874 = 9497247375082 := by decide
theorem cert_e701154352874 : check e701154352874 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154352986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701154352986 : Closed e701154352986 ∧ code e701154352986 = 9497247375194 := by decide
theorem cert_e701154352986 : check e701154352986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154353002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701154353002 : Closed e701154353002 ∧ code e701154353002 = 9497247375210 := by decide
theorem cert_e701154353002 : check e701154353002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154355066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701154355066 : Closed e701154355066 ∧ code e701154355066 = 9497247377274 := by decide
theorem cert_e701154355066 : check e701154355066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154355130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.var 0)))
theorem wire_e701154355130 : Closed e701154355130 ∧ code e701154355130 = 9497247377338 := by decide
theorem cert_e701154355130 : check e701154355130 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154355162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701154355162 : Closed e701154355162 ∧ code e701154355162 = 9497247377370 := by decide
theorem cert_e701154355162 : check e701154355162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154358138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701154358138 : Closed e701154358138 ∧ code e701154358138 = 9497247380346 := by decide
theorem cert_e701154358138 : check e701154358138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154358250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701154358250 : Closed e701154358250 ∧ code e701154358250 = 9497247380458 := by decide
theorem cert_e701154358250 : check e701154358250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154359738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701154359738 : Closed e701154359738 ∧ code e701154359738 = 9497247381946 := by decide
theorem cert_e701154359738 : check e701154359738 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154359786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701154359786 : Closed e701154359786 ∧ code e701154359786 = 9497247381994 := by decide
theorem cert_e701154359786 : check e701154359786 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154360538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701154360538 : Closed e701154360538 ∧ code e701154360538 = 9497247382746 := by decide
theorem cert_e701154360538 : check e701154360538 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154360554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701154360554 : Closed e701154360554 ∧ code e701154360554 = 9497247382762 := by decide
theorem cert_e701154360554 : check e701154360554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154405754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701154405754 : Closed e701154405754 ∧ code e701154405754 = 9497247427962 := by decide
theorem cert_e701154405754 : check e701154405754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154405818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701154405818 : Closed e701154405818 ∧ code e701154405818 = 9497247428026 := by decide
theorem cert_e701154405818 : check e701154405818 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154405850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701154405850 : Closed e701154405850 ∧ code e701154405850 = 9497247428058 := by decide
theorem cert_e701154405850 : check e701154405850 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154405866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701154405866 : Closed e701154405866 ∧ code e701154405866 = 9497247428074 := by decide
theorem cert_e701154405866 : check e701154405866 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154406074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701154406074 : Closed e701154406074 ∧ code e701154406074 = 9497247428282 := by decide
theorem cert_e701154406074 : check e701154406074 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154406122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701154406122 : Closed e701154406122 ∧ code e701154406122 = 9497247428330 := by decide
theorem cert_e701154406122 : check e701154406122 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154406234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701154406234 : Closed e701154406234 ∧ code e701154406234 = 9497247428442 := by decide
theorem cert_e701154406234 : check e701154406234 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154406250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701154406250 : Closed e701154406250 ∧ code e701154406250 = 9497247428458 := by decide
theorem cert_e701154406250 : check e701154406250 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154406314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701154406314 : Closed e701154406314 ∧ code e701154406314 = 9497247428522 := by decide
theorem cert_e701154406314 : check e701154406314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154407290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701154407290 : Closed e701154407290 ∧ code e701154407290 = 9497247429498 := by decide
theorem cert_e701154407290 : check e701154407290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154407354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701154407354 : Closed e701154407354 ∧ code e701154407354 = 9497247429562 := by decide
theorem cert_e701154407354 : check e701154407354 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154407386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701154407386 : Closed e701154407386 ∧ code e701154407386 = 9497247429594 := by decide
theorem cert_e701154407386 : check e701154407386 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154407402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701154407402 : Closed e701154407402 ∧ code e701154407402 = 9497247429610 := by decide
theorem cert_e701154407402 : check e701154407402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154408890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701154408890 : Closed e701154408890 ∧ code e701154408890 = 9497247431098 := by decide
theorem cert_e701154408890 : check e701154408890 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154408938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701154408938 : Closed e701154408938 ∧ code e701154408938 = 9497247431146 := by decide
theorem cert_e701154408938 : check e701154408938 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154409690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701154409690 : Closed e701154409690 ∧ code e701154409690 = 9497247431898 := by decide
theorem cert_e701154409690 : check e701154409690 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154409706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701154409706 : Closed e701154409706 ∧ code e701154409706 = 9497247431914 := by decide
theorem cert_e701154409706 : check e701154409706 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154410090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701154410090 : Closed e701154410090 ∧ code e701154410090 = 9497247432298 := by decide
theorem cert_e701154410090 : check e701154410090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701154432698 : Closed e701154432698 ∧ code e701154432698 = 9497247454906 := by decide
theorem cert_e701154432698 : check e701154432698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))) (.var 0)))
theorem wire_e701154432730 : Closed e701154432730 ∧ code e701154432730 = 9497247454938 := by decide
theorem cert_e701154432730 : check e701154432730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701154432746 : Closed e701154432746 ∧ code e701154432746 = 9497247454954 := by decide
theorem cert_e701154432746 : check e701154432746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701154432858 : Closed e701154432858 ∧ code e701154432858 = 9497247455066 := by decide
theorem cert_e701154432858 : check e701154432858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701154432874 : Closed e701154432874 ∧ code e701154432874 = 9497247455082 := by decide
theorem cert_e701154432874 : check e701154432874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154432938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701154432938 : Closed e701154432938 ∧ code e701154432938 = 9497247455146 := by decide
theorem cert_e701154432938 : check e701154432938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154433466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701154433466 : Closed e701154433466 ∧ code e701154433466 = 9497247455674 := by decide
theorem cert_e701154433466 : check e701154433466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154433498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))) (.var 0)))
theorem wire_e701154433498 : Closed e701154433498 ∧ code e701154433498 = 9497247455706 := by decide
theorem cert_e701154433498 : check e701154433498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154433514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701154433514 : Closed e701154433514 ∧ code e701154433514 = 9497247455722 := by decide
theorem cert_e701154433514 : check e701154433514 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154434266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701154434266 : Closed e701154434266 ∧ code e701154434266 = 9497247456474 := by decide
theorem cert_e701154434266 : check e701154434266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154434282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701154434282 : Closed e701154434282 ∧ code e701154434282 = 9497247456490 := by decide
theorem cert_e701154434282 : check e701154434282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154434666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701154434666 : Closed e701154434666 ∧ code e701154434666 = 9497247456874 := by decide
theorem cert_e701154434666 : check e701154434666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e701156218298 : Closed e701156218298 ∧ code e701156218298 = 9497249240506 := by decide
theorem cert_e701156218298 : check e701156218298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e701156218330 : Closed e701156218330 ∧ code e701156218330 = 9497249240538 := by decide
theorem cert_e701156218330 : check e701156218330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156218554 : Closed e701156218554 ∧ code e701156218554 = 9497249240762 := by decide
theorem cert_e701156218554 : check e701156218554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156218602 : Closed e701156218602 ∧ code e701156218602 = 9497249240810 := by decide
theorem cert_e701156218602 : check e701156218602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156218714 : Closed e701156218714 ∧ code e701156218714 = 9497249240922 := by decide
theorem cert_e701156218714 : check e701156218714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156218730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156218730 : Closed e701156218730 ∧ code e701156218730 = 9497249240938 := by decide
theorem cert_e701156218730 : check e701156218730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156219578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156219578 : Closed e701156219578 ∧ code e701156219578 = 9497249241786 := by decide
theorem cert_e701156219578 : check e701156219578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156219626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156219626 : Closed e701156219626 ∧ code e701156219626 = 9497249241834 := by decide
theorem cert_e701156219626 : check e701156219626 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156219818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156219818 : Closed e701156219818 ∧ code e701156219818 = 9497249242026 := by decide
theorem cert_e701156219818 : check e701156219818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156220250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156220250 : Closed e701156220250 ∧ code e701156220250 = 9497249242458 := by decide
theorem cert_e701156220250 : check e701156220250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156220266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156220266 : Closed e701156220266 ∧ code e701156220266 = 9497249242474 := by decide
theorem cert_e701156220266 : check e701156220266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156220330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156220330 : Closed e701156220330 ∧ code e701156220330 = 9497249242538 := by decide
theorem cert_e701156220330 : check e701156220330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156223674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156223674 : Closed e701156223674 ∧ code e701156223674 = 9497249245882 := by decide
theorem cert_e701156223674 : check e701156223674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156223722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156223722 : Closed e701156223722 ∧ code e701156223722 = 9497249245930 := by decide
theorem cert_e701156223722 : check e701156223722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156223914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156223914 : Closed e701156223914 ∧ code e701156223914 = 9497249246122 := by decide
theorem cert_e701156223914 : check e701156223914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156224682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156224682 : Closed e701156224682 ∧ code e701156224682 = 9497249246890 := by decide
theorem cert_e701156224682 : check e701156224682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156226394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156226394 : Closed e701156226394 ∧ code e701156226394 = 9497249248602 := by decide
theorem cert_e701156226394 : check e701156226394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156226410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156226410 : Closed e701156226410 ∧ code e701156226410 = 9497249248618 := by decide
theorem cert_e701156226410 : check e701156226410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156226474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156226474 : Closed e701156226474 ∧ code e701156226474 = 9497249248682 := by decide
theorem cert_e701156226474 : check e701156226474 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156226730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156226730 : Closed e701156226730 ∧ code e701156226730 = 9497249248938 := by decide
theorem cert_e701156226730 : check e701156226730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156236730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e701156236730 : Closed e701156236730 ∧ code e701156236730 = 9497249258938 := by decide
theorem cert_e701156236730 : check e701156236730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156236762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e701156236762 : Closed e701156236762 ∧ code e701156236762 = 9497249258970 := by decide
theorem cert_e701156236762 : check e701156236762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156237018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e701156237018 : Closed e701156237018 ∧ code e701156237018 = 9497249259226 := by decide
theorem cert_e701156237018 : check e701156237018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156242874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e701156242874 : Closed e701156242874 ∧ code e701156242874 = 9497249265082 := by decide
theorem cert_e701156242874 : check e701156242874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156242906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e701156242906 : Closed e701156242906 ∧ code e701156242906 = 9497249265114 := by decide
theorem cert_e701156242906 : check e701156242906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156243130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156243130 : Closed e701156243130 ∧ code e701156243130 = 9497249265338 := by decide
theorem cert_e701156243130 : check e701156243130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156243178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156243178 : Closed e701156243178 ∧ code e701156243178 = 9497249265386 := by decide
theorem cert_e701156243178 : check e701156243178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156243290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156243290 : Closed e701156243290 ∧ code e701156243290 = 9497249265498 := by decide
theorem cert_e701156243290 : check e701156243290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156243306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156243306 : Closed e701156243306 ∧ code e701156243306 = 9497249265514 := by decide
theorem cert_e701156243306 : check e701156243306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156244154 : Closed e701156244154 ∧ code e701156244154 = 9497249266362 := by decide
theorem cert_e701156244154 : check e701156244154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156244202 : Closed e701156244202 ∧ code e701156244202 = 9497249266410 := by decide
theorem cert_e701156244202 : check e701156244202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156244394 : Closed e701156244394 ∧ code e701156244394 = 9497249266602 := by decide
theorem cert_e701156244394 : check e701156244394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156244826 : Closed e701156244826 ∧ code e701156244826 = 9497249267034 := by decide
theorem cert_e701156244826 : check e701156244826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156244842 : Closed e701156244842 ∧ code e701156244842 = 9497249267050 := by decide
theorem cert_e701156244842 : check e701156244842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156244906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156244906 : Closed e701156244906 ∧ code e701156244906 = 9497249267114 := by decide
theorem cert_e701156244906 : check e701156244906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e701156249018 : Closed e701156249018 ∧ code e701156249018 = 9497249271226 := by decide
theorem cert_e701156249018 : check e701156249018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e701156249050 : Closed e701156249050 ∧ code e701156249050 = 9497249271258 := by decide
theorem cert_e701156249050 : check e701156249050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156249274 : Closed e701156249274 ∧ code e701156249274 = 9497249271482 := by decide
theorem cert_e701156249274 : check e701156249274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156249322 : Closed e701156249322 ∧ code e701156249322 = 9497249271530 := by decide
theorem cert_e701156249322 : check e701156249322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156249434 : Closed e701156249434 ∧ code e701156249434 = 9497249271642 := by decide
theorem cert_e701156249434 : check e701156249434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156249450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156249450 : Closed e701156249450 ∧ code e701156249450 = 9497249271658 := by decide
theorem cert_e701156249450 : check e701156249450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156250554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e701156250554 : Closed e701156250554 ∧ code e701156250554 = 9497249272762 := by decide
theorem cert_e701156250554 : check e701156250554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156250586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e701156250586 : Closed e701156250586 ∧ code e701156250586 = 9497249272794 := by decide
theorem cert_e701156250586 : check e701156250586 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156252090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156252090 : Closed e701156252090 ∧ code e701156252090 = 9497249274298 := by decide
theorem cert_e701156252090 : check e701156252090 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156252138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156252138 : Closed e701156252138 ∧ code e701156252138 = 9497249274346 := by decide
theorem cert_e701156252138 : check e701156252138 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156252570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156252570 : Closed e701156252570 ∧ code e701156252570 = 9497249274778 := by decide
theorem cert_e701156252570 : check e701156252570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156252890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156252890 : Closed e701156252890 ∧ code e701156252890 = 9497249275098 := by decide
theorem cert_e701156252890 : check e701156252890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156252906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156252906 : Closed e701156252906 ∧ code e701156252906 = 9497249275114 := by decide
theorem cert_e701156252906 : check e701156252906 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156253082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156253082 : Closed e701156253082 ∧ code e701156253082 = 9497249275290 := by decide
theorem cert_e701156253082 : check e701156253082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156254650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))) (.var 0)))
theorem wire_e701156254650 : Closed e701156254650 ∧ code e701156254650 = 9497249276858 := by decide
theorem cert_e701156254650 : check e701156254650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156254682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))) (.var 0)))
theorem wire_e701156254682 : Closed e701156254682 ∧ code e701156254682 = 9497249276890 := by decide
theorem cert_e701156254682 : check e701156254682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156255418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156255418 : Closed e701156255418 ∧ code e701156255418 = 9497249277626 := by decide
theorem cert_e701156255418 : check e701156255418 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156255466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156255466 : Closed e701156255466 ∧ code e701156255466 = 9497249277674 := by decide
theorem cert_e701156255466 : check e701156255466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156255658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156255658 : Closed e701156255658 ∧ code e701156255658 = 9497249277866 := by decide
theorem cert_e701156255658 : check e701156255658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156256186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156256186 : Closed e701156256186 ∧ code e701156256186 = 9497249278394 := by decide
theorem cert_e701156256186 : check e701156256186 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156256234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156256234 : Closed e701156256234 ∧ code e701156256234 = 9497249278442 := by decide
theorem cert_e701156256234 : check e701156256234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156256666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156256666 : Closed e701156256666 ∧ code e701156256666 = 9497249278874 := by decide
theorem cert_e701156256666 : check e701156256666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156256890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156256890 : Closed e701156256890 ∧ code e701156256890 = 9497249279098 := by decide
theorem cert_e701156256890 : check e701156256890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156257222 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156257222 : Closed e701156257222 ∧ code e701156257222 = 9497249279430 := by decide
theorem cert_e701156257222 : check e701156257222 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156257338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156257338 : Closed e701156257338 ∧ code e701156257338 = 9497249279546 := by decide
theorem cert_e701156257338 : check e701156257338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156257386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156257386 : Closed e701156257386 ∧ code e701156257386 = 9497249279594 := by decide
theorem cert_e701156257386 : check e701156257386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156257434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156257434 : Closed e701156257434 ∧ code e701156257434 = 9497249279642 := by decide
theorem cert_e701156257434 : check e701156257434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156257478 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156257478 : Closed e701156257478 ∧ code e701156257478 = 9497249279686 := by decide
theorem cert_e701156257478 : check e701156257478 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156258266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e701156258266 : Closed e701156258266 ∧ code e701156258266 = 9497249280474 := by decide
theorem cert_e701156258266 : check e701156258266 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
