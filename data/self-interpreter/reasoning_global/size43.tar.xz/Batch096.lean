import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834096772782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e834096772782 : Closed e834096772782 ∧ code e834096772782 = 9630189794990 := by decide
theorem cert_e834096772782 : check e834096772782 [] .sourceHead = true := by decide
def e834096772794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e834096772794 : Closed e834096772794 ∧ code e834096772794 = 9630189795002 := by decide
theorem cert_e834096772794 : check e834096772794 [] .sourceHead = true := by decide
def e834096772842 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e834096772842 : Closed e834096772842 ∧ code e834096772842 = 9630189795050 := by decide
theorem cert_e834096772842 : check e834096772842 [] .sourceHead = true := by decide
def e834096772950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e834096772950 : Closed e834096772950 ∧ code e834096772950 = 9630189795158 := by decide
theorem cert_e834096772950 : check e834096772950 [] .sourceHead = true := by decide
def e834096772954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e834096772954 : Closed e834096772954 ∧ code e834096772954 = 9630189795162 := by decide
theorem cert_e834096772954 : check e834096772954 [] .sourceHead = true := by decide
def e834096772970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e834096772970 : Closed e834096772970 ∧ code e834096772970 = 9630189795178 := by decide
theorem cert_e834096772970 : check e834096772970 [] .sourceHead = true := by decide
def e834096773806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e834096773806 : Closed e834096773806 ∧ code e834096773806 = 9630189796014 := by decide
theorem cert_e834096773806 : check e834096773806 [] .sourceHead = true := by decide
def e834096773818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e834096773818 : Closed e834096773818 ∧ code e834096773818 = 9630189796026 := by decide
theorem cert_e834096773818 : check e834096773818 [] .sourceHead = true := by decide
def e834096773866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e834096773866 : Closed e834096773866 ∧ code e834096773866 = 9630189796074 := by decide
theorem cert_e834096773866 : check e834096773866 [] .sourceHead = true := by decide
def e834096774058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e834096774058 : Closed e834096774058 ∧ code e834096774058 = 9630189796266 := by decide
theorem cert_e834096774058 : check e834096774058 [] .sourceHead = true := by decide
def e834096774486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e834096774486 : Closed e834096774486 ∧ code e834096774486 = 9630189796694 := by decide
theorem cert_e834096774486 : check e834096774486 [] .sourceHead = true := by decide
def e834096774490 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e834096774490 : Closed e834096774490 ∧ code e834096774490 = 9630189796698 := by decide
theorem cert_e834096774490 : check e834096774490 [] .sourceHead = true := by decide
def e834096774506 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e834096774506 : Closed e834096774506 ∧ code e834096774506 = 9630189796714 := by decide
theorem cert_e834096774506 : check e834096774506 [] .sourceHead = true := by decide
def e834096774570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e834096774570 : Closed e834096774570 ∧ code e834096774570 = 9630189796778 := by decide
theorem cert_e834096774570 : check e834096774570 [] .sourceHead = true := by decide
def e834096777070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e834096777070 : Closed e834096777070 ∧ code e834096777070 = 9630189799278 := by decide
theorem cert_e834096777070 : check e834096777070 [] .sourceHead = true := by decide
def e834096777078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e834096777078 : Closed e834096777078 ∧ code e834096777078 = 9630189799286 := by decide
theorem cert_e834096777078 : check e834096777078 [] .sourceHead = true := by decide
def e834096777142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e834096777142 : Closed e834096777142 ∧ code e834096777142 = 9630189799350 := by decide
theorem cert_e834096777142 : check e834096777142 [] .sourceHead = true := by decide
def e834096778606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e834096778606 : Closed e834096778606 ∧ code e834096778606 = 9630189800814 := by decide
theorem cert_e834096778606 : check e834096778606 [] .sourceHead = true := by decide
def e834096778614 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e834096778614 : Closed e834096778614 ∧ code e834096778614 = 9630189800822 := by decide
theorem cert_e834096778614 : check e834096778614 [] .sourceHead = true := by decide
def e834096778670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e834096778670 : Closed e834096778670 ∧ code e834096778670 = 9630189800878 := by decide
theorem cert_e834096778670 : check e834096778670 [] .sourceHead = true := by decide
def e834096778682 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e834096778682 : Closed e834096778682 ∧ code e834096778682 = 9630189800890 := by decide
theorem cert_e834096778682 : check e834096778682 [] .sourceHead = true := by decide
def e834096778710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e834096778710 : Closed e834096778710 ∧ code e834096778710 = 9630189800918 := by decide
theorem cert_e834096778710 : check e834096778710 [] .sourceHead = true := by decide
def e834096778714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e834096778714 : Closed e834096778714 ∧ code e834096778714 = 9630189800922 := by decide
theorem cert_e834096778714 : check e834096778714 [] .sourceHead = true := by decide
def e834096778926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e834096778926 : Closed e834096778926 ∧ code e834096778926 = 9630189801134 := by decide
theorem cert_e834096778926 : check e834096778926 [] .sourceHead = true := by decide
def e834096778938 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e834096778938 : Closed e834096778938 ∧ code e834096778938 = 9630189801146 := by decide
theorem cert_e834096778938 : check e834096778938 [] .sourceHead = true := by decide
def e834096778986 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e834096778986 : Closed e834096778986 ∧ code e834096778986 = 9630189801194 := by decide
theorem cert_e834096778986 : check e834096778986 [] .sourceHead = true := by decide
def e834096779094 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e834096779094 : Closed e834096779094 ∧ code e834096779094 = 9630189801302 := by decide
theorem cert_e834096779094 : check e834096779094 [] .sourceHead = true := by decide
def e834096779098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e834096779098 : Closed e834096779098 ∧ code e834096779098 = 9630189801306 := by decide
theorem cert_e834096779098 : check e834096779098 [] .sourceHead = true := by decide
def e834096779114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e834096779114 : Closed e834096779114 ∧ code e834096779114 = 9630189801322 := by decide
theorem cert_e834096779114 : check e834096779114 [] .sourceHead = true := by decide
def e834096780142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e834096780142 : Closed e834096780142 ∧ code e834096780142 = 9630189802350 := by decide
theorem cert_e834096780142 : check e834096780142 [] .sourceHead = true := by decide
def e834096780150 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e834096780150 : Closed e834096780150 ∧ code e834096780150 = 9630189802358 := by decide
theorem cert_e834096780150 : check e834096780150 [] .sourceHead = true := by decide
def e834096780206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e834096780206 : Closed e834096780206 ∧ code e834096780206 = 9630189802414 := by decide
theorem cert_e834096780206 : check e834096780206 [] .sourceHead = true := by decide
def e834096780218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e834096780218 : Closed e834096780218 ∧ code e834096780218 = 9630189802426 := by decide
theorem cert_e834096780218 : check e834096780218 [] .sourceHead = true := by decide
def e834096780246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e834096780246 : Closed e834096780246 ∧ code e834096780246 = 9630189802454 := by decide
theorem cert_e834096780246 : check e834096780246 [] .sourceHead = true := by decide
def e834096780250 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e834096780250 : Closed e834096780250 ∧ code e834096780250 = 9630189802458 := by decide
theorem cert_e834096780250 : check e834096780250 [] .sourceHead = true := by decide
def e834096780526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e834096780526 : Closed e834096780526 ∧ code e834096780526 = 9630189802734 := by decide
theorem cert_e834096780526 : check e834096780526 [] .sourceHead = true := by decide
def e834096780534 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e834096780534 : Closed e834096780534 ∧ code e834096780534 = 9630189802742 := by decide
theorem cert_e834096780534 : check e834096780534 [] .sourceHead = true := by decide
def e834096780910 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096780910 : Closed e834096780910 ∧ code e834096780910 = 9630189803118 := by decide
theorem cert_e834096780910 : check e834096780910 [] .sourceHead = true := by decide
def e834096780922 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096780922 : Closed e834096780922 ∧ code e834096780922 = 9630189803130 := by decide
theorem cert_e834096780922 : check e834096780922 [] .sourceHead = true := by decide
def e834096781110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096781110 : Closed e834096781110 ∧ code e834096781110 = 9630189803318 := by decide
theorem cert_e834096781110 : check e834096781110 [] .sourceHead = true := by decide
def e834096781114 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096781114 : Closed e834096781114 ∧ code e834096781114 = 9630189803322 := by decide
theorem cert_e834096781114 : check e834096781114 [] .sourceHead = true := by decide
def e834096781550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e834096781550 : Closed e834096781550 ∧ code e834096781550 = 9630189803758 := by decide
theorem cert_e834096781550 : check e834096781550 [] .sourceHead = true := by decide
def e834096781558 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e834096781558 : Closed e834096781558 ∧ code e834096781558 = 9630189803766 := by decide
theorem cert_e834096781558 : check e834096781558 [] .sourceHead = true := by decide
def e834096781742 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e834096781742 : Closed e834096781742 ∧ code e834096781742 = 9630189803950 := by decide
theorem cert_e834096781742 : check e834096781742 [] .sourceHead = true := by decide
def e834096781754 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e834096781754 : Closed e834096781754 ∧ code e834096781754 = 9630189803962 := by decide
theorem cert_e834096781754 : check e834096781754 [] .sourceHead = true := by decide
def e834096781802 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e834096781802 : Closed e834096781802 ∧ code e834096781802 = 9630189804010 := by decide
theorem cert_e834096781802 : check e834096781802 [] .sourceHead = true := by decide
def e834096781934 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096781934 : Closed e834096781934 ∧ code e834096781934 = 9630189804142 := by decide
theorem cert_e834096781934 : check e834096781934 [] .sourceHead = true := by decide
def e834096781946 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096781946 : Closed e834096781946 ∧ code e834096781946 = 9630189804154 := by decide
theorem cert_e834096781946 : check e834096781946 [] .sourceHead = true := by decide
def e834096782110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e834096782110 : Closed e834096782110 ∧ code e834096782110 = 9630189804318 := by decide
theorem cert_e834096782110 : check e834096782110 [] .sourceHead = true := by decide
def e834096782222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e834096782222 : Closed e834096782222 ∧ code e834096782222 = 9630189804430 := by decide
theorem cert_e834096782222 : check e834096782222 [] .sourceHead = true := by decide
def e834096782234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096782234 : Closed e834096782234 ∧ code e834096782234 = 9630189804442 := by decide
theorem cert_e834096782234 : check e834096782234 [] .sourceHead = true := by decide
def e834096782454 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e834096782454 : Closed e834096782454 ∧ code e834096782454 = 9630189804662 := by decide
theorem cert_e834096782454 : check e834096782454 [] .sourceHead = true := by decide
def e834096782550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e834096782550 : Closed e834096782550 ∧ code e834096782550 = 9630189804758 := by decide
theorem cert_e834096782550 : check e834096782550 [] .sourceHead = true := by decide
def e834096782554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e834096782554 : Closed e834096782554 ∧ code e834096782554 = 9630189804762 := by decide
theorem cert_e834096782554 : check e834096782554 [] .sourceHead = true := by decide
def e834096782570 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e834096782570 : Closed e834096782570 ∧ code e834096782570 = 9630189804778 := by decide
theorem cert_e834096782570 : check e834096782570 [] .sourceHead = true := by decide
def e834096782646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096782646 : Closed e834096782646 ∧ code e834096782646 = 9630189804854 := by decide
theorem cert_e834096782646 : check e834096782646 [] .sourceHead = true := by decide
def e834096782650 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096782650 : Closed e834096782650 ∧ code e834096782650 = 9630189804858 := by decide
theorem cert_e834096782650 : check e834096782650 [] .sourceHead = true := by decide
def e834096782734 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e834096782734 : Closed e834096782734 ∧ code e834096782734 = 9630189804942 := by decide
theorem cert_e834096782734 : check e834096782734 [] .sourceHead = true := by decide
def e834096782746 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096782746 : Closed e834096782746 ∧ code e834096782746 = 9630189804954 := by decide
theorem cert_e834096782746 : check e834096782746 [] .sourceHead = true := by decide
def e834096784238 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e834096784238 : Closed e834096784238 ∧ code e834096784238 = 9630189806446 := by decide
theorem cert_e834096784238 : check e834096784238 [] .sourceHead = true := by decide
def e834096784246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e834096784246 : Closed e834096784246 ∧ code e834096784246 = 9630189806454 := by decide
theorem cert_e834096784246 : check e834096784246 [] .sourceHead = true := by decide
def e834096784302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e834096784302 : Closed e834096784302 ∧ code e834096784302 = 9630189806510 := by decide
theorem cert_e834096784302 : check e834096784302 [] .sourceHead = true := by decide
def e834096784314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e834096784314 : Closed e834096784314 ∧ code e834096784314 = 9630189806522 := by decide
theorem cert_e834096784314 : check e834096784314 [] .sourceHead = true := by decide
def e834096784342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e834096784342 : Closed e834096784342 ∧ code e834096784342 = 9630189806550 := by decide
theorem cert_e834096784342 : check e834096784342 [] .sourceHead = true := by decide
def e834096784346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e834096784346 : Closed e834096784346 ∧ code e834096784346 = 9630189806554 := by decide
theorem cert_e834096784346 : check e834096784346 [] .sourceHead = true := by decide
def e834096785070 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e834096785070 : Closed e834096785070 ∧ code e834096785070 = 9630189807278 := by decide
theorem cert_e834096785070 : check e834096785070 [] .sourceHead = true := by decide
def e834096785082 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e834096785082 : Closed e834096785082 ∧ code e834096785082 = 9630189807290 := by decide
theorem cert_e834096785082 : check e834096785082 [] .sourceHead = true := by decide
def e834096785130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e834096785130 : Closed e834096785130 ∧ code e834096785130 = 9630189807338 := by decide
theorem cert_e834096785130 : check e834096785130 [] .sourceHead = true := by decide
def e834096785322 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e834096785322 : Closed e834096785322 ∧ code e834096785322 = 9630189807530 := by decide
theorem cert_e834096785322 : check e834096785322 [] .sourceHead = true := by decide
def e834096785646 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e834096785646 : Closed e834096785646 ∧ code e834096785646 = 9630189807854 := by decide
theorem cert_e834096785646 : check e834096785646 [] .sourceHead = true := by decide
def e834096785654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e834096785654 : Closed e834096785654 ∧ code e834096785654 = 9630189807862 := by decide
theorem cert_e834096785654 : check e834096785654 [] .sourceHead = true := by decide
def e834096785838 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e834096785838 : Closed e834096785838 ∧ code e834096785838 = 9630189808046 := by decide
theorem cert_e834096785838 : check e834096785838 [] .sourceHead = true := by decide
def e834096785850 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e834096785850 : Closed e834096785850 ∧ code e834096785850 = 9630189808058 := by decide
theorem cert_e834096785850 : check e834096785850 [] .sourceHead = true := by decide
def e834096785898 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e834096785898 : Closed e834096785898 ∧ code e834096785898 = 9630189808106 := by decide
theorem cert_e834096785898 : check e834096785898 [] .sourceHead = true := by decide
def e834096786030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096786030 : Closed e834096786030 ∧ code e834096786030 = 9630189808238 := by decide
theorem cert_e834096786030 : check e834096786030 [] .sourceHead = true := by decide
def e834096786042 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096786042 : Closed e834096786042 ∧ code e834096786042 = 9630189808250 := by decide
theorem cert_e834096786042 : check e834096786042 [] .sourceHead = true := by decide
def e834096786206 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e834096786206 : Closed e834096786206 ∧ code e834096786206 = 9630189808414 := by decide
theorem cert_e834096786206 : check e834096786206 [] .sourceHead = true := by decide
def e834096786318 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e834096786318 : Closed e834096786318 ∧ code e834096786318 = 9630189808526 := by decide
theorem cert_e834096786318 : check e834096786318 [] .sourceHead = true := by decide
def e834096786330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096786330 : Closed e834096786330 ∧ code e834096786330 = 9630189808538 := by decide
theorem cert_e834096786330 : check e834096786330 [] .sourceHead = true := by decide
def e834096786542 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e834096786542 : Closed e834096786542 ∧ code e834096786542 = 9630189808750 := by decide
theorem cert_e834096786542 : check e834096786542 [] .sourceHead = true := by decide
def e834096786554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e834096786554 : Closed e834096786554 ∧ code e834096786554 = 9630189808762 := by decide
theorem cert_e834096786554 : check e834096786554 [] .sourceHead = true := by decide
def e834096786718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e834096786718 : Closed e834096786718 ∧ code e834096786718 = 9630189808926 := by decide
theorem cert_e834096786718 : check e834096786718 [] .sourceHead = true := by decide
def e834096786886 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e834096786886 : Closed e834096786886 ∧ code e834096786886 = 9630189809094 := by decide
theorem cert_e834096786886 : check e834096786886 [] .sourceHead = true := by decide
def e834096786998 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e834096786998 : Closed e834096786998 ∧ code e834096786998 = 9630189809206 := by decide
theorem cert_e834096786998 : check e834096786998 [] .sourceHead = true := by decide
def e834096787002 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e834096787002 : Closed e834096787002 ∧ code e834096787002 = 9630189809210 := by decide
theorem cert_e834096787002 : check e834096787002 [] .sourceHead = true := by decide
def e834096787050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e834096787050 : Closed e834096787050 ∧ code e834096787050 = 9630189809258 := by decide
theorem cert_e834096787050 : check e834096787050 [] .sourceHead = true := by decide
def e834096787086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e834096787086 : Closed e834096787086 ∧ code e834096787086 = 9630189809294 := by decide
theorem cert_e834096787086 : check e834096787086 [] .sourceHead = true := by decide
def e834096787098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096787098 : Closed e834096787098 ∧ code e834096787098 = 9630189809306 := by decide
theorem cert_e834096787098 : check e834096787098 [] .sourceHead = true := by decide
def e834096787142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e834096787142 : Closed e834096787142 ∧ code e834096787142 = 9630189809350 := by decide
theorem cert_e834096787142 : check e834096787142 [] .sourceHead = true := by decide
def e834096787894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e834096787894 : Closed e834096787894 ∧ code e834096787894 = 9630189810102 := by decide
theorem cert_e834096787894 : check e834096787894 [] .sourceHead = true := by decide
def e834096787926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e834096787926 : Closed e834096787926 ∧ code e834096787926 = 9630189810134 := by decide
theorem cert_e834096787926 : check e834096787926 [] .sourceHead = true := by decide
def e834096787930 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e834096787930 : Closed e834096787930 ∧ code e834096787930 = 9630189810138 := by decide
theorem cert_e834096787930 : check e834096787930 [] .sourceHead = true := by decide
def e834096788310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e834096788310 : Closed e834096788310 ∧ code e834096788310 = 9630189810518 := by decide
theorem cert_e834096788310 : check e834096788310 [] .sourceHead = true := by decide
def e834096788314 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e834096788314 : Closed e834096788314 ∧ code e834096788314 = 9630189810522 := by decide
theorem cert_e834096788314 : check e834096788314 [] .sourceHead = true := by decide
def e834096788330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e834096788330 : Closed e834096788330 ∧ code e834096788330 = 9630189810538 := by decide
theorem cert_e834096788330 : check e834096788330 [] .sourceHead = true := by decide
def e834096788394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e834096788394 : Closed e834096788394 ∧ code e834096788394 = 9630189810602 := by decide
theorem cert_e834096788394 : check e834096788394 [] .sourceHead = true := by decide
def e834096788598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e834096788598 : Closed e834096788598 ∧ code e834096788598 = 9630189810806 := by decide
theorem cert_e834096788598 : check e834096788598 [] .sourceHead = true := by decide
def e834096788694 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e834096788694 : Closed e834096788694 ∧ code e834096788694 = 9630189810902 := by decide
theorem cert_e834096788694 : check e834096788694 [] .sourceHead = true := by decide
def e834096788698 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e834096788698 : Closed e834096788698 ∧ code e834096788698 = 9630189810906 := by decide
theorem cert_e834096788698 : check e834096788698 [] .sourceHead = true := by decide
def e834096788714 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e834096788714 : Closed e834096788714 ∧ code e834096788714 = 9630189810922 := by decide
theorem cert_e834096788714 : check e834096788714 [] .sourceHead = true := by decide
def e834096788790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096788790 : Closed e834096788790 ∧ code e834096788790 = 9630189810998 := by decide
theorem cert_e834096788790 : check e834096788790 [] .sourceHead = true := by decide
def e834096788794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096788794 : Closed e834096788794 ∧ code e834096788794 = 9630189811002 := by decide
theorem cert_e834096788794 : check e834096788794 [] .sourceHead = true := by decide
def e834096788878 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e834096788878 : Closed e834096788878 ∧ code e834096788878 = 9630189811086 := by decide
theorem cert_e834096788878 : check e834096788878 [] .sourceHead = true := by decide
def e834096788890 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096788890 : Closed e834096788890 ∧ code e834096788890 = 9630189811098 := by decide
theorem cert_e834096788890 : check e834096788890 [] .sourceHead = true := by decide
def e834096789046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e834096789046 : Closed e834096789046 ∧ code e834096789046 = 9630189811254 := by decide
theorem cert_e834096789046 : check e834096789046 [] .sourceHead = true := by decide
def e834096789050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e834096789050 : Closed e834096789050 ∧ code e834096789050 = 9630189811258 := by decide
theorem cert_e834096789050 : check e834096789050 [] .sourceHead = true := by decide
def e834096789098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e834096789098 : Closed e834096789098 ∧ code e834096789098 = 9630189811306 := by decide
theorem cert_e834096789098 : check e834096789098 [] .sourceHead = true := by decide
def e834096789134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e834096789134 : Closed e834096789134 ∧ code e834096789134 = 9630189811342 := by decide
theorem cert_e834096789134 : check e834096789134 [] .sourceHead = true := by decide
def e834096789146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096789146 : Closed e834096789146 ∧ code e834096789146 = 9630189811354 := by decide
theorem cert_e834096789146 : check e834096789146 [] .sourceHead = true := by decide
def e834096789190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e834096789190 : Closed e834096789190 ∧ code e834096789190 = 9630189811398 := by decide
theorem cert_e834096789190 : check e834096789190 [] .sourceHead = true := by decide
def e834096795374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e834096795374 : Closed e834096795374 ∧ code e834096795374 = 9630189817582 := by decide
theorem cert_e834096795374 : check e834096795374 [] .sourceHead = true := by decide
def e834096795382 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e834096795382 : Closed e834096795382 ∧ code e834096795382 = 9630189817590 := by decide
theorem cert_e834096795382 : check e834096795382 [] .sourceHead = true := by decide
def e834096795502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e834096795502 : Closed e834096795502 ∧ code e834096795502 = 9630189817710 := by decide
theorem cert_e834096795502 : check e834096795502 [] .sourceHead = true := by decide
def e834096795514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e834096795514 : Closed e834096795514 ∧ code e834096795514 = 9630189817722 := by decide
theorem cert_e834096795514 : check e834096795514 [] .sourceHead = true := by decide
def e834096795574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e834096795574 : Closed e834096795574 ∧ code e834096795574 = 9630189817782 := by decide
theorem cert_e834096795574 : check e834096795574 [] .sourceHead = true := by decide
def e834096795578 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e834096795578 : Closed e834096795578 ∧ code e834096795578 = 9630189817786 := by decide
theorem cert_e834096795578 : check e834096795578 [] .sourceHead = true := by decide
def e834096798958 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e834096798958 : Closed e834096798958 ∧ code e834096798958 = 9630189821166 := by decide
theorem cert_e834096798958 : check e834096798958 [] .sourceHead = true := by decide
def e834096798966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e834096798966 : Closed e834096798966 ∧ code e834096798966 = 9630189821174 := by decide
theorem cert_e834096798966 : check e834096798966 [] .sourceHead = true := by decide
def e834096799350 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e834096799350 : Closed e834096799350 ∧ code e834096799350 = 9630189821558 := by decide
theorem cert_e834096799350 : check e834096799350 [] .sourceHead = true := by decide
def e834096803182 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e834096803182 : Closed e834096803182 ∧ code e834096803182 = 9630189825390 := by decide
theorem cert_e834096803182 : check e834096803182 [] .sourceHead = true := by decide
def e834096803190 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e834096803190 : Closed e834096803190 ∧ code e834096803190 = 9630189825398 := by decide
theorem cert_e834096803190 : check e834096803190 [] .sourceHead = true := by decide
def e834096803246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e834096803246 : Closed e834096803246 ∧ code e834096803246 = 9630189825454 := by decide
theorem cert_e834096803246 : check e834096803246 [] .sourceHead = true := by decide
def e834096803258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e834096803258 : Closed e834096803258 ∧ code e834096803258 = 9630189825466 := by decide
theorem cert_e834096803258 : check e834096803258 [] .sourceHead = true := by decide
def e834096803286 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e834096803286 : Closed e834096803286 ∧ code e834096803286 = 9630189825494 := by decide
theorem cert_e834096803286 : check e834096803286 [] .sourceHead = true := by decide
def e834096803290 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e834096803290 : Closed e834096803290 ∧ code e834096803290 = 9630189825498 := by decide
theorem cert_e834096803290 : check e834096803290 [] .sourceHead = true := by decide
def e834096803502 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e834096803502 : Closed e834096803502 ∧ code e834096803502 = 9630189825710 := by decide
theorem cert_e834096803502 : check e834096803502 [] .sourceHead = true := by decide
def e834096803514 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e834096803514 : Closed e834096803514 ∧ code e834096803514 = 9630189825722 := by decide
theorem cert_e834096803514 : check e834096803514 [] .sourceHead = true := by decide
def e834096803562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e834096803562 : Closed e834096803562 ∧ code e834096803562 = 9630189825770 := by decide
theorem cert_e834096803562 : check e834096803562 [] .sourceHead = true := by decide
def e834096803670 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e834096803670 : Closed e834096803670 ∧ code e834096803670 = 9630189825878 := by decide
theorem cert_e834096803670 : check e834096803670 [] .sourceHead = true := by decide
def e834096803674 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e834096803674 : Closed e834096803674 ∧ code e834096803674 = 9630189825882 := by decide
theorem cert_e834096803674 : check e834096803674 [] .sourceHead = true := by decide
def e834096803690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e834096803690 : Closed e834096803690 ∧ code e834096803690 = 9630189825898 := by decide
theorem cert_e834096803690 : check e834096803690 [] .sourceHead = true := by decide
def e834096804718 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e834096804718 : Closed e834096804718 ∧ code e834096804718 = 9630189826926 := by decide
theorem cert_e834096804718 : check e834096804718 [] .sourceHead = true := by decide
def e834096804726 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e834096804726 : Closed e834096804726 ∧ code e834096804726 = 9630189826934 := by decide
theorem cert_e834096804726 : check e834096804726 [] .sourceHead = true := by decide
def e834096804782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e834096804782 : Closed e834096804782 ∧ code e834096804782 = 9630189826990 := by decide
theorem cert_e834096804782 : check e834096804782 [] .sourceHead = true := by decide
def e834096804794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e834096804794 : Closed e834096804794 ∧ code e834096804794 = 9630189827002 := by decide
theorem cert_e834096804794 : check e834096804794 [] .sourceHead = true := by decide
def e834096804822 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e834096804822 : Closed e834096804822 ∧ code e834096804822 = 9630189827030 := by decide
theorem cert_e834096804822 : check e834096804822 [] .sourceHead = true := by decide
def e834096804826 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e834096804826 : Closed e834096804826 ∧ code e834096804826 = 9630189827034 := by decide
theorem cert_e834096804826 : check e834096804826 [] .sourceHead = true := by decide
def e834096805102 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e834096805102 : Closed e834096805102 ∧ code e834096805102 = 9630189827310 := by decide
theorem cert_e834096805102 : check e834096805102 [] .sourceHead = true := by decide
def e834096805110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e834096805110 : Closed e834096805110 ∧ code e834096805110 = 9630189827318 := by decide
theorem cert_e834096805110 : check e834096805110 [] .sourceHead = true := by decide
def e834096805486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096805486 : Closed e834096805486 ∧ code e834096805486 = 9630189827694 := by decide
theorem cert_e834096805486 : check e834096805486 [] .sourceHead = true := by decide
def e834096805498 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096805498 : Closed e834096805498 ∧ code e834096805498 = 9630189827706 := by decide
theorem cert_e834096805498 : check e834096805498 [] .sourceHead = true := by decide
def e834096805686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096805686 : Closed e834096805686 ∧ code e834096805686 = 9630189827894 := by decide
theorem cert_e834096805686 : check e834096805686 [] .sourceHead = true := by decide
def e834096805690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096805690 : Closed e834096805690 ∧ code e834096805690 = 9630189827898 := by decide
theorem cert_e834096805690 : check e834096805690 [] .sourceHead = true := by decide
def e834096806126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e834096806126 : Closed e834096806126 ∧ code e834096806126 = 9630189828334 := by decide
theorem cert_e834096806126 : check e834096806126 [] .sourceHead = true := by decide
def e834096806134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e834096806134 : Closed e834096806134 ∧ code e834096806134 = 9630189828342 := by decide
theorem cert_e834096806134 : check e834096806134 [] .sourceHead = true := by decide
def e834096806318 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e834096806318 : Closed e834096806318 ∧ code e834096806318 = 9630189828526 := by decide
theorem cert_e834096806318 : check e834096806318 [] .sourceHead = true := by decide
def e834096806330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e834096806330 : Closed e834096806330 ∧ code e834096806330 = 9630189828538 := by decide
theorem cert_e834096806330 : check e834096806330 [] .sourceHead = true := by decide
def e834096806378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e834096806378 : Closed e834096806378 ∧ code e834096806378 = 9630189828586 := by decide
theorem cert_e834096806378 : check e834096806378 [] .sourceHead = true := by decide
def e834096806510 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096806510 : Closed e834096806510 ∧ code e834096806510 = 9630189828718 := by decide
theorem cert_e834096806510 : check e834096806510 [] .sourceHead = true := by decide
def e834096806522 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096806522 : Closed e834096806522 ∧ code e834096806522 = 9630189828730 := by decide
theorem cert_e834096806522 : check e834096806522 [] .sourceHead = true := by decide
def e834096806686 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e834096806686 : Closed e834096806686 ∧ code e834096806686 = 9630189828894 := by decide
theorem cert_e834096806686 : check e834096806686 [] .sourceHead = true := by decide
def e834096806798 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e834096806798 : Closed e834096806798 ∧ code e834096806798 = 9630189829006 := by decide
theorem cert_e834096806798 : check e834096806798 [] .sourceHead = true := by decide
def e834096806810 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096806810 : Closed e834096806810 ∧ code e834096806810 = 9630189829018 := by decide
theorem cert_e834096806810 : check e834096806810 [] .sourceHead = true := by decide
def e834096807030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e834096807030 : Closed e834096807030 ∧ code e834096807030 = 9630189829238 := by decide
theorem cert_e834096807030 : check e834096807030 [] .sourceHead = true := by decide
def e834096807126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e834096807126 : Closed e834096807126 ∧ code e834096807126 = 9630189829334 := by decide
theorem cert_e834096807126 : check e834096807126 [] .sourceHead = true := by decide
def e834096807130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e834096807130 : Closed e834096807130 ∧ code e834096807130 = 9630189829338 := by decide
theorem cert_e834096807130 : check e834096807130 [] .sourceHead = true := by decide
def e834096807146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e834096807146 : Closed e834096807146 ∧ code e834096807146 = 9630189829354 := by decide
theorem cert_e834096807146 : check e834096807146 [] .sourceHead = true := by decide
def e834096807222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096807222 : Closed e834096807222 ∧ code e834096807222 = 9630189829430 := by decide
theorem cert_e834096807222 : check e834096807222 [] .sourceHead = true := by decide
def e834096807226 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096807226 : Closed e834096807226 ∧ code e834096807226 = 9630189829434 := by decide
theorem cert_e834096807226 : check e834096807226 [] .sourceHead = true := by decide
def e834096807310 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e834096807310 : Closed e834096807310 ∧ code e834096807310 = 9630189829518 := by decide
theorem cert_e834096807310 : check e834096807310 [] .sourceHead = true := by decide
end Blc.Floor43
