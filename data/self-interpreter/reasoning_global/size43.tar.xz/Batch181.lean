import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262386788126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2262386788126 : Closed e2262386788126 ∧ code e2262386788126 = 11058479810334 := by decide
theorem cert_e2262386788126 : check e2262386788126 [[],[.under]] .chain = true := by decide
def e2262386788238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2262386788238 : Closed e2262386788238 ∧ code e2262386788238 = 11058479810446 := by decide
theorem cert_e2262386788238 : check e2262386788238 [[],[.under]] .chain = true := by decide
def e2262386789934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262386789934 : Closed e2262386789934 ∧ code e2262386789934 = 11058479812142 := by decide
theorem cert_e2262386789934 : check e2262386789934 [[],[.under]] .chain = true := by decide
def e2262386790114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262386790114 : Closed e2262386790114 ∧ code e2262386790114 = 11058479812322 := by decide
theorem cert_e2262386790114 : check e2262386790114 [[],[.under]] .chain = true := by decide
def e2262386790126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2262386790126 : Closed e2262386790126 ∧ code e2262386790126 = 11058479812334 := by decide
theorem cert_e2262386790126 : check e2262386790126 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386790166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262386790166 : Closed e2262386790166 ∧ code e2262386790166 = 11058479812374 := by decide
theorem cert_e2262386790166 : check e2262386790166 [[],[.under]] .chain = true := by decide
def e2262386790242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262386790242 : Closed e2262386790242 ∧ code e2262386790242 = 11058479812450 := by decide
theorem cert_e2262386790242 : check e2262386790242 [[],[.under]] .chain = true := by decide
def e2262386790254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2262386790254 : Closed e2262386790254 ∧ code e2262386790254 = 11058479812462 := by decide
theorem cert_e2262386790254 : check e2262386790254 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386790262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2262386790262 : Closed e2262386790262 ∧ code e2262386790262 = 11058479812470 := by decide
theorem cert_e2262386790262 : check e2262386790262 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262386792510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262386792510 : Closed e2262386792510 ∧ code e2262386792510 = 11058479814718 := by decide
theorem cert_e2262386792510 : check e2262386792510 [[],[.under]] .chain = true := by decide
def e2262386792930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262386792930 : Closed e2262386792930 ∧ code e2262386792930 = 11058479815138 := by decide
theorem cert_e2262386792930 : check e2262386792930 [[],[.under]] .chain = true := by decide
def e2262386792942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262386792942 : Closed e2262386792942 ∧ code e2262386792942 = 11058479815150 := by decide
theorem cert_e2262386792942 : check e2262386792942 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386793502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262386793502 : Closed e2262386793502 ∧ code e2262386793502 = 11058479815710 := by decide
theorem cert_e2262386793502 : check e2262386793502 [[],[.under]] .chain = true := by decide
def e2262386793698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262386793698 : Closed e2262386793698 ∧ code e2262386793698 = 11058479815906 := by decide
theorem cert_e2262386793698 : check e2262386793698 [[],[.under]] .chain = true := by decide
def e2262386793710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262386793710 : Closed e2262386793710 ∧ code e2262386793710 = 11058479815918 := by decide
theorem cert_e2262386793710 : check e2262386793710 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386793718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262386793718 : Closed e2262386793718 ∧ code e2262386793718 = 11058479815926 := by decide
theorem cert_e2262386793718 : check e2262386793718 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386794734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262386794734 : Closed e2262386794734 ∧ code e2262386794734 = 11058479816942 := by decide
theorem cert_e2262386794734 : check e2262386794734 [[],[.under]] .chain = true := by decide
def e2262386794746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262386794746 : Closed e2262386794746 ∧ code e2262386794746 = 11058479816954 := by decide
theorem cert_e2262386794746 : check e2262386794746 [[],[.under]] .chain = true := by decide
def e2262386795118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262386795118 : Closed e2262386795118 ∧ code e2262386795118 = 11058479817326 := by decide
theorem cert_e2262386795118 : check e2262386795118 [[],[.under]] .chain = true := by decide
def e2262386795130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262386795130 : Closed e2262386795130 ∧ code e2262386795130 = 11058479817338 := by decide
theorem cert_e2262386795130 : check e2262386795130 [[],[.under]] .chain = true := by decide
def e2262386795294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262386795294 : Closed e2262386795294 ∧ code e2262386795294 = 11058479817502 := by decide
theorem cert_e2262386795294 : check e2262386795294 [[],[.under]] .chain = true := by decide
def e2262386795462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262386795462 : Closed e2262386795462 ∧ code e2262386795462 = 11058479817670 := by decide
theorem cert_e2262386795462 : check e2262386795462 [[],[.under]] .chain = true := by decide
def e2262386796078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262386796078 : Closed e2262386796078 ∧ code e2262386796078 = 11058479818286 := by decide
theorem cert_e2262386796078 : check e2262386796078 [[],[.under]] .chain = true := by decide
def e2262386796258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262386796258 : Closed e2262386796258 ∧ code e2262386796258 = 11058479818466 := by decide
theorem cert_e2262386796258 : check e2262386796258 [[],[.under]] .chain = true := by decide
def e2262386796270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2262386796270 : Closed e2262386796270 ∧ code e2262386796270 = 11058479818478 := by decide
theorem cert_e2262386796270 : check e2262386796270 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2262386796426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262386796426 : Closed e2262386796426 ∧ code e2262386796426 = 11058479818634 := by decide
theorem cert_e2262386796426 : check e2262386796426 [[],[.under]] .chain = true := by decide
def e2262386796450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262386796450 : Closed e2262386796450 ∧ code e2262386796450 = 11058479818658 := by decide
theorem cert_e2262386796450 : check e2262386796450 [[],[.under]] .chain = true := by decide
def e2262386796462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2262386796462 : Closed e2262386796462 ∧ code e2262386796462 = 11058479818670 := by decide
theorem cert_e2262386796462 : check e2262386796462 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2262386796474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2262386796474 : Closed e2262386796474 ∧ code e2262386796474 = 11058479818682 := by decide
theorem cert_e2262386796474 : check e2262386796474 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262386796606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262386796606 : Closed e2262386796606 ∧ code e2262386796606 = 11058479818814 := by decide
theorem cert_e2262386796606 : check e2262386796606 [[],[.under]] .chain = true := by decide
def e2262386797026 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262386797026 : Closed e2262386797026 ∧ code e2262386797026 = 11058479819234 := by decide
theorem cert_e2262386797026 : check e2262386797026 [[],[.under]] .chain = true := by decide
def e2262386797038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262386797038 : Closed e2262386797038 ∧ code e2262386797038 = 11058479819246 := by decide
theorem cert_e2262386797038 : check e2262386797038 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2262386798094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262386798094 : Closed e2262386798094 ∧ code e2262386798094 = 11058479820302 := by decide
theorem cert_e2262386798094 : check e2262386798094 [[],[.under]] .chain = true := by decide
def e2262386798178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262386798178 : Closed e2262386798178 ∧ code e2262386798178 = 11058479820386 := by decide
theorem cert_e2262386798178 : check e2262386798178 [[],[.under]] .chain = true := by decide
def e2262386798190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262386798190 : Closed e2262386798190 ∧ code e2262386798190 = 11058479820398 := by decide
theorem cert_e2262386798190 : check e2262386798190 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386798202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262386798202 : Closed e2262386798202 ∧ code e2262386798202 = 11058479820410 := by decide
theorem cert_e2262386798202 : check e2262386798202 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386798710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262386798710 : Closed e2262386798710 ∧ code e2262386798710 = 11058479820918 := by decide
theorem cert_e2262386798710 : check e2262386798710 [[],[.under]] .chain = true := by decide
def e2262386798714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2262386798714 : Closed e2262386798714 ∧ code e2262386798714 = 11058479820922 := by decide
theorem cert_e2262386798714 : check e2262386798714 [[],[.under]] .chain = true := by decide
def e2262386798902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262386798902 : Closed e2262386798902 ∧ code e2262386798902 = 11058479821110 := by decide
theorem cert_e2262386798902 : check e2262386798902 [[],[.under]] .chain = true := by decide
def e2262386798906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262386798906 : Closed e2262386798906 ∧ code e2262386798906 = 11058479821114 := by decide
theorem cert_e2262386798906 : check e2262386798906 [[],[.under]] .chain = true := by decide
def e2262386798990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262386798990 : Closed e2262386798990 ∧ code e2262386798990 = 11058479821198 := by decide
theorem cert_e2262386798990 : check e2262386798990 [[],[.under]] .chain = true := by decide
def e2262386799046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2262386799046 : Closed e2262386799046 ∧ code e2262386799046 = 11058479821254 := by decide
theorem cert_e2262386799046 : check e2262386799046 [[],[.under]] .chain = true := by decide
def e2262386799382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262386799382 : Closed e2262386799382 ∧ code e2262386799382 = 11058479821590 := by decide
theorem cert_e2262386799382 : check e2262386799382 [[],[.under]] .chain = true := by decide
def e2262386799458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262386799458 : Closed e2262386799458 ∧ code e2262386799458 = 11058479821666 := by decide
theorem cert_e2262386799458 : check e2262386799458 [[],[.under]] .chain = true := by decide
def e2262386799470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262386799470 : Closed e2262386799470 ∧ code e2262386799470 = 11058479821678 := by decide
theorem cert_e2262386799470 : check e2262386799470 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386799478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262386799478 : Closed e2262386799478 ∧ code e2262386799478 = 11058479821686 := by decide
theorem cert_e2262386799478 : check e2262386799478 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386799498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262386799498 : Closed e2262386799498 ∧ code e2262386799498 = 11058479821706 := by decide
theorem cert_e2262386799498 : check e2262386799498 [[],[.under]] .chain = true := by decide
def e2262386799522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262386799522 : Closed e2262386799522 ∧ code e2262386799522 = 11058479821730 := by decide
theorem cert_e2262386799522 : check e2262386799522 [[],[.under]] .chain = true := by decide
def e2262386799534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262386799534 : Closed e2262386799534 ∧ code e2262386799534 = 11058479821742 := by decide
def e2262386799546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262386799546 : Closed e2262386799546 ∧ code e2262386799546 = 11058479821754 := by decide
theorem cert_e2262386799546 : check e2262386799546 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386799574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262386799574 : Closed e2262386799574 ∧ code e2262386799574 = 11058479821782 := by decide
theorem cert_e2262386799574 : check e2262386799574 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386799578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262386799578 : Closed e2262386799578 ∧ code e2262386799578 = 11058479821786 := by decide
theorem cert_e2262386799578 : check e2262386799578 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386799646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262386799646 : Closed e2262386799646 ∧ code e2262386799646 = 11058479821854 := by decide
theorem cert_e2262386799646 : check e2262386799646 [[],[.under]] .chain = true := by decide
def e2262386799842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262386799842 : Closed e2262386799842 ∧ code e2262386799842 = 11058479822050 := by decide
theorem cert_e2262386799842 : check e2262386799842 [[],[.under]] .chain = true := by decide
def e2262386799854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262386799854 : Closed e2262386799854 ∧ code e2262386799854 = 11058479822062 := by decide
theorem cert_e2262386799854 : check e2262386799854 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262386799862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262386799862 : Closed e2262386799862 ∧ code e2262386799862 = 11058479822070 := by decide
theorem cert_e2262386799862 : check e2262386799862 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386800142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262386800142 : Closed e2262386800142 ∧ code e2262386800142 = 11058479822350 := by decide
theorem cert_e2262386800142 : check e2262386800142 [[],[.under]] .chain = true := by decide
def e2262386800226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262386800226 : Closed e2262386800226 ∧ code e2262386800226 = 11058479822434 := by decide
theorem cert_e2262386800226 : check e2262386800226 [[],[.under]] .chain = true := by decide
def e2262386800238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262386800238 : Closed e2262386800238 ∧ code e2262386800238 = 11058479822446 := by decide
theorem cert_e2262386800238 : check e2262386800238 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386800250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262386800250 : Closed e2262386800250 ∧ code e2262386800250 = 11058479822458 := by decide
theorem cert_e2262386800250 : check e2262386800250 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386800438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262386800438 : Closed e2262386800438 ∧ code e2262386800438 = 11058479822646 := by decide
theorem cert_e2262386800438 : check e2262386800438 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386800442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262386800442 : Closed e2262386800442 ∧ code e2262386800442 = 11058479822650 := by decide
theorem cert_e2262386800442 : check e2262386800442 [[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386805614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262386805614 : Closed e2262386805614 ∧ code e2262386805614 = 11058479827822 := by decide
theorem cert_e2262386805614 : check e2262386805614 [[],[.under]] .smaller = true := by decide
def e2262386805622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262386805622 : Closed e2262386805622 ∧ code e2262386805622 = 11058479827830 := by decide
theorem cert_e2262386805622 : check e2262386805622 [[],[.under]] .smaller = true := by decide
def e2262386805678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262386805678 : Closed e2262386805678 ∧ code e2262386805678 = 11058479827886 := by decide
theorem cert_e2262386805678 : check e2262386805678 [[],[.under]] .smaller = true := by decide
def e2262386805690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262386805690 : Closed e2262386805690 ∧ code e2262386805690 = 11058479827898 := by decide
theorem cert_e2262386805690 : check e2262386805690 [[],[.under]] .smaller = true := by decide
def e2262386805718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262386805718 : Closed e2262386805718 ∧ code e2262386805718 = 11058479827926 := by decide
theorem cert_e2262386805718 : check e2262386805718 [[],[.under]] .smaller = true := by decide
def e2262386805722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262386805722 : Closed e2262386805722 ∧ code e2262386805722 = 11058479827930 := by decide
theorem cert_e2262386805722 : check e2262386805722 [[],[.under]] .smaller = true := by decide
def e2262386805998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262386805998 : Closed e2262386805998 ∧ code e2262386805998 = 11058479828206 := by decide
theorem cert_e2262386805998 : check e2262386805998 [[],[.under]] .smaller = true := by decide
def e2262386806006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262386806006 : Closed e2262386806006 ∧ code e2262386806006 = 11058479828214 := by decide
theorem cert_e2262386806006 : check e2262386806006 [[],[.under]] .smaller = true := by decide
def e2262386806382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262386806382 : Closed e2262386806382 ∧ code e2262386806382 = 11058479828590 := by decide
theorem cert_e2262386806382 : check e2262386806382 [[],[.under]] .smaller = true := by decide
def e2262386806394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262386806394 : Closed e2262386806394 ∧ code e2262386806394 = 11058479828602 := by decide
theorem cert_e2262386806394 : check e2262386806394 [[],[.under]] .smaller = true := by decide
def e2262386806582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262386806582 : Closed e2262386806582 ∧ code e2262386806582 = 11058479828790 := by decide
theorem cert_e2262386806582 : check e2262386806582 [[],[.under]] .smaller = true := by decide
def e2262386806586 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262386806586 : Closed e2262386806586 ∧ code e2262386806586 = 11058479828794 := by decide
theorem cert_e2262386806586 : check e2262386806586 [[],[.under]] .smaller = true := by decide
def e2262386814510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262386814510 : Closed e2262386814510 ∧ code e2262386814510 = 11058479836718 := by decide
theorem cert_e2262386814510 : check e2262386814510 [[],[.under]] .chain = true := by decide
def e2262386814690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262386814690 : Closed e2262386814690 ∧ code e2262386814690 = 11058479836898 := by decide
theorem cert_e2262386814690 : check e2262386814690 [[],[.under]] .chain = true := by decide
def e2262386814702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2262386814702 : Closed e2262386814702 ∧ code e2262386814702 = 11058479836910 := by decide
theorem cert_e2262386814702 : check e2262386814702 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386814742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262386814742 : Closed e2262386814742 ∧ code e2262386814742 = 11058479836950 := by decide
theorem cert_e2262386814742 : check e2262386814742 [[],[.under]] .chain = true := by decide
def e2262386814818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262386814818 : Closed e2262386814818 ∧ code e2262386814818 = 11058479837026 := by decide
theorem cert_e2262386814818 : check e2262386814818 [[],[.under]] .chain = true := by decide
def e2262386814830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2262386814830 : Closed e2262386814830 ∧ code e2262386814830 = 11058479837038 := by decide
theorem cert_e2262386814830 : check e2262386814830 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[.left],[],[]] .identityHead = true := by decide
def e2262386814838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2262386814838 : Closed e2262386814838 ∧ code e2262386814838 = 11058479837046 := by decide
def e2262386817086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2262386817086 : Closed e2262386817086 ∧ code e2262386817086 = 11058479839294 := by decide
theorem cert_e2262386817086 : check e2262386817086 [[],[.under]] .chain = true := by decide
def e2262386817506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262386817506 : Closed e2262386817506 ∧ code e2262386817506 = 11058479839714 := by decide
theorem cert_e2262386817506 : check e2262386817506 [[],[.under]] .chain = true := by decide
def e2262386817518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262386817518 : Closed e2262386817518 ∧ code e2262386817518 = 11058479839726 := by decide
theorem cert_e2262386817518 : check e2262386817518 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2262386818078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2262386818078 : Closed e2262386818078 ∧ code e2262386818078 = 11058479840286 := by decide
theorem cert_e2262386818078 : check e2262386818078 [[],[.under]] .chain = true := by decide
def e2262386818274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262386818274 : Closed e2262386818274 ∧ code e2262386818274 = 11058479840482 := by decide
theorem cert_e2262386818274 : check e2262386818274 [[],[.under]] .chain = true := by decide
def e2262386818286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262386818286 : Closed e2262386818286 ∧ code e2262386818286 = 11058479840494 := by decide
theorem cert_e2262386818286 : check e2262386818286 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e2262386818294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262386818294 : Closed e2262386818294 ∧ code e2262386818294 = 11058479840502 := by decide
theorem cert_e2262386818294 : check e2262386818294 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[]] .identityHead = true := by decide
def e2262386841134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262386841134 : Closed e2262386841134 ∧ code e2262386841134 = 11058479863342 := by decide
theorem cert_e2262386841134 : check e2262386841134 [[],[.under]] .chain = true := by decide
def e2262386841314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262386841314 : Closed e2262386841314 ∧ code e2262386841314 = 11058479863522 := by decide
theorem cert_e2262386841314 : check e2262386841314 [[],[.under]] .chain = true := by decide
def e2262386841326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2262386841326 : Closed e2262386841326 ∧ code e2262386841326 = 11058479863534 := by decide
theorem cert_e2262386841326 : check e2262386841326 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386841482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262386841482 : Closed e2262386841482 ∧ code e2262386841482 = 11058479863690 := by decide
theorem cert_e2262386841482 : check e2262386841482 [[],[.under]] .chain = true := by decide
def e2262386841506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262386841506 : Closed e2262386841506 ∧ code e2262386841506 = 11058479863714 := by decide
theorem cert_e2262386841506 : check e2262386841506 [[],[.under]] .chain = true := by decide
def e2262386841518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2262386841518 : Closed e2262386841518 ∧ code e2262386841518 = 11058479863726 := by decide
theorem cert_e2262386841518 : check e2262386841518 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under,.left],[.under],[.under],[.under]] .identityHead = true := by decide
def e2262386841530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2262386841530 : Closed e2262386841530 ∧ code e2262386841530 = 11058479863738 := by decide
theorem cert_e2262386841530 : check e2262386841530 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386841662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2262386841662 : Closed e2262386841662 ∧ code e2262386841662 = 11058479863870 := by decide
theorem cert_e2262386841662 : check e2262386841662 [[],[.under]] .chain = true := by decide
def e2262386842082 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262386842082 : Closed e2262386842082 ∧ code e2262386842082 = 11058479864290 := by decide
theorem cert_e2262386842082 : check e2262386842082 [[],[.under]] .chain = true := by decide
def e2262386842094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262386842094 : Closed e2262386842094 ∧ code e2262386842094 = 11058479864302 := by decide
theorem cert_e2262386842094 : check e2262386842094 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386843150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2262386843150 : Closed e2262386843150 ∧ code e2262386843150 = 11058479865358 := by decide
theorem cert_e2262386843150 : check e2262386843150 [[],[.under]] .chain = true := by decide
def e2262386843234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262386843234 : Closed e2262386843234 ∧ code e2262386843234 = 11058479865442 := by decide
theorem cert_e2262386843234 : check e2262386843234 [[],[.under]] .chain = true := by decide
def e2262386843246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262386843246 : Closed e2262386843246 ∧ code e2262386843246 = 11058479865454 := by decide
theorem cert_e2262386843246 : check e2262386843246 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386843258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262386843258 : Closed e2262386843258 ∧ code e2262386843258 = 11058479865466 := by decide
theorem cert_e2262386843258 : check e2262386843258 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2262386854678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262386854678 : Closed e2262386854678 ∧ code e2262386854678 = 11058479876886 := by decide
theorem cert_e2262386854678 : check e2262386854678 [[],[.under]] .chain = true := by decide
def e2262386854754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262386854754 : Closed e2262386854754 ∧ code e2262386854754 = 11058479876962 := by decide
theorem cert_e2262386854754 : check e2262386854754 [[],[.under]] .chain = true := by decide
def e2262386854766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262386854766 : Closed e2262386854766 ∧ code e2262386854766 = 11058479876974 := by decide
theorem cert_e2262386854766 : check e2262386854766 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386854774 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262386854774 : Closed e2262386854774 ∧ code e2262386854774 = 11058479876982 := by decide
theorem cert_e2262386854774 : check e2262386854774 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386854794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262386854794 : Closed e2262386854794 ∧ code e2262386854794 = 11058479877002 := by decide
theorem cert_e2262386854794 : check e2262386854794 [[],[.under]] .chain = true := by decide
def e2262386854818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262386854818 : Closed e2262386854818 ∧ code e2262386854818 = 11058479877026 := by decide
theorem cert_e2262386854818 : check e2262386854818 [[],[.under]] .chain = true := by decide
def e2262386854830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262386854830 : Closed e2262386854830 ∧ code e2262386854830 = 11058479877038 := by decide
theorem cert_e2262386854830 : check e2262386854830 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386854842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262386854842 : Closed e2262386854842 ∧ code e2262386854842 = 11058479877050 := by decide
theorem cert_e2262386854842 : check e2262386854842 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386854870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262386854870 : Closed e2262386854870 ∧ code e2262386854870 = 11058479877078 := by decide
theorem cert_e2262386854870 : check e2262386854870 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386854874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262386854874 : Closed e2262386854874 ∧ code e2262386854874 = 11058479877082 := by decide
theorem cert_e2262386854874 : check e2262386854874 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2262386854942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2262386854942 : Closed e2262386854942 ∧ code e2262386854942 = 11058479877150 := by decide
theorem cert_e2262386854942 : check e2262386854942 [[],[.under]] .chain = true := by decide
def e2262386855138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262386855138 : Closed e2262386855138 ∧ code e2262386855138 = 11058479877346 := by decide
theorem cert_e2262386855138 : check e2262386855138 [[],[.under]] .chain = true := by decide
def e2262386855150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262386855150 : Closed e2262386855150 ∧ code e2262386855150 = 11058479877358 := by decide
theorem cert_e2262386855150 : check e2262386855150 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2262386855158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262386855158 : Closed e2262386855158 ∧ code e2262386855158 = 11058479877366 := by decide
theorem cert_e2262386855158 : check e2262386855158 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262386855438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2262386855438 : Closed e2262386855438 ∧ code e2262386855438 = 11058479877646 := by decide
theorem cert_e2262386855438 : check e2262386855438 [[],[.under]] .chain = true := by decide
def e2262386855522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262386855522 : Closed e2262386855522 ∧ code e2262386855522 = 11058479877730 := by decide
theorem cert_e2262386855522 : check e2262386855522 [[],[.under]] .chain = true := by decide
def e2262386855534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262386855534 : Closed e2262386855534 ∧ code e2262386855534 = 11058479877742 := by decide
def e2262386855546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262386855546 : Closed e2262386855546 ∧ code e2262386855546 = 11058479877754 := by decide
theorem cert_e2262386855546 : check e2262386855546 [[.left,.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.under],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .identityHead = true := by decide
def e2262386855734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262386855734 : Closed e2262386855734 ∧ code e2262386855734 = 11058479877942 := by decide
def e2262386855738 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262386855738 : Closed e2262386855738 ∧ code e2262386855738 = 11058479877946 := by decide
def e2262387395438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262387395438 : Closed e2262387395438 ∧ code e2262387395438 = 11058480417646 := by decide
theorem cert_e2262387395438 : check e2262387395438 [[],[.under]] .smaller = true := by decide
def e2262387395446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262387395446 : Closed e2262387395446 ∧ code e2262387395446 = 11058480417654 := by decide
theorem cert_e2262387395446 : check e2262387395446 [[],[.under]] .smaller = true := by decide
def e2262387395502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262387395502 : Closed e2262387395502 ∧ code e2262387395502 = 11058480417710 := by decide
theorem cert_e2262387395502 : check e2262387395502 [[],[.under]] .smaller = true := by decide
def e2262387395514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262387395514 : Closed e2262387395514 ∧ code e2262387395514 = 11058480417722 := by decide
theorem cert_e2262387395514 : check e2262387395514 [[],[.under]] .smaller = true := by decide
def e2262387395542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262387395542 : Closed e2262387395542 ∧ code e2262387395542 = 11058480417750 := by decide
theorem cert_e2262387395542 : check e2262387395542 [[],[.under]] .smaller = true := by decide
def e2262387395546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262387395546 : Closed e2262387395546 ∧ code e2262387395546 = 11058480417754 := by decide
theorem cert_e2262387395546 : check e2262387395546 [[],[.under]] .smaller = true := by decide
def e2262387395822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262387395822 : Closed e2262387395822 ∧ code e2262387395822 = 11058480418030 := by decide
theorem cert_e2262387395822 : check e2262387395822 [[],[.under]] .smaller = true := by decide
def e2262387395830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262387395830 : Closed e2262387395830 ∧ code e2262387395830 = 11058480418038 := by decide
theorem cert_e2262387395830 : check e2262387395830 [[],[.under]] .smaller = true := by decide
def e2262387396206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262387396206 : Closed e2262387396206 ∧ code e2262387396206 = 11058480418414 := by decide
theorem cert_e2262387396206 : check e2262387396206 [[],[.under]] .smaller = true := by decide
def e2262387396218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262387396218 : Closed e2262387396218 ∧ code e2262387396218 = 11058480418426 := by decide
theorem cert_e2262387396218 : check e2262387396218 [[],[.under]] .smaller = true := by decide
def e2262387396406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262387396406 : Closed e2262387396406 ∧ code e2262387396406 = 11058480418614 := by decide
theorem cert_e2262387396406 : check e2262387396406 [[],[.under]] .smaller = true := by decide
def e2262387396410 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262387396410 : Closed e2262387396410 ∧ code e2262387396410 = 11058480418618 := by decide
theorem cert_e2262387396410 : check e2262387396410 [[],[.under]] .smaller = true := by decide
def e2262388727262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2262388727262 : Closed e2262388727262 ∧ code e2262388727262 = 11058481749470 := by decide
theorem cert_e2262388727262 : check e2262388727262 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388727278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2262388727278 : Closed e2262388727278 ∧ code e2262388727278 = 11058481749486 := by decide
private def t_e2262388727278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem cert_e2262388727278 : ¬ IsSelfInterpreter e2262388727278 :=
  wSource (t := t_e2262388727278) (replay_sound (ps := []) (t := e2262388727278) (by decide)) (by decide)
def e2262388727518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2262388727518 : Closed e2262388727518 ∧ code e2262388727518 = 11058481749726 := by decide
theorem cert_e2262388727518 : check e2262388727518 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388727542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2262388727542 : Closed e2262388727542 ∧ code e2262388727542 = 11058481749750 := by decide
theorem cert_e2262388727542 : check e2262388727542 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388727662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2262388727662 : Closed e2262388727662 ∧ code e2262388727662 = 11058481749870 := by decide
private def t_e2262388727662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem cert_e2262388727662 : ¬ IsSelfInterpreter e2262388727662 :=
  wSource (t := t_e2262388727662) (replay_sound (ps := []) (t := e2262388727662) (by decide)) (by decide)
def e2262388727670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2262388727670 : Closed e2262388727670 ∧ code e2262388727670 = 11058481749878 := by decide
theorem cert_e2262388727670 : check e2262388727670 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388732894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262388732894 : Closed e2262388732894 ∧ code e2262388732894 = 11058481755102 := by decide
theorem cert_e2262388732894 : check e2262388732894 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388732910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262388732910 : Closed e2262388732910 ∧ code e2262388732910 = 11058481755118 := by decide
theorem cert_e2262388732910 : check e2262388732910 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388734430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262388734430 : Closed e2262388734430 ∧ code e2262388734430 = 11058481756638 := by decide
theorem cert_e2262388734430 : check e2262388734430 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388734454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262388734454 : Closed e2262388734454 ∧ code e2262388734454 = 11058481756662 := by decide
theorem cert_e2262388734454 : check e2262388734454 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388735214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262388735214 : Closed e2262388735214 ∧ code e2262388735214 = 11058481757422 := by decide
theorem cert_e2262388735214 : check e2262388735214 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388735222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262388735222 : Closed e2262388735222 ∧ code e2262388735222 = 11058481757430 := by decide
theorem cert_e2262388735222 : check e2262388735222 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2262388792174 : Closed e2262388792174 ∧ code e2262388792174 = 11058481814382 := by decide
theorem cert_e2262388792174 : check e2262388792174 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2262388792182 : Closed e2262388792182 ∧ code e2262388792182 = 11058481814390 := by decide
theorem cert_e2262388792182 : check e2262388792182 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2262388792246 : Closed e2262388792246 ∧ code e2262388792246 = 11058481814454 := by decide
private def t_e2262388792246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem cert_e2262388792246 : ¬ IsSelfInterpreter e2262388792246 :=
  wSource (t := t_e2262388792246) (replay_sound (ps := []) (t := e2262388792246) (by decide)) (by decide)
def e2262388792686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262388792686 : Closed e2262388792686 ∧ code e2262388792686 = 11058481814894 := by decide
theorem cert_e2262388792686 : check e2262388792686 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262388792694 : Closed e2262388792694 ∧ code e2262388792694 = 11058481814902 := by decide
theorem cert_e2262388792694 : check e2262388792694 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262388792750 : Closed e2262388792750 ∧ code e2262388792750 = 11058481814958 := by decide
theorem cert_e2262388792750 : check e2262388792750 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792762 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262388792762 : Closed e2262388792762 ∧ code e2262388792762 = 11058481814970 := by decide
theorem cert_e2262388792762 : check e2262388792762 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262388792790 : Closed e2262388792790 ∧ code e2262388792790 = 11058481814998 := by decide
theorem cert_e2262388792790 : check e2262388792790 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388792794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262388792794 : Closed e2262388792794 ∧ code e2262388792794 = 11058481815002 := by decide
theorem cert_e2262388792794 : check e2262388792794 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388793014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2262388793014 : Closed e2262388793014 ∧ code e2262388793014 = 11058481815222 := by decide
private def t_e2262388793014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem cert_e2262388793014 : ¬ IsSelfInterpreter e2262388793014 :=
  wSource (t := t_e2262388793014) (replay_sound (ps := []) (t := e2262388793014) (by decide)) (by decide)
def e2262388793046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2262388793046 : Closed e2262388793046 ∧ code e2262388793046 = 11058481815254 := by decide
theorem cert_e2262388793046 : check e2262388793046 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388793050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2262388793050 : Closed e2262388793050 ∧ code e2262388793050 = 11058481815258 := by decide
theorem cert_e2262388793050 : check e2262388793050 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388795246 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2262388795246 : Closed e2262388795246 ∧ code e2262388795246 = 11058481817454 := by decide
theorem cert_e2262388795246 : check e2262388795246 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388795254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2262388795254 : Closed e2262388795254 ∧ code e2262388795254 = 11058481817462 := by decide
theorem cert_e2262388795254 : check e2262388795254 [[],[.under],[.under,.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262388727278
#print axioms Blc.Floor43.cert_e2262388727662
#print axioms Blc.Floor43.cert_e2262388792246
#print axioms Blc.Floor43.cert_e2262388793014
