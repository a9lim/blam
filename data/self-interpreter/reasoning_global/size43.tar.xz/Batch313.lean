import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411631688762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631688762 : Closed e2411631688762 ∧ code e2411631688762 = 11207724710970 := by decide
theorem cert_e2411631688762 : check e2411631688762 [[],[]] .chain = true := by decide
def e2411631688902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411631688902 : Closed e2411631688902 ∧ code e2411631688902 = 11207724711110 := by decide
theorem cert_e2411631688902 : check e2411631688902 [[],[]] .chain = true := by decide
def e2411631688930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411631688930 : Closed e2411631688930 ∧ code e2411631688930 = 11207724711138 := by decide
theorem cert_e2411631688930 : check e2411631688930 [[],[]] .chain = true := by decide
def e2411631688942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411631688942 : Closed e2411631688942 ∧ code e2411631688942 = 11207724711150 := by decide
theorem cert_e2411631688942 : check e2411631688942 [[],[]] .sourceHead = true := by decide
def e2411631688950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411631688950 : Closed e2411631688950 ∧ code e2411631688950 = 11207724711158 := by decide
theorem cert_e2411631688950 : check e2411631688950 [[],[]] .sourceHead = true := by decide
def e2411631711790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2411631711790 : Closed e2411631711790 ∧ code e2411631711790 = 11207724733998 := by decide
theorem cert_e2411631711790 : check e2411631711790 [[],[]] .chain = true := by decide
def e2411631711970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2411631711970 : Closed e2411631711970 ∧ code e2411631711970 = 11207724734178 := by decide
theorem cert_e2411631711970 : check e2411631711970 [[],[]] .chain = true := by decide
def e2411631711982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2411631711982 : Closed e2411631711982 ∧ code e2411631711982 = 11207724734190 := by decide
theorem cert_e2411631711982 : check e2411631711982 [[],[]] .sourceHead = true := by decide
def e2411631712138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2411631712138 : Closed e2411631712138 ∧ code e2411631712138 = 11207724734346 := by decide
theorem cert_e2411631712138 : check e2411631712138 [[],[]] .chain = true := by decide
def e2411631712162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2411631712162 : Closed e2411631712162 ∧ code e2411631712162 = 11207724734370 := by decide
theorem cert_e2411631712162 : check e2411631712162 [[],[]] .chain = true := by decide
def e2411631712174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2411631712174 : Closed e2411631712174 ∧ code e2411631712174 = 11207724734382 := by decide
theorem cert_e2411631712174 : check e2411631712174 [[],[]] .sourceHead = true := by decide
def e2411631712186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2411631712186 : Closed e2411631712186 ∧ code e2411631712186 = 11207724734394 := by decide
theorem cert_e2411631712186 : check e2411631712186 [[],[]] .sourceHead = true := by decide
def e2411631712318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2411631712318 : Closed e2411631712318 ∧ code e2411631712318 = 11207724734526 := by decide
theorem cert_e2411631712318 : check e2411631712318 [[],[]] .chain = true := by decide
def e2411631712738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2411631712738 : Closed e2411631712738 ∧ code e2411631712738 = 11207724734946 := by decide
theorem cert_e2411631712738 : check e2411631712738 [[],[]] .chain = true := by decide
def e2411631712750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411631712750 : Closed e2411631712750 ∧ code e2411631712750 = 11207724734958 := by decide
theorem cert_e2411631712750 : check e2411631712750 [[],[]] .sourceHead = true := by decide
def e2411631713806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2411631713806 : Closed e2411631713806 ∧ code e2411631713806 = 11207724736014 := by decide
theorem cert_e2411631713806 : check e2411631713806 [[],[]] .chain = true := by decide
def e2411631713890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2411631713890 : Closed e2411631713890 ∧ code e2411631713890 = 11207724736098 := by decide
theorem cert_e2411631713890 : check e2411631713890 [[],[]] .chain = true := by decide
def e2411631713902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411631713902 : Closed e2411631713902 ∧ code e2411631713902 = 11207724736110 := by decide
theorem cert_e2411631713902 : check e2411631713902 [[],[]] .sourceHead = true := by decide
def e2411631713914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411631713914 : Closed e2411631713914 ∧ code e2411631713914 = 11207724736122 := by decide
theorem cert_e2411631713914 : check e2411631713914 [[],[]] .sourceHead = true := by decide
def e2411631723222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411631723222 : Closed e2411631723222 ∧ code e2411631723222 = 11207724745430 := by decide
theorem cert_e2411631723222 : check e2411631723222 [[],[]] .sourceHead = true := by decide
def e2411631723226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411631723226 : Closed e2411631723226 ∧ code e2411631723226 = 11207724745434 := by decide
theorem cert_e2411631723226 : check e2411631723226 [[],[]] .sourceHead = true := by decide
def e2411631723242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411631723242 : Closed e2411631723242 ∧ code e2411631723242 = 11207724745450 := by decide
theorem cert_e2411631723242 : check e2411631723242 [[],[]] .sourceHead = true := by decide
def e2411631723318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631723318 : Closed e2411631723318 ∧ code e2411631723318 = 11207724745526 := by decide
theorem cert_e2411631723318 : check e2411631723318 [[],[]] .sourceHead = true := by decide
def e2411631723322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631723322 : Closed e2411631723322 ∧ code e2411631723322 = 11207724745530 := by decide
theorem cert_e2411631723322 : check e2411631723322 [[],[]] .sourceHead = true := by decide
def e2411631723406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2411631723406 : Closed e2411631723406 ∧ code e2411631723406 = 11207724745614 := by decide
theorem cert_e2411631723406 : check e2411631723406 [[],[]] .chain = true := by decide
def e2411631723418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411631723418 : Closed e2411631723418 ∧ code e2411631723418 = 11207724745626 := by decide
theorem cert_e2411631723418 : check e2411631723418 [[],[]] .sourceHead = true := by decide
def e2411631725334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411631725334 : Closed e2411631725334 ∧ code e2411631725334 = 11207724747542 := by decide
theorem cert_e2411631725334 : check e2411631725334 [[],[]] .chain = true := by decide
def e2411631725338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411631725338 : Closed e2411631725338 ∧ code e2411631725338 = 11207724747546 := by decide
theorem cert_e2411631725338 : check e2411631725338 [[],[]] .chain = true := by decide
def e2411631725382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411631725382 : Closed e2411631725382 ∧ code e2411631725382 = 11207724747590 := by decide
theorem cert_e2411631725382 : check e2411631725382 [[],[]] .chain = true := by decide
def e2411631725410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411631725410 : Closed e2411631725410 ∧ code e2411631725410 = 11207724747618 := by decide
theorem cert_e2411631725410 : check e2411631725410 [[],[]] .chain = true := by decide
def e2411631725422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411631725422 : Closed e2411631725422 ∧ code e2411631725422 = 11207724747630 := by decide
theorem cert_e2411631725422 : check e2411631725422 [[],[]] .sourceHead = true := by decide
def e2411631725430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411631725430 : Closed e2411631725430 ∧ code e2411631725430 = 11207724747638 := by decide
theorem cert_e2411631725430 : check e2411631725430 [[],[]] .sourceHead = true := by decide
def e2411631725450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2411631725450 : Closed e2411631725450 ∧ code e2411631725450 = 11207724747658 := by decide
theorem cert_e2411631725450 : check e2411631725450 [[],[]] .chain = true := by decide
def e2411631725474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2411631725474 : Closed e2411631725474 ∧ code e2411631725474 = 11207724747682 := by decide
theorem cert_e2411631725474 : check e2411631725474 [[],[]] .chain = true := by decide
def e2411631725486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411631725486 : Closed e2411631725486 ∧ code e2411631725486 = 11207724747694 := by decide
theorem cert_e2411631725486 : check e2411631725486 [[],[]] .sourceHead = true := by decide
def e2411631725498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411631725498 : Closed e2411631725498 ∧ code e2411631725498 = 11207724747706 := by decide
theorem cert_e2411631725498 : check e2411631725498 [[],[]] .sourceHead = true := by decide
def e2411631725526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411631725526 : Closed e2411631725526 ∧ code e2411631725526 = 11207724747734 := by decide
theorem cert_e2411631725526 : check e2411631725526 [[],[]] .sourceHead = true := by decide
def e2411631725530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411631725530 : Closed e2411631725530 ∧ code e2411631725530 = 11207724747738 := by decide
theorem cert_e2411631725530 : check e2411631725530 [[],[]] .sourceHead = true := by decide
def e2411631725598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2411631725598 : Closed e2411631725598 ∧ code e2411631725598 = 11207724747806 := by decide
theorem cert_e2411631725598 : check e2411631725598 [[],[]] .chain = true := by decide
def e2411631725622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411631725622 : Closed e2411631725622 ∧ code e2411631725622 = 11207724747830 := by decide
theorem cert_e2411631725622 : check e2411631725622 [[],[]] .chain = true := by decide
def e2411631725626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411631725626 : Closed e2411631725626 ∧ code e2411631725626 = 11207724747834 := by decide
theorem cert_e2411631725626 : check e2411631725626 [[],[]] .chain = true := by decide
def e2411631725766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411631725766 : Closed e2411631725766 ∧ code e2411631725766 = 11207724747974 := by decide
theorem cert_e2411631725766 : check e2411631725766 [[],[]] .chain = true := by decide
def e2411631725794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411631725794 : Closed e2411631725794 ∧ code e2411631725794 = 11207724748002 := by decide
theorem cert_e2411631725794 : check e2411631725794 [[],[]] .chain = true := by decide
def e2411631725806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411631725806 : Closed e2411631725806 ∧ code e2411631725806 = 11207724748014 := by decide
theorem cert_e2411631725806 : check e2411631725806 [[],[]] .sourceHead = true := by decide
def e2411631725814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411631725814 : Closed e2411631725814 ∧ code e2411631725814 = 11207724748022 := by decide
theorem cert_e2411631725814 : check e2411631725814 [[],[]] .sourceHead = true := by decide
def e2411631726094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2411631726094 : Closed e2411631726094 ∧ code e2411631726094 = 11207724748302 := by decide
theorem cert_e2411631726094 : check e2411631726094 [[],[]] .chain = true := by decide
def e2411631726178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2411631726178 : Closed e2411631726178 ∧ code e2411631726178 = 11207724748386 := by decide
theorem cert_e2411631726178 : check e2411631726178 [[],[]] .chain = true := by decide
def e2411631726190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411631726190 : Closed e2411631726190 ∧ code e2411631726190 = 11207724748398 := by decide
theorem cert_e2411631726190 : check e2411631726190 [[],[]] .sourceHead = true := by decide
def e2411631726202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411631726202 : Closed e2411631726202 ∧ code e2411631726202 = 11207724748410 := by decide
theorem cert_e2411631726202 : check e2411631726202 [[],[]] .sourceHead = true := by decide
def e2411631726390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411631726390 : Closed e2411631726390 ∧ code e2411631726390 = 11207724748598 := by decide
theorem cert_e2411631726390 : check e2411631726390 [[],[]] .sourceHead = true := by decide
def e2411631726394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411631726394 : Closed e2411631726394 ∧ code e2411631726394 = 11207724748602 := by decide
theorem cert_e2411631726394 : check e2411631726394 [[],[]] .sourceHead = true := by decide
def e2411632025054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2411632025054 : Closed e2411632025054 ∧ code e2411632025054 = 11207725047262 := by decide
theorem cert_e2411632025054 : check e2411632025054 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632025070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2411632025070 : Closed e2411632025070 ∧ code e2411632025070 = 11207725047278 := by decide
theorem cert_e2411632025070 : check e2411632025070 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632025310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2411632025310 : Closed e2411632025310 ∧ code e2411632025310 = 11207725047518 := by decide
theorem cert_e2411632025310 : check e2411632025310 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632025334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2411632025334 : Closed e2411632025334 ∧ code e2411632025334 = 11207725047542 := by decide
theorem cert_e2411632025334 : check e2411632025334 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632025454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2411632025454 : Closed e2411632025454 ∧ code e2411632025454 = 11207725047662 := by decide
theorem cert_e2411632025454 : check e2411632025454 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632025462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2411632025462 : Closed e2411632025462 ∧ code e2411632025462 = 11207725047670 := by decide
theorem cert_e2411632025462 : check e2411632025462 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632030686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411632030686 : Closed e2411632030686 ∧ code e2411632030686 = 11207725052894 := by decide
theorem cert_e2411632030686 : check e2411632030686 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632030702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411632030702 : Closed e2411632030702 ∧ code e2411632030702 = 11207725052910 := by decide
theorem cert_e2411632030702 : check e2411632030702 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632032222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411632032222 : Closed e2411632032222 ∧ code e2411632032222 = 11207725054430 := by decide
theorem cert_e2411632032222 : check e2411632032222 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632032246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411632032246 : Closed e2411632032246 ∧ code e2411632032246 = 11207725054454 := by decide
theorem cert_e2411632032246 : check e2411632032246 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632033006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411632033006 : Closed e2411632033006 ∧ code e2411632033006 = 11207725055214 := by decide
theorem cert_e2411632033006 : check e2411632033006 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632033014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411632033014 : Closed e2411632033014 ∧ code e2411632033014 = 11207725055222 := by decide
theorem cert_e2411632033014 : check e2411632033014 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632089270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2411632089270 : Closed e2411632089270 ∧ code e2411632089270 = 11207725111478 := by decide
theorem cert_e2411632089270 : check e2411632089270 [[],[]] .chain = true := by decide
def e2411632089302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411632089302 : Closed e2411632089302 ∧ code e2411632089302 = 11207725111510 := by decide
theorem cert_e2411632089302 : check e2411632089302 [[],[]] .chain = true := by decide
def e2411632089306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411632089306 : Closed e2411632089306 ∧ code e2411632089306 = 11207725111514 := by decide
theorem cert_e2411632089306 : check e2411632089306 [[],[]] .chain = true := by decide
def e2411632089322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2411632089322 : Closed e2411632089322 ∧ code e2411632089322 = 11207725111530 := by decide
theorem cert_e2411632089322 : check e2411632089322 [[],[]] .chain = true := by decide
def e2411632089654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411632089654 : Closed e2411632089654 ∧ code e2411632089654 = 11207725111862 := by decide
theorem cert_e2411632089654 : check e2411632089654 [[],[]] .chain = true := by decide
def e2411632089658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411632089658 : Closed e2411632089658 ∧ code e2411632089658 = 11207725111866 := by decide
theorem cert_e2411632089658 : check e2411632089658 [[],[]] .chain = true := by decide
def e2411632089742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411632089742 : Closed e2411632089742 ∧ code e2411632089742 = 11207725111950 := by decide
theorem cert_e2411632089742 : check e2411632089742 [[],[]] .chain = true := by decide
def e2411632089798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411632089798 : Closed e2411632089798 ∧ code e2411632089798 = 11207725112006 := by decide
theorem cert_e2411632089798 : check e2411632089798 [[],[]] .chain = true := by decide
def e2411632089878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411632089878 : Closed e2411632089878 ∧ code e2411632089878 = 11207725112086 := by decide
theorem cert_e2411632089878 : check e2411632089878 [[],[]] .chain = true := by decide
def e2411632089882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411632089882 : Closed e2411632089882 ∧ code e2411632089882 = 11207725112090 := by decide
theorem cert_e2411632089882 : check e2411632089882 [[],[]] .chain = true := by decide
def e2411632089926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411632089926 : Closed e2411632089926 ∧ code e2411632089926 = 11207725112134 := by decide
theorem cert_e2411632089926 : check e2411632089926 [[],[]] .chain = true := by decide
def e2411632089954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411632089954 : Closed e2411632089954 ∧ code e2411632089954 = 11207725112162 := by decide
theorem cert_e2411632089954 : check e2411632089954 [[],[]] .chain = true := by decide
def e2411632089966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2411632089966 : Closed e2411632089966 ∧ code e2411632089966 = 11207725112174 := by decide
theorem cert_e2411632089966 : check e2411632089966 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632089974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2411632089974 : Closed e2411632089974 ∧ code e2411632089974 = 11207725112182 := by decide
theorem cert_e2411632089974 : check e2411632089974 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2411632090038 : Closed e2411632090038 ∧ code e2411632090038 = 11207725112246 := by decide
theorem cert_e2411632090038 : check e2411632090038 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2411632090198 : Closed e2411632090198 ∧ code e2411632090198 = 11207725112406 := by decide
theorem cert_e2411632090198 : check e2411632090198 [[],[]] .chain = true := by decide
def e2411632090202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2411632090202 : Closed e2411632090202 ∧ code e2411632090202 = 11207725112410 := by decide
theorem cert_e2411632090202 : check e2411632090202 [[],[]] .chain = true := by decide
def e2411632090218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2411632090218 : Closed e2411632090218 ∧ code e2411632090218 = 11207725112426 := by decide
theorem cert_e2411632090218 : check e2411632090218 [[],[]] .chain = true := by decide
def e2411632090390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411632090390 : Closed e2411632090390 ∧ code e2411632090390 = 11207725112598 := by decide
theorem cert_e2411632090390 : check e2411632090390 [[],[]] .chain = true := by decide
def e2411632090394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411632090394 : Closed e2411632090394 ∧ code e2411632090394 = 11207725112602 := by decide
theorem cert_e2411632090394 : check e2411632090394 [[],[]] .chain = true := by decide
def e2411632090438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411632090438 : Closed e2411632090438 ∧ code e2411632090438 = 11207725112646 := by decide
theorem cert_e2411632090438 : check e2411632090438 [[],[]] .chain = true := by decide
def e2411632090466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411632090466 : Closed e2411632090466 ∧ code e2411632090466 = 11207725112674 := by decide
theorem cert_e2411632090466 : check e2411632090466 [[],[]] .chain = true := by decide
def e2411632090478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2411632090478 : Closed e2411632090478 ∧ code e2411632090478 = 11207725112686 := by decide
theorem cert_e2411632090478 : check e2411632090478 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2411632090486 : Closed e2411632090486 ∧ code e2411632090486 = 11207725112694 := by decide
theorem cert_e2411632090486 : check e2411632090486 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411632090506 : Closed e2411632090506 ∧ code e2411632090506 = 11207725112714 := by decide
theorem cert_e2411632090506 : check e2411632090506 [[],[]] .chain = true := by decide
def e2411632090530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411632090530 : Closed e2411632090530 ∧ code e2411632090530 = 11207725112738 := by decide
theorem cert_e2411632090530 : check e2411632090530 [[],[]] .chain = true := by decide
def e2411632090542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2411632090542 : Closed e2411632090542 ∧ code e2411632090542 = 11207725112750 := by decide
theorem cert_e2411632090542 : check e2411632090542 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2411632090554 : Closed e2411632090554 ∧ code e2411632090554 = 11207725112762 := by decide
theorem cert_e2411632090554 : check e2411632090554 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2411632090582 : Closed e2411632090582 ∧ code e2411632090582 = 11207725112790 := by decide
theorem cert_e2411632090582 : check e2411632090582 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2411632090586 : Closed e2411632090586 ∧ code e2411632090586 = 11207725112794 := by decide
theorem cert_e2411632090586 : check e2411632090586 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2411632090806 : Closed e2411632090806 ∧ code e2411632090806 = 11207725113014 := by decide
theorem cert_e2411632090806 : check e2411632090806 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2411632090838 : Closed e2411632090838 ∧ code e2411632090838 = 11207725113046 := by decide
theorem cert_e2411632090838 : check e2411632090838 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632090842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2411632090842 : Closed e2411632090842 ∧ code e2411632090842 = 11207725113050 := by decide
theorem cert_e2411632090842 : check e2411632090842 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632091382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411632091382 : Closed e2411632091382 ∧ code e2411632091382 = 11207725113590 := by decide
theorem cert_e2411632091382 : check e2411632091382 [[],[]] .chain = true := by decide
def e2411632091574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411632091574 : Closed e2411632091574 ∧ code e2411632091574 = 11207725113782 := by decide
theorem cert_e2411632091574 : check e2411632091574 [[],[]] .chain = true := by decide
def e2411632091578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2411632091578 : Closed e2411632091578 ∧ code e2411632091578 = 11207725113786 := by decide
theorem cert_e2411632091578 : check e2411632091578 [[],[]] .chain = true := by decide
def e2411632091606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411632091606 : Closed e2411632091606 ∧ code e2411632091606 = 11207725113814 := by decide
theorem cert_e2411632091606 : check e2411632091606 [[],[]] .chain = true := by decide
def e2411632091626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2411632091626 : Closed e2411632091626 ∧ code e2411632091626 = 11207725113834 := by decide
theorem cert_e2411632091626 : check e2411632091626 [[],[]] .chain = true := by decide
def e2411632091766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2411632091766 : Closed e2411632091766 ∧ code e2411632091766 = 11207725113974 := by decide
theorem cert_e2411632091766 : check e2411632091766 [[],[]] .chain = true := by decide
def e2411632091958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411632091958 : Closed e2411632091958 ∧ code e2411632091958 = 11207725114166 := by decide
theorem cert_e2411632091958 : check e2411632091958 [[],[]] .chain = true := by decide
def e2411632091962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411632091962 : Closed e2411632091962 ∧ code e2411632091962 = 11207725114170 := by decide
theorem cert_e2411632091962 : check e2411632091962 [[],[]] .chain = true := by decide
def e2411632092046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411632092046 : Closed e2411632092046 ∧ code e2411632092046 = 11207725114254 := by decide
theorem cert_e2411632092046 : check e2411632092046 [[],[]] .chain = true := by decide
def e2411632092058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411632092058 : Closed e2411632092058 ∧ code e2411632092058 = 11207725114266 := by decide
theorem cert_e2411632092058 : check e2411632092058 [[],[]] .chain = true := by decide
def e2411632092726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411632092726 : Closed e2411632092726 ∧ code e2411632092726 = 11207725114934 := by decide
theorem cert_e2411632092726 : check e2411632092726 [[],[]] .chain = true := by decide
def e2411632092730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411632092730 : Closed e2411632092730 ∧ code e2411632092730 = 11207725114938 := by decide
theorem cert_e2411632092730 : check e2411632092730 [[],[]] .chain = true := by decide
def e2411632092814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411632092814 : Closed e2411632092814 ∧ code e2411632092814 = 11207725115022 := by decide
theorem cert_e2411632092814 : check e2411632092814 [[],[]] .chain = true := by decide
def e2411632092870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411632092870 : Closed e2411632092870 ∧ code e2411632092870 = 11207725115078 := by decide
theorem cert_e2411632092870 : check e2411632092870 [[],[]] .chain = true := by decide
def e2411632092950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411632092950 : Closed e2411632092950 ∧ code e2411632092950 = 11207725115158 := by decide
theorem cert_e2411632092950 : check e2411632092950 [[],[]] .chain = true := by decide
def e2411632092954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411632092954 : Closed e2411632092954 ∧ code e2411632092954 = 11207725115162 := by decide
theorem cert_e2411632092954 : check e2411632092954 [[],[]] .chain = true := by decide
def e2411632092998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411632092998 : Closed e2411632092998 ∧ code e2411632092998 = 11207725115206 := by decide
theorem cert_e2411632092998 : check e2411632092998 [[],[]] .chain = true := by decide
def e2411632093026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411632093026 : Closed e2411632093026 ∧ code e2411632093026 = 11207725115234 := by decide
theorem cert_e2411632093026 : check e2411632093026 [[],[]] .chain = true := by decide
def e2411632093038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2411632093038 : Closed e2411632093038 ∧ code e2411632093038 = 11207725115246 := by decide
theorem cert_e2411632093038 : check e2411632093038 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632093046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2411632093046 : Closed e2411632093046 ∧ code e2411632093046 = 11207725115254 := by decide
theorem cert_e2411632093046 : check e2411632093046 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632093110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2411632093110 : Closed e2411632093110 ∧ code e2411632093110 = 11207725115318 := by decide
theorem cert_e2411632093110 : check e2411632093110 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632093294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411632093294 : Closed e2411632093294 ∧ code e2411632093294 = 11207725115502 := by decide
theorem cert_e2411632093294 : check e2411632093294 [[],[]] .chain = true := by decide
def e2411632093306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411632093306 : Closed e2411632093306 ∧ code e2411632093306 = 11207725115514 := by decide
theorem cert_e2411632093306 : check e2411632093306 [[],[]] .chain = true := by decide
def e2411632093582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411632093582 : Closed e2411632093582 ∧ code e2411632093582 = 11207725115790 := by decide
theorem cert_e2411632093582 : check e2411632093582 [[],[]] .chain = true := by decide
def e2411632093638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411632093638 : Closed e2411632093638 ∧ code e2411632093638 = 11207725115846 := by decide
theorem cert_e2411632093638 : check e2411632093638 [[],[]] .chain = true := by decide
def e2411632094238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411632094238 : Closed e2411632094238 ∧ code e2411632094238 = 11207725116446 := by decide
theorem cert_e2411632094238 : check e2411632094238 [[],[]] .chain = true := by decide
def e2411632094262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411632094262 : Closed e2411632094262 ∧ code e2411632094262 = 11207725116470 := by decide
theorem cert_e2411632094262 : check e2411632094262 [[],[]] .chain = true := by decide
def e2411632094266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411632094266 : Closed e2411632094266 ∧ code e2411632094266 = 11207725116474 := by decide
theorem cert_e2411632094266 : check e2411632094266 [[],[]] .chain = true := by decide
def e2411632094406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411632094406 : Closed e2411632094406 ∧ code e2411632094406 = 11207725116614 := by decide
theorem cert_e2411632094406 : check e2411632094406 [[],[]] .chain = true := by decide
def e2411632094434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411632094434 : Closed e2411632094434 ∧ code e2411632094434 = 11207725116642 := by decide
theorem cert_e2411632094434 : check e2411632094434 [[],[]] .chain = true := by decide
def e2411632094446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411632094446 : Closed e2411632094446 ∧ code e2411632094446 = 11207725116654 := by decide
theorem cert_e2411632094446 : check e2411632094446 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632094454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411632094454 : Closed e2411632094454 ∧ code e2411632094454 = 11207725116662 := by decide
theorem cert_e2411632094454 : check e2411632094454 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632094838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411632094838 : Closed e2411632094838 ∧ code e2411632094838 = 11207725117046 := by decide
theorem cert_e2411632094838 : check e2411632094838 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632095350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2411632095350 : Closed e2411632095350 ∧ code e2411632095350 = 11207725117558 := by decide
theorem cert_e2411632095350 : check e2411632095350 [[],[]] .chain = true := by decide
def e2411632095354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411632095354 : Closed e2411632095354 ∧ code e2411632095354 = 11207725117562 := by decide
theorem cert_e2411632095354 : check e2411632095354 [[],[]] .chain = true := by decide
def e2411632095450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2411632095450 : Closed e2411632095450 ∧ code e2411632095450 = 11207725117658 := by decide
theorem cert_e2411632095450 : check e2411632095450 [[],[]] .chain = true := by decide
def e2411632095466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2411632095466 : Closed e2411632095466 ∧ code e2411632095466 = 11207725117674 := by decide
theorem cert_e2411632095466 : check e2411632095466 [[],[]] .chain = true := by decide
def e2411632095542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411632095542 : Closed e2411632095542 ∧ code e2411632095542 = 11207725117750 := by decide
theorem cert_e2411632095542 : check e2411632095542 [[],[]] .chain = true := by decide
def e2411632095546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411632095546 : Closed e2411632095546 ∧ code e2411632095546 = 11207725117754 := by decide
theorem cert_e2411632095546 : check e2411632095546 [[],[]] .chain = true := by decide
def e2411632095630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2411632095630 : Closed e2411632095630 ∧ code e2411632095630 = 11207725117838 := by decide
theorem cert_e2411632095630 : check e2411632095630 [[],[]] .chain = true := by decide
def e2411632095642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411632095642 : Closed e2411632095642 ∧ code e2411632095642 = 11207725117850 := by decide
theorem cert_e2411632095642 : check e2411632095642 [[],[]] .chain = true := by decide
def e2411632095686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411632095686 : Closed e2411632095686 ∧ code e2411632095686 = 11207725117894 := by decide
theorem cert_e2411632095686 : check e2411632095686 [[],[]] .chain = true := by decide
def e2411632096022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2411632096022 : Closed e2411632096022 ∧ code e2411632096022 = 11207725118230 := by decide
theorem cert_e2411632096022 : check e2411632096022 [[],[]] .chain = true := by decide
def e2411632096026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411632096026 : Closed e2411632096026 ∧ code e2411632096026 = 11207725118234 := by decide
theorem cert_e2411632096026 : check e2411632096026 [[],[]] .chain = true := by decide
def e2411632096070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411632096070 : Closed e2411632096070 ∧ code e2411632096070 = 11207725118278 := by decide
theorem cert_e2411632096070 : check e2411632096070 [[],[]] .chain = true := by decide
def e2411632096098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2411632096098 : Closed e2411632096098 ∧ code e2411632096098 = 11207725118306 := by decide
theorem cert_e2411632096098 : check e2411632096098 [[],[]] .chain = true := by decide
def e2411632096110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2411632096110 : Closed e2411632096110 ∧ code e2411632096110 = 11207725118318 := by decide
theorem cert_e2411632096110 : check e2411632096110 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2411632096118 : Closed e2411632096118 ∧ code e2411632096118 = 11207725118326 := by decide
theorem cert_e2411632096118 : check e2411632096118 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2411632096138 : Closed e2411632096138 ∧ code e2411632096138 = 11207725118346 := by decide
theorem cert_e2411632096138 : check e2411632096138 [[],[]] .chain = true := by decide
def e2411632096162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2411632096162 : Closed e2411632096162 ∧ code e2411632096162 = 11207725118370 := by decide
theorem cert_e2411632096162 : check e2411632096162 [[],[]] .chain = true := by decide
def e2411632096174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2411632096174 : Closed e2411632096174 ∧ code e2411632096174 = 11207725118382 := by decide
theorem cert_e2411632096174 : check e2411632096174 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2411632096186 : Closed e2411632096186 ∧ code e2411632096186 = 11207725118394 := by decide
theorem cert_e2411632096186 : check e2411632096186 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2411632096214 : Closed e2411632096214 ∧ code e2411632096214 = 11207725118422 := by decide
theorem cert_e2411632096214 : check e2411632096214 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2411632096218 : Closed e2411632096218 ∧ code e2411632096218 = 11207725118426 := by decide
theorem cert_e2411632096218 : check e2411632096218 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2411632096286 : Closed e2411632096286 ∧ code e2411632096286 = 11207725118494 := by decide
theorem cert_e2411632096286 : check e2411632096286 [[],[]] .chain = true := by decide
def e2411632096310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411632096310 : Closed e2411632096310 ∧ code e2411632096310 = 11207725118518 := by decide
theorem cert_e2411632096310 : check e2411632096310 [[],[]] .chain = true := by decide
def e2411632096314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411632096314 : Closed e2411632096314 ∧ code e2411632096314 = 11207725118522 := by decide
theorem cert_e2411632096314 : check e2411632096314 [[],[]] .chain = true := by decide
def e2411632096454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411632096454 : Closed e2411632096454 ∧ code e2411632096454 = 11207725118662 := by decide
theorem cert_e2411632096454 : check e2411632096454 [[],[]] .chain = true := by decide
def e2411632096482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411632096482 : Closed e2411632096482 ∧ code e2411632096482 = 11207725118690 := by decide
theorem cert_e2411632096482 : check e2411632096482 [[],[]] .chain = true := by decide
def e2411632096494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2411632096494 : Closed e2411632096494 ∧ code e2411632096494 = 11207725118702 := by decide
theorem cert_e2411632096494 : check e2411632096494 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2411632096502 : Closed e2411632096502 ∧ code e2411632096502 = 11207725118710 := by decide
theorem cert_e2411632096502 : check e2411632096502 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632096782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2411632096782 : Closed e2411632096782 ∧ code e2411632096782 = 11207725118990 := by decide
theorem cert_e2411632096782 : check e2411632096782 [[],[]] .chain = true := by decide
def e2411632096866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411632096866 : Closed e2411632096866 ∧ code e2411632096866 = 11207725119074 := by decide
theorem cert_e2411632096866 : check e2411632096866 [[],[]] .chain = true := by decide
def e2411632096878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2411632096878 : Closed e2411632096878 ∧ code e2411632096878 = 11207725119086 := by decide
theorem cert_e2411632096878 : check e2411632096878 [[],[],[.under,.under]] .smaller = true := by decide
end Blc.Floor43
