import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419144273774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2419144273774 : Closed e2419144273774 ∧ code e2419144273774 = 11215237295982 := by decide
theorem cert_e2419144273774 : check e2419144273774 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144273782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2419144273782 : Closed e2419144273782 ∧ code e2419144273782 = 11215237295990 := by decide
theorem cert_e2419144273782 : check e2419144273782 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144273786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2419144273786 : Closed e2419144273786 ∧ code e2419144273786 = 11215237295994 := by decide
theorem cert_e2419144273786 : check e2419144273786 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144273838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2419144273838 : Closed e2419144273838 ∧ code e2419144273838 = 11215237296046 := by decide
private def t_e2419144273838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem cert_e2419144273838 : ¬ IsSelfInterpreter e2419144273838 :=
  wSource (t := t_e2419144273838) (replay_sound (ps := []) (t := e2419144273838) (by decide)) (by decide)
def e2419144273850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2419144273850 : Closed e2419144273850 ∧ code e2419144273850 = 11215237296058 := by decide
theorem cert_e2419144273850 : check e2419144273850 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144274910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419144274910 : Closed e2419144274910 ∧ code e2419144274910 = 11215237297118 := by decide
theorem cert_e2419144274910 : check e2419144274910 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144274926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419144274926 : Closed e2419144274926 ∧ code e2419144274926 = 11215237297134 := by decide
theorem cert_e2419144274926 : check e2419144274926 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144276462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419144276462 : Closed e2419144276462 ∧ code e2419144276462 = 11215237298670 := by decide
theorem cert_e2419144276462 : check e2419144276462 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144277214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419144277214 : Closed e2419144277214 ∧ code e2419144277214 = 11215237299422 := by decide
theorem cert_e2419144277214 : check e2419144277214 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144277230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144277230 : Closed e2419144277230 ∧ code e2419144277230 = 11215237299438 := by decide
theorem cert_e2419144277230 : check e2419144277230 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144277238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144277238 : Closed e2419144277238 ∧ code e2419144277238 = 11215237299446 := by decide
theorem cert_e2419144277238 : check e2419144277238 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144277242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419144277242 : Closed e2419144277242 ∧ code e2419144277242 = 11215237299450 := by decide
theorem cert_e2419144277242 : check e2419144277242 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144277614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144277614 : Closed e2419144277614 ∧ code e2419144277614 = 11215237299822 := by decide
theorem cert_e2419144277614 : check e2419144277614 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144277626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144277626 : Closed e2419144277626 ∧ code e2419144277626 = 11215237299834 := by decide
theorem cert_e2419144277626 : check e2419144277626 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144305750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2419144305750 : Closed e2419144305750 ∧ code e2419144305750 = 11215237327958 := by decide
theorem cert_e2419144305750 : check e2419144305750 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144305754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2419144305754 : Closed e2419144305754 ∧ code e2419144305754 = 11215237327962 := by decide
theorem cert_e2419144305754 : check e2419144305754 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144305942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2419144305942 : Closed e2419144305942 ∧ code e2419144305942 = 11215237328150 := by decide
theorem cert_e2419144305942 : check e2419144305942 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2419144306018 : Closed e2419144306018 ∧ code e2419144306018 = 11215237328226 := by decide
theorem cert_e2419144306018 : check e2419144306018 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419144306030 : Closed e2419144306030 ∧ code e2419144306030 = 11215237328238 := by decide
theorem cert_e2419144306030 : check e2419144306030 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419144306038 : Closed e2419144306038 ∧ code e2419144306038 = 11215237328246 := by decide
theorem cert_e2419144306038 : check e2419144306038 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419144306058 : Closed e2419144306058 ∧ code e2419144306058 = 11215237328266 := by decide
theorem cert_e2419144306058 : check e2419144306058 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419144306082 : Closed e2419144306082 ∧ code e2419144306082 = 11215237328290 := by decide
theorem cert_e2419144306082 : check e2419144306082 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419144306094 : Closed e2419144306094 ∧ code e2419144306094 = 11215237328302 := by decide
theorem cert_e2419144306094 : check e2419144306094 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2419144306102 : Closed e2419144306102 ∧ code e2419144306102 = 11215237328310 := by decide
theorem cert_e2419144306102 : check e2419144306102 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419144306106 : Closed e2419144306106 ∧ code e2419144306106 = 11215237328314 := by decide
theorem cert_e2419144306106 : check e2419144306106 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419144306134 : Closed e2419144306134 ∧ code e2419144306134 = 11215237328342 := by decide
theorem cert_e2419144306134 : check e2419144306134 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419144306138 : Closed e2419144306138 ∧ code e2419144306138 = 11215237328346 := by decide
theorem cert_e2419144306138 : check e2419144306138 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2419144306218 : Closed e2419144306218 ∧ code e2419144306218 = 11215237328426 := by decide
theorem cert_e2419144306218 : check e2419144306218 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419144306314 : Closed e2419144306314 ∧ code e2419144306314 = 11215237328522 := by decide
theorem cert_e2419144306314 : check e2419144306314 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419144306338 : Closed e2419144306338 ∧ code e2419144306338 = 11215237328546 := by decide
theorem cert_e2419144306338 : check e2419144306338 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2419144306350 : Closed e2419144306350 ∧ code e2419144306350 = 11215237328558 := by decide
theorem cert_e2419144306350 : check e2419144306350 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2419144306358 : Closed e2419144306358 ∧ code e2419144306358 = 11215237328566 := by decide
theorem cert_e2419144306358 : check e2419144306358 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2419144306362 : Closed e2419144306362 ∧ code e2419144306362 = 11215237328570 := by decide
theorem cert_e2419144306362 : check e2419144306362 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2419144306390 : Closed e2419144306390 ∧ code e2419144306390 = 11215237328598 := by decide
theorem cert_e2419144306390 : check e2419144306390 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2419144306394 : Closed e2419144306394 ∧ code e2419144306394 = 11215237328602 := by decide
theorem cert_e2419144306394 : check e2419144306394 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2419144306410 : Closed e2419144306410 ∧ code e2419144306410 = 11215237328618 := by decide
theorem cert_e2419144306410 : check e2419144306410 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2419144306518 : Closed e2419144306518 ∧ code e2419144306518 = 11215237328726 := by decide
theorem cert_e2419144306518 : check e2419144306518 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2419144306522 : Closed e2419144306522 ∧ code e2419144306522 = 11215237328730 := by decide
theorem cert_e2419144306522 : check e2419144306522 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2419144306538 : Closed e2419144306538 ∧ code e2419144306538 = 11215237328746 := by decide
theorem cert_e2419144306538 : check e2419144306538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2419144306806 : Closed e2419144306806 ∧ code e2419144306806 = 11215237329014 := by decide
theorem cert_e2419144306806 : check e2419144306806 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2419144306810 : Closed e2419144306810 ∧ code e2419144306810 = 11215237329018 := by decide
theorem cert_e2419144306810 : check e2419144306810 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144306902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2419144306902 : Closed e2419144306902 ∧ code e2419144306902 = 11215237329110 := by decide
theorem cert_e2419144306902 : check e2419144306902 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144306998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144306998 : Closed e2419144306998 ∧ code e2419144306998 = 11215237329206 := by decide
theorem cert_e2419144306998 : check e2419144306998 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144307002 : Closed e2419144307002 ∧ code e2419144307002 = 11215237329210 := by decide
theorem cert_e2419144307002 : check e2419144307002 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2419144307086 : Closed e2419144307086 ∧ code e2419144307086 = 11215237329294 := by decide
theorem cert_e2419144307086 : check e2419144307086 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2419144307142 : Closed e2419144307142 ∧ code e2419144307142 = 11215237329350 := by decide
theorem cert_e2419144307142 : check e2419144307142 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2419144307478 : Closed e2419144307478 ∧ code e2419144307478 = 11215237329686 := by decide
theorem cert_e2419144307478 : check e2419144307478 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2419144307554 : Closed e2419144307554 ∧ code e2419144307554 = 11215237329762 := by decide
theorem cert_e2419144307554 : check e2419144307554 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419144307566 : Closed e2419144307566 ∧ code e2419144307566 = 11215237329774 := by decide
theorem cert_e2419144307566 : check e2419144307566 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419144307574 : Closed e2419144307574 ∧ code e2419144307574 = 11215237329782 := by decide
theorem cert_e2419144307574 : check e2419144307574 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419144307594 : Closed e2419144307594 ∧ code e2419144307594 = 11215237329802 := by decide
theorem cert_e2419144307594 : check e2419144307594 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419144307618 : Closed e2419144307618 ∧ code e2419144307618 = 11215237329826 := by decide
theorem cert_e2419144307618 : check e2419144307618 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419144307630 : Closed e2419144307630 ∧ code e2419144307630 = 11215237329838 := by decide
theorem cert_e2419144307630 : check e2419144307630 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2419144307638 : Closed e2419144307638 ∧ code e2419144307638 = 11215237329846 := by decide
theorem cert_e2419144307638 : check e2419144307638 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419144307642 : Closed e2419144307642 ∧ code e2419144307642 = 11215237329850 := by decide
theorem cert_e2419144307642 : check e2419144307642 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419144307670 : Closed e2419144307670 ∧ code e2419144307670 = 11215237329878 := by decide
theorem cert_e2419144307670 : check e2419144307670 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419144307674 : Closed e2419144307674 ∧ code e2419144307674 = 11215237329882 := by decide
theorem cert_e2419144307674 : check e2419144307674 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2419144307742 : Closed e2419144307742 ∧ code e2419144307742 = 11215237329950 := by decide
theorem cert_e2419144307742 : check e2419144307742 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2419144307938 : Closed e2419144307938 ∧ code e2419144307938 = 11215237330146 := by decide
theorem cert_e2419144307938 : check e2419144307938 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144307950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419144307950 : Closed e2419144307950 ∧ code e2419144307950 = 11215237330158 := by decide
theorem cert_e2419144307950 : check e2419144307950 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144307958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419144307958 : Closed e2419144307958 ∧ code e2419144307958 = 11215237330166 := by decide
theorem cert_e2419144307958 : check e2419144307958 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419144308238 : Closed e2419144308238 ∧ code e2419144308238 = 11215237330446 := by decide
theorem cert_e2419144308238 : check e2419144308238 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144308250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144308250 : Closed e2419144308250 ∧ code e2419144308250 = 11215237330458 := by decide
theorem cert_e2419144308250 : check e2419144308250 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419144308322 : Closed e2419144308322 ∧ code e2419144308322 = 11215237330530 := by decide
theorem cert_e2419144308322 : check e2419144308322 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144308334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144308334 : Closed e2419144308334 ∧ code e2419144308334 = 11215237330542 := by decide
theorem cert_e2419144308334 : check e2419144308334 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419144308342 : Closed e2419144308342 ∧ code e2419144308342 = 11215237330550 := by decide
theorem cert_e2419144308342 : check e2419144308342 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144308346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144308346 : Closed e2419144308346 ∧ code e2419144308346 = 11215237330554 := by decide
theorem cert_e2419144308346 : check e2419144308346 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144308534 : Closed e2419144308534 ∧ code e2419144308534 = 11215237330742 := by decide
theorem cert_e2419144308534 : check e2419144308534 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144308538 : Closed e2419144308538 ∧ code e2419144308538 = 11215237330746 := by decide
theorem cert_e2419144308538 : check e2419144308538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419144308794 : Closed e2419144308794 ∧ code e2419144308794 = 11215237331002 := by decide
theorem cert_e2419144308794 : check e2419144308794 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144308842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2419144308842 : Closed e2419144308842 ∧ code e2419144308842 = 11215237331050 := by decide
theorem cert_e2419144308842 : check e2419144308842 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144308890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419144308890 : Closed e2419144308890 ∧ code e2419144308890 = 11215237331098 := by decide
theorem cert_e2419144308890 : check e2419144308890 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144308934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419144308934 : Closed e2419144308934 ∧ code e2419144308934 = 11215237331142 := by decide
theorem cert_e2419144308934 : check e2419144308934 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419144309130 : Closed e2419144309130 ∧ code e2419144309130 = 11215237331338 := by decide
theorem cert_e2419144309130 : check e2419144309130 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419144309154 : Closed e2419144309154 ∧ code e2419144309154 = 11215237331362 := by decide
theorem cert_e2419144309154 : check e2419144309154 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2419144309166 : Closed e2419144309166 ∧ code e2419144309166 = 11215237331374 := by decide
theorem cert_e2419144309166 : check e2419144309166 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2419144309174 : Closed e2419144309174 ∧ code e2419144309174 = 11215237331382 := by decide
theorem cert_e2419144309174 : check e2419144309174 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2419144309178 : Closed e2419144309178 ∧ code e2419144309178 = 11215237331386 := by decide
theorem cert_e2419144309178 : check e2419144309178 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2419144309206 : Closed e2419144309206 ∧ code e2419144309206 = 11215237331414 := by decide
theorem cert_e2419144309206 : check e2419144309206 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2419144309210 : Closed e2419144309210 ∧ code e2419144309210 = 11215237331418 := by decide
theorem cert_e2419144309210 : check e2419144309210 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2419144309226 : Closed e2419144309226 ∧ code e2419144309226 = 11215237331434 := by decide
theorem cert_e2419144309226 : check e2419144309226 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419144309262 : Closed e2419144309262 ∧ code e2419144309262 = 11215237331470 := by decide
theorem cert_e2419144309262 : check e2419144309262 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144309274 : Closed e2419144309274 ∧ code e2419144309274 = 11215237331482 := by decide
theorem cert_e2419144309274 : check e2419144309274 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419144309346 : Closed e2419144309346 ∧ code e2419144309346 = 11215237331554 := by decide
theorem cert_e2419144309346 : check e2419144309346 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144309358 : Closed e2419144309358 ∧ code e2419144309358 = 11215237331566 := by decide
theorem cert_e2419144309358 : check e2419144309358 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419144309366 : Closed e2419144309366 ∧ code e2419144309366 = 11215237331574 := by decide
theorem cert_e2419144309366 : check e2419144309366 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144309370 : Closed e2419144309370 ∧ code e2419144309370 = 11215237331578 := by decide
theorem cert_e2419144309370 : check e2419144309370 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144309558 : Closed e2419144309558 ∧ code e2419144309558 = 11215237331766 := by decide
theorem cert_e2419144309558 : check e2419144309558 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144309562 : Closed e2419144309562 ∧ code e2419144309562 = 11215237331770 := by decide
theorem cert_e2419144309562 : check e2419144309562 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144309658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419144309658 : Closed e2419144309658 ∧ code e2419144309658 = 11215237331866 := by decide
theorem cert_e2419144309658 : check e2419144309658 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2419144309974 : Closed e2419144309974 ∧ code e2419144309974 = 11215237332182 := by decide
theorem cert_e2419144309974 : check e2419144309974 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2419144309978 : Closed e2419144309978 ∧ code e2419144309978 = 11215237332186 := by decide
theorem cert_e2419144309978 : check e2419144309978 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144309994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2419144309994 : Closed e2419144309994 ∧ code e2419144309994 = 11215237332202 := by decide
theorem cert_e2419144309994 : check e2419144309994 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144310070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144310070 : Closed e2419144310070 ∧ code e2419144310070 = 11215237332278 := by decide
theorem cert_e2419144310070 : check e2419144310070 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144310074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144310074 : Closed e2419144310074 ∧ code e2419144310074 = 11215237332282 := by decide
theorem cert_e2419144310074 : check e2419144310074 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144310170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419144310170 : Closed e2419144310170 ∧ code e2419144310170 = 11215237332378 := by decide
theorem cert_e2419144310170 : check e2419144310170 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144311774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2419144311774 : Closed e2419144311774 ∧ code e2419144311774 = 11215237333982 := by decide
theorem cert_e2419144311774 : check e2419144311774 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144311790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2419144311790 : Closed e2419144311790 ∧ code e2419144311790 = 11215237333998 := by decide
theorem cert_e2419144311790 : check e2419144311790 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419144313622 : Closed e2419144313622 ∧ code e2419144313622 = 11215237335830 := by decide
theorem cert_e2419144313622 : check e2419144313622 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144313698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419144313698 : Closed e2419144313698 ∧ code e2419144313698 = 11215237335906 := by decide
theorem cert_e2419144313698 : check e2419144313698 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144313710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419144313710 : Closed e2419144313710 ∧ code e2419144313710 = 11215237335918 := by decide
theorem cert_e2419144313710 : check e2419144313710 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419144313718 : Closed e2419144313718 ∧ code e2419144313718 = 11215237335926 := by decide
theorem cert_e2419144313718 : check e2419144313718 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419144313738 : Closed e2419144313738 ∧ code e2419144313738 = 11215237335946 := by decide
theorem cert_e2419144313738 : check e2419144313738 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144313762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419144313762 : Closed e2419144313762 ∧ code e2419144313762 = 11215237335970 := by decide
theorem cert_e2419144313762 : check e2419144313762 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144313774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419144313774 : Closed e2419144313774 ∧ code e2419144313774 = 11215237335982 := by decide
theorem cert_e2419144313774 : check e2419144313774 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2419144313782 : Closed e2419144313782 ∧ code e2419144313782 = 11215237335990 := by decide
theorem cert_e2419144313782 : check e2419144313782 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144313786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419144313786 : Closed e2419144313786 ∧ code e2419144313786 = 11215237335994 := by decide
theorem cert_e2419144313786 : check e2419144313786 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419144313814 : Closed e2419144313814 ∧ code e2419144313814 = 11215237336022 := by decide
theorem cert_e2419144313814 : check e2419144313814 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419144313818 : Closed e2419144313818 ∧ code e2419144313818 = 11215237336026 := by decide
theorem cert_e2419144313818 : check e2419144313818 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144313886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2419144313886 : Closed e2419144313886 ∧ code e2419144313886 = 11215237336094 := by decide
theorem cert_e2419144313886 : check e2419144313886 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144314082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419144314082 : Closed e2419144314082 ∧ code e2419144314082 = 11215237336290 := by decide
theorem cert_e2419144314082 : check e2419144314082 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144314094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144314094 : Closed e2419144314094 ∧ code e2419144314094 = 11215237336302 := by decide
theorem cert_e2419144314094 : check e2419144314094 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144314102 : Closed e2419144314102 ∧ code e2419144314102 = 11215237336310 := by decide
theorem cert_e2419144314102 : check e2419144314102 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2419144314382 : Closed e2419144314382 ∧ code e2419144314382 = 11215237336590 := by decide
theorem cert_e2419144314382 : check e2419144314382 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144314394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419144314394 : Closed e2419144314394 ∧ code e2419144314394 = 11215237336602 := by decide
theorem cert_e2419144314394 : check e2419144314394 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419144314466 : Closed e2419144314466 ∧ code e2419144314466 = 11215237336674 := by decide
theorem cert_e2419144314466 : check e2419144314466 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144314478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144314478 : Closed e2419144314478 ∧ code e2419144314478 = 11215237336686 := by decide
theorem cert_e2419144314478 : check e2419144314478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419144314486 : Closed e2419144314486 ∧ code e2419144314486 = 11215237336694 := by decide
theorem cert_e2419144314486 : check e2419144314486 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144314490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144314490 : Closed e2419144314490 ∧ code e2419144314490 = 11215237336698 := by decide
theorem cert_e2419144314490 : check e2419144314490 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419144314678 : Closed e2419144314678 ∧ code e2419144314678 = 11215237336886 := by decide
theorem cert_e2419144314678 : check e2419144314678 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144314682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419144314682 : Closed e2419144314682 ∧ code e2419144314682 = 11215237336890 := by decide
theorem cert_e2419144314682 : check e2419144314682 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144319454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2419144319454 : Closed e2419144319454 ∧ code e2419144319454 = 11215237341662 := by decide
theorem cert_e2419144319454 : check e2419144319454 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144319478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2419144319478 : Closed e2419144319478 ∧ code e2419144319478 = 11215237341686 := by decide
theorem cert_e2419144319478 : check e2419144319478 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419144320394 : Closed e2419144320394 ∧ code e2419144320394 = 11215237342602 := by decide
theorem cert_e2419144320394 : check e2419144320394 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419144320418 : Closed e2419144320418 ∧ code e2419144320418 = 11215237342626 := by decide
theorem cert_e2419144320418 : check e2419144320418 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2419144320430 : Closed e2419144320430 ∧ code e2419144320430 = 11215237342638 := by decide
theorem cert_e2419144320430 : check e2419144320430 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2419144320438 : Closed e2419144320438 ∧ code e2419144320438 = 11215237342646 := by decide
theorem cert_e2419144320438 : check e2419144320438 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2419144320442 : Closed e2419144320442 ∧ code e2419144320442 = 11215237342650 := by decide
theorem cert_e2419144320442 : check e2419144320442 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2419144320470 : Closed e2419144320470 ∧ code e2419144320470 = 11215237342678 := by decide
theorem cert_e2419144320470 : check e2419144320470 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2419144320474 : Closed e2419144320474 ∧ code e2419144320474 = 11215237342682 := by decide
theorem cert_e2419144320474 : check e2419144320474 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2419144320490 : Closed e2419144320490 ∧ code e2419144320490 = 11215237342698 := by decide
theorem cert_e2419144320490 : check e2419144320490 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2419144320526 : Closed e2419144320526 ∧ code e2419144320526 = 11215237342734 := by decide
theorem cert_e2419144320526 : check e2419144320526 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419144320538 : Closed e2419144320538 ∧ code e2419144320538 = 11215237342746 := by decide
theorem cert_e2419144320538 : check e2419144320538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419144320610 : Closed e2419144320610 ∧ code e2419144320610 = 11215237342818 := by decide
theorem cert_e2419144320610 : check e2419144320610 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144320622 : Closed e2419144320622 ∧ code e2419144320622 = 11215237342830 := by decide
theorem cert_e2419144320622 : check e2419144320622 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419144320630 : Closed e2419144320630 ∧ code e2419144320630 = 11215237342838 := by decide
theorem cert_e2419144320630 : check e2419144320630 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144320634 : Closed e2419144320634 ∧ code e2419144320634 = 11215237342842 := by decide
theorem cert_e2419144320634 : check e2419144320634 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144320822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419144320822 : Closed e2419144320822 ∧ code e2419144320822 = 11215237343030 := by decide
theorem cert_e2419144320822 : check e2419144320822 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419144320826 : Closed e2419144320826 ∧ code e2419144320826 = 11215237343034 := by decide
theorem cert_e2419144320826 : check e2419144320826 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144320922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144320922 : Closed e2419144320922 ∧ code e2419144320922 = 11215237343130 := by decide
theorem cert_e2419144320922 : check e2419144320922 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144323310 : Closed e2419144323310 ∧ code e2419144323310 = 11215237345518 := by decide
theorem cert_e2419144323310 : check e2419144323310 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144323318 : Closed e2419144323318 ∧ code e2419144323318 = 11215237345526 := by decide
theorem cert_e2419144323318 : check e2419144323318 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2419144323798 : Closed e2419144323798 ∧ code e2419144323798 = 11215237346006 := by decide
theorem cert_e2419144323798 : check e2419144323798 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2419144323802 : Closed e2419144323802 ∧ code e2419144323802 = 11215237346010 := by decide
theorem cert_e2419144323802 : check e2419144323802 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2419144323818 : Closed e2419144323818 ∧ code e2419144323818 = 11215237346026 := by decide
theorem cert_e2419144323818 : check e2419144323818 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419144323894 : Closed e2419144323894 ∧ code e2419144323894 = 11215237346102 := by decide
theorem cert_e2419144323894 : check e2419144323894 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419144323898 : Closed e2419144323898 ∧ code e2419144323898 = 11215237346106 := by decide
theorem cert_e2419144323898 : check e2419144323898 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144323994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144323994 : Closed e2419144323994 ∧ code e2419144323994 = 11215237346202 := by decide
theorem cert_e2419144323994 : check e2419144323994 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419149572974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419149572974 : Closed e2419149572974 ∧ code e2419149572974 = 11215242595182 := by decide
theorem cert_e2419149572974 : check e2419149572974 [[],[],[.under],[.under],[.under,.left]] .sourceHead = true := by decide
def e2419149572982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419149572982 : Closed e2419149572982 ∧ code e2419149572982 = 11215242595190 := by decide
private def t_e2419149572982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2419149572982 : ¬ IsSelfInterpreter e2419149572982 :=
  wSource (t := t_e2419149572982) (replay_sound (ps := []) (t := e2419149572982) (by decide)) (by decide)
def e2419149573038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419149573038 : Closed e2419149573038 ∧ code e2419149573038 = 11215242595246 := by decide
theorem cert_e2419149573038 : check e2419149573038 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e2419149573050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419149573050 : Closed e2419149573050 ∧ code e2419149573050 = 11215242595258 := by decide
theorem cert_e2419149573050 : check e2419149573050 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e2419149573078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419149573078 : Closed e2419149573078 ∧ code e2419149573078 = 11215242595286 := by decide
private def t_e2419149573078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2419149573078 : ¬ IsSelfInterpreter e2419149573078 :=
  wSource (t := t_e2419149573078) (replay_sound (ps := []) (t := e2419149573078) (by decide)) (by decide)
def e2419149573082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419149573082 : Closed e2419149573082 ∧ code e2419149573082 = 11215242595290 := by decide
theorem cert_e2419149573082 : check e2419149573082 [[],[],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2419149573358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419149573358 : Closed e2419149573358 ∧ code e2419149573358 = 11215242595566 := by decide
theorem cert_e2419149573358 : check e2419149573358 [[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e2419149573366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419149573366 : Closed e2419149573366 ∧ code e2419149573366 = 11215242595574 := by decide
theorem cert_e2419149573366 : check e2419149573366 [[],[],[.under],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2419149573742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419149573742 : Closed e2419149573742 ∧ code e2419149573742 = 11215242595950 := by decide
theorem cert_e2419149573742 : check e2419149573742 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e2419149573754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419149573754 : Closed e2419149573754 ∧ code e2419149573754 = 11215242595962 := by decide
theorem cert_e2419149573754 : check e2419149573754 [[],[],[.under],[.under]] .sourceHead = true := by decide
def e2419149573942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419149573942 : Closed e2419149573942 ∧ code e2419149573942 = 11215242596150 := by decide
def e2419149573946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419149573946 : Closed e2419149573946 ∧ code e2419149573946 = 11215242596154 := by decide
theorem cert_e2419149573946 : check e2419149573946 [[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under],[.under],[.under,.under],[.under,.under]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419144273838
#print axioms Blc.Floor43.cert_e2419149572982
#print axioms Blc.Floor43.cert_e2419149573078
