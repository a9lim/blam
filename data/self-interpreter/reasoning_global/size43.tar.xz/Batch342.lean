import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419140519802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2419140519802 : Closed e2419140519802 ∧ code e2419140519802 = 11215233542010 := by decide
theorem cert_e2419140519802 : check e2419140519802 [[],[]] .smaller = true := by decide
def e2419140519854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2419140519854 : Closed e2419140519854 ∧ code e2419140519854 = 11215233542062 := by decide
theorem cert_e2419140519854 : check e2419140519854 [[],[]] .smaller = true := by decide
def e2419140519866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2419140519866 : Closed e2419140519866 ∧ code e2419140519866 = 11215233542074 := by decide
theorem cert_e2419140519866 : check e2419140519866 [[],[]] .smaller = true := by decide
def e2419140519894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2419140519894 : Closed e2419140519894 ∧ code e2419140519894 = 11215233542102 := by decide
theorem cert_e2419140519894 : check e2419140519894 [[],[]] .smaller = true := by decide
def e2419140519898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2419140519898 : Closed e2419140519898 ∧ code e2419140519898 = 11215233542106 := by decide
theorem cert_e2419140519898 : check e2419140519898 [[],[]] .smaller = true := by decide
def e2419140519914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0))))))))
theorem wire_e2419140519914 : Closed e2419140519914 ∧ code e2419140519914 = 11215233542122 := by decide
theorem cert_e2419140519914 : check e2419140519914 [[],[]] .three = true := by decide
def e2419140520382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2419140520382 : Closed e2419140520382 ∧ code e2419140520382 = 11215233542590 := by decide
theorem cert_e2419140520382 : check e2419140520382 [[],[]] .three = true := by decide
def e2419140520414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419140520414 : Closed e2419140520414 ∧ code e2419140520414 = 11215233542622 := by decide
theorem cert_e2419140520414 : check e2419140520414 [[],[]] .smaller = true := by decide
def e2419140520430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419140520430 : Closed e2419140520430 ∧ code e2419140520430 = 11215233542638 := by decide
theorem cert_e2419140520430 : check e2419140520430 [[],[]] .smaller = true := by decide
def e2419140520438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419140520438 : Closed e2419140520438 ∧ code e2419140520438 = 11215233542646 := by decide
theorem cert_e2419140520438 : check e2419140520438 [[],[]] .smaller = true := by decide
def e2419140520442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2419140520442 : Closed e2419140520442 ∧ code e2419140520442 = 11215233542650 := by decide
theorem cert_e2419140520442 : check e2419140520442 [[],[]] .three = true := by decide
def e2419140521182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419140521182 : Closed e2419140521182 ∧ code e2419140521182 = 11215233543390 := by decide
theorem cert_e2419140521182 : check e2419140521182 [[],[]] .smaller = true := by decide
def e2419140521210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419140521210 : Closed e2419140521210 ∧ code e2419140521210 = 11215233543418 := by decide
theorem cert_e2419140521210 : check e2419140521210 [[],[]] .smaller = true := by decide
def e2419140521582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419140521582 : Closed e2419140521582 ∧ code e2419140521582 = 11215233543790 := by decide
theorem cert_e2419140521582 : check e2419140521582 [[],[]] .smaller = true := by decide
def e2419140521594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419140521594 : Closed e2419140521594 ∧ code e2419140521594 = 11215233543802 := by decide
theorem cert_e2419140521594 : check e2419140521594 [[],[]] .smaller = true := by decide
def e2419140521782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419140521782 : Closed e2419140521782 ∧ code e2419140521782 = 11215233543990 := by decide
theorem cert_e2419140521782 : check e2419140521782 [[],[]] .smaller = true := by decide
def e2419140521786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419140521786 : Closed e2419140521786 ∧ code e2419140521786 = 11215233543994 := by decide
theorem cert_e2419140521786 : check e2419140521786 [[],[]] .smaller = true := by decide
def e2419140521882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419140521882 : Closed e2419140521882 ∧ code e2419140521882 = 11215233544090 := by decide
theorem cert_e2419140521882 : check e2419140521882 [[],[]] .three = true := by decide
def e2419140522846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2419140522846 : Closed e2419140522846 ∧ code e2419140522846 = 11215233545054 := by decide
theorem cert_e2419140522846 : check e2419140522846 [[],[]] .smaller = true := by decide
def e2419140522862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2419140522862 : Closed e2419140522862 ∧ code e2419140522862 = 11215233545070 := by decide
theorem cert_e2419140522862 : check e2419140522862 [[],[]] .smaller = true := by decide
def e2419140522870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2419140522870 : Closed e2419140522870 ∧ code e2419140522870 = 11215233545078 := by decide
theorem cert_e2419140522870 : check e2419140522870 [[],[]] .smaller = true := by decide
def e2419140522874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2419140522874 : Closed e2419140522874 ∧ code e2419140522874 = 11215233545082 := by decide
theorem cert_e2419140522874 : check e2419140522874 [[],[]] .smaller = true := by decide
def e2419140522926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2419140522926 : Closed e2419140522926 ∧ code e2419140522926 = 11215233545134 := by decide
theorem cert_e2419140522926 : check e2419140522926 [[],[]] .smaller = true := by decide
def e2419140522938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2419140522938 : Closed e2419140522938 ∧ code e2419140522938 = 11215233545146 := by decide
theorem cert_e2419140522938 : check e2419140522938 [[],[]] .smaller = true := by decide
def e2419140522966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2419140522966 : Closed e2419140522966 ∧ code e2419140522966 = 11215233545174 := by decide
theorem cert_e2419140522966 : check e2419140522966 [[],[]] .smaller = true := by decide
def e2419140522970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2419140522970 : Closed e2419140522970 ∧ code e2419140522970 = 11215233545178 := by decide
theorem cert_e2419140522970 : check e2419140522970 [[],[]] .smaller = true := by decide
def e2419140522986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2419140522986 : Closed e2419140522986 ∧ code e2419140522986 = 11215233545194 := by decide
theorem cert_e2419140522986 : check e2419140522986 [[],[]] .smaller = true := by decide
def e2419140523230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419140523230 : Closed e2419140523230 ∧ code e2419140523230 = 11215233545438 := by decide
theorem cert_e2419140523230 : check e2419140523230 [[],[]] .smaller = true := by decide
def e2419140523246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419140523246 : Closed e2419140523246 ∧ code e2419140523246 = 11215233545454 := by decide
theorem cert_e2419140523246 : check e2419140523246 [[],[]] .smaller = true := by decide
def e2419140523254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419140523254 : Closed e2419140523254 ∧ code e2419140523254 = 11215233545462 := by decide
theorem cert_e2419140523254 : check e2419140523254 [[],[]] .smaller = true := by decide
def e2419140523258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419140523258 : Closed e2419140523258 ∧ code e2419140523258 = 11215233545466 := by decide
theorem cert_e2419140523258 : check e2419140523258 [[],[]] .smaller = true := by decide
def e2419140523630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419140523630 : Closed e2419140523630 ∧ code e2419140523630 = 11215233545838 := by decide
theorem cert_e2419140523630 : check e2419140523630 [[],[]] .smaller = true := by decide
def e2419140523642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419140523642 : Closed e2419140523642 ∧ code e2419140523642 = 11215233545850 := by decide
theorem cert_e2419140523642 : check e2419140523642 [[],[]] .smaller = true := by decide
def e2419140523830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419140523830 : Closed e2419140523830 ∧ code e2419140523830 = 11215233546038 := by decide
theorem cert_e2419140523830 : check e2419140523830 [[],[]] .smaller = true := by decide
def e2419140523834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419140523834 : Closed e2419140523834 ∧ code e2419140523834 = 11215233546042 := by decide
theorem cert_e2419140523834 : check e2419140523834 [[],[]] .smaller = true := by decide
def e2419140523930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419140523930 : Closed e2419140523930 ∧ code e2419140523930 = 11215233546138 := by decide
theorem cert_e2419140523930 : check e2419140523930 [[],[]] .smaller = true := by decide
def e2419140524462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2419140524462 : Closed e2419140524462 ∧ code e2419140524462 = 11215233546670 := by decide
theorem cert_e2419140524462 : check e2419140524462 [[],[]] .smaller = true := by decide
def e2419140524470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2419140524470 : Closed e2419140524470 ∧ code e2419140524470 = 11215233546678 := by decide
theorem cert_e2419140524470 : check e2419140524470 [[],[]] .smaller = true := by decide
def e2419140524474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2419140524474 : Closed e2419140524474 ∧ code e2419140524474 = 11215233546682 := by decide
theorem cert_e2419140524474 : check e2419140524474 [[],[]] .smaller = true := by decide
def e2419140524502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2419140524502 : Closed e2419140524502 ∧ code e2419140524502 = 11215233546710 := by decide
theorem cert_e2419140524502 : check e2419140524502 [[],[]] .smaller = true := by decide
def e2419140524506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2419140524506 : Closed e2419140524506 ∧ code e2419140524506 = 11215233546714 := by decide
theorem cert_e2419140524506 : check e2419140524506 [[],[]] .smaller = true := by decide
def e2419140524522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2419140524522 : Closed e2419140524522 ∧ code e2419140524522 = 11215233546730 := by decide
theorem cert_e2419140524522 : check e2419140524522 [[],[]] .smaller = true := by decide
def e2419140524654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419140524654 : Closed e2419140524654 ∧ code e2419140524654 = 11215233546862 := by decide
theorem cert_e2419140524654 : check e2419140524654 [[],[]] .smaller = true := by decide
def e2419140524662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419140524662 : Closed e2419140524662 ∧ code e2419140524662 = 11215233546870 := by decide
theorem cert_e2419140524662 : check e2419140524662 [[],[]] .smaller = true := by decide
def e2419140524666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419140524666 : Closed e2419140524666 ∧ code e2419140524666 = 11215233546874 := by decide
theorem cert_e2419140524666 : check e2419140524666 [[],[]] .smaller = true := by decide
def e2419140524854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419140524854 : Closed e2419140524854 ∧ code e2419140524854 = 11215233547062 := by decide
theorem cert_e2419140524854 : check e2419140524854 [[],[]] .smaller = true := by decide
def e2419140524858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419140524858 : Closed e2419140524858 ∧ code e2419140524858 = 11215233547066 := by decide
theorem cert_e2419140524858 : check e2419140524858 [[],[]] .smaller = true := by decide
def e2419140524954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419140524954 : Closed e2419140524954 ∧ code e2419140524954 = 11215233547162 := by decide
theorem cert_e2419140524954 : check e2419140524954 [[],[]] .smaller = true := by decide
def e2419140525270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2419140525270 : Closed e2419140525270 ∧ code e2419140525270 = 11215233547478 := by decide
theorem cert_e2419140525270 : check e2419140525270 [[],[]] .three = true := by decide
def e2419140525274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2419140525274 : Closed e2419140525274 ∧ code e2419140525274 = 11215233547482 := by decide
theorem cert_e2419140525274 : check e2419140525274 [[],[]] .three = true := by decide
def e2419140525290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2419140525290 : Closed e2419140525290 ∧ code e2419140525290 = 11215233547498 := by decide
theorem cert_e2419140525290 : check e2419140525290 [[],[]] .three = true := by decide
def e2419140525366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419140525366 : Closed e2419140525366 ∧ code e2419140525366 = 11215233547574 := by decide
theorem cert_e2419140525366 : check e2419140525366 [[],[]] .three = true := by decide
def e2419140525370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419140525370 : Closed e2419140525370 ∧ code e2419140525370 = 11215233547578 := by decide
theorem cert_e2419140525370 : check e2419140525370 [[],[]] .three = true := by decide
def e2419140525466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419140525466 : Closed e2419140525466 ∧ code e2419140525466 = 11215233547674 := by decide
theorem cert_e2419140525466 : check e2419140525466 [[],[]] .three = true := by decide
def e2419140529006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2419140529006 : Closed e2419140529006 ∧ code e2419140529006 = 11215233551214 := by decide
theorem cert_e2419140529006 : check e2419140529006 [[],[]] .smaller = true := by decide
def e2419140529014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2419140529014 : Closed e2419140529014 ∧ code e2419140529014 = 11215233551222 := by decide
theorem cert_e2419140529014 : check e2419140529014 [[],[]] .smaller = true := by decide
def e2419140529070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2419140529070 : Closed e2419140529070 ∧ code e2419140529070 = 11215233551278 := by decide
theorem cert_e2419140529070 : check e2419140529070 [[],[]] .smaller = true := by decide
def e2419140529082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2419140529082 : Closed e2419140529082 ∧ code e2419140529082 = 11215233551290 := by decide
theorem cert_e2419140529082 : check e2419140529082 [[],[]] .smaller = true := by decide
def e2419140529110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2419140529110 : Closed e2419140529110 ∧ code e2419140529110 = 11215233551318 := by decide
theorem cert_e2419140529110 : check e2419140529110 [[],[]] .smaller = true := by decide
def e2419140529114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2419140529114 : Closed e2419140529114 ∧ code e2419140529114 = 11215233551322 := by decide
theorem cert_e2419140529114 : check e2419140529114 [[],[]] .smaller = true := by decide
def e2419140529390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2419140529390 : Closed e2419140529390 ∧ code e2419140529390 = 11215233551598 := by decide
theorem cert_e2419140529390 : check e2419140529390 [[],[]] .smaller = true := by decide
def e2419140529398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2419140529398 : Closed e2419140529398 ∧ code e2419140529398 = 11215233551606 := by decide
theorem cert_e2419140529398 : check e2419140529398 [[],[]] .smaller = true := by decide
def e2419140529774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2419140529774 : Closed e2419140529774 ∧ code e2419140529774 = 11215233551982 := by decide
theorem cert_e2419140529774 : check e2419140529774 [[],[]] .smaller = true := by decide
def e2419140529786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2419140529786 : Closed e2419140529786 ∧ code e2419140529786 = 11215233551994 := by decide
theorem cert_e2419140529786 : check e2419140529786 [[],[]] .smaller = true := by decide
def e2419140529974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2419140529974 : Closed e2419140529974 ∧ code e2419140529974 = 11215233552182 := by decide
theorem cert_e2419140529974 : check e2419140529974 [[],[]] .smaller = true := by decide
def e2419140529978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2419140529978 : Closed e2419140529978 ∧ code e2419140529978 = 11215233552186 := by decide
theorem cert_e2419140529978 : check e2419140529978 [[],[]] .smaller = true := by decide
def e2419140537790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2419140537790 : Closed e2419140537790 ∧ code e2419140537790 = 11215233559998 := by decide
theorem cert_e2419140537790 : check e2419140537790 [[],[]] .three = true := by decide
def e2419140537822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2419140537822 : Closed e2419140537822 ∧ code e2419140537822 = 11215233560030 := by decide
theorem cert_e2419140537822 : check e2419140537822 [[],[]] .smaller = true := by decide
def e2419140537838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2419140537838 : Closed e2419140537838 ∧ code e2419140537838 = 11215233560046 := by decide
theorem cert_e2419140537838 : check e2419140537838 [[],[]] .smaller = true := by decide
def e2419140537846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2419140537846 : Closed e2419140537846 ∧ code e2419140537846 = 11215233560054 := by decide
theorem cert_e2419140537846 : check e2419140537846 [[],[]] .three = true := by decide
def e2419140538046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2419140538046 : Closed e2419140538046 ∧ code e2419140538046 = 11215233560254 := by decide
theorem cert_e2419140538046 : check e2419140538046 [[],[]] .three = true := by decide
def e2419140538078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2419140538078 : Closed e2419140538078 ∧ code e2419140538078 = 11215233560286 := by decide
theorem cert_e2419140538078 : check e2419140538078 [[],[]] .smaller = true := by decide
def e2419140538094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2419140538094 : Closed e2419140538094 ∧ code e2419140538094 = 11215233560302 := by decide
theorem cert_e2419140538094 : check e2419140538094 [[],[]] .smaller = true := by decide
def e2419140538102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2419140538102 : Closed e2419140538102 ∧ code e2419140538102 = 11215233560310 := by decide
theorem cert_e2419140538102 : check e2419140538102 [[],[]] .smaller = true := by decide
def e2419140538106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2419140538106 : Closed e2419140538106 ∧ code e2419140538106 = 11215233560314 := by decide
theorem cert_e2419140538106 : check e2419140538106 [[],[]] .three = true := by decide
def e2419140538206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2419140538206 : Closed e2419140538206 ∧ code e2419140538206 = 11215233560414 := by decide
theorem cert_e2419140538206 : check e2419140538206 [[],[]] .smaller = true := by decide
def e2419140538222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2419140538222 : Closed e2419140538222 ∧ code e2419140538222 = 11215233560430 := by decide
theorem cert_e2419140538222 : check e2419140538222 [[],[]] .smaller = true := by decide
def e2419140538230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2419140538230 : Closed e2419140538230 ∧ code e2419140538230 = 11215233560438 := by decide
theorem cert_e2419140538230 : check e2419140538230 [[],[]] .smaller = true := by decide
def e2419140538234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2419140538234 : Closed e2419140538234 ∧ code e2419140538234 = 11215233560442 := by decide
theorem cert_e2419140538234 : check e2419140538234 [[],[]] .smaller = true := by decide
def e2419140538286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2419140538286 : Closed e2419140538286 ∧ code e2419140538286 = 11215233560494 := by decide
theorem cert_e2419140538286 : check e2419140538286 [[],[]] .smaller = true := by decide
def e2419140538294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2419140538294 : Closed e2419140538294 ∧ code e2419140538294 = 11215233560502 := by decide
theorem cert_e2419140538294 : check e2419140538294 [[],[]] .smaller = true := by decide
def e2419140538298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2419140538298 : Closed e2419140538298 ∧ code e2419140538298 = 11215233560506 := by decide
theorem cert_e2419140538298 : check e2419140538298 [[],[]] .smaller = true := by decide
def e2419140538326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2419140538326 : Closed e2419140538326 ∧ code e2419140538326 = 11215233560534 := by decide
theorem cert_e2419140538326 : check e2419140538326 [[],[]] .three = true := by decide
def e2419140538330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2419140538330 : Closed e2419140538330 ∧ code e2419140538330 = 11215233560538 := by decide
theorem cert_e2419140538330 : check e2419140538330 [[],[]] .three = true := by decide
def e2419140539326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2419140539326 : Closed e2419140539326 ∧ code e2419140539326 = 11215233561534 := by decide
theorem cert_e2419140539326 : check e2419140539326 [[],[]] .three = true := by decide
def e2419140539358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2419140539358 : Closed e2419140539358 ∧ code e2419140539358 = 11215233561566 := by decide
theorem cert_e2419140539358 : check e2419140539358 [[],[]] .smaller = true := by decide
def e2419140539374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2419140539374 : Closed e2419140539374 ∧ code e2419140539374 = 11215233561582 := by decide
theorem cert_e2419140539374 : check e2419140539374 [[],[]] .smaller = true := by decide
def e2419140539382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2419140539382 : Closed e2419140539382 ∧ code e2419140539382 = 11215233561590 := by decide
theorem cert_e2419140539382 : check e2419140539382 [[],[]] .three = true := by decide
def e2419140540862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2419140540862 : Closed e2419140540862 ∧ code e2419140540862 = 11215233563070 := by decide
theorem cert_e2419140540862 : check e2419140540862 [[],[]] .three = true := by decide
def e2419140540894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2419140540894 : Closed e2419140540894 ∧ code e2419140540894 = 11215233563102 := by decide
theorem cert_e2419140540894 : check e2419140540894 [[],[]] .smaller = true := by decide
def e2419140540910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2419140540910 : Closed e2419140540910 ∧ code e2419140540910 = 11215233563118 := by decide
theorem cert_e2419140540910 : check e2419140540910 [[],[]] .smaller = true := by decide
def e2419140540918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2419140540918 : Closed e2419140540918 ∧ code e2419140540918 = 11215233563126 := by decide
theorem cert_e2419140540918 : check e2419140540918 [[],[]] .smaller = true := by decide
def e2419140540922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2419140540922 : Closed e2419140540922 ∧ code e2419140540922 = 11215233563130 := by decide
theorem cert_e2419140540922 : check e2419140540922 [[],[]] .three = true := by decide
def e2419140541662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419140541662 : Closed e2419140541662 ∧ code e2419140541662 = 11215233563870 := by decide
theorem cert_e2419140541662 : check e2419140541662 [[],[]] .smaller = true := by decide
def e2419140541678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419140541678 : Closed e2419140541678 ∧ code e2419140541678 = 11215233563886 := by decide
theorem cert_e2419140541678 : check e2419140541678 [[],[]] .smaller = true := by decide
def e2419140541686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419140541686 : Closed e2419140541686 ∧ code e2419140541686 = 11215233563894 := by decide
theorem cert_e2419140541686 : check e2419140541686 [[],[]] .smaller = true := by decide
def e2419140541690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419140541690 : Closed e2419140541690 ∧ code e2419140541690 = 11215233563898 := by decide
theorem cert_e2419140541690 : check e2419140541690 [[],[]] .smaller = true := by decide
def e2419140542062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140542062 : Closed e2419140542062 ∧ code e2419140542062 = 11215233564270 := by decide
theorem cert_e2419140542062 : check e2419140542062 [[],[]] .smaller = true := by decide
def e2419140542070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2419140542070 : Closed e2419140542070 ∧ code e2419140542070 = 11215233564278 := by decide
theorem cert_e2419140542070 : check e2419140542070 [[],[]] .smaller = true := by decide
def e2419140542074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140542074 : Closed e2419140542074 ∧ code e2419140542074 = 11215233564282 := by decide
theorem cert_e2419140542074 : check e2419140542074 [[],[]] .smaller = true := by decide
def e2419140542262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140542262 : Closed e2419140542262 ∧ code e2419140542262 = 11215233564470 := by decide
theorem cert_e2419140542262 : check e2419140542262 [[],[]] .three = true := by decide
def e2419140542266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140542266 : Closed e2419140542266 ∧ code e2419140542266 = 11215233564474 := by decide
theorem cert_e2419140542266 : check e2419140542266 [[],[]] .three = true := by decide
def e2419140564670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))
theorem wire_e2419140564670 : Closed e2419140564670 ∧ code e2419140564670 = 11215233586878 := by decide
theorem cert_e2419140564670 : check e2419140564670 [[],[]] .three = true := by decide
def e2419140564702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2419140564702 : Closed e2419140564702 ∧ code e2419140564702 = 11215233586910 := by decide
theorem cert_e2419140564702 : check e2419140564702 [[],[]] .smaller = true := by decide
def e2419140564718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2419140564718 : Closed e2419140564718 ∧ code e2419140564718 = 11215233586926 := by decide
theorem cert_e2419140564718 : check e2419140564718 [[],[]] .smaller = true := by decide
def e2419140564726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2419140564726 : Closed e2419140564726 ∧ code e2419140564726 = 11215233586934 := by decide
theorem cert_e2419140564726 : check e2419140564726 [[],[]] .smaller = true := by decide
def e2419140564730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))
theorem wire_e2419140564730 : Closed e2419140564730 ∧ code e2419140564730 = 11215233586938 := by decide
theorem cert_e2419140564730 : check e2419140564730 [[],[]] .three = true := by decide
def e2419140564830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2419140564830 : Closed e2419140564830 ∧ code e2419140564830 = 11215233587038 := by decide
theorem cert_e2419140564830 : check e2419140564830 [[],[]] .smaller = true := by decide
def e2419140564858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2419140564858 : Closed e2419140564858 ∧ code e2419140564858 = 11215233587066 := by decide
theorem cert_e2419140564858 : check e2419140564858 [[],[]] .smaller = true := by decide
def e2419140564910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2419140564910 : Closed e2419140564910 ∧ code e2419140564910 = 11215233587118 := by decide
theorem cert_e2419140564910 : check e2419140564910 [[],[]] .smaller = true := by decide
def e2419140564922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2419140564922 : Closed e2419140564922 ∧ code e2419140564922 = 11215233587130 := by decide
theorem cert_e2419140564922 : check e2419140564922 [[],[]] .smaller = true := by decide
def e2419140564950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2419140564950 : Closed e2419140564950 ∧ code e2419140564950 = 11215233587158 := by decide
theorem cert_e2419140564950 : check e2419140564950 [[],[]] .smaller = true := by decide
def e2419140564954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2419140564954 : Closed e2419140564954 ∧ code e2419140564954 = 11215233587162 := by decide
theorem cert_e2419140564954 : check e2419140564954 [[],[]] .smaller = true := by decide
def e2419140564970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))
theorem wire_e2419140564970 : Closed e2419140564970 ∧ code e2419140564970 = 11215233587178 := by decide
theorem cert_e2419140564970 : check e2419140564970 [[],[]] .three = true := by decide
def e2419140565438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4))))))))))
theorem wire_e2419140565438 : Closed e2419140565438 ∧ code e2419140565438 = 11215233587646 := by decide
theorem cert_e2419140565438 : check e2419140565438 [[],[]] .three = true := by decide
def e2419140565470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2419140565470 : Closed e2419140565470 ∧ code e2419140565470 = 11215233587678 := by decide
theorem cert_e2419140565470 : check e2419140565470 [[],[]] .smaller = true := by decide
def e2419140565486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2419140565486 : Closed e2419140565486 ∧ code e2419140565486 = 11215233587694 := by decide
theorem cert_e2419140565486 : check e2419140565486 [[],[]] .smaller = true := by decide
def e2419140565494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2419140565494 : Closed e2419140565494 ∧ code e2419140565494 = 11215233587702 := by decide
theorem cert_e2419140565494 : check e2419140565494 [[],[]] .smaller = true := by decide
def e2419140565498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0))))))))))
theorem wire_e2419140565498 : Closed e2419140565498 ∧ code e2419140565498 = 11215233587706 := by decide
theorem cert_e2419140565498 : check e2419140565498 [[],[]] .three = true := by decide
def e2419140566238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419140566238 : Closed e2419140566238 ∧ code e2419140566238 = 11215233588446 := by decide
theorem cert_e2419140566238 : check e2419140566238 [[],[]] .smaller = true := by decide
def e2419140566266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419140566266 : Closed e2419140566266 ∧ code e2419140566266 = 11215233588474 := by decide
theorem cert_e2419140566266 : check e2419140566266 [[],[]] .smaller = true := by decide
def e2419140566638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140566638 : Closed e2419140566638 ∧ code e2419140566638 = 11215233588846 := by decide
theorem cert_e2419140566638 : check e2419140566638 [[],[]] .smaller = true := by decide
def e2419140566650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140566650 : Closed e2419140566650 ∧ code e2419140566650 = 11215233588858 := by decide
theorem cert_e2419140566650 : check e2419140566650 [[],[]] .smaller = true := by decide
def e2419140566838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140566838 : Closed e2419140566838 ∧ code e2419140566838 = 11215233589046 := by decide
theorem cert_e2419140566838 : check e2419140566838 [[],[]] .smaller = true := by decide
def e2419140566842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140566842 : Closed e2419140566842 ∧ code e2419140566842 = 11215233589050 := by decide
theorem cert_e2419140566842 : check e2419140566842 [[],[]] .smaller = true := by decide
def e2419140566938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140566938 : Closed e2419140566938 ∧ code e2419140566938 = 11215233589146 := by decide
theorem cert_e2419140566938 : check e2419140566938 [[],[]] .three = true := by decide
def e2419140578142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2419140578142 : Closed e2419140578142 ∧ code e2419140578142 = 11215233600350 := by decide
theorem cert_e2419140578142 : check e2419140578142 [[],[]] .smaller = true := by decide
def e2419140578158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419140578158 : Closed e2419140578158 ∧ code e2419140578158 = 11215233600366 := by decide
theorem cert_e2419140578158 : check e2419140578158 [[],[]] .smaller = true := by decide
def e2419140578166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419140578166 : Closed e2419140578166 ∧ code e2419140578166 = 11215233600374 := by decide
theorem cert_e2419140578166 : check e2419140578166 [[],[]] .smaller = true := by decide
def e2419140578170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2419140578170 : Closed e2419140578170 ∧ code e2419140578170 = 11215233600378 := by decide
theorem cert_e2419140578170 : check e2419140578170 [[],[]] .smaller = true := by decide
def e2419140578222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419140578222 : Closed e2419140578222 ∧ code e2419140578222 = 11215233600430 := by decide
theorem cert_e2419140578222 : check e2419140578222 [[],[]] .smaller = true := by decide
def e2419140578234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419140578234 : Closed e2419140578234 ∧ code e2419140578234 = 11215233600442 := by decide
theorem cert_e2419140578234 : check e2419140578234 [[],[]] .smaller = true := by decide
def e2419140578262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419140578262 : Closed e2419140578262 ∧ code e2419140578262 = 11215233600470 := by decide
theorem cert_e2419140578262 : check e2419140578262 [[],[]] .smaller = true := by decide
def e2419140578266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419140578266 : Closed e2419140578266 ∧ code e2419140578266 = 11215233600474 := by decide
theorem cert_e2419140578266 : check e2419140578266 [[],[]] .smaller = true := by decide
def e2419140578282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2419140578282 : Closed e2419140578282 ∧ code e2419140578282 = 11215233600490 := by decide
theorem cert_e2419140578282 : check e2419140578282 [[],[]] .smaller = true := by decide
def e2419140578526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2419140578526 : Closed e2419140578526 ∧ code e2419140578526 = 11215233600734 := by decide
theorem cert_e2419140578526 : check e2419140578526 [[],[]] .smaller = true := by decide
def e2419140578542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419140578542 : Closed e2419140578542 ∧ code e2419140578542 = 11215233600750 := by decide
theorem cert_e2419140578542 : check e2419140578542 [[],[]] .smaller = true := by decide
def e2419140578550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419140578550 : Closed e2419140578550 ∧ code e2419140578550 = 11215233600758 := by decide
theorem cert_e2419140578550 : check e2419140578550 [[],[]] .smaller = true := by decide
def e2419140578554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2419140578554 : Closed e2419140578554 ∧ code e2419140578554 = 11215233600762 := by decide
theorem cert_e2419140578554 : check e2419140578554 [[],[]] .smaller = true := by decide
def e2419140578926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140578926 : Closed e2419140578926 ∧ code e2419140578926 = 11215233601134 := by decide
theorem cert_e2419140578926 : check e2419140578926 [[],[]] .smaller = true := by decide
def e2419140578938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140578938 : Closed e2419140578938 ∧ code e2419140578938 = 11215233601146 := by decide
theorem cert_e2419140578938 : check e2419140578938 [[],[]] .smaller = true := by decide
def e2419140579126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140579126 : Closed e2419140579126 ∧ code e2419140579126 = 11215233601334 := by decide
theorem cert_e2419140579126 : check e2419140579126 [[],[]] .smaller = true := by decide
def e2419140579130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140579130 : Closed e2419140579130 ∧ code e2419140579130 = 11215233601338 := by decide
theorem cert_e2419140579130 : check e2419140579130 [[],[]] .smaller = true := by decide
def e2419140579226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140579226 : Closed e2419140579226 ∧ code e2419140579226 = 11215233601434 := by decide
theorem cert_e2419140579226 : check e2419140579226 [[],[]] .smaller = true := by decide
def e2419140584878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2419140584878 : Closed e2419140584878 ∧ code e2419140584878 = 11215233607086 := by decide
theorem cert_e2419140584878 : check e2419140584878 [[],[]] .smaller = true := by decide
def e2419140584886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2419140584886 : Closed e2419140584886 ∧ code e2419140584886 = 11215233607094 := by decide
theorem cert_e2419140584886 : check e2419140584886 [[],[]] .smaller = true := by decide
def e2419140584890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2419140584890 : Closed e2419140584890 ∧ code e2419140584890 = 11215233607098 := by decide
theorem cert_e2419140584890 : check e2419140584890 [[],[]] .smaller = true := by decide
def e2419140584918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2419140584918 : Closed e2419140584918 ∧ code e2419140584918 = 11215233607126 := by decide
theorem cert_e2419140584918 : check e2419140584918 [[],[]] .smaller = true := by decide
def e2419140584922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2419140584922 : Closed e2419140584922 ∧ code e2419140584922 = 11215233607130 := by decide
theorem cert_e2419140584922 : check e2419140584922 [[],[]] .smaller = true := by decide
def e2419140584938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2419140584938 : Closed e2419140584938 ∧ code e2419140584938 = 11215233607146 := by decide
theorem cert_e2419140584938 : check e2419140584938 [[],[]] .smaller = true := by decide
def e2419140585070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140585070 : Closed e2419140585070 ∧ code e2419140585070 = 11215233607278 := by decide
theorem cert_e2419140585070 : check e2419140585070 [[],[]] .smaller = true := by decide
def e2419140585078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2419140585078 : Closed e2419140585078 ∧ code e2419140585078 = 11215233607286 := by decide
theorem cert_e2419140585078 : check e2419140585078 [[],[]] .smaller = true := by decide
def e2419140585082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140585082 : Closed e2419140585082 ∧ code e2419140585082 = 11215233607290 := by decide
theorem cert_e2419140585082 : check e2419140585082 [[],[]] .smaller = true := by decide
def e2419140585270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140585270 : Closed e2419140585270 ∧ code e2419140585270 = 11215233607478 := by decide
theorem cert_e2419140585270 : check e2419140585270 [[],[]] .smaller = true := by decide
def e2419140585274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140585274 : Closed e2419140585274 ∧ code e2419140585274 = 11215233607482 := by decide
theorem cert_e2419140585274 : check e2419140585274 [[],[]] .smaller = true := by decide
def e2419140585370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140585370 : Closed e2419140585370 ∧ code e2419140585370 = 11215233607578 := by decide
theorem cert_e2419140585370 : check e2419140585370 [[],[]] .smaller = true := by decide
def e2419140588246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2419140588246 : Closed e2419140588246 ∧ code e2419140588246 = 11215233610454 := by decide
theorem cert_e2419140588246 : check e2419140588246 [[],[]] .three = true := by decide
def e2419140588250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2419140588250 : Closed e2419140588250 ∧ code e2419140588250 = 11215233610458 := by decide
theorem cert_e2419140588250 : check e2419140588250 [[],[]] .three = true := by decide
def e2419140588266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2419140588266 : Closed e2419140588266 ∧ code e2419140588266 = 11215233610474 := by decide
theorem cert_e2419140588266 : check e2419140588266 [[],[]] .three = true := by decide
def e2419140588342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140588342 : Closed e2419140588342 ∧ code e2419140588342 = 11215233610550 := by decide
theorem cert_e2419140588342 : check e2419140588342 [[],[]] .three = true := by decide
end Blc.Floor43
