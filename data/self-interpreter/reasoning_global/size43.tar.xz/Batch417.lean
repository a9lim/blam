import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373582814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2422373582814 : Closed e2422373582814 ∧ code e2422373582814 = 11218466605022 := by decide
theorem cert_e2422373582814 : check e2422373582814 [[],[]] .three = true := by decide
def e2422373582830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2422373582830 : Closed e2422373582830 ∧ code e2422373582830 = 11218466605038 := by decide
theorem cert_e2422373582830 : check e2422373582830 [[],[]] .three = true := by decide
def e2422373586478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373586478 : Closed e2422373586478 ∧ code e2422373586478 = 11218466608686 := by decide
theorem cert_e2422373586478 : check e2422373586478 [[],[]] .three = true := by decide
def e2422373586486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373586486 : Closed e2422373586486 ∧ code e2422373586486 = 11218466608694 := by decide
theorem cert_e2422373586486 : check e2422373586486 [[],[]] .three = true := by decide
def e2422373586490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373586490 : Closed e2422373586490 ∧ code e2422373586490 = 11218466608698 := by decide
theorem cert_e2422373586490 : check e2422373586490 [[],[]] .three = true := by decide
def e2422373586574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373586574 : Closed e2422373586574 ∧ code e2422373586574 = 11218466608782 := by decide
theorem cert_e2422373586574 : check e2422373586574 [[],[]] .three = true := by decide
def e2422373586630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373586630 : Closed e2422373586630 ∧ code e2422373586630 = 11218466608838 := by decide
theorem cert_e2422373586630 : check e2422373586630 [[],[]] .three = true := by decide
def e2422373586654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422373586654 : Closed e2422373586654 ∧ code e2422373586654 = 11218466608862 := by decide
theorem cert_e2422373586654 : check e2422373586654 [[],[]] .three = true := by decide
def e2422373586658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373586658 : Closed e2422373586658 ∧ code e2422373586658 = 11218466608866 := by decide
theorem cert_e2422373586658 : check e2422373586658 [[],[]] .three = true := by decide
def e2422373586670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2422373586670 : Closed e2422373586670 ∧ code e2422373586670 = 11218466608878 := by decide
theorem cert_e2422373586670 : check e2422373586670 [[],[]] .three = true := by decide
def e2422373586678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422373586678 : Closed e2422373586678 ∧ code e2422373586678 = 11218466608886 := by decide
theorem cert_e2422373586678 : check e2422373586678 [[],[]] .three = true := by decide
def e2422373586710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373586710 : Closed e2422373586710 ∧ code e2422373586710 = 11218466608918 := by decide
theorem cert_e2422373586710 : check e2422373586710 [[],[]] .three = true := by decide
def e2422373586714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373586714 : Closed e2422373586714 ∧ code e2422373586714 = 11218466608922 := by decide
theorem cert_e2422373586714 : check e2422373586714 [[],[]] .three = true := by decide
def e2422373586758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373586758 : Closed e2422373586758 ∧ code e2422373586758 = 11218466608966 := by decide
theorem cert_e2422373586758 : check e2422373586758 [[],[]] .three = true := by decide
def e2422373586782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422373586782 : Closed e2422373586782 ∧ code e2422373586782 = 11218466608990 := by decide
theorem cert_e2422373586782 : check e2422373586782 [[],[]] .three = true := by decide
def e2422373586786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373586786 : Closed e2422373586786 ∧ code e2422373586786 = 11218466608994 := by decide
theorem cert_e2422373586786 : check e2422373586786 [[],[]] .three = true := by decide
def e2422373586798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2422373586798 : Closed e2422373586798 ∧ code e2422373586798 = 11218466609006 := by decide
theorem cert_e2422373586798 : check e2422373586798 [[],[]] .three = true := by decide
def e2422373586806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2422373586806 : Closed e2422373586806 ∧ code e2422373586806 = 11218466609014 := by decide
theorem cert_e2422373586806 : check e2422373586806 [[],[]] .three = true := by decide
def e2422373586810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422373586810 : Closed e2422373586810 ∧ code e2422373586810 = 11218466609018 := by decide
theorem cert_e2422373586810 : check e2422373586810 [[],[]] .three = true := by decide
def e2422373586826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373586826 : Closed e2422373586826 ∧ code e2422373586826 = 11218466609034 := by decide
theorem cert_e2422373586826 : check e2422373586826 [[],[]] .three = true := by decide
def e2422373586850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373586850 : Closed e2422373586850 ∧ code e2422373586850 = 11218466609058 := by decide
theorem cert_e2422373586850 : check e2422373586850 [[],[]] .three = true := by decide
def e2422373586862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2422373586862 : Closed e2422373586862 ∧ code e2422373586862 = 11218466609070 := by decide
theorem cert_e2422373586862 : check e2422373586862 [[],[]] .three = true := by decide
def e2422373586870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2422373586870 : Closed e2422373586870 ∧ code e2422373586870 = 11218466609078 := by decide
theorem cert_e2422373586870 : check e2422373586870 [[],[]] .three = true := by decide
def e2422373586874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2422373586874 : Closed e2422373586874 ∧ code e2422373586874 = 11218466609082 := by decide
theorem cert_e2422373586874 : check e2422373586874 [[],[]] .three = true := by decide
def e2422373586902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422373586902 : Closed e2422373586902 ∧ code e2422373586902 = 11218466609110 := by decide
theorem cert_e2422373586902 : check e2422373586902 [[],[]] .three = true := by decide
def e2422373586906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422373586906 : Closed e2422373586906 ∧ code e2422373586906 = 11218466609114 := by decide
theorem cert_e2422373586906 : check e2422373586906 [[],[]] .three = true := by decide
def e2422373587006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373587006 : Closed e2422373587006 ∧ code e2422373587006 = 11218466609214 := by decide
theorem cert_e2422373587006 : check e2422373587006 [[],[]] .three = true := by decide
def e2422373587054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373587054 : Closed e2422373587054 ∧ code e2422373587054 = 11218466609262 := by decide
theorem cert_e2422373587054 : check e2422373587054 [[],[]] .three = true := by decide
def e2422373587066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373587066 : Closed e2422373587066 ∧ code e2422373587066 = 11218466609274 := by decide
theorem cert_e2422373587066 : check e2422373587066 [[],[]] .three = true := by decide
def e2422373587342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373587342 : Closed e2422373587342 ∧ code e2422373587342 = 11218466609550 := by decide
theorem cert_e2422373587342 : check e2422373587342 [[],[]] .three = true := by decide
def e2422373587398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373587398 : Closed e2422373587398 ∧ code e2422373587398 = 11218466609606 := by decide
theorem cert_e2422373587398 : check e2422373587398 [[],[]] .three = true := by decide
def e2422373587422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373587422 : Closed e2422373587422 ∧ code e2422373587422 = 11218466609630 := by decide
theorem cert_e2422373587422 : check e2422373587422 [[],[]] .three = true := by decide
def e2422373587426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373587426 : Closed e2422373587426 ∧ code e2422373587426 = 11218466609634 := by decide
theorem cert_e2422373587426 : check e2422373587426 [[],[]] .three = true := by decide
def e2422373587438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373587438 : Closed e2422373587438 ∧ code e2422373587438 = 11218466609646 := by decide
theorem cert_e2422373587438 : check e2422373587438 [[],[]] .three = true := by decide
def e2422373587446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373587446 : Closed e2422373587446 ∧ code e2422373587446 = 11218466609654 := by decide
theorem cert_e2422373587446 : check e2422373587446 [[],[]] .three = true := by decide
def e2422373587998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373587998 : Closed e2422373587998 ∧ code e2422373587998 = 11218466610206 := by decide
theorem cert_e2422373587998 : check e2422373587998 [[],[]] .three = true := by decide
def e2422373588022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373588022 : Closed e2422373588022 ∧ code e2422373588022 = 11218466610230 := by decide
theorem cert_e2422373588022 : check e2422373588022 [[],[]] .three = true := by decide
def e2422373588026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373588026 : Closed e2422373588026 ∧ code e2422373588026 = 11218466610234 := by decide
theorem cert_e2422373588026 : check e2422373588026 [[],[]] .three = true := by decide
def e2422373588166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373588166 : Closed e2422373588166 ∧ code e2422373588166 = 11218466610374 := by decide
theorem cert_e2422373588166 : check e2422373588166 [[],[]] .three = true := by decide
def e2422373588190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373588190 : Closed e2422373588190 ∧ code e2422373588190 = 11218466610398 := by decide
theorem cert_e2422373588190 : check e2422373588190 [[],[]] .three = true := by decide
def e2422373588194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373588194 : Closed e2422373588194 ∧ code e2422373588194 = 11218466610402 := by decide
theorem cert_e2422373588194 : check e2422373588194 [[],[]] .three = true := by decide
def e2422373588206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373588206 : Closed e2422373588206 ∧ code e2422373588206 = 11218466610414 := by decide
theorem cert_e2422373588206 : check e2422373588206 [[],[]] .three = true := by decide
def e2422373588214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373588214 : Closed e2422373588214 ∧ code e2422373588214 = 11218466610422 := by decide
theorem cert_e2422373588214 : check e2422373588214 [[],[]] .three = true := by decide
def e2422373588218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373588218 : Closed e2422373588218 ∧ code e2422373588218 = 11218466610426 := by decide
theorem cert_e2422373588218 : check e2422373588218 [[],[]] .three = true := by decide
def e2422373588494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373588494 : Closed e2422373588494 ∧ code e2422373588494 = 11218466610702 := by decide
theorem cert_e2422373588494 : check e2422373588494 [[],[]] .three = true := by decide
def e2422373588506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373588506 : Closed e2422373588506 ∧ code e2422373588506 = 11218466610714 := by decide
theorem cert_e2422373588506 : check e2422373588506 [[],[]] .three = true := by decide
def e2422373588542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422373588542 : Closed e2422373588542 ∧ code e2422373588542 = 11218466610750 := by decide
theorem cert_e2422373588542 : check e2422373588542 [[],[]] .three = true := by decide
def e2422373588578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373588578 : Closed e2422373588578 ∧ code e2422373588578 = 11218466610786 := by decide
theorem cert_e2422373588578 : check e2422373588578 [[],[]] .three = true := by decide
def e2422373588590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373588590 : Closed e2422373588590 ∧ code e2422373588590 = 11218466610798 := by decide
theorem cert_e2422373588590 : check e2422373588590 [[],[]] .three = true := by decide
def e2422373588598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373588598 : Closed e2422373588598 ∧ code e2422373588598 = 11218466610806 := by decide
theorem cert_e2422373588598 : check e2422373588598 [[],[]] .three = true := by decide
def e2422373588602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373588602 : Closed e2422373588602 ∧ code e2422373588602 = 11218466610810 := by decide
theorem cert_e2422373588602 : check e2422373588602 [[],[]] .three = true := by decide
def e2422373588766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422373588766 : Closed e2422373588766 ∧ code e2422373588766 = 11218466610974 := by decide
theorem cert_e2422373588766 : check e2422373588766 [[],[]] .three = true := by decide
def e2422373588790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373588790 : Closed e2422373588790 ∧ code e2422373588790 = 11218466610998 := by decide
theorem cert_e2422373588790 : check e2422373588790 [[],[]] .three = true := by decide
def e2422373588794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373588794 : Closed e2422373588794 ∧ code e2422373588794 = 11218466611002 := by decide
theorem cert_e2422373588794 : check e2422373588794 [[],[]] .three = true := by decide
def e2422373620334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373620334 : Closed e2422373620334 ∧ code e2422373620334 = 11218466642542 := by decide
theorem cert_e2422373620334 : check e2422373620334 [[],[]] .smaller = true := by decide
def e2422373620346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373620346 : Closed e2422373620346 ∧ code e2422373620346 = 11218466642554 := by decide
theorem cert_e2422373620346 : check e2422373620346 [[],[]] .smaller = true := by decide
def e2422373621486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 2)))))))
theorem wire_e2422373621486 : Closed e2422373621486 ∧ code e2422373621486 = 11218466643694 := by decide
theorem cert_e2422373621486 : check e2422373621486 [[],[]] .smaller = true := by decide
def e2422373621498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 4))))) (.var 0)))))))
theorem wire_e2422373621498 : Closed e2422373621498 ∧ code e2422373621498 = 11218466643706 := by decide
theorem cert_e2422373621498 : check e2422373621498 [[],[]] .smaller = true := by decide
def e2422373621690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 2))))) (.var 0)))))))
theorem wire_e2422373621690 : Closed e2422373621690 ∧ code e2422373621690 = 11218466643898 := by decide
theorem cert_e2422373621690 : check e2422373621690 [[],[]] .smaller = true := by decide
def e2422373623214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373623214 : Closed e2422373623214 ∧ code e2422373623214 = 11218466645422 := by decide
theorem cert_e2422373623214 : check e2422373623214 [[],[]] .smaller = true := by decide
def e2422373623226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373623226 : Closed e2422373623226 ∧ code e2422373623226 = 11218466645434 := by decide
theorem cert_e2422373623226 : check e2422373623226 [[],[]] .smaller = true := by decide
def e2422373623274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373623274 : Closed e2422373623274 ∧ code e2422373623274 = 11218466645482 := by decide
theorem cert_e2422373623274 : check e2422373623274 [[],[]] .smaller = true := by decide
def e2422373623406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373623406 : Closed e2422373623406 ∧ code e2422373623406 = 11218466645614 := by decide
theorem cert_e2422373623406 : check e2422373623406 [[],[]] .smaller = true := by decide
def e2422373623418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373623418 : Closed e2422373623418 ∧ code e2422373623418 = 11218466645626 := by decide
theorem cert_e2422373623418 : check e2422373623418 [[],[]] .smaller = true := by decide
def e2422373623706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373623706 : Closed e2422373623706 ∧ code e2422373623706 = 11218466645914 := by decide
theorem cert_e2422373623706 : check e2422373623706 [[],[]] .smaller = true := by decide
def e2422373628382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373628382 : Closed e2422373628382 ∧ code e2422373628382 = 11218466650590 := by decide
theorem cert_e2422373628382 : check e2422373628382 [[],[]] .three = true := by decide
def e2422373628398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373628398 : Closed e2422373628398 ∧ code e2422373628398 = 11218466650606 := by decide
theorem cert_e2422373628398 : check e2422373628398 [[],[]] .smaller = true := by decide
def e2422373628406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373628406 : Closed e2422373628406 ∧ code e2422373628406 = 11218466650614 := by decide
theorem cert_e2422373628406 : check e2422373628406 [[],[]] .three = true := by decide
def e2422373629150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373629150 : Closed e2422373629150 ∧ code e2422373629150 = 11218466651358 := by decide
theorem cert_e2422373629150 : check e2422373629150 [[],[]] .three = true := by decide
def e2422373629178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373629178 : Closed e2422373629178 ∧ code e2422373629178 = 11218466651386 := by decide
theorem cert_e2422373629178 : check e2422373629178 [[],[]] .three = true := by decide
def e2422373629550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373629550 : Closed e2422373629550 ∧ code e2422373629550 = 11218466651758 := by decide
theorem cert_e2422373629550 : check e2422373629550 [[],[]] .smaller = true := by decide
def e2422373629562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373629562 : Closed e2422373629562 ∧ code e2422373629562 = 11218466651770 := by decide
theorem cert_e2422373629562 : check e2422373629562 [[],[]] .smaller = true := by decide
def e2422373629750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373629750 : Closed e2422373629750 ∧ code e2422373629750 = 11218466651958 := by decide
theorem cert_e2422373629750 : check e2422373629750 [[],[]] .three = true := by decide
def e2422373629754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373629754 : Closed e2422373629754 ∧ code e2422373629754 = 11218466651962 := by decide
theorem cert_e2422373629754 : check e2422373629754 [[],[]] .three = true := by decide
def e2422373636830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 3)))))))
theorem wire_e2422373636830 : Closed e2422373636830 ∧ code e2422373636830 = 11218466659038 := by decide
theorem cert_e2422373636830 : check e2422373636830 [[],[]] .three = true := by decide
def e2422373636858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 4)))) (.var 0)))))))
theorem wire_e2422373636858 : Closed e2422373636858 ∧ code e2422373636858 = 11218466659066 := by decide
theorem cert_e2422373636858 : check e2422373636858 [[],[]] .three = true := by decide
def e2422373636958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 3)))))))
theorem wire_e2422373636958 : Closed e2422373636958 ∧ code e2422373636958 = 11218466659166 := by decide
theorem cert_e2422373636958 : check e2422373636958 [[],[]] .three = true := by decide
def e2422373636974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 2)))))))
theorem wire_e2422373636974 : Closed e2422373636974 ∧ code e2422373636974 = 11218466659182 := by decide
theorem cert_e2422373636974 : check e2422373636974 [[],[]] .smaller = true := by decide
def e2422373636982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))))
theorem wire_e2422373636982 : Closed e2422373636982 ∧ code e2422373636982 = 11218466659190 := by decide
theorem cert_e2422373636982 : check e2422373636982 [[],[]] .smaller = true := by decide
def e2422373636986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))) (.var 0)))))))
theorem wire_e2422373636986 : Closed e2422373636986 ∧ code e2422373636986 = 11218466659194 := by decide
theorem cert_e2422373636986 : check e2422373636986 [[],[]] .smaller = true := by decide
def e2422373637046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373637046 : Closed e2422373637046 ∧ code e2422373637046 = 11218466659254 := by decide
theorem cert_e2422373637046 : check e2422373637046 [[],[]] .smaller = true := by decide
def e2422373637082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373637082 : Closed e2422373637082 ∧ code e2422373637082 = 11218466659290 := by decide
theorem cert_e2422373637082 : check e2422373637082 [[],[]] .smaller = true := by decide
def e2422373637098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 4)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373637098 : Closed e2422373637098 ∧ code e2422373637098 = 11218466659306 := by decide
theorem cert_e2422373637098 : check e2422373637098 [[],[]] .three = true := by decide
def e2422373637470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 3)))))))
theorem wire_e2422373637470 : Closed e2422373637470 ∧ code e2422373637470 = 11218466659678 := by decide
theorem cert_e2422373637470 : check e2422373637470 [[],[]] .three = true := by decide
def e2422373637486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 2)))))))
theorem wire_e2422373637486 : Closed e2422373637486 ∧ code e2422373637486 = 11218466659694 := by decide
theorem cert_e2422373637486 : check e2422373637486 [[],[]] .smaller = true := by decide
def e2422373637494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))))
theorem wire_e2422373637494 : Closed e2422373637494 ∧ code e2422373637494 = 11218466659702 := by decide
theorem cert_e2422373637494 : check e2422373637494 [[],[]] .smaller = true := by decide
def e2422373637498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))) (.var 0)))))))
theorem wire_e2422373637498 : Closed e2422373637498 ∧ code e2422373637498 = 11218466659706 := by decide
theorem cert_e2422373637498 : check e2422373637498 [[],[]] .smaller = true := by decide
def e2422373637550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373637550 : Closed e2422373637550 ∧ code e2422373637550 = 11218466659758 := by decide
theorem cert_e2422373637550 : check e2422373637550 [[],[]] .smaller = true := by decide
def e2422373637590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373637590 : Closed e2422373637590 ∧ code e2422373637590 = 11218466659798 := by decide
theorem cert_e2422373637590 : check e2422373637590 [[],[]] .smaller = true := by decide
def e2422373637610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373637610 : Closed e2422373637610 ∧ code e2422373637610 = 11218466659818 := by decide
theorem cert_e2422373637610 : check e2422373637610 [[],[]] .smaller = true := by decide
def e2422373637814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373637814 : Closed e2422373637814 ∧ code e2422373637814 = 11218466660022 := by decide
theorem cert_e2422373637814 : check e2422373637814 [[],[]] .smaller = true := by decide
def e2422373637846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e2422373637846 : Closed e2422373637846 ∧ code e2422373637846 = 11218466660054 := by decide
theorem cert_e2422373637846 : check e2422373637846 [[],[]] .smaller = true := by decide
def e2422373637978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373637978 : Closed e2422373637978 ∧ code e2422373637978 = 11218466660186 := by decide
theorem cert_e2422373637978 : check e2422373637978 [[],[]] .smaller = true := by decide
def e2422373637994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373637994 : Closed e2422373637994 ∧ code e2422373637994 = 11218466660202 := by decide
theorem cert_e2422373637994 : check e2422373637994 [[],[]] .smaller = true := by decide
def e2422373638058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 4) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373638058 : Closed e2422373638058 ∧ code e2422373638058 = 11218466660266 := by decide
theorem cert_e2422373638058 : check e2422373638058 [[],[]] .three = true := by decide
def e2422373639902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 3)))))))
theorem wire_e2422373639902 : Closed e2422373639902 ∧ code e2422373639902 = 11218466662110 := by decide
theorem cert_e2422373639902 : check e2422373639902 [[],[]] .three = true := by decide
def e2422373639930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 4))))) (.var 0)))))))
theorem wire_e2422373639930 : Closed e2422373639930 ∧ code e2422373639930 = 11218466662138 := by decide
theorem cert_e2422373639930 : check e2422373639930 [[],[]] .three = true := by decide
def e2422373640030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 3)))))))
theorem wire_e2422373640030 : Closed e2422373640030 ∧ code e2422373640030 = 11218466662238 := by decide
theorem cert_e2422373640030 : check e2422373640030 [[],[]] .three = true := by decide
def e2422373640046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.var 2)))))))
theorem wire_e2422373640046 : Closed e2422373640046 ∧ code e2422373640046 = 11218466662254 := by decide
theorem cert_e2422373640046 : check e2422373640046 [[],[]] .smaller = true := by decide
def e2422373640054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))))
theorem wire_e2422373640054 : Closed e2422373640054 ∧ code e2422373640054 = 11218466662262 := by decide
theorem cert_e2422373640054 : check e2422373640054 [[],[]] .smaller = true := by decide
def e2422373640058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))) (.var 0)))))))
theorem wire_e2422373640058 : Closed e2422373640058 ∧ code e2422373640058 = 11218466662266 := by decide
theorem cert_e2422373640058 : check e2422373640058 [[],[]] .smaller = true := by decide
def e2422373640118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))))
theorem wire_e2422373640118 : Closed e2422373640118 ∧ code e2422373640118 = 11218466662326 := by decide
theorem cert_e2422373640118 : check e2422373640118 [[],[]] .smaller = true := by decide
def e2422373640154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))) (.var 0)))))))
theorem wire_e2422373640154 : Closed e2422373640154 ∧ code e2422373640154 = 11218466662362 := by decide
theorem cert_e2422373640154 : check e2422373640154 [[],[]] .smaller = true := by decide
def e2422373640170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 4) (.var 0))))) (.var 0)))))))
theorem wire_e2422373640170 : Closed e2422373640170 ∧ code e2422373640170 = 11218466662378 := by decide
theorem cert_e2422373640170 : check e2422373640170 [[],[]] .three = true := by decide
def e2422373641438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373641438 : Closed e2422373641438 ∧ code e2422373641438 = 11218466663646 := by decide
theorem cert_e2422373641438 : check e2422373641438 [[],[]] .three = true := by decide
def e2422373641454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373641454 : Closed e2422373641454 ∧ code e2422373641454 = 11218466663662 := by decide
theorem cert_e2422373641454 : check e2422373641454 [[],[]] .smaller = true := by decide
def e2422373641462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373641462 : Closed e2422373641462 ∧ code e2422373641462 = 11218466663670 := by decide
theorem cert_e2422373641462 : check e2422373641462 [[],[]] .smaller = true := by decide
def e2422373641466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373641466 : Closed e2422373641466 ∧ code e2422373641466 = 11218466663674 := by decide
theorem cert_e2422373641466 : check e2422373641466 [[],[]] .three = true := by decide
def e2422373641838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373641838 : Closed e2422373641838 ∧ code e2422373641838 = 11218466664046 := by decide
theorem cert_e2422373641838 : check e2422373641838 [[],[]] .smaller = true := by decide
def e2422373641850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373641850 : Closed e2422373641850 ∧ code e2422373641850 = 11218466664058 := by decide
theorem cert_e2422373641850 : check e2422373641850 [[],[]] .smaller = true := by decide
def e2422373642038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373642038 : Closed e2422373642038 ∧ code e2422373642038 = 11218466664246 := by decide
theorem cert_e2422373642038 : check e2422373642038 [[],[]] .smaller = true := by decide
def e2422373642042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373642042 : Closed e2422373642042 ∧ code e2422373642042 = 11218466664250 := by decide
theorem cert_e2422373642042 : check e2422373642042 [[],[]] .smaller = true := by decide
def e2422373642138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 4)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373642138 : Closed e2422373642138 ∧ code e2422373642138 = 11218466664346 := by decide
theorem cert_e2422373642138 : check e2422373642138 [[],[]] .three = true := by decide
def e2422373642718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373642718 : Closed e2422373642718 ∧ code e2422373642718 = 11218466664926 := by decide
theorem cert_e2422373642718 : check e2422373642718 [[],[]] .three = true := by decide
def e2422373642734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2)))))))
theorem wire_e2422373642734 : Closed e2422373642734 ∧ code e2422373642734 = 11218466664942 := by decide
theorem cert_e2422373642734 : check e2422373642734 [[],[]] .smaller = true := by decide
def e2422373642742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 1)))))))
theorem wire_e2422373642742 : Closed e2422373642742 ∧ code e2422373642742 = 11218466664950 := by decide
theorem cert_e2422373642742 : check e2422373642742 [[],[]] .smaller = true := by decide
def e2422373642746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 5))))) (.var 0)))))))
theorem wire_e2422373642746 : Closed e2422373642746 ∧ code e2422373642746 = 11218466664954 := by decide
theorem cert_e2422373642746 : check e2422373642746 [[],[]] .three = true := by decide
def e2422373643102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 3)))))))
theorem wire_e2422373643102 : Closed e2422373643102 ∧ code e2422373643102 = 11218466665310 := by decide
theorem cert_e2422373643102 : check e2422373643102 [[],[]] .three = true := by decide
def e2422373643118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e2422373643118 : Closed e2422373643118 ∧ code e2422373643118 = 11218466665326 := by decide
theorem cert_e2422373643118 : check e2422373643118 [[],[]] .smaller = true := by decide
def e2422373643126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))))
theorem wire_e2422373643126 : Closed e2422373643126 ∧ code e2422373643126 = 11218466665334 := by decide
theorem cert_e2422373643126 : check e2422373643126 [[],[]] .smaller = true := by decide
def e2422373643130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e2422373643130 : Closed e2422373643130 ∧ code e2422373643130 = 11218466665338 := by decide
theorem cert_e2422373643130 : check e2422373643130 [[],[]] .smaller = true := by decide
def e2422373643182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e2422373643182 : Closed e2422373643182 ∧ code e2422373643182 = 11218466665390 := by decide
theorem cert_e2422373643182 : check e2422373643182 [[],[]] .smaller = true := by decide
def e2422373643222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))))
theorem wire_e2422373643222 : Closed e2422373643222 ∧ code e2422373643222 = 11218466665430 := by decide
theorem cert_e2422373643222 : check e2422373643222 [[],[]] .smaller = true := by decide
def e2422373643242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e2422373643242 : Closed e2422373643242 ∧ code e2422373643242 = 11218466665450 := by decide
theorem cert_e2422373643242 : check e2422373643242 [[],[]] .smaller = true := by decide
def e2422373643486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373643486 : Closed e2422373643486 ∧ code e2422373643486 = 11218466665694 := by decide
theorem cert_e2422373643486 : check e2422373643486 [[],[]] .three = true := by decide
def e2422373643502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373643502 : Closed e2422373643502 ∧ code e2422373643502 = 11218466665710 := by decide
theorem cert_e2422373643502 : check e2422373643502 [[],[]] .smaller = true := by decide
def e2422373643510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373643510 : Closed e2422373643510 ∧ code e2422373643510 = 11218466665718 := by decide
theorem cert_e2422373643510 : check e2422373643510 [[],[]] .smaller = true := by decide
def e2422373643514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373643514 : Closed e2422373643514 ∧ code e2422373643514 = 11218466665722 := by decide
theorem cert_e2422373643514 : check e2422373643514 [[],[]] .three = true := by decide
def e2422373643838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373643838 : Closed e2422373643838 ∧ code e2422373643838 = 11218466666046 := by decide
theorem cert_e2422373643838 : check e2422373643838 [[],[]] .three = true := by decide
def e2422373643886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373643886 : Closed e2422373643886 ∧ code e2422373643886 = 11218466666094 := by decide
theorem cert_e2422373643886 : check e2422373643886 [[],[]] .smaller = true := by decide
def e2422373643898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373643898 : Closed e2422373643898 ∧ code e2422373643898 = 11218466666106 := by decide
theorem cert_e2422373643898 : check e2422373643898 [[],[]] .smaller = true := by decide
def e2422373644062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3))))))))
theorem wire_e2422373644062 : Closed e2422373644062 ∧ code e2422373644062 = 11218466666270 := by decide
theorem cert_e2422373644062 : check e2422373644062 [[],[]] .smaller = true := by decide
def e2422373644174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 2))))))))
theorem wire_e2422373644174 : Closed e2422373644174 ∧ code e2422373644174 = 11218466666382 := by decide
theorem cert_e2422373644174 : check e2422373644174 [[],[]] .smaller = true := by decide
def e2422373644186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373644186 : Closed e2422373644186 ∧ code e2422373644186 = 11218466666394 := by decide
theorem cert_e2422373644186 : check e2422373644186 [[],[]] .smaller = true := by decide
def e2422373644230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.lam (.var 1))))))))
theorem wire_e2422373644230 : Closed e2422373644230 ∧ code e2422373644230 = 11218466666438 := by decide
theorem cert_e2422373644230 : check e2422373644230 [[],[]] .three = true := by decide
def e2422373644254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 4)))) (.var 3)))))))
theorem wire_e2422373644254 : Closed e2422373644254 ∧ code e2422373644254 = 11218466666462 := by decide
theorem cert_e2422373644254 : check e2422373644254 [[],[]] .three = true := by decide
def e2422373644526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373644526 : Closed e2422373644526 ∧ code e2422373644526 = 11218466666734 := by decide
theorem cert_e2422373644526 : check e2422373644526 [[],[]] .smaller = true := by decide
def e2422373644538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373644538 : Closed e2422373644538 ∧ code e2422373644538 = 11218466666746 := by decide
theorem cert_e2422373644538 : check e2422373644538 [[],[]] .smaller = true := by decide
def e2422373644726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373644726 : Closed e2422373644726 ∧ code e2422373644726 = 11218466666934 := by decide
theorem cert_e2422373644726 : check e2422373644726 [[],[]] .smaller = true := by decide
def e2422373644758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373644758 : Closed e2422373644758 ∧ code e2422373644758 = 11218466666966 := by decide
theorem cert_e2422373644758 : check e2422373644758 [[],[]] .smaller = true := by decide
def e2422373644910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373644910 : Closed e2422373644910 ∧ code e2422373644910 = 11218466667118 := by decide
theorem cert_e2422373644910 : check e2422373644910 [[],[]] .smaller = true := by decide
def e2422373644922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373644922 : Closed e2422373644922 ∧ code e2422373644922 = 11218466667130 := by decide
theorem cert_e2422373644922 : check e2422373644922 [[],[]] .smaller = true := by decide
def e2422373645086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373645086 : Closed e2422373645086 ∧ code e2422373645086 = 11218466667294 := by decide
theorem cert_e2422373645086 : check e2422373645086 [[],[]] .smaller = true := by decide
def e2422373645254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373645254 : Closed e2422373645254 ∧ code e2422373645254 = 11218466667462 := by decide
theorem cert_e2422373645254 : check e2422373645254 [[],[]] .smaller = true := by decide
def e2422373645278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 3)))))))
theorem wire_e2422373645278 : Closed e2422373645278 ∧ code e2422373645278 = 11218466667486 := by decide
theorem cert_e2422373645278 : check e2422373645278 [[],[]] .three = true := by decide
def e2422373645294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 4)))) (.var 2)))))))
theorem wire_e2422373645294 : Closed e2422373645294 ∧ code e2422373645294 = 11218466667502 := by decide
theorem cert_e2422373645294 : check e2422373645294 [[],[]] .three = true := by decide
def e2422373645430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373645430 : Closed e2422373645430 ∧ code e2422373645430 = 11218466667638 := by decide
theorem cert_e2422373645430 : check e2422373645430 [[],[]] .smaller = true := by decide
def e2422373645434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373645434 : Closed e2422373645434 ∧ code e2422373645434 = 11218466667642 := by decide
theorem cert_e2422373645434 : check e2422373645434 [[],[]] .smaller = true := by decide
def e2422373645530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373645530 : Closed e2422373645530 ∧ code e2422373645530 = 11218466667738 := by decide
theorem cert_e2422373645530 : check e2422373645530 [[],[]] .smaller = true := by decide
def e2422373645546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373645546 : Closed e2422373645546 ∧ code e2422373645546 = 11218466667754 := by decide
theorem cert_e2422373645546 : check e2422373645546 [[],[]] .smaller = true := by decide
def e2422373645622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373645622 : Closed e2422373645622 ∧ code e2422373645622 = 11218466667830 := by decide
theorem cert_e2422373645622 : check e2422373645622 [[],[]] .smaller = true := by decide
def e2422373645626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373645626 : Closed e2422373645626 ∧ code e2422373645626 = 11218466667834 := by decide
theorem cert_e2422373645626 : check e2422373645626 [[],[]] .smaller = true := by decide
def e2422373645710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373645710 : Closed e2422373645710 ∧ code e2422373645710 = 11218466667918 := by decide
theorem cert_e2422373645710 : check e2422373645710 [[],[]] .smaller = true := by decide
def e2422373645722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373645722 : Closed e2422373645722 ∧ code e2422373645722 = 11218466667930 := by decide
theorem cert_e2422373645722 : check e2422373645722 [[],[]] .smaller = true := by decide
def e2422373645766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373645766 : Closed e2422373645766 ∧ code e2422373645766 = 11218466667974 := by decide
theorem cert_e2422373645766 : check e2422373645766 [[],[]] .smaller = true := by decide
def e2422373645790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 3)))))))
theorem wire_e2422373645790 : Closed e2422373645790 ∧ code e2422373645790 = 11218466667998 := by decide
theorem cert_e2422373645790 : check e2422373645790 [[],[]] .three = true := by decide
def e2422373645814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 4)))) (.var 1)))))))
theorem wire_e2422373645814 : Closed e2422373645814 ∧ code e2422373645814 = 11218466668022 := by decide
theorem cert_e2422373645814 : check e2422373645814 [[],[]] .three = true := by decide
def e2422373645882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373645882 : Closed e2422373645882 ∧ code e2422373645882 = 11218466668090 := by decide
theorem cert_e2422373645882 : check e2422373645882 [[],[]] .three = true := by decide
def e2422373645930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373645930 : Closed e2422373645930 ∧ code e2422373645930 = 11218466668138 := by decide
theorem cert_e2422373645930 : check e2422373645930 [[],[]] .three = true := by decide
def e2422373645978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373645978 : Closed e2422373645978 ∧ code e2422373645978 = 11218466668186 := by decide
theorem cert_e2422373645978 : check e2422373645978 [[],[]] .three = true := by decide
end Blc.Floor43
