import Slice42Regular4004Model
import Slice42Regular4004Four000
import Slice42Regular4004Four004
import Slice42Regular4004Four008
import Slice42Regular4004Four012
import Slice42Regular4004Four016
import Slice42Regular4004Four020
import Slice42Regular4004Four024
import Slice42Regular4004Four028
import Slice42Regular4004Four032
import Slice42Regular4004Four036
import Slice42Regular4004Four040
import Slice42Regular4004Four044
import Slice42Regular4004Four048
import Slice42Regular4004Four052
import Slice42Regular4004Four056
import Slice42Regular4004Four060
import Slice42Regular4004Four064
import Slice42Regular4004Four068
import Slice42Regular4004Four072
import Slice42Regular4004Four076
import Slice42Regular4004Four080
import Slice42Regular4004Four084
import Slice42Regular4004Four088
import Slice42Regular4004Four092
import Slice42Regular4004Four096
import Slice42Regular4004Four100
import Slice42Regular4004Four104
import Slice42Regular4004Four108
import Slice42Regular4004Four112
import Slice42Regular4004Four116
import Slice42Regular4004Four120
import Slice42Regular4004Four124
import Slice42Regular4004Four128
import Slice42Regular4004Four132
import Slice42Regular4004Four136
import Slice42Regular4004Four140
import Slice42Regular4004Four144
import Slice42Regular4004Four148
import Slice42Regular4004Four152
import Slice42Regular4004Four156
import Slice42Regular4004Four160
import Slice42Regular4004Four164
import Slice42Regular4004Four168
import Blc.SelfintRootLetEmbedding
import Certificates
namespace Certgen.Slice42Regular4004
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintClass Blc.SelfintSourceCost
open Blc.HandlerLet Blc.SelfintLowerBound Blc.SelfintStreamSpecializer
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i < 172 := hi
 by_cases bound84 : i < 84
 · by_cases bound40 : i < 40
   · by_cases bound20 : i < 20
     · by_cases bound8 : i < 8
       · by_cases bound4 : i < 4
         · exact range_sound small0 i (by omega) (by omega) hi
         · exact range_sound small4 i (by omega) (by omega) hi
       · by_cases bound12 : i < 12
         · exact range_sound small8 i (by omega) (by omega) hi
         · by_cases bound16 : i < 16
           · exact range_sound small12 i (by omega) (by omega) hi
           · exact range_sound small16 i (by omega) (by omega) hi
     · by_cases bound28 : i < 28
       · by_cases bound24 : i < 24
         · exact range_sound small20 i (by omega) (by omega) hi
         · exact range_sound small24 i (by omega) (by omega) hi
       · by_cases bound32 : i < 32
         · exact range_sound small28 i (by omega) (by omega) hi
         · by_cases bound36 : i < 36
           · exact range_sound small32 i (by omega) (by omega) hi
           · exact range_sound small36 i (by omega) (by omega) hi
   · by_cases bound60 : i < 60
     · by_cases bound48 : i < 48
       · by_cases bound44 : i < 44
         · exact range_sound small40 i (by omega) (by omega) hi
         · exact range_sound small44 i (by omega) (by omega) hi
       · by_cases bound52 : i < 52
         · exact range_sound small48 i (by omega) (by omega) hi
         · by_cases bound56 : i < 56
           · exact range_sound small52 i (by omega) (by omega) hi
           · exact range_sound small56 i (by omega) (by omega) hi
     · by_cases bound72 : i < 72
       · by_cases bound64 : i < 64
         · exact range_sound small60 i (by omega) (by omega) hi
         · by_cases bound68 : i < 68
           · exact range_sound small64 i (by omega) (by omega) hi
           · exact range_sound small68 i (by omega) (by omega) hi
       · by_cases bound76 : i < 76
         · exact range_sound small72 i (by omega) (by omega) hi
         · by_cases bound80 : i < 80
           · exact range_sound small76 i (by omega) (by omega) hi
           · exact range_sound small80 i (by omega) (by omega) hi
 · by_cases bound128 : i < 128
   · by_cases bound104 : i < 104
     · by_cases bound92 : i < 92
       · by_cases bound88 : i < 88
         · exact range_sound small84 i (by omega) (by omega) hi
         · exact range_sound small88 i (by omega) (by omega) hi
       · by_cases bound96 : i < 96
         · exact range_sound small92 i (by omega) (by omega) hi
         · by_cases bound100 : i < 100
           · exact range_sound small96 i (by omega) (by omega) hi
           · exact range_sound small100 i (by omega) (by omega) hi
     · by_cases bound116 : i < 116
       · by_cases bound108 : i < 108
         · exact range_sound small104 i (by omega) (by omega) hi
         · by_cases bound112 : i < 112
           · exact range_sound small108 i (by omega) (by omega) hi
           · exact range_sound small112 i (by omega) (by omega) hi
       · by_cases bound120 : i < 120
         · exact range_sound small116 i (by omega) (by omega) hi
         · by_cases bound124 : i < 124
           · exact range_sound small120 i (by omega) (by omega) hi
           · exact range_sound small124 i (by omega) (by omega) hi
   · by_cases bound148 : i < 148
     · by_cases bound136 : i < 136
       · by_cases bound132 : i < 132
         · exact range_sound small128 i (by omega) (by omega) hi
         · exact range_sound small132 i (by omega) (by omega) hi
       · by_cases bound140 : i < 140
         · exact range_sound small136 i (by omega) (by omega) hi
         · by_cases bound144 : i < 144
           · exact range_sound small140 i (by omega) (by omega) hi
           · exact range_sound small144 i (by omega) (by omega) hi
     · by_cases bound160 : i < 160
       · by_cases bound152 : i < 152
         · exact range_sound small148 i (by omega) (by omega) hi
         · by_cases bound156 : i < 156
           · exact range_sound small152 i (by omega) (by omega) hi
           · exact range_sound small156 i (by omega) (by omega) hi
       · by_cases bound164 : i < 164
         · exact range_sound small160 i (by omega) (by omega) hi
         · by_cases bound168 : i < 168
           · exact range_sound small164 i (by omega) (by omega) hi
           · exact range_sound small168 i (by omega) (by omega) hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)
theorem diverges (n : Nat) : ¬ Count core n := by rw [←literal]; exact regular_no_clock model closed root n
def r4004 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))) (.var 1)) (.var 0))
theorem reject4004 : ¬ Reader r4004 := by
 intro hr
 have replay : betaSteps [[1, 1, 1]] (.app r4004 Z) = some (spine core [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have nf := betas_preserve_nf (betaSteps_sound _ replay) hr.zero_red zeroOut_normal
 obtain ⟨n,h⟩ := hasNormalForm_count ⟨_,nf,zeroOut_normal⟩
 obtain ⟨m,_,hm⟩ := SelfintRootLetOrbit.count_spine_fn [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] h
 exact diverges m hm
#print axioms reject4004

end Certgen.Slice42Regular4004
