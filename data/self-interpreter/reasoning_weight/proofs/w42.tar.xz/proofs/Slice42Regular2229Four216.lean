import Slice42Regular2229Data
namespace Certgen.Slice42Regular2229
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem small216 : checkRange P V K states hints 216 3 = true := by decide +kernel
end Certgen.Slice42Regular2229
