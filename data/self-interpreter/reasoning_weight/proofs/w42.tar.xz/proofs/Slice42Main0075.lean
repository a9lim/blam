import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0075
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r2843 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))) (.var 1))
theorem reject2843 : ¬ Reader r2843 := by
  exact replay_loop true [] 6 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0)))))) [] [(.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2843
def r2844 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))) (.var 1))
theorem reject2844 : ¬ Reader r2844 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[],[],[],[],[]] [[],[],[],[],[],[6],[],[8],[0,7],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.lam 7 (.lam 8 (.var 3 [0,7]) [8]) [7]) [6]) (.var 0 [5]) []) (.var 0 [5]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject2844
def r2845 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject2845 : ¬ Reader r2845 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2845
def r2846 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))) (.var 1))
theorem reject2846 : ¬ Reader r2846 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2846
def r2847 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))) (.var 1))
theorem reject2847 : ¬ Reader r2847 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2847
def r2848 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))))) (.var 1))
theorem reject2848 : ¬ Reader r2848 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2848
def r2849 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject2849 : ¬ Reader r2849 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5],[0,8],[5],[],[],[],[]] [[],[],[],[],[],[6],[7],[],[0,8],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.var 1 [0]) [7]) (.lam 5 (.var 1 [6]) [5]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.lam 8 (.var 2 [0,8]) [8]) [7]) (.var 0 [5]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject2849
def r2850 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0))))) (.var 1))
theorem reject2850 : ¬ Reader r2850 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2850
def r2851 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2))))))) (.var 1))
theorem reject2851 : ¬ Reader r2851 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.var 2)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.var 2))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.var 2)))) (.lam (.lam (.lam (.var 3)))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2851
def r2852 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject2852 : ¬ Reader r2852 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 1], [1, 1, 2], [1, 1, 2, 0, 2, 2]] [[2], [1], [], [2], [2, 1], [2, 2]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))) [(.app (.var 0) (.var 0))] [(.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide)
#print axioms reject2852
def r2853 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))))) (.var 1))
theorem reject2853 : ¬ Reader r2853 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2853
def r2854 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))))) (.var 1))
theorem reject2854 : ¬ Reader r2854 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r2854 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject2854
def r2855 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))))) (.var 1))
theorem reject2855 : ¬ Reader r2855 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r2855 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject2855
def r2856 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))) (.var 1))
theorem reject2856 : ¬ Reader r2856 := by
  exact replay_loop true [] 6 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))))) [] [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2856
def r2857 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))))) (.var 1))
theorem reject2857 : ¬ Reader r2857 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[],[5,8],[6],[],[],[],[]] [[],[],[],[],[],[0],[7],[],[5,8],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.lam 5 (.var 2 [0]) [5]) [7]) (.var 0 [6]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [6]) (.lam 8 (.var 2 [5,8]) [8]) [7]) (.var 0 [6]) []) (.var 0 [6]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject2857
def r2858 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject2858 : ¬ Reader r2858 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))))))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2858
def r2859 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1))))) (.var 1))
theorem reject2859 : ¬ Reader r2859 := by
  exact replay_loop true [] 3 5 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1))))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2859
def r2860 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1))))) (.var 1))
theorem reject2860 : ¬ Reader r2860 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1))))) [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2860
def r2861 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject2861 : ¬ Reader r2861 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2861
def r2862 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject2862 : ¬ Reader r2862 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2862
def r2863 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject2863 : ¬ Reader r2863 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 2)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 2))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 2)))) (.lam (.lam (.var 2))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2863
def r2864 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject2864 : ¬ Reader r2864 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r2864 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject2864
def r2865 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject2865 : ¬ Reader r2865 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r2865 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject2865
def r2866 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject2866 : ¬ Reader r2866 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2866
def r2867 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject2867 : ¬ Reader r2867 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2867
def r2868 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.lam (.var 3)))))) (.var 1))
theorem reject2868 : ¬ Reader r2868 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2868
def r2869 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)) (.var 2))))) (.var 1))
theorem reject2869 : ¬ Reader r2869 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2869
def r2870 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1))
theorem reject2870 : ¬ Reader r2870 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2870
def r2871 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject2871 : ¬ Reader r2871 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2871
def r2872 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0))))) (.var 1))
theorem reject2872 : ¬ Reader r2872 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r2872 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject2872
def r2873 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))) (.var 1))
theorem reject2873 : ¬ Reader r2873 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))) [(.lam (.lam (.lam (.var 0))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2873
def r2874 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) (.var 1))
theorem reject2874 : ¬ Reader r2874 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) [(.lam (.lam (.lam (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2874
def r2875 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject2875 : ¬ Reader r2875 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))) [(.var 0)] [(.lam (.lam (.lam (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2875
def r2876 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject2876 : ¬ Reader r2876 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 0))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.var 0)))))) [(.lam (.lam (.lam (.var 0))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2876
def r2877 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject2877 : ¬ Reader r2877 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2877
def r2878 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject2878 : ¬ Reader r2878 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.lam (.lam (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2878
def r2879 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject2879 : ¬ Reader r2879 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2879
def r2880 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)))))) (.var 1))
theorem reject2880 : ¬ Reader r2880 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2880
def r2881 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))))) (.var 1))
theorem reject2881 : ¬ Reader r2881 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2881
def r2882 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject2882 : ¬ Reader r2882 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2882
end Blc.HandlerLet.Slice42Main0075
