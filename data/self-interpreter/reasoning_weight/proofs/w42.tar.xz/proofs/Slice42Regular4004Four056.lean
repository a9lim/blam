import Slice42Regular4004Data
namespace Certgen.Slice42Regular4004
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem small56 : checkRange P V K states hints 56 4 = true := by decide +kernel
end Certgen.Slice42Regular4004
