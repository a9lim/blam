import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0165
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6348 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6348 : ¬ Reader r6348 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6348
def r6349 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6349 : ¬ Reader r6349 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6349
def r6350 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))) (.var 1)) (.var 0))
theorem reject6350 : ¬ Reader r6350 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[1],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.lam 8 (.var 2 [1]) [8]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6350
def r6351 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))) (.var 0)) (.var 1))
theorem reject6351 : ¬ Reader r6351 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0]) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) [0]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6351
def r6352 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))) (.var 1)) (.var 0))
theorem reject6352 : ¬ Reader r6352 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))) (.var 1)) [(.lam (.lam (.var 3)))] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6352
def r6353 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))) (.var 0)) (.var 1))
theorem reject6353 : ¬ Reader r6353 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))) (.var 0)) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6353
def r6354 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject6354 : ¬ Reader r6354 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[1,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) (.lam 8 (.var 1 [1,7]) [8]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6354
def r6355 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject6355 : ¬ Reader r6355 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[0,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) (.lam 8 (.var 1 [0,7]) [8]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6355
def r6356 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))) (.var 1)) (.var 0))
theorem reject6356 : ¬ Reader r6356 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[1,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.lam 8 (.var 2 [1,7]) [8]) [7]) []) (.var 0 [1,7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6356
def r6357 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))) (.var 0)) (.var 1))
theorem reject6357 : ¬ Reader r6357 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.lam 8 (.var 2 [0,7]) [8]) [7]) []) (.var 0 [0,7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6357
def r6358 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject6358 : ¬ Reader r6358 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6358
def r6359 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject6359 : ¬ Reader r6359 := by
  exact replay_absent true [] 6 1 (by decide) (by decide)
#print axioms reject6359
def r6360 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject6360 : ¬ Reader r6360 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6360
def r6361 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject6361 : ¬ Reader r6361 := by
  exact replay_loop true [] 3 4 (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6361
def r6362 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject6362 : ¬ Reader r6362 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6362
def r6363 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject6363 : ¬ Reader r6363 := by
  exact replay_loop true [] 3 3 (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 0))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6363
def r6364 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject6364 : ¬ Reader r6364 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6364
def r6365 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject6365 : ¬ Reader r6365 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1))))))) [(.lam (.lam (.app (.var 1) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6365
def r6366 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 1)) (.var 0))
theorem reject6366 : ¬ Reader r6366 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6366
def r6367 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0)) (.var 1))
theorem reject6367 : ¬ Reader r6367 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.var 2)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6367
def r6368 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))) (.var 1)) (.lam (.var 1)))
theorem reject6368 : ¬ Reader r6368 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))) (.var 1)) [] [(.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6368
def r6369 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0))))) (.lam (.var 1))) (.var 1))
theorem reject6369 : ¬ Reader r6369 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.var 1))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6369
def r6370 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))
theorem reject6370 : ¬ Reader r6370 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6370
def r6371 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject6371 : ¬ Reader r6371 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[1,8],[5],[1,8],[],[],[],[]] [[],[],[],[],[7],[6],[7],[],[1,8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 0 [1,8]) [6]) (.var 1 [5]) [7]) (.lam 8 (.var 1 [1,8]) [8]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6371
def r6372 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject6372 : ¬ Reader r6372 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0,8],[5],[0,8],[],[],[],[]] [[],[],[],[],[7],[6],[7],[],[0,8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 0 [0,8]) [6]) (.var 1 [5]) [7]) (.lam 8 (.var 1 [0,8]) [8]) []) [7]) [6]) [7]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6372
def r6373 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0))))) (.var 1)) (.var 0))
theorem reject6373 : ¬ Reader r6373 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.var 1)) [] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6373
def r6374 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0))))) (.var 0)) (.var 1))
theorem reject6374 : ¬ Reader r6374 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0)))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6374
def r6375 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.var 0))
theorem reject6375 : ¬ Reader r6375 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6375
def r6376 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))
theorem reject6376 : ¬ Reader r6376 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))) [(.lam (.lam (.lam (.app (.var 1) (.var 1)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6376
def r6377 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.var 0))
theorem reject6377 : ¬ Reader r6377 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6377
def r6378 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))
theorem reject6378 : ¬ Reader r6378 := by
  exact replay_loop true [] 3 3 (.app (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.lam (.var 1)))) (.lam (.app (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.lam (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6378
def r6379 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))
theorem reject6379 : ¬ Reader r6379 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6379
def r6380 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))
theorem reject6380 : ¬ Reader r6380 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6380
def r6381 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))
theorem reject6381 : ¬ Reader r6381 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6381
def r6382 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))
theorem reject6382 : ¬ Reader r6382 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6382
def r6383 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))) (.var 1)) (.lam (.var 1)))
theorem reject6383 : ¬ Reader r6383 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6383
def r6384 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))) (.lam (.var 1))) (.var 1))
theorem reject6384 : ¬ Reader r6384 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6384
def r6385 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject6385 : ¬ Reader r6385 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6385
def r6386 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1))
theorem reject6386 : ¬ Reader r6386 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 0))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 0))))))) (.lam (.var 0))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6386
def r6387 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.var 1)) (.lam (.var 1)))
theorem reject6387 : ¬ Reader r6387 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6387
end Blc.HandlerLet.Slice42Main0165
