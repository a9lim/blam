import Slice42Regular4005Data
namespace Certgen.Slice42Regular4005
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem small68 : checkRange P V K states hints 68 4 = true := by decide +kernel
end Certgen.Slice42Regular4005
