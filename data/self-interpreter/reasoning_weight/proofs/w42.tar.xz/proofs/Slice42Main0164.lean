import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0164
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6308 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2)))))))) (.var 1)) (.var 0))
theorem reject6308 : ¬ Reader r6308 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[1,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 0 []) (.lam 8 (.var 2 [1,7]) [8]) []) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6308
def r6309 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2)))))))) (.var 0)) (.var 1))
theorem reject6309 : ¬ Reader r6309 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[0,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 0 []) (.lam 8 (.var 2 [0,7]) [8]) []) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6309
def r6310 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6310 : ¬ Reader r6310 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[8],[],[],[],[]] [[],[],[],[],[6],[6],[],[1],[8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 1 [1,7]) (.lam 8 (.var 1 [8]) [8]) [1]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6310
def r6311 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6311 : ¬ Reader r6311 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[8],[],[],[],[]] [[],[],[],[],[6],[6],[],[0],[8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 1 [0,7]) (.lam 8 (.var 1 [8]) [8]) [0]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6311
def r6312 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject6312 : ¬ Reader r6312 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5,6],[5,6],[1,8],[],[],[],[]] [[],[],[],[],[7],[7],[7],[],[1,8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.app (.var 0 [5,6]) (.var 1 [6]) [7]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [7]) (.lam 8 (.var 1 [1,8]) [8]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6312
def r6313 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject6313 : ¬ Reader r6313 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5,6],[5,6],[0,8],[],[],[],[]] [[],[],[],[],[7],[7],[7],[],[0,8],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.app (.var 0 [5,6]) (.var 1 [6]) [7]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [7]) (.lam 8 (.var 1 [0,8]) [8]) []) [7]) [6]) [7]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6313
def r6314 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject6314 : ¬ Reader r6314 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.var 0 [1]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6314
def r6315 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject6315 : ¬ Reader r6315 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7,8],[0,7,8],[0,7,8],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0,7,8]) (.var 0 [0,7,8]) [0,8]) []) [6]) [5]) [6]) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6315
def r6316 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject6316 : ¬ Reader r6316 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))) (.var 1)) [(.var 1)] [(.lam (.lam (.var 2))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6316
def r6317 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject6317 : ¬ Reader r6317 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0))))) (.lam (.lam (.var 2)))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6317
def r6318 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))
theorem reject6318 : ¬ Reader r6318 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6318
def r6319 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem reject6319 : ¬ Reader r6319 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6319
def r6320 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 1)) (.lam (.var 1)))
theorem reject6320 : ¬ Reader r6320 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6320
def r6321 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.var 1))) (.var 1))
theorem reject6321 : ¬ Reader r6321 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6321
def r6322 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 1)) (.lam (.var 1)))
theorem reject6322 : ¬ Reader r6322 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6322
def r6323 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))) (.var 1))
theorem reject6323 : ¬ Reader r6323 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6323
def r6324 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 1)) (.lam (.var 1)))
theorem reject6324 : ¬ Reader r6324 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6324
def r6325 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))) (.var 1))
theorem reject6325 : ¬ Reader r6325 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6325
def r6326 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 1)) (.lam (.var 1)))
theorem reject6326 : ¬ Reader r6326 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6326
def r6327 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.var 1))) (.var 1))
theorem reject6327 : ¬ Reader r6327 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6327
def r6328 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 1)) (.lam (.var 1)))
theorem reject6328 : ¬ Reader r6328 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6328
def r6329 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.var 1))) (.var 1))
theorem reject6329 : ¬ Reader r6329 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6329
def r6330 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 1)) (.lam (.var 1)))
theorem reject6330 : ¬ Reader r6330 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6330
def r6331 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.var 1))) (.var 1))
theorem reject6331 : ¬ Reader r6331 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6331
def r6332 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1))))))) (.var 1)) (.lam (.var 1)))
theorem reject6332 : ¬ Reader r6332 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.var 1 [1]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.var 1 [0]) [8]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6332
def r6333 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1))))))) (.lam (.var 1))) (.var 1))
theorem reject6333 : ¬ Reader r6333 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,8],[],[7],[],[],[]] [[],[],[],[],[6],[6],[],[0,8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0,8]) (.lam 7 (.var 1 [0,8]) [7]) [0]) []) [6]) [5]) [6]) (.lam 8 (.var 1 [0]) [8]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6333
def r6334 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1)))))) (.var 1)) (.lam (.var 1)))
theorem reject6334 : ¬ Reader r6334 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1)))))) (.var 1)) [(.lam (.var 2))] [(.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6334
def r6335 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1)))))) (.lam (.var 1))) (.var 1))
theorem reject6335 : ¬ Reader r6335 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1)))))) (.lam (.var 1))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6335
def r6336 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0))))) (.var 1)) (.lam (.var 1)))
theorem reject6336 : ¬ Reader r6336 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) (.var 0 [1,7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.var 1 [0]) [8]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6336
def r6337 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0))))) (.lam (.var 1))) (.var 1))
theorem reject6337 : ¬ Reader r6337 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[7,8],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[7,8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [7,8]) [7]) []) (.var 0 [7,8]) []) [6]) [5]) [6]) (.lam 8 (.var 1 [0]) [8]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6337
def r6338 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.var 1)) (.var 0))
theorem reject6338 : ¬ Reader r6338 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6338
def r6339 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.var 0)) (.var 1))
theorem reject6339 : ¬ Reader r6339 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6339
def r6340 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.var 1)) (.var 0))
theorem reject6340 : ¬ Reader r6340 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6340
def r6341 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))) (.var 0)) (.var 1))
theorem reject6341 : ¬ Reader r6341 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6341
def r6342 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6342 : ¬ Reader r6342 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6342
def r6343 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6343 : ¬ Reader r6343 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6343
def r6344 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6344 : ¬ Reader r6344 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6344
def r6345 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6345 : ¬ Reader r6345 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6345
def r6346 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.var 1)) (.var 0))
theorem reject6346 : ¬ Reader r6346 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6346
def r6347 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.var 0)) (.var 1))
theorem reject6347 : ¬ Reader r6347 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6347
end Blc.HandlerLet.Slice42Main0164
