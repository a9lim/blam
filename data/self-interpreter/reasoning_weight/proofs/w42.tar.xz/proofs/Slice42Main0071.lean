import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0071
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r2683 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject2683 : ¬ Reader r2683 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2683
def r2684 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.var 1))
theorem reject2684 : ¬ Reader r2684 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2684
def r2685 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject2685 : ¬ Reader r2685 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2685
def r2686 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject2686 : ¬ Reader r2686 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0))] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2686
def r2687 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))) (.var 1))
theorem reject2687 : ¬ Reader r2687 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)) (.var 0)), (.var 0)] [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))) (.var 0)) (.var 0)), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2687
def r2688 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))) (.var 1))
theorem reject2688 : ¬ Reader r2688 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2688
def r2689 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))) (.var 1))
theorem reject2689 : ¬ Reader r2689 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))) (.var 0))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2689
def r2690 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject2690 : ¬ Reader r2690 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2690
def r2691 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.var 1))
theorem reject2691 : ¬ Reader r2691 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2691
def r2692 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.var 1))
theorem reject2692 : ¬ Reader r2692 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2692
def r2693 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject2693 : ¬ Reader r2693 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))), (.var 0)] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2693
def r2694 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject2694 : ¬ Reader r2694 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.app (.var 0) (.var 0)))) [(.app (.var 0) (.var 0))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2694
def r2695 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject2695 : ¬ Reader r2695 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))) [(.var 0)] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2695
def r2696 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject2696 : ¬ Reader r2696 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2696
def r2697 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject2697 : ¬ Reader r2697 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2697
def r2698 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject2698 : ¬ Reader r2698 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2698
def r2699 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1))
theorem reject2699 : ¬ Reader r2699 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2699
def r2700 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject2700 : ¬ Reader r2700 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2700
def r2701 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject2701 : ¬ Reader r2701 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2701
def r2702 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))) (.var 1))
theorem reject2702 : ¬ Reader r2702 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2702
def r2703 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))) (.var 1))
theorem reject2703 : ¬ Reader r2703 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2703
def r2704 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject2704 : ¬ Reader r2704 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2704
def r2705 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1))
theorem reject2705 : ¬ Reader r2705 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2705
def r2706 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1))
theorem reject2706 : ¬ Reader r2706 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject2706
def r2707 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 1))
theorem reject2707 : ¬ Reader r2707 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0,1,5,7,8],[5,7],[0,1,5,7,8],[],[],[]] [[],[],[],[],[7],[6],[7],[7],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [5,7]) (.var 2 [0]) [6,7]) (.app (.app (.var 1 [5,7]) (.var 0 [0,1,5,7,8]) [6,7]) (.var 1 [5,7]) [7]) [7]) [7]) [6]) [7]) (.var 1 [1]) [7]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [7]) (by decide) (by decide) (by decide)
#print axioms reject2707
def r2708 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 1))
theorem reject2708 : ¬ Reader r2708 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0,5,6,7],[0,5,6,7],[0,1,5,6,7,8],[],[],[]] [[],[],[],[],[7],[6],[7],[0,7],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [0,5,6,7]) (.var 1 [0,5,6,7]) [0,6,7]) (.app (.var 1 [0,5,6,7]) (.app (.var 2 [0]) (.var 0 [0,1,5,6,7,8]) [0]) [0,6,7]) [0,7]) [7]) [6]) [7]) (.var 1 [1]) [0,7]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0,7]) (by decide) (by decide) (by decide)
#print axioms reject2708
def r2709 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 1))
theorem reject2709 : ¬ Reader r2709 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0,1,5,6,7],[0,1,5,6,7],[0,1,5,6,7,8],[0],[],[]] [[],[],[],[],[7],[6],[7],[0,1,7],[0],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [0,1,5,6,7]) (.var 1 [0,1,5,6,7]) [0,1,6,7]) (.app (.var 1 [0,1,5,6,7]) (.app (.var 0 [0,1,5,6,7,8]) (.var 2 [0]) [0,1,6,7]) [0,1,6,7]) [0,1,7]) [7]) [6]) [7]) (.var 1 [1]) [0,1,7]) (.lam 8 (.app (.app (.var 0 [0]) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) [0]) (.var 4 [3]) [0]) [8]) [0,1,7]) (by decide) (by decide) (by decide)
#print axioms reject2709
def r2710 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 1))
theorem reject2710 : ¬ Reader r2710 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 0, 2], [1, 1, 0, 1, 1], [1]] [[1, 1, 0, 2], [1, 1, 0, 1, 1], [1]] (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide) (by decide)
#print axioms reject2710
def r2711 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject2711 : ¬ Reader r2711 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[5],[1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 2 [0]) [6]) (.var 1 [5]) [7]) (.app (.var 0 [1]) (.var 1 [5]) [1]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject2711
def r2712 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.var 1))
theorem reject2712 : ¬ Reader r2712 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2712
def r2713 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))) (.var 1))
theorem reject2713 : ¬ Reader r2713 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2713
def r2714 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))) (.var 1))
theorem reject2714 : ¬ Reader r2714 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0,1,5,6,7],[0,1,5,6,7],[0,1,5,6,7],[],[],[]] [[],[],[],[],[7],[6],[7],[0,1],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [0,1,5,6,7]) (.var 1 [0,1,5,6,7]) [0,1,6,7]) (.app (.var 1 [0,1,5,6,7]) (.var 0 [0,1,5,6,7]) [0,1,6,7]) [0,1,7]) (.var 2 [0]) [0,1]) [7]) [6]) [7]) (.var 1 [1]) [0,1]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0,1]) (by decide) (by decide) (by decide)
#print axioms reject2714
def r2715 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 1))
theorem reject2715 : ¬ Reader r2715 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5],[5],[0,1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.var 1 [5]) [7]) (.app (.var 2 [0]) (.var 0 [0,1]) [0]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject2715
def r2716 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 1))
theorem reject2716 : ¬ Reader r2716 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5],[5],[1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.var 1 [5]) [7]) (.app (.var 0 [1]) (.var 2 [0]) [1]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject2716
def r2717 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 1))
theorem reject2717 : ¬ Reader r2717 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2717
def r2718 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject2718 : ¬ Reader r2718 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2718
def r2719 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject2719 : ¬ Reader r2719 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2719
def r2720 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1))))) (.var 1))
theorem reject2720 : ¬ Reader r2720 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))) (.var 1)) [(.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject2720
def r2721 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))) (.var 1))
theorem reject2721 : ¬ Reader r2721 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2721
def r2722 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))) (.var 1))
theorem reject2722 : ¬ Reader r2722 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject2722
end Blc.HandlerLet.Slice42Main0071
