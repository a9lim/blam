import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0244
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r9507 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.var 1))
theorem reject9507 : ¬ Reader r9507 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9507
def r9508 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.var 1))
theorem reject9508 : ¬ Reader r9508 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9508
def r9509 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))) (.var 1))
theorem reject9509 : ¬ Reader r9509 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[1,5,6,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[0],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.app (.var 0 [5]) (.var 0 [5]) [6]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.lam 7 (.app (.var 3 [0]) (.var 1 [1,5,6,7]) [0]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject9509
def r9510 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))) (.var 1))
theorem reject9510 : ¬ Reader r9510 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,1,5,6,7],[0],[],[],[]] [[],[],[],[],[6],[6],[0],[0,1,6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.app (.var 0 [5]) (.var 0 [5]) [6]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [0,5,6]) (.var 1 [0,5,6]) [0,6]) (.lam 7 (.app (.var 1 [0,1,5,6,7]) (.var 3 [0]) [0,1,6]) [7]) [0]) [6]) [5]) [6]) (.var 1 [1]) [0]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0]) (by decide) (by decide) (by decide)
#print axioms reject9510
def r9511 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.var 1))
theorem reject9511 : ¬ Reader r9511 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject9511
def r9512 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.var 1))
theorem reject9512 : ¬ Reader r9512 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject9512
def r9513 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1))))))) (.var 1))
theorem reject9513 : ¬ Reader r9513 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[5,7],[],[],[],[]] [[],[],[],[],[],[6],[],[0],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 3 [0]) (.var 1 [5,7]) [0]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject9513
def r9514 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))) (.var 1))
theorem reject9514 : ¬ Reader r9514 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2, 0]] [[1, 1], [1, 1, 2, 0]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3))))))) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide) (by decide)
#print axioms reject9514
def r9515 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9515 : ¬ Reader r9515 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9515
def r9516 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9516 : ¬ Reader r9516 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9516
def r9517 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9517 : ¬ Reader r9517 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9517
def r9518 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9518 : ¬ Reader r9518 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9518
def r9519 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9519 : ¬ Reader r9519 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9519
def r9520 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9520 : ¬ Reader r9520 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9520
def r9521 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9521 : ¬ Reader r9521 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9521
def r9522 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9522 : ¬ Reader r9522 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9522
def r9523 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9523 : ¬ Reader r9523 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9523
def r9524 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9524 : ¬ Reader r9524 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9524
def r9525 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9525 : ¬ Reader r9525 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject9525
def r9526 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 1))
theorem reject9526 : ¬ Reader r9526 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5,6],[5,6],[0,1],[],[],[]] [[],[],[],[],[7],[7],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.app (.var 1 [6]) (.var 1 [6]) [7]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [7]) (.app (.var 2 [0]) (.var 0 [0,1]) [0]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject9526
def r9527 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 1))
theorem reject9527 : ¬ Reader r9527 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5,6],[5,6],[1],[],[],[]] [[],[],[],[],[7],[7],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.app (.var 1 [6]) (.var 1 [6]) [7]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [7]) (.app (.var 0 [1]) (.var 2 [0]) [1]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide) (by decide) (by decide)
#print axioms reject9527
def r9528 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 1))
theorem reject9528 : ¬ Reader r9528 := by
  exact replay_loop true [] 4 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.var 1)) [(.var 0)] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9528
def r9529 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject9529 : ¬ Reader r9529 := by
  exact replay_absent true [] 4 1 (by decide) (by decide)
#print axioms reject9529
def r9530 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))))) (.var 1))
theorem reject9530 : ¬ Reader r9530 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9530
def r9531 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject9531 : ¬ Reader r9531 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) [(.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.var 0)))] [(.app (.var 0) (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9531
def r9532 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))) (.var 1))
theorem reject9532 : ¬ Reader r9532 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))) [(.lam (.var 0)), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))] [(.lam (.var 0)), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9532
def r9533 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9533 : ¬ Reader r9533 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))), (.lam (.var 0))] [(.var 0), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9533
def r9534 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))))) (.var 1))
theorem reject9534 : ¬ Reader r9534 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9534
def r9535 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject9535 : ¬ Reader r9535 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.var 0))) [(.app (.var 0) (.lam (.var 0)))] [(.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9535
def r9536 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))))) (.var 1))
theorem reject9536 : ¬ Reader r9536 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))) (.var 0))) [(.lam (.var 0)), (.var 0)] [(.lam (.var 0)), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9536
def r9537 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) (.var 1))
theorem reject9537 : ¬ Reader r9537 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) [(.lam (.var 0))] [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))) (.var 0)), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9537
def r9538 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9538 : ¬ Reader r9538 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.var 0))) [(.var 0), (.lam (.var 0))] [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9538
def r9539 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1))))) (.var 1))
theorem reject9539 : ¬ Reader r9539 := by
  exact replay_loop true [] 7 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9539
def r9540 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0))))) (.var 1))
theorem reject9540 : ¬ Reader r9540 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9540 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9540
def r9541 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0))))) (.var 1))
theorem reject9541 : ¬ Reader r9541 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9541 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.var 0))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)))) (.var 0))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9541
def r9542 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9542 : ¬ Reader r9542 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))) [(.lam (.var 0))] [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9542
def r9543 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9543 : ¬ Reader r9543 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1))))) [(.lam (.var 0))] [(.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9543
def r9544 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) (.var 1))
theorem reject9544 : ¬ Reader r9544 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9544
def r9545 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) (.var 1))
theorem reject9545 : ¬ Reader r9545 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0)))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9545
def r9546 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9546 : ¬ Reader r9546 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))) (.var 0))) [(.var 0), (.lam (.var 0))] [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))), (.lam (.var 0)), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject9546
end Blc.HandlerLet.Slice42Main0244
