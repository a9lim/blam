import Slice42Regular4004Data
import Blc.SelfintRegularSoundness
namespace Certgen.Slice42Regular4004
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintClass Blc.SelfintSourceCost
def node3 : Term := (.var 0)
def node6 : Term := (.var 0)
def node9 : Term := (.var 0)
def node11 : Term := (.var 2)
def node10 : Term := .lam node11
def node8 : Term := .app node9 node10
def node12 : Term := (.var 0)
def node7 : Term := .app node8 node12
def node5 : Term := .app node6 node7
def node4 : Term := .lam node5
def node2 : Term := .app node3 node4
def node1 : Term := .lam node2
def node15 : Term := (.var 0)
def node18 : Term := (.var 0)
def node21 : Term := (.var 0)
def node23 : Term := (.var 2)
def node22 : Term := .lam node23
def node20 : Term := .app node21 node22
def node24 : Term := (.var 0)
def node19 : Term := .app node20 node24
def node17 : Term := .app node18 node19
def node16 : Term := .lam node17
def node14 : Term := .app node15 node16
def node13 : Term := .lam node14
def node0 : Term := .app node1 node13
def core : Term := node0
def syntaxTable : Array Term := #[node0, node1, node2, node3, node4, node5, node6, node7, node8, node9, node10, node11, node12, node13, node14, node15, node16, node17, node18, node19, node20, node21, node22, node23, node24]
def termAt (i : Nat) : Term := syntaxTable[i]?.getD (.var 0)
def aligns (p : Nat) : Bool := match P p with
 | .opaque => true
 | .var i => decide (termAt p = .var i)
 | .lam b => decide (termAt p = .lam (termAt b))
 | .app f a => decide (termAt p = .app (termAt f) (termAt a))
theorem tableValidated : (List.range code.size).all aligns = true := by decide
theorem alignEvery (p : Nat) : aligns p = true := by
 by_cases hp : p < code.size
 · exact List.all_eq_true.mp tableValidated p (List.mem_range.mpr hp)
 · have hz : code[p]? = none := Array.getElem?_eq_none (by omega)
   simp [aligns,P,hz]
def model : Model P where
 term := termAt
 var_eq := by intro p i h; simpa [aligns,h] using alignEvery p
 lam_eq := by intro p b h; simpa [aligns,h] using alignEvery p
 app_eq := by intro p f a h; simpa [aligns,h] using alignEvery p
theorem literal : model.term 0 = core := rfl

end Certgen.Slice42Regular4004
