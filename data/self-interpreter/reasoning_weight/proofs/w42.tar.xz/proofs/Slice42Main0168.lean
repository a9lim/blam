import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0168
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6468 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4))))))) (.var 1)) (.lam (.var 0)))
theorem reject6468 : ¬ Reader r6468 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6468
def r6469 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.var 0))))) (.var 1))
theorem reject6469 : ¬ Reader r6469 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.lam (.lam (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6469
def r6470 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.lam (.lam (.lam (.var 0)))))
theorem reject6470 : ¬ Reader r6470 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.lam (.lam (.var 0)))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6470
def r6471 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))
theorem reject6471 : ¬ Reader r6471 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6471
def r6472 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))
theorem reject6472 : ¬ Reader r6472 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6472
def r6473 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))
theorem reject6473 : ¬ Reader r6473 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6473
def r6474 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))
theorem reject6474 : ¬ Reader r6474 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6474
def r6475 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))
theorem reject6475 : ¬ Reader r6475 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6475
def r6476 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))
theorem reject6476 : ¬ Reader r6476 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6476
def r6477 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))) (.var 1)) (.lam (.var 1)))
theorem reject6477 : ¬ Reader r6477 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6477
def r6478 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))) (.lam (.var 1))) (.var 1))
theorem reject6478 : ¬ Reader r6478 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6478
def r6479 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))) (.var 1)) (.lam (.var 1)))
theorem reject6479 : ¬ Reader r6479 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6479
def r6480 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))) (.lam (.var 1))) (.var 1))
theorem reject6480 : ¬ Reader r6480 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6480
def r6481 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject6481 : ¬ Reader r6481 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6481
def r6482 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1))
theorem reject6482 : ¬ Reader r6482 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6482
def r6483 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.var 1)) (.app (.var 0) (.lam (.var 0))))
theorem reject6483 : ¬ Reader r6483 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6483
def r6484 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.app (.var 0) (.lam (.var 0)))) (.var 1))
theorem reject6484 : ¬ Reader r6484 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.lam (.lam (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6484
def r6485 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))))) (.var 1)) (.var 0))
theorem reject6485 : ¬ Reader r6485 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6485
def r6486 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))))) (.var 0)) (.var 1))
theorem reject6486 : ¬ Reader r6486 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6486
def r6487 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1))))))) (.var 1)) (.var 0))
theorem reject6487 : ¬ Reader r6487 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6487
def r6488 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1))
theorem reject6488 : ¬ Reader r6488 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6488
def r6489 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject6489 : ¬ Reader r6489 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6489
def r6490 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject6490 : ¬ Reader r6490 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.var 0)))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.lam (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6490
def r6491 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject6491 : ¬ Reader r6491 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6491
def r6492 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject6492 : ¬ Reader r6492 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 0))))))))) (.lam (.app (.var 0) (.lam (.lam (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6492
def r6493 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 0))))))) (.var 1)) (.var 0))
theorem reject6493 : ¬ Reader r6493 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6493
def r6494 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 0))))))) (.var 0)) (.var 1))
theorem reject6494 : ¬ Reader r6494 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 0))))))) (.lam (.var 0))) [(.lam (.lam (.var 0)))] [(.lam (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6494
def r6495 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.lam (.var 0)))))) (.var 1)) (.var 0))
theorem reject6495 : ¬ Reader r6495 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6495
def r6496 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.lam (.var 0)))))) (.var 0)) (.var 1))
theorem reject6496 : ¬ Reader r6496 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))) (.lam (.var 0)))))) (.lam (.lam (.var 0)))) [(.lam (.var 0))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6496
def r6497 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject6497 : ¬ Reader r6497 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[9],[],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide) (by decide) (by decide)
#print axioms reject6497
def r6498 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject6498 : ¬ Reader r6498 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[9],[],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0]) (.lam 7 (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) [7]) [0]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide) (by decide) (by decide)
#print axioms reject6498
def r6499 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) (.var 1)) (.var 0))
theorem reject6499 : ¬ Reader r6499 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) (.var 1)) [(.lam (.lam (.lam (.var 0))))] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6499
def r6500 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) (.var 0)) (.var 1))
theorem reject6500 : ¬ Reader r6500 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))) (.var 0)) [(.lam (.lam (.lam (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6500
def r6501 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.lam (.var 1)))
theorem reject6501 : ¬ Reader r6501 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6501
def r6502 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.var 1))) (.var 1))
theorem reject6502 : ¬ Reader r6502 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6502
def r6503 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1)) (.var 0))
theorem reject6503 : ¬ Reader r6503 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r6503 Z) = some (spine (BodyLetSpecial.templateState (.lam (.var 2)) (.lam (.lam (.var 0)))) [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject6503
def r6504 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 0)) (.var 1))
theorem reject6504 : ¬ Reader r6504 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r6504 Z) = some (spine (BodyLetSpecial.templateState (.lam (.var 2)) (.lam (.lam (.var 0)))) [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject6504
def r6505 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.var 0))
theorem reject6505 : ¬ Reader r6505 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6505
def r6506 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.var 1))
theorem reject6506 : ¬ Reader r6506 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6506
def r6507 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))) (.var 1)) (.var 0))
theorem reject6507 : ¬ Reader r6507 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6507
end Blc.HandlerLet.Slice42Main0168
