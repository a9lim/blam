import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0177
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6828 : Term := (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6828 : ¬ Reader r6828 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6828
def r6829 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6829 : ¬ Reader r6829 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.var 0), (.lam (.lam (.var 1))), (.var 3), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6829
def r6830 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6830 : ¬ Reader r6830 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.lam (.var 1))), (.var 3), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6830
def r6831 : Term := (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6831 : ¬ Reader r6831 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6831
def r6832 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6832 : ¬ Reader r6832 := by
  exact replay_absent false [] 12 0 (by decide) (by decide)
#print axioms reject6832
def r6833 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6833 : ¬ Reader r6833 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6833
def r6834 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6834 : ¬ Reader r6834 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.lam (.var 1))), (.var 3), (.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6834
def r6835 : Term := (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6835 : ¬ Reader r6835 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6835
def r6836 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject6836 : ¬ Reader r6836 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.lam (.var 1))), (.var 3), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6836
def r6837 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))
theorem reject6837 : ¬ Reader r6837 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))] (by decide) (by decide) (by decide)
#print axioms reject6837
def r6838 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))
theorem reject6838 : ¬ Reader r6838 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))) (.var 0))] (by decide) (by decide) (by decide)
#print axioms reject6838
def r6839 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))
theorem reject6839 : ¬ Reader r6839 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))] (by decide) (by decide) (by decide)
#print axioms reject6839
def r6840 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))
theorem reject6840 : ¬ Reader r6840 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))) (.var 0))] (by decide) (by decide) (by decide)
#print axioms reject6840
def r6841 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))
theorem reject6841 : ¬ Reader r6841 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))] (by decide) (by decide) (by decide)
#print axioms reject6841
def r6842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))
theorem reject6842 : ¬ Reader r6842 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))) (.var 0))] (by decide) (by decide) (by decide)
#print axioms reject6842
def r6843 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))
theorem reject6843 : ¬ Reader r6843 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6843
def r6844 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))
theorem reject6844 : ¬ Reader r6844 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6844
def r6845 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))
theorem reject6845 : ¬ Reader r6845 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6845
def r6846 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))
theorem reject6846 : ¬ Reader r6846 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6846
def r6847 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))
theorem reject6847 : ¬ Reader r6847 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6847
def r6848 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))
theorem reject6848 : ¬ Reader r6848 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6848
def r6849 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))
theorem reject6849 : ¬ Reader r6849 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6849
def r6850 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))
theorem reject6850 : ¬ Reader r6850 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6850
def r6851 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))
theorem reject6851 : ¬ Reader r6851 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide) (by decide) (by decide)
#print axioms reject6851
def r6852 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))
theorem reject6852 : ¬ Reader r6852 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))) [(.var 1), (.app (.var 0) (.var 0))] [(.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6852
def r6853 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))))
theorem reject6853 : ¬ Reader r6853 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 1)))) [(.var 1), (.var 0), (.var 0)] [(.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6853
def r6854 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))))
theorem reject6854 : ¬ Reader r6854 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 1)))) [(.var 0), (.var 1), (.var 0)] [(.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6854
def r6855 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))
theorem reject6855 : ¬ Reader r6855 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))) [(.app (.var 0) (.var 0)), (.var 1)] [(.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6855
def r6856 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))))
theorem reject6856 : ¬ Reader r6856 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.var 2)))) [(.var 0), (.var 0), (.var 1)] [(.lam (.lam (.var 1))), (.var 3)] (by decide) (by decide) (by decide)
#print axioms reject6856
def r6857 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))
theorem reject6857 : ¬ Reader r6857 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))), (.var 1), (.var 0), (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6857
def r6858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))
theorem reject6858 : ¬ Reader r6858 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.app (.app (.var 0) (.var 0)) (.var 2))), (.var 0), (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6858
def r6859 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0)))
theorem reject6859 : ¬ Reader r6859 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))) (.var 1))] [(.var 0), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6859
def r6860 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0)))
theorem reject6860 : ¬ Reader r6860 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))) [(.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 1))] [(.var 0), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6860
def r6861 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) (.var 0)))
theorem reject6861 : ¬ Reader r6861 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) [(.var 1), (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))] [(.var 0), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6861
def r6862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0)))
theorem reject6862 : ¬ Reader r6862 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))) [(.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))) (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))), (.var 1), (.var 1)] [(.var 0), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6862
def r6863 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) (.var 0)))
theorem reject6863 : ¬ Reader r6863 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))), (.var 1)] [(.var 0), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6863
def r6864 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem reject6864 : ¬ Reader r6864 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 1)), (.var 0), (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6864
def r6865 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem reject6865 : ¬ Reader r6865 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.lam (.app (.var 0) (.var 0))) (.var 1)), (.var 0), (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.app (.var 0) (.var 0)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6865
def r6866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)))
theorem reject6866 : ¬ Reader r6866 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.app (.var 0) (.var 0))), (.var 0), (.app (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6866
def r6867 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0))))
theorem reject6867 : ¬ Reader r6867 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.app (.var 0) (.var 0)), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6867
end Blc.HandlerLet.Slice42Main0177
