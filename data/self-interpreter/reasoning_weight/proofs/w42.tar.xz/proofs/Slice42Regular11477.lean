import Slice42Regular11477Model
import Slice42Regular11477Four000
import Slice42Regular11477Four004
import Slice42Regular11477Four008
import Slice42Regular11477Four012
import Slice42Regular11477Four016
import Slice42Regular11477Four020
import Slice42Regular11477Four024
import Slice42Regular11477Four028
import Slice42Regular11477Four032
import Slice42Regular11477Four036
import Slice42Regular11477Four040
import Slice42Regular11477Four044
import Slice42Regular11477Four048
import Slice42Regular11477Four052
import Slice42Regular11477Four056
import Blc.SelfintRootLetEmbedding
import Certificates
namespace Certgen.Slice42Regular11477
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintClass Blc.SelfintSourceCost
open Blc.HandlerLet Blc.SelfintLowerBound Blc.SelfintStreamSpecializer
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i < 58 := hi
 by_cases bound28 : i < 28
 · by_cases bound12 : i < 12
   · by_cases bound4 : i < 4
     · exact range_sound small0 i (by omega) (by omega) hi
     · by_cases bound8 : i < 8
       · exact range_sound small4 i (by omega) (by omega) hi
       · exact range_sound small8 i (by omega) (by omega) hi
   · by_cases bound20 : i < 20
     · by_cases bound16 : i < 16
       · exact range_sound small12 i (by omega) (by omega) hi
       · exact range_sound small16 i (by omega) (by omega) hi
     · by_cases bound24 : i < 24
       · exact range_sound small20 i (by omega) (by omega) hi
       · exact range_sound small24 i (by omega) (by omega) hi
 · by_cases bound44 : i < 44
   · by_cases bound36 : i < 36
     · by_cases bound32 : i < 32
       · exact range_sound small28 i (by omega) (by omega) hi
       · exact range_sound small32 i (by omega) (by omega) hi
     · by_cases bound40 : i < 40
       · exact range_sound small36 i (by omega) (by omega) hi
       · exact range_sound small40 i (by omega) (by omega) hi
   · by_cases bound52 : i < 52
     · by_cases bound48 : i < 48
       · exact range_sound small44 i (by omega) (by omega) hi
       · exact range_sound small48 i (by omega) (by omega) hi
     · by_cases bound56 : i < 56
       · exact range_sound small52 i (by omega) (by omega) hi
       · exact range_sound small56 i (by omega) (by omega) hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)
theorem diverges (n : Nat) : ¬ Count core n := by rw [←literal]; exact regular_no_clock model closed root n
def r11477 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject11477 : ¬ Reader r11477 := by
 intro hr
 have replay : betaSteps [] (.app r11477 Z) = some (spine core []) := by decide
 have nf := betas_preserve_nf (betaSteps_sound _ replay) hr.zero_red zeroOut_normal
 obtain ⟨n,h⟩ := hasNormalForm_count ⟨_,nf,zeroOut_normal⟩
 obtain ⟨m,_,hm⟩ := SelfintRootLetOrbit.count_spine_fn [] h
 exact diverges m hm
#print axioms reject11477

end Certgen.Slice42Regular11477
