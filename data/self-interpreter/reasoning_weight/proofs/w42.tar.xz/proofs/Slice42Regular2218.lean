import Slice42Regular2218Model
import Slice42Regular2218Four000
import Slice42Regular2218Four004
import Slice42Regular2218Four008
import Slice42Regular2218Four012
import Slice42Regular2218Four016
import Slice42Regular2218Four020
import Slice42Regular2218Four024
import Slice42Regular2218Four028
import Slice42Regular2218Four032
import Slice42Regular2218Four036
import Slice42Regular2218Four040
import Slice42Regular2218Four044
import Slice42Regular2218Four048
import Slice42Regular2218Four052
import Slice42Regular2218Four056
import Slice42Regular2218Four060
import Slice42Regular2218Four064
import Slice42Regular2218Four068
import Slice42Regular2218Four072
import Slice42Regular2218Four076
import Slice42Regular2218Four080
import Slice42Regular2218Four084
import Slice42Regular2218Four088
import Slice42Regular2218Four092
import Slice42Regular2218Four096
import Slice42Regular2218Four100
import Slice42Regular2218Four104
import Slice42Regular2218Four108
import Blc.SelfintRootLetEmbedding
import Certificates
namespace Certgen.Slice42Regular2218
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
open Blc Blc.SelfintRegularSoundness Blc.WeakHeadClock Blc.SelfintClass Blc.SelfintSourceCost
open Blc.HandlerLet Blc.SelfintLowerBound Blc.SelfintStreamSpecializer
theorem closedAt (i : Nat) (hi : i<states.size) : Good P V K states states[i] := by
 have hh : i < 109 := hi
 by_cases bound56 : i < 56
 · by_cases bound28 : i < 28
   · by_cases bound12 : i < 12
     · by_cases bound4 : i < 4
       · exact range_sound small0 i (by omega) (by omega) hi
       · by_cases bound8 : i < 8
         · exact range_sound small4 i (by omega) (by omega) hi
         · exact range_sound small8 i (by omega) (by omega) hi
     · by_cases bound20 : i < 20
       · by_cases bound16 : i < 16
         · exact range_sound small12 i (by omega) (by omega) hi
         · exact range_sound small16 i (by omega) (by omega) hi
       · by_cases bound24 : i < 24
         · exact range_sound small20 i (by omega) (by omega) hi
         · exact range_sound small24 i (by omega) (by omega) hi
   · by_cases bound40 : i < 40
     · by_cases bound32 : i < 32
       · exact range_sound small28 i (by omega) (by omega) hi
       · by_cases bound36 : i < 36
         · exact range_sound small32 i (by omega) (by omega) hi
         · exact range_sound small36 i (by omega) (by omega) hi
     · by_cases bound48 : i < 48
       · by_cases bound44 : i < 44
         · exact range_sound small40 i (by omega) (by omega) hi
         · exact range_sound small44 i (by omega) (by omega) hi
       · by_cases bound52 : i < 52
         · exact range_sound small48 i (by omega) (by omega) hi
         · exact range_sound small52 i (by omega) (by omega) hi
 · by_cases bound84 : i < 84
   · by_cases bound68 : i < 68
     · by_cases bound60 : i < 60
       · exact range_sound small56 i (by omega) (by omega) hi
       · by_cases bound64 : i < 64
         · exact range_sound small60 i (by omega) (by omega) hi
         · exact range_sound small64 i (by omega) (by omega) hi
     · by_cases bound76 : i < 76
       · by_cases bound72 : i < 72
         · exact range_sound small68 i (by omega) (by omega) hi
         · exact range_sound small72 i (by omega) (by omega) hi
       · by_cases bound80 : i < 80
         · exact range_sound small76 i (by omega) (by omega) hi
         · exact range_sound small80 i (by omega) (by omega) hi
   · by_cases bound96 : i < 96
     · by_cases bound88 : i < 88
       · exact range_sound small84 i (by omega) (by omega) hi
       · by_cases bound92 : i < 92
         · exact range_sound small88 i (by omega) (by omega) hi
         · exact range_sound small92 i (by omega) (by omega) hi
     · by_cases bound104 : i < 104
       · by_cases bound100 : i < 100
         · exact range_sound small96 i (by omega) (by omega) hi
         · exact range_sound small100 i (by omega) (by omega) hi
       · by_cases bound108 : i < 108
         · exact range_sound small104 i (by omega) (by omega) hi
         · exact range_sound small108 i (by omega) (by omega) hi
theorem closed : ∀ s ∈ states, Good P V K states s := by
 intro s hs
 obtain ⟨i,hi,he⟩ := Array.mem_iff_getElem.mp hs
 simpa [he] using closedAt i hi
theorem root : entry ∈ states := Array.mem_of_getElem? (i := 0) (by decide)
theorem diverges (n : Nat) : ¬ Count core n := by rw [←literal]; exact regular_no_clock model closed root n
def r2218 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))) (.var 1)))) (.var 1))
theorem reject2218 : ¬ Reader r2218 := by
 intro hr
 have replay : betaSteps [] (.app r2218 Z) = some (spine core [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have nf := betas_preserve_nf (betaSteps_sound _ replay) hr.zero_red zeroOut_normal
 obtain ⟨n,h⟩ := hasNormalForm_count ⟨_,nf,zeroOut_normal⟩
 obtain ⟨m,_,hm⟩ := SelfintRootLetOrbit.count_spine_fn [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] h
 exact diverges m hm
#print axioms reject2218

end Certgen.Slice42Regular2218
