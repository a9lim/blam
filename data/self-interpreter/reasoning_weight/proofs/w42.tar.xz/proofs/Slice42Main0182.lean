import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0182
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r7028 : Term := (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject7028 : ¬ Reader r7028 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.var 1)), (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7028
def r7029 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject7029 : ¬ Reader r7029 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7029
def r7030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject7030 : ¬ Reader r7030 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 1))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7030
def r7031 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject7031 : ¬ Reader r7031 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 3)))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7031
def r7032 : Term := (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject7032 : ¬ Reader r7032 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.var 0)) (.var 2))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7032
def r7033 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2)) (.lam (.var 2)))))
theorem reject7033 : ¬ Reader r7033 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) [(.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))] [(.var 1), (.lam (.var 1)), (.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7033
def r7034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2)) (.lam (.var 2)))))
theorem reject7034 : ¬ Reader r7034 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) [(.lam (.app (.app (.var 0) (.var 0)) (.var 0)))] [(.var 1), (.lam (.var 1)), (.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7034
def r7035 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 2)) (.var 1))))
theorem reject7035 : ¬ Reader r7035 := by
 exact mixed_reduct true [[1], [1], [1, 1, 1]] [[1, 1, 1, 1, 1, 2], [1, 1, 1, 1, 1, 2]] (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 1)) (.var 0)) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide) (by decide)
#print axioms reject7035
def r7036 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))) (.var 2)) (.var 1))))
theorem reject7036 : ¬ Reader r7036 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))) [(.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))] [(.var 1), (.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7036
def r7037 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))) (.var 2)) (.var 1))))
theorem reject7037 : ¬ Reader r7037 := by
  exact replay_loop true [] 4 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))), (.var 1), (.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7037
def r7038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.var 2))) (.var 2))))
theorem reject7038 : ¬ Reader r7038 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) [(.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))] [(.lam (.var 1)), (.var 1), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7038
def r7039 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.lam (.var 2))) (.var 2))))
theorem reject7039 : ¬ Reader r7039 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) [(.lam (.app (.app (.var 0) (.var 0)) (.var 0)))] [(.lam (.var 1)), (.var 1), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7039
def r7040 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 1)) (.var 2))))
theorem reject7040 : ¬ Reader r7040 := by
 exact mixed_reduct true [[1], [1], [1, 1, 1]] [[1, 1, 1, 1, 1, 2], [1, 1, 1, 1, 1, 2]] (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 1)) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide) (by decide)
#print axioms reject7040
def r7041 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))) (.var 1)) (.var 2))))
theorem reject7041 : ¬ Reader r7041 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))) [(.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))] [(.var 0), (.var 1), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7041
def r7042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))) (.var 1)) (.var 2))))
theorem reject7042 : ¬ Reader r7042 := by
  exact replay_loop true [] 4 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))), (.var 0), (.var 1), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7042
def r7043 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))
theorem reject7043 : ¬ Reader r7043 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7043
def r7044 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))
theorem reject7044 : ¬ Reader r7044 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7044
def r7045 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))
theorem reject7045 : ¬ Reader r7045 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7045
def r7046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))
theorem reject7046 : ¬ Reader r7046 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7046
def r7047 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))
theorem reject7047 : ¬ Reader r7047 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7047
def r7048 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))
theorem reject7048 : ¬ Reader r7048 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7048
def r7049 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))
theorem reject7049 : ¬ Reader r7049 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7049
def r7050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))
theorem reject7050 : ¬ Reader r7050 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7050
def r7051 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))
theorem reject7051 : ¬ Reader r7051 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7051
def r7052 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))
theorem reject7052 : ¬ Reader r7052 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7052
def r7053 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))
theorem reject7053 : ¬ Reader r7053 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7053
def r7054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))
theorem reject7054 : ¬ Reader r7054 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7054
def r7055 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))
theorem reject7055 : ¬ Reader r7055 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7055
def r7056 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))
theorem reject7056 : ¬ Reader r7056 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7056
def r7057 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))
theorem reject7057 : ¬ Reader r7057 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7057
def r7058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))
theorem reject7058 : ¬ Reader r7058 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7058
def r7059 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))
theorem reject7059 : ¬ Reader r7059 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7059
def r7060 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.var 1))) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))
theorem reject7060 : ¬ Reader r7060 := by
  exact replay_absent true [] 4 3 (by decide) (by decide)
#print axioms reject7060
def r7061 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))))
theorem reject7061 : ¬ Reader r7061 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))) [(.var 1), (.lam (.app (.var 1) (.lam (.var 0)))), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7061
def r7062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))))
theorem reject7062 : ¬ Reader r7062 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))) [(.var 1), (.app (.var 0) (.lam (.lam (.var 1)))), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7062
def r7063 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 1)))))
theorem reject7063 : ¬ Reader r7063 := by
 exact mixed_reduct true [[1]] [[1, 2, 1, 1, 1], [1, 2, 1, 1, 1], [1, 2, 1, 1, 1, 0, 1, 1, 1], [1, 2, 1, 1, 1, 0, 1, 1], [1, 2, 1, 1, 1, 0, 1], [1, 2, 1, 1, 1, 0], [1, 2, 1, 1], [1, 2, 1], [1], [1, 2, 1, 2], [1, 2, 1, 1, 1, 1], [1, 2, 1, 1, 1], [1, 2, 1, 1, 1], [1, 2, 1, 1, 1, 0, 1, 1, 1], [1, 2, 1, 1, 1, 0, 1, 1], [1, 2, 1, 1, 1, 0, 1], [1, 2, 1, 1, 1, 0], [1, 1], [1, 2, 1, 1], [1, 2, 1], [1, 2]] (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide) (by decide)
#print axioms reject7063
def r7064 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))))
theorem reject7064 : ¬ Reader r7064 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))) [(.lam (.var 0)), (.var 1), (.lam (.var 1)), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))) (.lam (.var 0))) (.var 1)) (.lam (.var 1))) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7064
def r7065 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))))
theorem reject7065 : ¬ Reader r7065 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))) [(.lam (.lam (.var 1))), (.var 1), (.var 0), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7065
def r7066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))))
theorem reject7066 : ¬ Reader r7066 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))) [(.var 0), (.var 1), (.lam (.lam (.var 1))), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7066
def r7067 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))))
theorem reject7067 : ¬ Reader r7067 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))) [(.lam (.var 1)), (.var 1), (.lam (.var 0)), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1)) (.lam (.var 0))) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject7067
end Blc.HandlerLet.Slice42Main0182
