import Slice42Regular2218Data
namespace Certgen.Slice42Regular2218
set_option maxRecDepth 30000
set_option maxHeartbeats 12000000
theorem small100 : checkRange P V K states hints 100 4 = true := by decide +kernel
end Certgen.Slice42Regular2218
