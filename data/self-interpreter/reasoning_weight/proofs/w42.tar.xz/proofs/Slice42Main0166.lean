import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice42Main0166
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6388 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.lam (.var 1))) (.var 1))
theorem reject6388 : ¬ Reader r6388 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0)))))) (.lam (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6388
def r6389 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject6389 : ¬ Reader r6389 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6389
def r6390 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject6390 : ¬ Reader r6390 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1))))) (.lam (.var 0))) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1))))] [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6390
def r6391 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject6391 : ¬ Reader r6391 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6391
def r6392 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1))
theorem reject6392 : ¬ Reader r6392 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) [(.lam (.var 0))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6392
def r6393 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.var 1)) (.app (.var 0) (.lam (.var 0))))
theorem reject6393 : ¬ Reader r6393 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6393
def r6394 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.app (.var 0) (.lam (.var 0)))) (.var 1))
theorem reject6394 : ¬ Reader r6394 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6394
def r6395 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6395 : ¬ Reader r6395 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6395
def r6396 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6396 : ¬ Reader r6396 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6396
def r6397 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6397 : ¬ Reader r6397 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6397
def r6398 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6398 : ¬ Reader r6398 := by
  exact replay_absent true [] 5 1 (by decide) (by decide)
#print axioms reject6398
def r6399 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1))))))) (.var 1)) (.var 0))
theorem reject6399 : ¬ Reader r6399 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6399
def r6400 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1))
theorem reject6400 : ¬ Reader r6400 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1)))))))) (.lam (.lam (.var 1)))) [(.lam (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6400
def r6401 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0)))))))) (.var 1)) (.var 0))
theorem reject6401 : ¬ Reader r6401 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6401
def r6402 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0)))))))) (.var 0)) (.var 1))
theorem reject6402 : ¬ Reader r6402 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0))))))) (.lam (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6402
def r6403 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject6403 : ¬ Reader r6403 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6403
def r6404 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject6404 : ¬ Reader r6404 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1))))))) (.lam (.lam (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6404
def r6405 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.var 0))
theorem reject6405 : ¬ Reader r6405 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6405
def r6406 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))) (.var 0)) (.var 1))
theorem reject6406 : ¬ Reader r6406 := by
  exact replay_loop true [] 5 3 (.app (.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 0))))))) (.lam (.var 0))) [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6406
def r6407 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))) (.var 1)) (.var 0))
theorem reject6407 : ¬ Reader r6407 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6407
def r6408 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))) (.var 0)) (.var 1))
theorem reject6408 : ¬ Reader r6408 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))) (.lam (.var 0))) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2))))))] [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6408
def r6409 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 0)))))) (.var 1)) (.var 0))
theorem reject6409 : ¬ Reader r6409 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6409
def r6410 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 0)))))) (.var 0)) (.var 1))
theorem reject6410 : ¬ Reader r6410 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 0))))))) [(.lam (.var 0))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6410
def r6411 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))) (.var 1)) (.var 0))
theorem reject6411 : ¬ Reader r6411 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6411
def r6412 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))) (.var 0)) (.var 1))
theorem reject6412 : ¬ Reader r6412 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))) (.lam (.lam (.var 1)))) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))] [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6412
def r6413 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1)) (.var 0))
theorem reject6413 : ¬ Reader r6413 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6413
def r6414 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1))
theorem reject6414 : ¬ Reader r6414 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))) [(.lam (.lam (.var 1)))] [(.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6414
def r6415 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.var 1)) (.var 0))
theorem reject6415 : ¬ Reader r6415 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6415
def r6416 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.var 0)) (.var 1))
theorem reject6416 : ¬ Reader r6416 := by
  exact replay_absent true [] 6 1 (by decide) (by decide)
#print axioms reject6416
def r6417 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1))))) (.var 1)) (.var 0))
theorem reject6417 : ¬ Reader r6417 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6417
def r6418 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1))))) (.var 0)) (.var 1))
theorem reject6418 : ¬ Reader r6418 := by
  exact replay_loop true [] 3 3 (.app (.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1))))) (.lam (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6418
def r6419 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.var 0))
theorem reject6419 : ¬ Reader r6419 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6419
def r6420 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.var 0)) (.var 1))
theorem reject6420 : ¬ Reader r6420 := by
  exact replay_loop true [] 3 3 (.app (.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0))))))) (.lam (.var 0))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6420
def r6421 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject6421 : ¬ Reader r6421 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.lam (.var 2))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6421
def r6422 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject6422 : ¬ Reader r6422 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6422
def r6423 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))
theorem reject6423 : ¬ Reader r6423 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6423
def r6424 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))
theorem reject6424 : ¬ Reader r6424 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6424
def r6425 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.lam (.app (.var 1) (.var 1))))
theorem reject6425 : ¬ Reader r6425 := by
  exact replay_absent true [] 3 1 (by decide) (by decide)
#print axioms reject6425
def r6426 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.app (.var 1) (.var 1)))) (.var 1))
theorem reject6426 : ¬ Reader r6426 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide) (by decide) (by decide)
#print axioms reject6426
def r6427 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.app (.var 0) (.lam (.var 1))))
theorem reject6427 : ¬ Reader r6427 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.app (.var 0 [0]) (.lam 8 (.var 1 [0]) [8]) [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide) (by decide) (by decide)
#print axioms reject6427
end Blc.HandlerLet.Slice42Main0166
