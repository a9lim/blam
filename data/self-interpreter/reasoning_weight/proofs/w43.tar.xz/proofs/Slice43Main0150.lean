import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0150
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r5372 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)))) (.var 1))
theorem reject5372 : ¬ Reader r5372 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0)))))))) [(.lam (.lam (.lam (.lam (.var 0)))))] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5372
def r5373 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 1)))) (.var 1))
theorem reject5373 : ¬ Reader r5373 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.lam (.var 0))))), (.var 0), (.lam (.lam (.lam (.lam (.var 0))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5373
def r5374 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1))
theorem reject5374 : ¬ Reader r5374 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.lam (.lam (.lam (.var 0))))), (.var 0), (.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5374
def r5375 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))) (.var 1))
theorem reject5375 : ¬ Reader r5375 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 0), (.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5375
def r5376 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))) (.var 1)) (.var 0)))) (.var 1))
theorem reject5376 : ¬ Reader r5376 := by
  exact replay_loop true [] 0 7 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))) (.var 1)) (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5376
def r5377 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))))) (.var 1))
theorem reject5377 : ¬ Reader r5377 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))))) [(.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5377
def r5378 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))))) (.var 1))
theorem reject5378 : ¬ Reader r5378 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))))) [(.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 0), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5378
def r5379 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.var 1))
theorem reject5379 : ¬ Reader r5379 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) [(.var 0), (.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5379
def r5380 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 1))
theorem reject5380 : ¬ Reader r5380 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) [(.var 0), (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 0)) (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 0))) (.var 0)), (.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.lam (.lam (.lam (.lam (.lam (.var 0))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5380
def r5381 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.app (.var 0) (.var 0))))) (.var 1))
theorem reject5381 : ¬ Reader r5381 := by
  exact replay_loop true [] 1 7 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.app (.var 0) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5381
def r5382 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.var 1))
theorem reject5382 : ¬ Reader r5382 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) [(.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))) (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))))), (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))), (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5382
def r5383 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)))) (.var 1))
theorem reject5383 : ¬ Reader r5383 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)))) [(.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5383
def r5384 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) (.var 1))
theorem reject5384 : ¬ Reader r5384 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) [(.app (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1)))) (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))))), (.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 0), (.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5384
def r5385 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 1))
theorem reject5385 : ¬ Reader r5385 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) [(.app (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0))))))))) (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))))), (.var 0), (.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 0), (.lam (.lam (.lam (.lam (.lam (.var 0))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5385
def r5386 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.var 0)) (.var 1)))) (.var 1))
theorem reject5386 : ¬ Reader r5386 := by
  exact replay_loop true [] 1 7 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.var 0)) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5386
def r5387 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject5387 : ¬ Reader r5387 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) [(.var 0), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0)) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 0))) (.var 0))] [(.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5387
def r5388 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1))
theorem reject5388 : ¬ Reader r5388 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) [(.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))), (.var 0), (.var 0)] [(.lam (.lam (.lam (.lam (.lam (.var 0)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5388
def r5389 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.lam (.lam (.var 0)))))))))) (.var 1))
theorem reject5389 : ¬ Reader r5389 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.lam (.lam (.lam (.lam (.var 0))))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject5389
def r5390 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0)))) (.var 1))
theorem reject5390 : ¬ Reader r5390 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5390
def r5391 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))) (.var 0)))) (.var 1))
theorem reject5391 : ¬ Reader r5391 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5391
def r5392 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject5392 : ¬ Reader r5392 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.lam (.var 3)))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5392
def r5393 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 1))))))) (.var 0)) (.var 1)))) (.var 1))
theorem reject5393 : ¬ Reader r5393 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 1))))))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 1))))))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5393
def r5394 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 1))))))))) (.var 1))
theorem reject5394 : ¬ Reader r5394 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))))) [(.lam (.lam (.lam (.lam (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5394
def r5395 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1))
theorem reject5395 : ¬ Reader r5395 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))))) [(.lam (.lam (.lam (.lam (.var 0)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5395
def r5396 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0)))) (.var 1))
theorem reject5396 : ¬ Reader r5396 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 3)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5396
def r5397 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1))
theorem reject5397 : ¬ Reader r5397 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5397
def r5398 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.var 1))
theorem reject5398 : ¬ Reader r5398 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5398
def r5399 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))
theorem reject5399 : ¬ Reader r5399 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.lam (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5399
def r5400 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))) (.var 1))
theorem reject5400 : ¬ Reader r5400 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5400 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5400
def r5401 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))) (.var 1))
theorem reject5401 : ¬ Reader r5401 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5401 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5401
def r5402 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))) (.var 1))
theorem reject5402 : ¬ Reader r5402 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5402 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5402
def r5403 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))) (.var 1))
theorem reject5403 : ¬ Reader r5403 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5403 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5403
def r5404 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))) (.var 1))
theorem reject5404 : ¬ Reader r5404 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5404 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5404
def r5405 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))) (.var 1))
theorem reject5405 : ¬ Reader r5405 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5405 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5405
def r5406 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject5406 : ¬ Reader r5406 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5406
def r5407 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))) (.var 1))
theorem reject5407 : ¬ Reader r5407 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .rigid) (.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))
#print axioms reject5407
def r5408 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject5408 : ¬ Reader r5408 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5408
def r5409 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject5409 : ¬ Reader r5409 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5409
def r5410 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))) (.var 1))
theorem reject5410 : ¬ Reader r5410 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 2 [0]) (.var 1 [0]) [0]) [6]) (.var 0 [5]) []) (.var 1 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5410
def r5411 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))) (.var 1))
theorem reject5411 : ¬ Reader r5411 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 1 [0]) (.var 2 [0]) [0]) [6]) (.var 0 [5]) []) (.var 1 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5411
end Blc.HandlerLet.Slice43Main0150
