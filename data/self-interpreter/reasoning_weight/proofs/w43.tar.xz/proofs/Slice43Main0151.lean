import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0151
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r5412 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))) (.var 1))
theorem reject5412 : ¬ Reader r5412 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1))))) [(.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5412
def r5413 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))) (.var 1))
theorem reject5413 : ¬ Reader r5413 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 1))))) [(.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5413
def r5414 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject5414 : ¬ Reader r5414 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2)))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 2))))) [(.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5414
def r5415 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject5415 : ¬ Reader r5415 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5415
def r5416 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject5416 : ¬ Reader r5416 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0))) [(.app (.var 0) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5416
def r5417 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.var 1))
theorem reject5417 : ¬ Reader r5417 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.var 0))) [(.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5417
def r5418 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject5418 : ¬ Reader r5418 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.var 0))) [(.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5418
def r5419 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 1))
theorem reject5419 : ¬ Reader r5419 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5419 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5419
def r5420 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 1))
theorem reject5420 : ¬ Reader r5420 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5420 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5420
def r5421 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 1))
theorem reject5421 : ¬ Reader r5421 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) [(.var 0)] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5421
def r5422 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 1))
theorem reject5422 : ¬ Reader r5422 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5422
def r5423 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2)))))) (.var 1))
theorem reject5423 : ¬ Reader r5423 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5423
def r5424 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2))))) (.var 1))
theorem reject5424 : ¬ Reader r5424 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5424
def r5425 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject5425 : ¬ Reader r5425 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5425
def r5426 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject5426 : ¬ Reader r5426 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5426
def r5427 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject5427 : ¬ Reader r5427 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5427
def r5428 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject5428 : ¬ Reader r5428 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5428
def r5429 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 1))
theorem reject5429 : ¬ Reader r5429 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[5],[0,1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 2 [0]) [6]) (.var 1 [5]) [7]) (.app (.var 2 [0]) (.var 0 [0,1]) [0]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5429
def r5430 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 1))
theorem reject5430 : ¬ Reader r5430 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[5],[1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 2 [0]) [6]) (.var 1 [5]) [7]) (.app (.var 0 [1]) (.var 2 [0]) [1]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5430
def r5431 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.var 1))
theorem reject5431 : ¬ Reader r5431 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5431
def r5432 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.var 1))
theorem reject5432 : ¬ Reader r5432 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5432
def r5433 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.var 1))
theorem reject5433 : ¬ Reader r5433 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5433
def r5434 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.var 1))
theorem reject5434 : ¬ Reader r5434 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 3)))))) (.var 1)) [(.var 0)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5434
def r5435 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 2))))) (.var 1))
theorem reject5435 : ¬ Reader r5435 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject5435
def r5436 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 1))
theorem reject5436 : ¬ Reader r5436 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))
#print axioms reject5436
def r5437 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))) (.var 1))
theorem reject5437 : ¬ Reader r5437 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5437 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5437
def r5438 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))) (.var 1))
theorem reject5438 : ¬ Reader r5438 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5438 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5438
def r5439 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))) (.var 1))
theorem reject5439 : ¬ Reader r5439 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5439 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5439
def r5440 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))) (.var 1))
theorem reject5440 : ¬ Reader r5440 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5440 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5440
def r5441 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))) (.var 1))
theorem reject5441 : ¬ Reader r5441 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5441 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5441
def r5442 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))) (.var 1))
theorem reject5442 : ¬ Reader r5442 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5442 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5442
def r5443 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 1))
theorem reject5443 : ¬ Reader r5443 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) [(.var 0)] [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5443
def r5444 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 0))))) (.var 1))
theorem reject5444 : ¬ Reader r5444 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5444 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5444
def r5445 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 0))))) (.var 1))
theorem reject5445 : ¬ Reader r5445 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5445 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5445
def r5446 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 0))))) (.var 1))
theorem reject5446 : ¬ Reader r5446 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r5446 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject5446
def r5447 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject5447 : ¬ Reader r5447 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))) [(.app (.lam (.var 0)) (.lam (.var 0)))] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5447
def r5448 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 0)))))) (.var 1))
theorem reject5448 : ¬ Reader r5448 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))
#print axioms reject5448
def r5449 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject5449 : ¬ Reader r5449 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) [(.app (.var 0) (.lam (.var 0)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5449
def r5450 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 1))))) (.var 1))
theorem reject5450 : ¬ Reader r5450 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 1 [0]) (.lam 7 (.var 0 []) [7]) [0]) [6]) (.var 0 [5]) []) (.var 1 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5450
def r5451 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1))))) (.var 1))
theorem reject5451 : ¬ Reader r5451 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1)))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 1))))) [(.lam (.var 0)), (.lam (.var 0))] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5451
end Blc.HandlerLet.Slice43Main0151
