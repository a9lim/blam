import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0318
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r11449 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2)))))) (.var 1)) (.lam (.var 1)))
theorem reject11449 : ¬ Reader r11449 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2)))))) (.var 1)) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))))))] [(.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11449
def r11450 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2)))))) (.lam (.var 1))) (.var 1))
theorem reject11450 : ¬ Reader r11450 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2)))))) (.lam (.var 1))) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 2))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11450
def r11451 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject11451 : ¬ Reader r11451 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) (.var 1 [5]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.var 1 [0]) [8]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11451
def r11452 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject11452 : ¬ Reader r11452 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[7,8],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[7,8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [7,8]) [7]) []) (.var 1 [5]) []) [6]) [5]) [6]) (.lam 8 (.var 1 [0]) [8]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11452
def r11453 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.var 1)) (.lam (.app (.var 0) (.var 1))))
theorem reject11453 : ¬ Reader r11453 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11453
def r11454 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.lam (.app (.var 0) (.var 1)))) (.var 1))
theorem reject11454 : ¬ Reader r11454 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11454
def r11455 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 2)))))) (.var 1)) (.var 0))
theorem reject11455 : ¬ Reader r11455 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11455
def r11456 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 2)))))) (.var 0)) (.var 1))
theorem reject11456 : ¬ Reader r11456 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 2)))))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 2))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11456
def r11457 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 0)))))) (.var 1)) (.var 0))
theorem reject11457 : ¬ Reader r11457 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11457
def r11458 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 0)))))) (.var 0)) (.var 1))
theorem reject11458 : ¬ Reader r11458 := by
  exact replay_loop true [] 3 5 (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 0))))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 0)))))))) (.lam (.var 0))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11458
def r11459 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.var 3)))))))) (.var 1)) (.var 0))
theorem reject11459 : ¬ Reader r11459 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11459
def r11460 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.var 3)))))))) (.var 0)) (.var 1))
theorem reject11460 : ¬ Reader r11460 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 0) (.var 3))))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11460
def r11461 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 3)))))))) (.var 1)) (.var 0))
theorem reject11461 : ¬ Reader r11461 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11461
def r11462 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 3)))))))) (.var 0)) (.var 1))
theorem reject11462 : ¬ Reader r11462 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 3))))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11462
def r11463 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 1)))))))) (.var 1)) (.var 0))
theorem reject11463 : ¬ Reader r11463 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11463
def r11464 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 1)))))))) (.var 0)) (.var 1))
theorem reject11464 : ¬ Reader r11464 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.lam (.var 1))))))) (.lam (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11464
def r11465 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))))))) (.var 1)) (.var 0))
theorem reject11465 : ¬ Reader r11465 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,9],[],[],[],[],[]] [[],[],[],[],[6],[6],[6],[8],[0,1,5,6,7,9],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.lam 7 (.lam 8 (.var 2 [0,1,5,6,7,9]) [8]) [7]) [6]) [6]) [6]) [5]) [6]) (.var 1 [1]) [6]) (.var 0 [0]) [6]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11465
def r11466 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))))))) (.var 0)) (.var 1))
theorem reject11466 : ¬ Reader r11466 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,9],[],[],[],[],[]] [[],[],[],[],[6],[6],[6],[8],[0,1,5,6,7,9],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.lam 7 (.lam 8 (.var 2 [0,1,5,6,7,9]) [8]) [7]) [6]) [6]) [6]) [5]) [6]) (.var 0 [0]) [6]) (.var 1 [1]) [6]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11466
def r11469 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3)))))))) (.var 1)) (.var 0))
theorem reject11469 : ¬ Reader r11469 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[5],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.lam 8 (.var 3 [5]) [8]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11469
def r11470 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3)))))))) (.var 0)) (.var 1))
theorem reject11470 : ¬ Reader r11470 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[5],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0]) (.lam 7 (.lam 8 (.var 3 [5]) [8]) [7]) [0]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11470
def r11471 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.var 1)) (.var 0))
theorem reject11471 : ¬ Reader r11471 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))) [(.lam (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))))))] [(.lam (.lam (.lam (.lam (.var 5))))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11471
def r11472 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.var 0)) (.var 1))
theorem reject11472 : ¬ Reader r11472 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))) [(.lam (.lam (.lam (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.lam (.var 2))))))))))))] [(.lam (.lam (.lam (.lam (.var 4))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11472
def r11473 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) (.var 1)) (.var 0))
theorem reject11473 : ¬ Reader r11473 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))))] [(.lam (.lam (.var 3))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11473
def r11474 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) (.var 0)) (.var 1))
theorem reject11474 : ¬ Reader r11474 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.lam (.var 2))))))))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11474
def r11475 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject11475 : ¬ Reader r11475 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))))] [(.lam (.var 2)), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11475
def r11476 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject11476 : ¬ Reader r11476 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1))))))) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 2))) (.lam (.var 1)))))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11476
def r11477 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 2)))))) (.var 1)) (.var 0))
theorem reject11477 : ¬ Reader r11477 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[5],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) (.lam 8 (.var 2 [5]) [8]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11477
def r11478 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 2)))))) (.var 0)) (.var 1))
theorem reject11478 : ¬ Reader r11478 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[5],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) (.lam 8 (.var 2 [5]) [8]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11478
def r11479 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject11479 : ¬ Reader r11479 := by
 exact Rootcert2Flow.reject [[1, 1, 1]] [[],[],[],[],[8],[1],[10],[],[6],[8,11],[],[],[],[],[]] [[],[],[],[],[5],[],[8],[1],[9],[],[6],[8,11],[],[14],[]] (.app (.app (.app (.app (.lam 4 (.lam 5 (.app (.app (.app (.var 1 [8]) (.lam 6 (.var 2 [8]) [6]) [9]) (.var 1 [8]) []) (.lam 7 (.var 1 [1]) [7]) []) [5]) [4]) (.lam 8 (.lam 9 (.app (.app (.app (.var 1 [6]) (.lam 10 (.var 2 [6]) [10]) [8]) (.var 1 [6]) [9]) (.lam 11 (.var 1 [8,11]) [11]) []) [9]) [8]) [5]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 12 (.app (.app (.var 0 []) (.lam 13 (.lam 14 (.var 1 []) [14]) [13]) []) (.var 4 [3]) []) [12]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11479
def r11480 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject11480 : ¬ Reader r11480 := by
 exact Rootcert2Flow.reject [[1, 1, 1]] [[],[],[],[],[8],[0],[10],[],[6],[8,11],[],[],[],[],[]] [[],[],[],[],[5],[],[8],[0],[9],[],[6],[8,11],[],[14],[]] (.app (.app (.app (.app (.lam 4 (.lam 5 (.app (.app (.app (.var 1 [8]) (.lam 6 (.var 2 [8]) [6]) [9]) (.var 1 [8]) []) (.lam 7 (.var 1 [0]) [7]) []) [5]) [4]) (.lam 8 (.lam 9 (.app (.app (.app (.var 1 [6]) (.lam 10 (.var 2 [6]) [10]) [8]) (.var 1 [6]) [9]) (.lam 11 (.var 1 [8,11]) [11]) []) [9]) [8]) [5]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 12 (.app (.app (.var 0 []) (.lam 13 (.lam 14 (.var 1 []) [14]) [13]) []) (.var 4 [3]) []) [12]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11480
def r11481 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 1)) (.var 0))
theorem reject11481 : ¬ Reader r11481 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 1)) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))))] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11481
def r11482 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 0)) (.var 1))
theorem reject11482 : ¬ Reader r11482 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 0)) [(.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 3))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11482
def r11483 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 1))))) (.var 1)) (.var 0))
theorem reject11483 : ¬ Reader r11483 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[1,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.lam 8 (.var 2 [1,7]) [8]) [7]) []) (.var 1 [5]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11483
def r11484 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 1))))) (.var 0)) (.var 1))
theorem reject11484 : ¬ Reader r11484 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0,7],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.lam 8 (.var 2 [0,7]) [8]) [7]) []) (.var 1 [5]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11484
def r11485 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject11485 : ¬ Reader r11485 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11485
def r11486 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject11486 : ¬ Reader r11486 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11486
def r11487 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.var 1)) (.var 0))
theorem reject11487 : ¬ Reader r11487 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11487
def r11488 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.var 0)) (.var 1))
theorem reject11488 : ¬ Reader r11488 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 2))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11488
def r11489 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject11489 : ¬ Reader r11489 := by
 exact Rootcert2Flow.reject [[1, 1, 1]] [[],[],[],[],[6],[1],[1,6],[0,7,8,9],[0,7,8,9],[0,7,8,9],[],[],[]] [[],[],[],[],[5],[8],[7],[8],[0],[0],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.lam 5 (.app (.app (.var 1 [6]) (.var 1 [6]) [7]) (.app (.var 1 [6]) (.var 0 [1]) [7]) [8]) [5]) [4]) (.lam 6 (.lam 7 (.lam 8 (.app (.app (.var 1 [0,7,8,9]) (.var 1 [0,7,8,9]) [0,8]) (.app (.var 1 [0,7,8,9]) (.var 0 [0,7,8,9]) [0,8]) [0]) [8]) [7]) [6]) [5]) (.var 1 [1]) [8]) (.lam 9 (.var 1 [0]) [9]) [0]) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11489
def r11490 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.var 1))) (.var 1))
theorem reject11490 : ¬ Reader r11490 := by
 exact Rootcert2Flow.reject [[1, 1, 1]] [[],[],[],[],[6],[9],[6,9],[1,7,8],[1,7,8],[],[],[],[]] [[],[],[],[],[5],[8],[7],[8],[1],[0],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.lam 5 (.app (.app (.var 1 [6]) (.var 1 [6]) [7]) (.app (.var 1 [6]) (.var 0 [9]) [7]) [8]) [5]) [4]) (.lam 6 (.lam 7 (.lam 8 (.app (.app (.var 1 [1,7,8]) (.var 1 [1,7,8]) [1,8]) (.app (.var 1 [1,7,8]) (.var 0 [1,7,8]) [1,8]) [1]) [8]) [7]) [6]) [5]) (.lam 9 (.var 1 [0]) [9]) [8]) (.var 1 [1]) [1]) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) [1]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11490
end Blc.HandlerLet.Slice43Main0318
