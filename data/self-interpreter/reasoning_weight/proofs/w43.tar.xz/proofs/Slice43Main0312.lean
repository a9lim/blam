import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0312
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r11209 : Term := (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.var 0))
theorem reject11209 : ¬ Reader r11209 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11209
def r11210 : Term := (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.var 1))
theorem reject11210 : ¬ Reader r11210 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.var 0) (.var 0))), (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11210
def r11211 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.var 1)) (.var 0))
theorem reject11211 : ¬ Reader r11211 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11211
def r11212 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.var 0)) (.var 1))
theorem reject11212 : ¬ Reader r11212 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11212
def r11213 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.var 0))
theorem reject11213 : ¬ Reader r11213 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.var 0) (.var 0))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11213
def r11214 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.var 1))
theorem reject11214 : ¬ Reader r11214 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.var 0) (.var 0))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11214
def r11215 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 1)) (.var 0))
theorem reject11215 : ¬ Reader r11215 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[1],[5],[1],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 0 [1]) [6]) (.var 1 [5]) [7]) (.app (.var 0 [1]) (.var 0 [1]) [1]) []) [7]) [6]) [7]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11215
def r11216 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0)) (.var 1))
theorem reject11216 : ¬ Reader r11216 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[5],[0],[],[],[]] [[],[],[],[],[7],[6],[7],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [6]) (.lam 5 (.var 1 [6]) [5]) [7]) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 1 [5]) (.var 0 [0]) [6]) (.var 1 [5]) [7]) (.app (.var 0 [0]) (.var 0 [0]) [0]) []) [7]) [6]) [7]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11216
def r11217 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0))))) (.var 1)) (.var 0))
theorem reject11217 : ¬ Reader r11217 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))) (.var 1)) [(.var 1)] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11217
def r11218 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0))))) (.var 0)) (.var 1))
theorem reject11218 : ¬ Reader r11218 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11218
def r11219 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))) (.var 1)) (.var 0))
theorem reject11219 : ¬ Reader r11219 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))) (.var 1)) [] [(.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11219
def r11220 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))) (.var 0)) (.var 1))
theorem reject11220 : ¬ Reader r11220 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11220
def r11221 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.lam (.app (.var 0) (.var 1))))
theorem reject11221 : ¬ Reader r11221 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.app (.var 0) (.var 1))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11221
def r11222 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 1)))) (.var 1))
theorem reject11222 : ¬ Reader r11222 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.app (.var 0) (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11222
def r11223 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.var 0))) (.var 1))
theorem reject11223 : ¬ Reader r11223 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))) [(.var 0)] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11223
def r11224 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1)) (.lam (.var 0)))
theorem reject11224 : ¬ Reader r11224 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0))) [(.var 0)] [(.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11224
def r11225 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.var 0))) (.var 1))
theorem reject11225 : ¬ Reader r11225 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11225
def r11226 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.lam (.var 0)))
theorem reject11226 : ¬ Reader r11226 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11226
def r11227 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1))))))) (.var 1)) (.app (.var 0) (.var 0)))
theorem reject11227 : ¬ Reader r11227 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 0 []) (.var 1 [1,7]) []) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.app (.var 0 [0]) (.var 0 [0]) [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11227
def r11228 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0))) (.var 1))
theorem reject11228 : ¬ Reader r11228 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 0 []) (.var 1 [0,7]) []) [7]) []) [6]) [5]) [6]) (.app (.var 0 [0]) (.var 0 [0]) [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11228
def r11229 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))) (.var 1)) (.var 0))
theorem reject11229 : ¬ Reader r11229 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.var 0) (.app (.var 0) (.var 1))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11229
def r11230 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))) (.var 0)) (.var 1))
theorem reject11230 : ¬ Reader r11230 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.var 0) (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11230
def r11231 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))) (.var 1)) (.var 0))
theorem reject11231 : ¬ Reader r11231 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.app (.var 1) (.var 0)) (.var 0)), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11231
def r11232 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))) (.var 0)) (.var 1))
theorem reject11232 : ¬ Reader r11232 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.app (.var 0) (.var 0)) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11232
def r11233 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))) (.var 1)) (.var 0))
theorem reject11233 : ¬ Reader r11233 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.var 0), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11233
def r11234 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))) (.var 0)) (.var 1))
theorem reject11234 : ¬ Reader r11234 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11234
def r11235 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))))) (.var 1)) (.var 0))
theorem reject11235 : ¬ Reader r11235 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11235 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.var 2))) (.var 0)) [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11235
def r11236 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))))) (.var 0)) (.var 1))
theorem reject11236 : ¬ Reader r11236 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11236 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.var 2))) (.var 0)) [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11236
def r11237 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 1)) (.var 0))
theorem reject11237 : ¬ Reader r11237 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11237 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.var 1)) (.lam (.var 0))) [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11237
def r11238 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0)) (.var 1))
theorem reject11238 : ¬ Reader r11238 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11238 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.var 1)) (.lam (.var 0))) [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11238
def r11239 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 1)) (.var 0))
theorem reject11239 : ¬ Reader r11239 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11239 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 2)) (.lam (.var 0))) [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11239
def r11240 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0)) (.var 1))
theorem reject11240 : ¬ Reader r11240 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11240 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 2)) (.lam (.var 0))) [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11240
def r11241 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 1)) (.var 0))
theorem reject11241 : ¬ Reader r11241 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) [(.var 0)] [(.lam (.var 0)), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11241
def r11242 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 0)) (.var 1))
theorem reject11242 : ¬ Reader r11242 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) [(.var 0)] [(.lam (.var 0)), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11242
def r11243 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 1)) (.var 0))
theorem reject11243 : ¬ Reader r11243 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11243
def r11244 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 0)) (.var 1))
theorem reject11244 : ¬ Reader r11244 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.lam (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11244
def r11245 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.var 0))
theorem reject11245 : ¬ Reader r11245 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11245
def r11246 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.var 1))
theorem reject11246 : ¬ Reader r11246 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11246
def r11247 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 1)) (.app (.var 0) (.lam (.var 1))))
theorem reject11247 : ¬ Reader r11247 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .clear) (ka := .rigid) (.app (kf := .clear) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.var _ _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .clear) (ka := .rigid) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.app (kf := .clear) (ka := .pending) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel))
#print axioms reject11247
def r11248 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0)))))) (.app (.var 0) (.lam (.var 1)))) (.var 1))
theorem reject11248 : ¬ Reader r11248 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .clear) (ka := .rigid) (.app (kf := .clear) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.var _ _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.app (kf := .clear) (ka := .rigid) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.app (kf := .clear) (ka := .pending) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))
#print axioms reject11248
end Blc.HandlerLet.Slice43Main0312
