import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0303
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r10857 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 1))
theorem reject10857 : ¬ Reader r10857 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))) [] [(.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10857
def r10858 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject10858 : ¬ Reader r10858 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.lam (.lam (.lam (.var 0))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.var 0))))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10858
def r10859 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject10859 : ¬ Reader r10859 := by
  exact replay_loop true [] 3 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.lam (.lam (.lam (.var 0))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))))) (.lam (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.lam (.var 0))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10859
def r10860 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)))) (.var 1)) (.var 0))
theorem reject10860 : ¬ Reader r10860 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10860
def r10861 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0)))) (.var 0)) (.var 1))
theorem reject10861 : ¬ Reader r10861 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0))))))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10861
def r10862 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0)))) (.var 1)) (.var 0))
theorem reject10862 : ¬ Reader r10862 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10862
def r10863 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0)))) (.var 0)) (.var 1))
theorem reject10863 : ¬ Reader r10863 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10863
def r10864 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 1)) (.var 0))
theorem reject10864 : ¬ Reader r10864 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))))) [(.lam (.lam (.lam (.lam (.var 0)))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10864
def r10865 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0)) (.var 1))
theorem reject10865 : ¬ Reader r10865 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))))) [(.lam (.lam (.lam (.lam (.var 0)))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10865
def r10866 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 1)) (.var 0))
theorem reject10866 : ¬ Reader r10866 := by
 exact mixed_reduct true [[1, 1, 1]] [[1, 1, 1, 1, 2], [1, 1, 1, 1, 2]] (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject10866
def r10867 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 1))
theorem reject10867 : ¬ Reader r10867 := by
 exact mixed_reduct true [[1, 1, 1]] [[1, 1, 1, 1, 2], [1, 1, 1, 1, 2]] (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject10867
def r10868 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))) (.var 1)) (.var 0))
theorem reject10868 : ¬ Reader r10868 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))), (.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10868
def r10869 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))) (.var 0)) (.var 1))
theorem reject10869 : ¬ Reader r10869 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))) [] [(.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))), (.lam (.lam (.lam (.lam (.var 0))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10869
def r10870 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)) (.var 0))
theorem reject10870 : ¬ Reader r10870 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10870
def r10871 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)) (.var 1))
theorem reject10871 : ¬ Reader r10871 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.var 0))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10871
def r10872 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))
theorem reject10872 : ¬ Reader r10872 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.var 1), (.app (.var 0) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10872
def r10873 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))
theorem reject10873 : ¬ Reader r10873 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 0))))) [] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10873
def r10874 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.var 1))))))) (.var 1))
theorem reject10874 : ¬ Reader r10874 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.lam (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10874
def r10875 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1)) (.lam (.lam (.lam (.lam (.lam (.var 1)))))))
theorem reject10875 : ¬ Reader r10875 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))) [] [(.var 1), (.lam (.lam (.lam (.lam (.lam (.var 1)))))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10875
def r10876 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.lam (.lam (.lam (.lam (.var 0)))))) (.var 1))
theorem reject10876 : ¬ Reader r10876 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))) [] [(.lam (.lam (.lam (.lam (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10876
def r10877 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.var 1)) (.lam (.lam (.lam (.lam (.var 0))))))
theorem reject10877 : ¬ Reader r10877 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))) [] [(.var 1), (.lam (.lam (.lam (.lam (.var 0))))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10877
def r10878 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject10878 : ¬ Reader r10878 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))) [] [(.var 1), (.lam (.lam (.var 2))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10878
def r10879 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject10879 : ¬ Reader r10879 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))) [] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10879
def r10880 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0)))) (.var 1)) (.lam (.var 1)))
theorem reject10880 : ¬ Reader r10880 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10880
def r10881 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0)))) (.lam (.var 1))) (.var 1))
theorem reject10881 : ¬ Reader r10881 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.var 1)))))) (.var 0))))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10881
def r10882 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0)))) (.var 1)) (.var 0))
theorem reject10882 : ¬ Reader r10882 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10882
def r10883 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0)))) (.var 0)) (.var 1))
theorem reject10883 : ¬ Reader r10883 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.var 2))))))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10883
def r10884 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0)))) (.var 1)) (.var 0))
theorem reject10884 : ¬ Reader r10884 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10884
def r10885 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0)))) (.var 0)) (.var 1))
theorem reject10885 : ¬ Reader r10885 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.lam (.var 0)))))))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10885
def r10886 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 1)) (.var 0))
theorem reject10886 : ¬ Reader r10886 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7],[],[],[]] [[],[],[],[],[6],[6],[6],[],[9],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.app (.var 2 [0]) (.var 0 [0,1,5,6,7]) [0]) [6]) [6]) [6]) [5]) [6]) (.var 1 [1]) [6]) (.var 0 [0]) [6]) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10886
def r10887 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)) (.var 1))
theorem reject10887 : ¬ Reader r10887 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7],[],[],[]] [[],[],[],[],[6],[6],[6],[],[9],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.app (.var 2 [0]) (.var 0 [0,1,5,6,7]) [0]) [6]) [6]) [6]) [5]) [6]) (.var 0 [0]) [6]) (.var 1 [1]) [6]) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10887
def r10888 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 1)) (.var 0))
theorem reject10888 : ¬ Reader r10888 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,1,5,6,7],[0],[],[]] [[],[],[],[],[6],[6],[0,6],[0],[9],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [0,5,6]) (.app (.app (.var 1 [0,5,6]) (.var 1 [0,5,6]) [0,6]) (.app (.var 0 [0,1,5,6,7]) (.var 2 [0]) [0,1,6]) [0,6]) [0,6]) [6]) [5]) [6]) (.var 1 [1]) [0,6]) (.var 0 [0]) [0,6]) (.lam 7 (.app (.app (.var 0 [0]) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) [0]) (.var 4 [3]) [0]) [7]) [0,6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10888
def r10889 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)) (.var 1))
theorem reject10889 : ¬ Reader r10889 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,1,5,6,7],[0],[],[]] [[],[],[],[],[6],[6],[0,6],[0],[9],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [0,5,6]) (.app (.app (.var 1 [0,5,6]) (.var 1 [0,5,6]) [0,6]) (.app (.var 0 [0,1,5,6,7]) (.var 2 [0]) [0,1,6]) [0,6]) [0,6]) [6]) [5]) [6]) (.var 0 [0]) [0,6]) (.var 1 [1]) [0,6]) (.lam 7 (.app (.app (.var 0 [0]) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) [0]) (.var 4 [3]) [0]) [7]) [0,6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10889
def r10890 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 1)) (.var 0))
theorem reject10890 : ¬ Reader r10890 := by
  exact replay_loop true [] 9 4 (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0))) (.var 0)) (.var 0))] [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0))) (.var 0)) (.var 1)), (.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 1)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 1))) (.var 0)) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10890
def r10891 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 1))
theorem reject10891 : ¬ Reader r10891 := by
  exact replay_loop true [] 5 4 (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0))) (.var 0)) (.var 0))] [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)) (.var 0))) (.var 0)) (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10891
def r10892 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 1)) (.var 0))
theorem reject10892 : ¬ Reader r10892 := by
  exact replay_loop true [] 1 4 (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 1)) (.var 0)) [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 1)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 1)) (.var 0))) (.var 0)) (.var 0))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10892
def r10893 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 1))
theorem reject10893 : ¬ Reader r10893 := by
  exact replay_loop true [] 5 4 (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0)) [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0))) (.var 0)) (.var 0))] [(.app (.app (.app (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0)) (.app (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)) (.var 0))) (.var 1)) (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10893
def r10894 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.var 1)) (.var 0))
theorem reject10894 : ¬ Reader r10894 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))) [(.app (.var 0) (.app (.var 0) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))))] [(.app (.var 0) (.app (.var 0) (.var 1))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10894
def r10895 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.var 0)) (.var 1))
theorem reject10895 : ¬ Reader r10895 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))) [(.app (.var 0) (.app (.var 0) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))))] [(.app (.var 0) (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10895
def r10896 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))) (.var 1)) (.var 0))
theorem reject10896 : ¬ Reader r10896 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))) [(.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))))))) (.var 0)) (.var 0))] [(.app (.app (.var 1) (.var 0)) (.var 0)), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject10896
end Blc.HandlerLet.Slice43Main0303
