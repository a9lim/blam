import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0334
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r12091 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))) (.var 1)) (.var 0)) (.var 0))
theorem reject12091 : ¬ Reader r12091 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12091
def r12092 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))) (.var 0)) (.var 1)) (.var 0))
theorem reject12092 : ¬ Reader r12092 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12092
def r12093 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))) (.var 0)) (.var 0)) (.var 1))
theorem reject12093 : ¬ Reader r12093 := by
  exact replay_loop true [] 7 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12093
def r12094 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))) (.var 1)) (.var 0)) (.var 0))
theorem reject12094 : ¬ Reader r12094 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12094
def r12095 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))) (.var 0)) (.var 1)) (.var 0))
theorem reject12095 : ¬ Reader r12095 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12095
def r12096 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))) (.var 0)) (.var 0)) (.var 1))
theorem reject12096 : ¬ Reader r12096 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))) [(.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12096
def r12097 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 0)))))) (.var 1)) (.var 0)) (.var 0))
theorem reject12097 : ¬ Reader r12097 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12097
def r12098 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 0)))))) (.var 0)) (.var 1)) (.var 0))
theorem reject12098 : ¬ Reader r12098 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 0)), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12098
def r12099 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 0)))))) (.var 0)) (.var 0)) (.var 1))
theorem reject12099 : ¬ Reader r12099 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 0)), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12099
def r12100 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)) (.var 0)) (.var 0))
theorem reject12100 : ¬ Reader r12100 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 1), (.var 0), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12100
def r12101 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.var 1)) (.var 0))
theorem reject12101 : ¬ Reader r12101 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12101
def r12102 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.var 0)) (.var 1))
theorem reject12102 : ¬ Reader r12102 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) [] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12102
def r12103 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 0)) (.lam (.var 1)))
theorem reject12103 : ¬ Reader r12103 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12103
def r12104 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.lam (.var 1))) (.var 0))
theorem reject12104 : ¬ Reader r12104 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.var 1)), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12104
def r12105 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 1)) (.lam (.var 1)))
theorem reject12105 : ¬ Reader r12105 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12105
def r12106 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.lam (.var 1))) (.var 1))
theorem reject12106 : ¬ Reader r12106 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12106
def r12107 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 1))) (.var 1)) (.var 0))
theorem reject12107 : ¬ Reader r12107 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 1)), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12107
def r12108 : Term := (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.lam (.var 1))) (.var 0)) (.var 1))
theorem reject12108 : ¬ Reader r12108 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 1)), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12108
def r12109 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))
theorem reject12109 : ¬ Reader r12109 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12109
def r12110 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) (.lam (.var 1))) (.var 1))
theorem reject12110 : ¬ Reader r12110 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12110
def r12111 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))
theorem reject12111 : ¬ Reader r12111 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12111
def r12112 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))
theorem reject12112 : ¬ Reader r12112 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12112
def r12113 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.lam (.var 0))) (.lam (.var 1)))
theorem reject12113 : ¬ Reader r12113 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12113
def r12114 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.lam (.lam (.var 1)))) (.var 0))
theorem reject12114 : ¬ Reader r12114 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12114
def r12115 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.var 0)) (.lam (.lam (.var 1))))
theorem reject12115 : ¬ Reader r12115 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12115
def r12116 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 1)) (.lam (.var 1))) (.lam (.var 0)))
theorem reject12116 : ¬ Reader r12116 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12116
def r12117 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 0)) (.lam (.lam (.var 1)))) (.var 1))
theorem reject12117 : ¬ Reader r12117 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12117
def r12118 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))
theorem reject12118 : ¬ Reader r12118 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.lam (.lam (.var 1))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12118
def r12119 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 1))) (.lam (.var 0))) (.var 1))
theorem reject12119 : ¬ Reader r12119 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12119
def r12120 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))
theorem reject12120 : ¬ Reader r12120 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))) (.lam (.var 0))) [] [(.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12120
def r12121 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))
theorem reject12121 : ¬ Reader r12121 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[7,8],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[7,8],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [7,8]) [7]) []) [6]) [5]) [6]) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12121
def r12122 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))
theorem reject12122 : ¬ Reader r12122 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[7,8],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[7,8],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [7,8]) [7]) []) [6]) [5]) [6]) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12122
def r12123 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))
theorem reject12123 : ¬ Reader r12123 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.var 0 [0]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12123
def r12124 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))
theorem reject12124 : ¬ Reader r12124 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12124
def r12125 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))
theorem reject12125 : ¬ Reader r12125 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12125
def r12126 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))
theorem reject12126 : ¬ Reader r12126 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12126
def r12127 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject12127 : ¬ Reader r12127 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.lam (.var 1)))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12127
def r12128 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject12128 : ¬ Reader r12128 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.lam (.var 1)))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12128
def r12129 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject12129 : ¬ Reader r12129 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12129
def r12130 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject12130 : ¬ Reader r12130 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12130
end Blc.HandlerLet.Slice43Main0334
