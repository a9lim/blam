import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0476
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r17636 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 1))
theorem reject17636 : ¬ Reader r17636 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,5],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.app (.var 0 [0,5]) (.var 1 [5]) [0,6]) (.var 2 [0]) [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17636
def r17637 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.var 1))
theorem reject17637 : ¬ Reader r17637 := by
  exact replay_loop true [] 2 10 (.app (.lam (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 3))))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) [(.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))), (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))), (.var 0), (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))), (.var 0), (.var 0), (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17637
def r17638 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))) (.var 1))
theorem reject17638 : ¬ Reader r17638 := by
  exact replay_loop true [] 3 6 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))) [(.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))), (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))), (.var 0), (.var 0), (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17638
def r17639 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 1))
theorem reject17639 : ¬ Reader r17639 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0)) [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))) (.var 0))] [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17639
def r17640 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17640 : ¬ Reader r17640 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0)) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))] [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17640
def r17641 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))) (.var 1))
theorem reject17641 : ¬ Reader r17641 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[5,6],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.app (.var 1 [5,6]) (.var 0 [5,6]) [6]) []) (.var 2 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17641
def r17642 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))) (.var 1))
theorem reject17642 : ¬ Reader r17642 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[5,6],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [5,6]) (.var 1 [5]) [6]) []) (.var 2 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17642
def r17643 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 1))
theorem reject17643 : ¬ Reader r17643 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17643
def r17644 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 1))
theorem reject17644 : ¬ Reader r17644 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))) [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17644
def r17645 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))) (.var 1))
theorem reject17645 : ¬ Reader r17645 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1)))))) [(.var 0), (.app (.app (.var 0) (.var 0)) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17645
def r17646 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject17646 : ¬ Reader r17646 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))))) [(.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))) (.var 0))] [(.app (.var 0) (.var 0)), (.app (.var 0) (.var 0)), (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 2)))))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17646
def r17647 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))) (.var 1))
theorem reject17647 : ¬ Reader r17647 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))) (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))), (.var 0), (.var 0)] [(.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17647
def r17648 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))) (.var 1))
theorem reject17648 : ¬ Reader r17648 := by
  exact replay_loop true [] 9 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))), (.var 0)] [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))))), (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))), (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))), (.var 0), (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2)))))), (.var 0), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17648
def r17649 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1))
theorem reject17649 : ¬ Reader r17649 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))) (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))), (.var 0), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17649
def r17650 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1))
theorem reject17650 : ¬ Reader r17650 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17650
def r17651 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject17651 : ¬ Reader r17651 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17651
def r17652 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject17652 : ¬ Reader r17652 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))) [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17652
def r17653 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject17653 : ¬ Reader r17653 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17653
def r17654 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject17654 : ¬ Reader r17654 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))) [(.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17654
def r17655 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject17655 : ¬ Reader r17655 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17655
def r17656 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject17656 : ¬ Reader r17656 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2))))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17656
def r17657 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))) (.var 1))
theorem reject17657 : ¬ Reader r17657 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,5],[],[],[]] [[],[],[],[],[],[6],[],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 2 [0]) (.var 0 [0,5]) [0]) []) (.var 1 [5]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17657
def r17658 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))) (.var 1))
theorem reject17658 : ¬ Reader r17658 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5],[0,5,6],[],[],[]] [[],[],[],[],[0],[6],[0],[],[9],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.var 0 [5]) [0]) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 1 [0,5]) (.var 1 [0,5]) [0,6]) (.app (.var 0 [0,5,6]) (.var 2 [0]) [0,6]) [0]) (.var 1 [0,5]) [0]) [6]) [5]) [0]) (.var 1 [1]) [0]) (.lam 7 (.app (.app (.var 0 []) (.lam 8 (.lam 9 (.var 1 []) [9]) [8]) []) (.var 4 [3]) []) [7]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17658
def r17659 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17659 : ¬ Reader r17659 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))) (.var 0)) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))] [(.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1)))), (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17659
def r17660 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))) (.var 1))
theorem reject17660 : ¬ Reader r17660 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17660
def r17661 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))) (.var 1))
theorem reject17661 : ¬ Reader r17661 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17661
def r17662 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))) (.var 1))
theorem reject17662 : ¬ Reader r17662 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17662
def r17663 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))) (.var 1))
theorem reject17663 : ¬ Reader r17663 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17663
def r17664 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject17664 : ¬ Reader r17664 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17664
def r17665 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))) (.var 1))
theorem reject17665 : ¬ Reader r17665 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17665
def r17666 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))) (.var 1))
theorem reject17666 : ¬ Reader r17666 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17666
def r17667 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))) (.var 1))
theorem reject17667 : ¬ Reader r17667 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17667 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17667
def r17668 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))) (.var 1))
theorem reject17668 : ¬ Reader r17668 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17668 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17668
def r17669 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))) (.var 1))
theorem reject17669 : ¬ Reader r17669 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17669 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17669
def r17670 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))) (.var 1))
theorem reject17670 : ¬ Reader r17670 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17670 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17670
def r17671 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))) (.var 1))
theorem reject17671 : ¬ Reader r17671 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17671 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17671
def r17672 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))) (.var 1))
theorem reject17672 : ¬ Reader r17672 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17672 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17672
def r17673 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.var 1))
theorem reject17673 : ¬ Reader r17673 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.var 0))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.var 0)))) [(.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))] [(.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2)))))) (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17673
def r17674 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject17674 : ¬ Reader r17674 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))) [(.app (.var 0) (.var 0))] [(.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17674
def r17675 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject17675 : ¬ Reader r17675 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))) [(.app (.var 0) (.var 0))] [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2))))) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17675
end Blc.HandlerLet.Slice43Main0476
