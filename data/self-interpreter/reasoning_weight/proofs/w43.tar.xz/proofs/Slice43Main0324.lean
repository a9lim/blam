import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0324
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r11691 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))
theorem reject11691 : ¬ Reader r11691 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.app (.var 0 [0]) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) [0]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11691
def r11692 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))
theorem reject11692 : ¬ Reader r11692 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[9],[],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.app (.var 0 [0]) (.lam 8 (.lam 9 (.var 0 []) [9]) [8]) [0]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11692
def r11693 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11693 : ¬ Reader r11693 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11693
def r11694 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11694 : ¬ Reader r11694 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11694
def r11695 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11695 : ¬ Reader r11695 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11695 Z) = some (spine (BodyLetSpecial.templateState (.lam (.var 2)) (.var 0)) [(.lam (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11695
def r11696 : Term := (.app (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11696 : ¬ Reader r11696 := by
 intro hr
 have he : betaSteps [[1, 1, 1]] (.app r11696 Z) = some (spine (BodyLetSpecial.templateState (.lam (.var 2)) (.var 0)) [(.var 1), (.lam (.lam (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject11696
def r11697 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))) (.var 1)) (.lam (.var 1)))
theorem reject11697 : ¬ Reader r11697 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11697
def r11698 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))) (.lam (.var 1))) (.var 1))
theorem reject11698 : ¬ Reader r11698 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11698
def r11699 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1)))))) (.var 1)) (.lam (.var 1)))
theorem reject11699 : ¬ Reader r11699 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 3))), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11699
def r11700 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1)))))) (.lam (.var 1))) (.var 1))
theorem reject11700 : ¬ Reader r11700 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11700
def r11701 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 0)))))))) (.var 1)) (.lam (.var 1)))
theorem reject11701 : ¬ Reader r11701 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11701
def r11702 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 0)))))))) (.lam (.var 1))) (.var 1))
theorem reject11702 : ¬ Reader r11702 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11702
def r11703 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 0)))))) (.var 1)) (.lam (.var 1)))
theorem reject11703 : ¬ Reader r11703 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11703
def r11704 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 0)))))) (.lam (.var 1))) (.var 1))
theorem reject11704 : ¬ Reader r11704 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 0))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.var 0)))))) (.lam (.var 0))) [(.lam (.var 0))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11704
def r11705 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))) (.var 1)) (.lam (.var 1)))
theorem reject11705 : ¬ Reader r11705 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[],[0],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.lam 8 (.var 0 []) [8]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 9 (.var 1 [0]) [9]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11705
def r11706 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))) (.lam (.var 1))) (.var 1))
theorem reject11706 : ¬ Reader r11706 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,9],[],[],[7],[],[],[]] [[],[],[],[],[6],[6],[],[8],[],[0],[],[12],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0,9]) (.lam 7 (.lam 8 (.var 0 []) [8]) [7]) [0]) []) [6]) [5]) [6]) (.lam 9 (.var 1 [0]) [9]) []) (.var 1 [1]) []) (.lam 10 (.app (.app (.var 0 []) (.lam 11 (.lam 12 (.var 1 []) [12]) [11]) []) (.var 4 [3]) []) [10]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11706
def r11707 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))) (.var 1)) (.lam (.var 1)))
theorem reject11707 : ¬ Reader r11707 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))) (.var 1)) [(.lam (.lam (.var 0)))] [(.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11707
def r11708 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))) (.lam (.var 1))) (.var 1))
theorem reject11708 : ¬ Reader r11708 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))) (.lam (.var 1))) [(.lam (.lam (.var 0)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11708
def r11709 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.var 1)) (.lam (.app (.var 0) (.var 1))))
theorem reject11709 : ¬ Reader r11709 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11709
def r11710 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 1)))) (.var 1))
theorem reject11710 : ¬ Reader r11710 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0))))))) (.lam (.lam (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11710
def r11711 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.var 1)) (.app (.var 0) (.lam (.var 0))))
theorem reject11711 : ¬ Reader r11711 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11711
def r11712 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.app (.var 0) (.lam (.var 0)))) (.var 1))
theorem reject11712 : ¬ Reader r11712 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1))))))) (.lam (.lam (.var 1)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11712
def r11713 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject11713 : ¬ Reader r11713 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11713
def r11714 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject11714 : ¬ Reader r11714 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11714
def r11715 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 2))))))) (.var 1)) (.var 0))
theorem reject11715 : ¬ Reader r11715 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.lam (.var 5))))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11715
def r11716 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 2))))))) (.var 0)) (.var 1))
theorem reject11716 : ¬ Reader r11716 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.lam (.var 4))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11716
def r11717 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject11717 : ¬ Reader r11717 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11717
def r11718 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject11718 : ¬ Reader r11718 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11718
def r11719 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject11719 : ¬ Reader r11719 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11719
def r11720 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject11720 : ¬ Reader r11720 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11720
def r11721 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))) (.var 1)) (.var 0))
theorem reject11721 : ¬ Reader r11721 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11721
def r11722 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))) (.var 0)) (.var 1))
theorem reject11722 : ¬ Reader r11722 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0))))))))) (.lam (.lam (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11722
def r11723 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 1))))))))) (.var 1)) (.var 0))
theorem reject11723 : ¬ Reader r11723 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11723
def r11724 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 1))))))))) (.var 0)) (.var 1))
theorem reject11724 : ¬ Reader r11724 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11724
def r11725 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.var 0))))))))) (.var 1)) (.var 0))
theorem reject11725 : ¬ Reader r11725 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11725
def r11726 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.var 0))))))))) (.var 0)) (.var 1))
theorem reject11726 : ¬ Reader r11726 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.var 0)))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.var 1) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.lam (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11726
def r11727 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 1))))))))) (.var 1)) (.var 0))
theorem reject11727 : ¬ Reader r11727 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11727
def r11728 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 1))))))))) (.var 0)) (.var 1))
theorem reject11728 : ¬ Reader r11728 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.lam (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.lam (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11728
def r11729 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 1))))))) (.var 1)) (.var 0))
theorem reject11729 : ¬ Reader r11729 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11729
def r11730 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 1))))))) (.var 0)) (.var 1))
theorem reject11730 : ¬ Reader r11730 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.lam (.lam (.var 1))))))) (.lam (.var 0))) [(.lam (.lam (.var 1)))] [(.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11730
end Blc.HandlerLet.Slice43Main0324
