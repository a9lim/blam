import Blc.SelfintRound6ReaderBinary
namespace Blc.FloorDebt
open Term SelfintClass SelfintLowerBound SelfintSourceCost SelfintNestedLets WeakHeadClock
open SelfintSourceFront SelfintNeededHead SelfintLambdaSink SelfintLocalCost SelfintFlatMinimum SelfintRootFlat SelfintFlatPrefix SelfintControl SelfintWidenHoist SelfintDispatchAudit
open SelfintRootLetPowers (reader_betas)
open SelfintRootLetOrbit (count_fn)
open SelfintRootLetForcing (count_endpoint)
abbrev Table := Nat → (Nat × Nat) → Prop
abbrev Env := Nat → Nat
def ext (a : Nat) (e : Env) : Env
 | 0 => a
 | i+1 => e i

-- 0 excludes a lambda endpoint. 1 is unconstrained. Other atoms describe
-- functions by any finite list of input and output atom obligations.
inductive Ty (F : Table) : Env → Term → Nat → Prop where
 | var (e : Env) (i : Nat) : Ty F e (.var i) (e i)
 | top (t : Term) (e : Env) : Ty F e t 1
 | up {e t} (k : Nat) : Ty F e t 0 → Ty F e t k
 | lam {e b k} : 2 ≤ k →
     (∀ q, F k q → Ty F (ext q.1 e) b q.2) → Ty F e (.lam b) k
 | app {e f a k x y} : 2 ≤ k → F k (x,y) →
     Ty F e f k → Ty F e a x → Ty F e (.app f a) y
 | rigidApp {e f} (a : Term) : Ty F e f 0 → Ty F e (.app f a) 0

variable {F : Table}

theorem noLamAux (h : Ty F e t k) : ∀ b, t = .lam b → k = 0 → False := by
 induction h with
 | up _ _ ih => exact fun b h _ => ih b h rfl
 | lam hk _ _ => intros; omega
 | _ => intros; contradiction

theorem arrowAux (h : Ty F e t k) : ∀ b, t = .lam b → 2 ≤ k →
    ∀ q, F k q → Ty F (ext q.1 e) b q.2 := by
 induction h with
 | up _ h _ => intro b he; exact (noLamAux h b he rfl).elim
 | lam hk hb _ => intro b he; cases he; exact fun _ => hb
 | top => intros; omega
 | _ => intros; contradiction

theorem shiftTy (h : Ty F e t k) : ∀ d c e',
    (∀ n, e' (if c ≤ n then n+d else n) = e n) → Ty F e' (shift d c t) k := by
 induction h with
 | var e n =>
   intro d c e' he
   rw [←he n]
   by_cases hh : c≤n <;> simp [shift,hh] <;> exact .var _ _
 | top => intros; exact .top _ _
 | up k _ ih => intros; exact .up k (ih _ _ _ (by assumption))
 | lam hk hb ih =>
   intro d c e' he
   apply Ty.lam hk
   intro q hq
   apply ih q hq d (c+1) (ext q.1 e')
   intro n
   cases n with
   | zero => simp [ext]
   | succ n => by_cases hh : c ≤ n <;> simpa [hh,ext,show n+1+d=n+d+1 by omega] using he n
 | app hk hm _ _ ihf iha => intros; exact .app hk hm (ihf _ _ _ (by assumption)) (iha _ _ _ (by assumption))
 | rigidApp a _ ih => intros; exact .rigidApp _ (ih _ _ _ (by assumption))

theorem substTy (h : Ty F e t k) : ∀ j s d, Ty F d s (e j) →
   (∀ i, i ≠ j → d (if j < i then i-1 else i) = e i) → Ty F d (substDec j s t) k := by
 induction h with
 | var e i =>
   intro j s d hs he
   by_cases hi : i=j
   · subst i; simpa [substDec] using hs
   · rw [←he i hi]
     by_cases hj : j<i <;> simp [substDec,hi,hj] <;> exact .var _ _
 | top => intros; exact .top _ _
 | up k _ ih => intros; exact .up k (ih _ _ _ (by assumption) (by assumption))
 | lam hk hb ih =>
   intro j s d hs he
   apply Ty.lam hk
   intro q hq
   apply ih q hq (j+1) (shift 1 0 s) (ext q.1 d)
   · exact shiftTy hs 1 0 _ (by intro n; simp [ext])
   · intro i hi
     cases i with
     | zero => simp [ext]
     | succ i =>
       have h : i ≠ j := by omega
       by_cases hl : j<i
       · have hh : 0<i := by omega
         simpa [ext,hl,show i+1-1=(i-1)+1 by omega] using he i h
       · simpa [ext,hl] using he i h
 | app hk hm _ _ ihf iha => intros; exact .app hk hm (ihf _ _ _ (by assumption) (by assumption)) (iha _ _ _ (by assumption) (by assumption))
 | rigidApp a _ ih => intros; exact .rigidApp _ (ih _ _ _ (by assumption) (by assumption))

theorem preserve (ht : Ty F e t k) : ∀ u, Beta t u → Ty F e u k := by
 induction ht with
 | var => intro u h; cases h
 | top => intros; exact .top _ _
 | up k _ ih => intro u h; exact .up k (ih u h)
 | lam hk hb ih => intro u h; cases h with | lam hh => exact .lam hk (fun q hq => ih q hq _ hh)
 | @app e f a k x y hk hm hf ha ihf iha =>
   intro u h
   cases h with
   | beta b a =>
     have h := arrowAux hf b rfl hk (x,y) hm
     exact substTy h 0 a e ha (by intro i hi; cases i with | zero => contradiction | succ i => simp [ext])
   | appL _ h => exact .app hk hm (ihf _ h) ha
   | appR _ h => exact .app hk hm hf (iha _ h)
 | rigidApp a hf ih =>
   intro u h
   cases h with
   | beta b a => exact (noLamAux hf b rfl rfl).elim
   | appL _ h => exact .rigidApp _ (ih _ h)
   | appR => exact .rigidApp _ hf

theorem many (ht : Ty F e t k) (h : Betas t u) : Ty F e u k := by
 induction h with
 | refl => exact ht
 | head hb _ ih => exact ih (preserve ht _ hb)

theorem reject (ht : Ty F e t 0) : ¬ Reader t := by
 intro hr
 obtain ⟨n,hcn⟩ := hasNormalForm_count ⟨zeroOut,hr.zero_red,zeroOut_normal⟩
 obtain ⟨m,_,hcm⟩ := count_fn n hcn
 obtain ⟨u,hu,hs⟩ := count_endpoint hcm
 have htu := many ht hu
 have hr' := reader_betas hr hu
 cases u with
 | var v => exact reader_not_rigid hr' (.var v)
 | app f a => exact reader_not_rigid hr' (weakStep_none_rigid hs (fun h => h))
 | lam b => exact noLamAux htu b rfl rfl
end Blc.FloorDebt
