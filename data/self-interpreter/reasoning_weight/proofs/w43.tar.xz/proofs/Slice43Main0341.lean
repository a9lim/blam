import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0341
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r12371 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject12371 : ¬ Reader r12371 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 0), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12371
def r12372 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject12372 : ¬ Reader r12372 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 0), (.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12372
def r12373 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.var 0)) (.var 0)) (.var 0))
theorem reject12373 : ¬ Reader r12373 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[1,7],[],[10],[]] (.app (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [1,7]) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.var 0 [0]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12373
def r12374 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 1)) (.var 0)) (.var 0))
theorem reject12374 : ¬ Reader r12374 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12374
def r12375 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 0)) (.var 1)) (.var 0))
theorem reject12375 : ¬ Reader r12375 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12375
def r12376 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))) (.var 0)) (.var 0)) (.var 0)) (.var 1))
theorem reject12376 : ¬ Reader r12376 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.var 1 [0,7]) [7]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 0 [0]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12376
def r12377 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))
theorem reject12377 : ¬ Reader r12377 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12377
def r12378 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))
theorem reject12378 : ¬ Reader r12378 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12378
def r12379 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))
theorem reject12379 : ¬ Reader r12379 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12379
def r12380 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))
theorem reject12380 : ¬ Reader r12380 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12380
def r12381 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))
theorem reject12381 : ¬ Reader r12381 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12381
def r12382 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))
theorem reject12382 : ¬ Reader r12382 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12382
def r12383 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject12383 : ¬ Reader r12383 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12383
def r12384 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject12384 : ¬ Reader r12384 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12384
def r12385 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject12385 : ¬ Reader r12385 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12385
def r12386 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject12386 : ¬ Reader r12386 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject12386
def r12387 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject12387 : ¬ Reader r12387 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12387
def r12388 : Term := (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject12388 : ¬ Reader r12388 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12388
def r12389 : Term := (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 0))
theorem reject12389 : ¬ Reader r12389 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))) [] [(.var 1), (.var 0), (.var 0), (.var 0), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12389
def r12390 : Term := (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 0))
theorem reject12390 : ¬ Reader r12390 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))) [] [(.var 0), (.var 1), (.var 0), (.var 0), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12390
def r12391 : Term := (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 0))
theorem reject12391 : ¬ Reader r12391 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))) [] [(.var 0), (.var 0), (.var 1), (.var 0), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12391
def r12392 : Term := (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 0))
theorem reject12392 : ¬ Reader r12392 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))) [] [(.var 0), (.var 0), (.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12392
def r12393 : Term := (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.var 0)) (.var 0)) (.var 0)) (.var 0)) (.var 1))
theorem reject12393 : ¬ Reader r12393 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))) [] [(.var 0), (.var 0), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12393
def r12394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))
theorem reject12394 : ¬ Reader r12394 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) [(.var 1), (.var 0)] [(.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12394
def r12395 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))
theorem reject12395 : ¬ Reader r12395 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) [(.var 1), (.var 0)] [(.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))) (.var 0))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12395
def r12396 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))
theorem reject12396 : ¬ Reader r12396 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) [(.var 0), (.var 1)] [(.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12396
def r12397 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))
theorem reject12397 : ¬ Reader r12397 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) [(.var 0), (.var 1)] [(.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))) (.var 0))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12397
def r12398 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))
theorem reject12398 : ¬ Reader r12398 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) [(.var 1), (.var 0)] [(.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12398
def r12399 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))
theorem reject12399 : ¬ Reader r12399 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) [(.var 0), (.var 1)] [(.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12399
def r12400 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))
theorem reject12400 : ¬ Reader r12400 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) [(.var 1), (.var 0)] [(.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12400
def r12401 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))
theorem reject12401 : ¬ Reader r12401 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) [(.var 0), (.var 1)] [(.lam (.lam (.var 1))), (.var 3), (.var 0)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12401
def r12402 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))
theorem reject12402 : ¬ Reader r12402 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) [(.var 1), (.var 0)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12402
def r12403 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))
theorem reject12403 : ¬ Reader r12403 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) [(.var 0), (.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4))), (.var 0)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12403
def r12404 : Term := (.app (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject12404 : ¬ Reader r12404 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.var 0), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12404
def r12405 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))
theorem reject12405 : ¬ Reader r12405 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.var 1), (.var 0), (.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12405
def r12406 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))
theorem reject12406 : ¬ Reader r12406 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.var 0), (.var 1), (.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12406
def r12407 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))
theorem reject12407 : ¬ Reader r12407 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))) [(.var 1), (.app (.var 0) (.lam (.var 0)))] [(.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12407
def r12408 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))
theorem reject12408 : ¬ Reader r12408 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1)))) [(.lam (.var 0)), (.var 1), (.var 0)] [(.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12408
def r12409 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))
theorem reject12409 : ¬ Reader r12409 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0))))) [(.var 0), (.var 1), (.lam (.var 0))] [(.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12409
def r12410 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))
theorem reject12410 : ¬ Reader r12410 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1)))) [(.var 1), (.lam (.var 0)), (.var 0)] [(.lam (.lam (.var 1))), (.var 3)] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12410
end Blc.HandlerLet.Slice43Main0341
