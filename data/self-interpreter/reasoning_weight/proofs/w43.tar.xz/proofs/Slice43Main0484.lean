import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0484
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r17956 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17956 : ¬ Reader r17956 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1)))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1))), (.lam (.var 1))] [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1))), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17956
def r17957 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17957 : ¬ Reader r17957 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)) (.var 0))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17957
def r17958 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject17958 : ¬ Reader r17958 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17958 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 0)) (.var 0)) [(.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17958
def r17959 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject17959 : ¬ Reader r17959 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17959 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.var 1)) (.var 0)) [(.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17959
def r17960 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject17960 : ¬ Reader r17960 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))] [(.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17960
def r17961 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17961 : ¬ Reader r17961 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))] [(.var 0), (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17961
def r17962 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17962 : ¬ Reader r17962 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17962
def r17963 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject17963 : ¬ Reader r17963 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17963 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17963
def r17964 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject17964 : ¬ Reader r17964 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17964 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17964
def r17965 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject17965 : ¬ Reader r17965 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17965
def r17966 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17966 : ¬ Reader r17966 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))] [(.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17966
def r17967 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17967 : ¬ Reader r17967 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17967
def r17968 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject17968 : ¬ Reader r17968 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17968 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))) (.lam (.var 1)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17968
def r17969 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject17969 : ¬ Reader r17969 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17969 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.var 1)) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))) (.lam (.var 1)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17969
def r17970 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject17970 : ¬ Reader r17970 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17970
def r17971 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject17971 : ¬ Reader r17971 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1)))) [(.lam (.var 1)), (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1)))] [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))), (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1))), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17971
def r17972 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))) (.var 1))
theorem reject17972 : ¬ Reader r17972 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))) (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))))) [(.lam (.var 1)), (.app (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1)))) (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.var 1))))), (.lam (.var 1))] [(.app (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17972
def r17973 : Term := (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17973 : ¬ Reader r17973 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))] [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17973
def r17974 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 1))
theorem reject17974 : ¬ Reader r17974 := by
  exact replay_absent false [] 4 0 (by decide +kernel) (by decide +kernel)
#print axioms reject17974
def r17975 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17975 : ¬ Reader r17975 := by
  exact replay_loop true [] 8 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0)))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0)))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.app (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17975
def r17976 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject17976 : ¬ Reader r17976 := by
  exact replay_absent false [] 4 0 (by decide +kernel) (by decide +kernel)
#print axioms reject17976
def r17977 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject17977 : ¬ Reader r17977 := by
  exact replay_absent false [] 4 0 (by decide +kernel) (by decide +kernel)
#print axioms reject17977
def r17978 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject17978 : ¬ Reader r17978 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))) [] [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17978
def r17979 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject17979 : ¬ Reader r17979 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))) [] [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17979
def r17980 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject17980 : ¬ Reader r17980 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1)))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))) (.lam (.var 1)))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))), (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17980
def r17981 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject17981 : ¬ Reader r17981 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17981 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 0)) (.lam (.var 1))) [(.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17981
def r17982 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject17982 : ¬ Reader r17982 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r17982 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.var 1)) (.lam (.var 1))) [(.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject17982
def r17983 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject17983 : ¬ Reader r17983 := by
  exact replay_loop true [] 0 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17983
def r17984 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject17984 : ¬ Reader r17984 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))] [(.lam (.var 1)), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17984
def r17985 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2))))) (.var 1))
theorem reject17985 : ¬ Reader r17985 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17985
def r17986 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0))))))) (.var 1))
theorem reject17986 : ¬ Reader r17986 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))) (.var 0))) [(.app (.var 0) (.lam (.var 0)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17986
def r17987 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2))))) (.var 1))
theorem reject17987 : ¬ Reader r17987 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))) (.var 0))) [(.lam (.var 0)), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17987
def r17988 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0)))))) (.var 1))
theorem reject17988 : ¬ Reader r17988 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0)))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))) (.var 0))) [(.var 0), (.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17988
def r17989 : Term := (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1))
theorem reject17989 : ¬ Reader r17989 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject17989
def r17990 : Term := (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))) (.var 1))
theorem reject17990 : ¬ Reader r17990 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject17990
def r17991 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))) (.var 1))
theorem reject17991 : ¬ Reader r17991 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) (.app (.var 1) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17991
def r17992 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))
theorem reject17992 : ¬ Reader r17992 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.app (.var 0) (.lam (.var 0))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17992
def r17993 : Term := (.app (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1))
theorem reject17993 : ¬ Reader r17993 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))) [(.var 0)] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17993
def r17994 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))
theorem reject17994 : ¬ Reader r17994 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject17994
def r17995 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))) (.var 1))
theorem reject17995 : ¬ Reader r17995 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject17995
end Blc.HandlerLet.Slice43Main0484
