import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0317
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r11409 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject11409 : ¬ Reader r11409 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[1,5,6],[1,5,6],[],[],[],[],[]] [[],[],[],[],[6],[6],[1],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [1,5,6]) (.var 1 [1,5,6]) [1,6]) (.app (.var 1 [1,5,6]) (.var 0 [1,5,6]) [1,6]) [1]) [6]) [5]) [6]) (.var 1 [1]) [1]) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) [1]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [1]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11409
def r11410 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject11410 : ¬ Reader r11410 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6,7,8],[0,5,6,7,8],[0,5,6,7,8],[0,5,6,7,8],[],[],[]] [[],[],[],[],[6],[6],[0],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [0,5,6,7,8]) (.var 1 [0,5,6,7,8]) [0,6,8]) (.app (.var 1 [0,5,6,7,8]) (.var 0 [0,5,6,7,8]) [0,6,8]) [0]) [6]) [5]) [6]) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) [0]) (.var 1 [1]) [0]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11410
def r11411 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject11411 : ¬ Reader r11411 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.var 1 [5]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11411
def r11412 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject11412 : ¬ Reader r11412 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,7,8],[5],[5],[],[],[]] [[],[],[],[],[6],[6],[],[8],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0,7,8]) (.var 1 [5]) [0,8]) []) [6]) [5]) [6]) (.lam 7 (.lam 8 (.var 2 [0]) [8]) [7]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11412
def r11413 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) (.lam (.lam (.var 2))))
theorem reject11413 : ¬ Reader r11413 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.lam (.lam (.var 2))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11413
def r11414 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.lam (.var 2)))) (.var 1))
theorem reject11414 : ¬ Reader r11414 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.lam (.var 2)))) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11414
def r11415 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.lam (.app (.var 0) (.var 2)))))
theorem reject11415 : ¬ Reader r11415 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11415
def r11416 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1)))))
theorem reject11416 : ¬ Reader r11416 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11416
def r11417 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2)))))
theorem reject11417 : ¬ Reader r11417 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11417
def r11418 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 1))
theorem reject11418 : ¬ Reader r11418 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11418
def r11419 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 1))
theorem reject11419 : ¬ Reader r11419 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11419
def r11420 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 1))
theorem reject11420 : ¬ Reader r11420 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11420
def r11421 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11421 : ¬ Reader r11421 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11421
def r11422 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11422 : ¬ Reader r11422 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11422
def r11423 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11423 : ¬ Reader r11423 := by
  exact replay_loop true [] 3 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)))))) (.var 0)) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11423
def r11424 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11424 : ¬ Reader r11424 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11424
def r11425 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11425 : ¬ Reader r11425 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11425
def r11426 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11426 : ¬ Reader r11426 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11426
def r11427 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11427 : ¬ Reader r11427 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))))) (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))))) (.var 0))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11427
def r11428 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11428 : ¬ Reader r11428 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11428
def r11429 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11429 : ¬ Reader r11429 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))) (.var 0)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))] [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11429
def r11430 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11430 : ¬ Reader r11430 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11430
def r11431 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))) (.lam (.lam (.var 0)))) (.var 1))
theorem reject11431 : ¬ Reader r11431 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))) [(.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11431
def r11432 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2))))) (.var 1)) (.lam (.lam (.var 0))))
theorem reject11432 : ¬ Reader r11432 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11432
def r11433 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))) (.var 1)) (.lam (.var 1)))
theorem reject11433 : ¬ Reader r11433 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11433
def r11434 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))) (.lam (.var 1))) (.var 1))
theorem reject11434 : ¬ Reader r11434 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11434
def r11435 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 2))))))) (.var 1)) (.lam (.var 1)))
theorem reject11435 : ¬ Reader r11435 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11435
def r11436 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 2))))))) (.lam (.var 1))) (.var 1))
theorem reject11436 : ¬ Reader r11436 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 2))))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11436
def r11437 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 1))))) (.var 1)) (.lam (.var 1)))
theorem reject11437 : ¬ Reader r11437 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11437
def r11438 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 1))))) (.lam (.var 1))) (.var 1))
theorem reject11438 : ¬ Reader r11438 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11438
def r11439 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))) (.var 1)) (.lam (.var 1)))
theorem reject11439 : ¬ Reader r11439 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[1,5,6,7,8,9],[],[],[],[],[]] [[],[],[],[],[6],[6],[6],[1,5,6,7,8,9],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.lam 7 (.var 1 [1,5,6,7,8,9]) [7]) [6]) [6]) [6]) [5]) [6]) (.var 1 [1]) [6]) (.lam 8 (.var 1 [0]) [8]) [6]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11439
def r11440 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))) (.lam (.var 1))) (.var 1))
theorem reject11440 : ¬ Reader r11440 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[1,5,6,7,8,9],[],[],[],[],[]] [[],[],[],[],[6],[6],[6],[1,5,6,7,8,9],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.lam 7 (.var 1 [1,5,6,7,8,9]) [7]) [6]) [6]) [6]) [5]) [6]) (.lam 8 (.var 1 [0]) [8]) [6]) (.var 1 [1]) [6]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11440
def r11441 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1))))))) (.var 1)) (.lam (.var 1)))
theorem reject11441 : ¬ Reader r11441 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1], [1, 1, 1, 0, 2], [1, 1, 1, 0, 2, 0, 1], [1, 1, 1, 0, 2, 0, 2], [1, 1]] [[1, 1, 1, 0, 2], [1, 1, 1, 0, 2, 0, 1], [1, 1, 1, 0, 2, 0, 2], [1, 1], [1, 1, 2, 0]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.app (.var 2) (.var 2)))) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11441
def r11442 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.var 1))) (.var 1))
theorem reject11442 : ¬ Reader r11442 := by
 exact mixed_reduct true [[1, 1, 1]] [[1, 1, 1, 0, 2], [1, 1, 1, 0, 2, 0, 1], [1, 1, 1, 0, 2, 0, 2], [1, 1], [1, 1, 2, 0]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 1))))))) (.lam (.var 1))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11442
def r11443 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 2))))))) (.var 1)) (.lam (.var 1)))
theorem reject11443 : ¬ Reader r11443 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[],[]] [[],[],[],[],[6],[6],[],[5],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.lam 7 (.var 2 [5]) [7]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 8 (.var 1 [0]) [8]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11443
def r11444 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 2))))))) (.lam (.var 1))) (.var 1))
theorem reject11444 : ¬ Reader r11444 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0,8],[],[7],[],[],[]] [[],[],[],[],[6],[6],[],[5],[0],[],[11],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0,8]) (.lam 7 (.var 2 [5]) [7]) [0]) []) [6]) [5]) [6]) (.lam 8 (.var 1 [0]) [8]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11444
def r11445 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.var 1)) (.lam (.var 1)))
theorem reject11445 : ¬ Reader r11445 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))) [(.lam (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))] [(.lam (.lam (.var 3))), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11445
def r11446 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.lam (.var 1))) (.var 1))
theorem reject11446 : ¬ Reader r11446 := by
  exact replay_loop true [] 5 4 (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))) [(.lam (.lam (.app (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))] [(.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11446
def r11447 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) (.var 1)) (.lam (.var 1)))
theorem reject11447 : ¬ Reader r11447 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))))))] [(.lam (.var 2)), (.lam (.var 1)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11447
def r11448 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) (.lam (.var 1))) (.var 1))
theorem reject11448 : ¬ Reader r11448 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 1))))))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11448
end Blc.HandlerLet.Slice43Main0317
