import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0329
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r11891 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)) (.var 0)) (.var 1))
theorem reject11891 : ¬ Reader r11891 := by
  exact replay_loop true [] 0 3 (.app (.lam (.app (.var 0) (.var 0))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0)))))) [] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11891
def r11892 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11892 : ¬ Reader r11892 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.var 1 [1]) [6]) (.var 0 [0]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11892
def r11893 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11893 : ¬ Reader r11893 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.var 0 [0]) [6]) (.var 1 [1]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11893
def r11894 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject11894 : ¬ Reader r11894 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.var 1 [1]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.var 0 [0]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11894
def r11895 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject11895 : ¬ Reader r11895 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.var 1 [1]) [6]) (.var 0 [0]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11895
def r11896 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject11896 : ¬ Reader r11896 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.var 0 [0]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.var 1 [1]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11896
def r11897 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0)))))) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject11897 : ¬ Reader r11897 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[0,1,5,6,7,8],[],[],[],[]] [[],[],[],[],[6],[6],[6],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.var 1 [5,6]) (.app (.app (.var 1 [5,6]) (.var 1 [5,6]) [6]) (.var 0 [0,1,5,6,7,8]) [6]) [6]) [6]) [5]) [6]) (.var 0 [0]) [6]) (.var 1 [1]) [6]) (.lam 7 (.var 0 []) [7]) [6]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [6]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11897
def r11898 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11898 : ¬ Reader r11898 := by
 exact mixed_reduct true [[1, 1, 1, 1]] [[1, 1, 1, 1, 0, 2], [1, 1, 1], [1, 1, 1, 2, 0, 2], [1, 1, 1, 2, 0, 1], [1, 1, 1, 2, 0]] (.app (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11898
def r11899 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11899 : ¬ Reader r11899 := by
 exact mixed_reduct true [[1, 1, 1, 1]] [[1, 1, 1, 1, 0, 2], [1, 1, 1], [1, 1, 1, 2, 0, 2], [1, 1, 1, 2, 0, 1], [1, 1, 1, 2, 0]] (.app (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11899
def r11900 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject11900 : ¬ Reader r11900 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[1,5,6],[1,5,6],[],[],[],[]] [[],[],[],[],[6],[6],[1],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [1,5,6]) (.var 1 [1,5,6]) [1,6]) (.app (.var 1 [1,5,6]) (.var 0 [1,5,6]) [1,6]) [1]) [6]) [5]) [6]) (.var 1 [1]) [1]) (.lam 7 (.var 0 []) [7]) [1]) (.var 0 [0]) [1]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [1]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11900
def r11901 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject11901 : ¬ Reader r11901 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[1,5,6],[1,5,6],[],[],[],[]] [[],[],[],[],[6],[6],[1],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [1,5,6]) (.var 1 [1,5,6]) [1,6]) (.app (.var 1 [1,5,6]) (.var 0 [1,5,6]) [1,6]) [1]) [6]) [5]) [6]) (.var 1 [1]) [1]) (.var 0 [0]) [1]) (.lam 7 (.var 0 []) [7]) [1]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [1]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11901
def r11902 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject11902 : ¬ Reader r11902 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,5,6],[],[],[],[]] [[],[],[],[],[6],[6],[0],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [0,5,6]) (.var 1 [0,5,6]) [0,6]) (.app (.var 1 [0,5,6]) (.var 0 [0,5,6]) [0,6]) [0]) [6]) [5]) [6]) (.var 0 [0]) [0]) (.lam 7 (.var 0 []) [7]) [0]) (.var 1 [1]) [0]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11902
def r11903 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0)))))) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject11903 : ¬ Reader r11903 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6],[0,5,6],[],[],[],[]] [[],[],[],[],[6],[6],[0],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [0,5,6]) (.var 1 [0,5,6]) [0,6]) (.app (.var 1 [0,5,6]) (.var 0 [0,5,6]) [0,6]) [0]) [6]) [5]) [6]) (.var 0 [0]) [0]) (.var 1 [1]) [0]) (.lam 7 (.var 0 []) [7]) [0]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11903
def r11904 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11904 : ¬ Reader r11904 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[5,6,7],[5],[],[],[]] [[],[],[],[],[6],[6],[],[5],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [5,6,7]) (.var 1 [5]) [5,6]) []) [6]) [5]) [6]) (.lam 7 (.var 0 [5]) [7]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11904
def r11905 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11905 : ¬ Reader r11905 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[5,6,7],[5],[],[],[]] [[],[],[],[],[6],[6],[],[5],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [5,6,7]) (.var 1 [5]) [5,6]) []) [6]) [5]) [6]) (.lam 7 (.var 0 [5]) [7]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11905
def r11906 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject11906 : ¬ Reader r11906 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.var 1 [5]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.lam 7 (.var 0 []) [7]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11906
def r11907 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject11907 : ¬ Reader r11907 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [1]) (.var 1 [5]) [1]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 7 (.var 0 []) [7]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11907
def r11908 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject11908 : ¬ Reader r11908 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0]) (.var 1 [5]) [0]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.lam 7 (.var 0 []) [7]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11908
def r11909 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1)))))) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject11909 : ¬ Reader r11909 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[0],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.app (.var 0 [0]) (.var 1 [5]) [0]) []) [6]) [5]) [6]) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 7 (.var 0 []) [7]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11909
def r11910 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11910 : ¬ Reader r11910 := by
 exact mixed_reduct true [[1, 1, 1, 1]] [[1, 1, 1, 1, 0, 1], [1, 1, 1], [1, 1, 1, 1, 0, 2], [1, 1, 1, 1, 0, 1], [1, 1, 1]] (.app (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11910
def r11911 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11911 : ¬ Reader r11911 := by
 exact mixed_reduct true [[1, 1, 1, 1]] [[1, 1, 1, 1, 0, 1], [1, 1, 1], [1, 1, 1, 1, 0, 2], [1, 1, 1, 1, 0, 1], [1, 1, 1]] (.app (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject11911
def r11912 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11912 : ¬ Reader r11912 := by
  exact replay_loop true [] 5 8 (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))) [(.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))), (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))), (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11912
def r11913 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11913 : ¬ Reader r11913 := by
  exact replay_loop true [] 5 8 (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))) [(.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))), (.app (.app (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))), (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))) (.app (.lam (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11913
def r11914 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11914 : ¬ Reader r11914 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.var 0))) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11914
def r11915 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11915 : ¬ Reader r11915 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.lam (.var 0))) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11915
def r11916 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) (.lam (.var 0))) (.var 0))
theorem reject11916 : ¬ Reader r11916 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.lam (.var 0)), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11916
def r11917 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) (.var 0)) (.lam (.var 0)))
theorem reject11917 : ¬ Reader r11917 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 1)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.var 0), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11917
def r11918 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 0)) (.lam (.var 0))) (.var 1))
theorem reject11918 : ¬ Reader r11918 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 0)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11918
def r11919 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 0)) (.var 1)) (.lam (.var 0)))
theorem reject11919 : ¬ Reader r11919 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))) (.var 0)) [(.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1))))] [(.var 1), (.lam (.var 0)), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11919
def r11920 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11920 : ¬ Reader r11920 := by
  exact replay_loop true [] 12 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))) [(.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))), (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))), (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))), (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11920
def r11921 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11921 : ¬ Reader r11921 := by
  exact replay_loop true [] 12 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))) [(.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))), (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))), (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))), (.app (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1))))) (.app (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11921
def r11922 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) (.lam (.var 0))) (.var 1)) (.var 0))
theorem reject11922 : ¬ Reader r11922 := by
  exact replay_loop true [] 4 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11922
def r11923 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) (.lam (.var 0))) (.var 0)) (.var 1))
theorem reject11923 : ¬ Reader r11923 := by
  exact replay_loop true [] 4 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11923
def r11924 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))
theorem reject11924 : ¬ Reader r11924 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11924
def r11925 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))
theorem reject11925 : ¬ Reader r11925 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11925
def r11926 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))
theorem reject11926 : ¬ Reader r11926 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11926
def r11927 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))
theorem reject11927 : ¬ Reader r11927 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject11927
def r11928 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))
theorem reject11928 : ¬ Reader r11928 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.lam (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11928
def r11929 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))
theorem reject11929 : ¬ Reader r11929 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) [] [(.var 1), (.lam (.app (.var 0) (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11929
def r11930 : Term := (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1))))))) (.var 1)) (.var 0)) (.var 0))
theorem reject11930 : ¬ Reader r11930 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5],[1,7],[],[],[],[]] [[],[],[],[],[6],[6],[],[],[],[10],[]] (.app (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [6]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 1 [5]) (.var 1 [5]) [6]) (.lam 7 (.app (.var 0 []) (.var 1 [1,7]) []) [7]) []) [6]) [5]) [6]) (.var 1 [1]) []) (.var 0 [0]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject11930
end Blc.HandlerLet.Slice43Main0329
