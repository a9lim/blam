import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice43Main0376
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r13686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))
theorem reject13686 : ¬ Reader r13686 := by
 exact mixed_reduct true [[1]] [[1, 2, 0], [1, 1]] (.app (.app (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject13686
def r13687 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))
theorem reject13687 : ¬ Reader r13687 := by
 exact mixed_reduct true [[1]] [[1, 2, 0], [1, 1]] (.app (.app (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject13687
def r13688 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 3) (.var 1)))))))
theorem reject13688 : ¬ Reader r13688 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 3) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.lam (.app (.var 4) (.var 1)))))))) [(.lam (.lam (.app (.var 2) (.var 1))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13688
def r13689 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 1) (.var 3)))))))
theorem reject13689 : ¬ Reader r13689 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 1) (.var 3)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.lam (.app (.var 1) (.var 4)))))))) [(.lam (.lam (.app (.var 1) (.var 2))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13689
def r13690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 1))))) (.var 0)) (.var 2))))
theorem reject13690 : ¬ Reader r13690 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 1))))) (.var 0)) (.var 2))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 1))))) (.var 0)) (.var 3))))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13690
def r13691 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 3))))) (.var 0)) (.var 2))))
theorem reject13691 : ¬ Reader r13691 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 3))))) (.var 0)) (.var 2))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 4))))) (.var 0)) (.var 3))))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13691
def r13692 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))
theorem reject13692 : ¬ Reader r13692 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.lam (.var 4)))) (.var 1))))) [(.lam (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13692
def r13693 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))
theorem reject13693 : ¬ Reader r13693 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))) [(.var 1), (.lam (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13693
def r13694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))
theorem reject13694 : ¬ Reader r13694 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))) (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 4))) (.var 1))))) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13694
def r13695 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))
theorem reject13695 : ¬ Reader r13695 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))) [(.lam (.var 1)), (.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13695
def r13696 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))
theorem reject13696 : ¬ Reader r13696 := by
 exact mixed_reduct true [[1], [1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 2))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4))))) (.var 3))))) (.var 1)) (.var 1)) [(.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject13696
def r13697 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))
theorem reject13697 : ¬ Reader r13697 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 5)) (.var 0)) (.var 4))) (.var 1)))))) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13697
def r13698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))
theorem reject13698 : ¬ Reader r13698 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 5))) (.var 1)))))) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13698
def r13699 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject13699 : ¬ Reader r13699 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 0)) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2))), (.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13699
def r13700 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))
theorem reject13700 : ¬ Reader r13700 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) [(.var 1)] [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13700
def r13701 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))
theorem reject13701 : ¬ Reader r13701 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.app (.var 0) (.lam (.lam (.var 0)))), (.var 1), (.app (.var 0) (.lam (.lam (.var 0)))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13701
def r13702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))) (.var 2)) (.var 1))))
theorem reject13702 : ¬ Reader r13702 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))) [(.lam (.lam (.var 0)))] [(.var 1), (.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13702
def r13703 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))
theorem reject13703 : ¬ Reader r13703 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 0))), (.var 1), (.var 0), (.lam (.lam (.var 0))), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13703
def r13704 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))
theorem reject13704 : ¬ Reader r13704 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.lam (.lam (.var 0))), (.var 0), (.var 1), (.lam (.lam (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13704
def r13705 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))
theorem reject13705 : ¬ Reader r13705 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.lam (.lam (.var 0))), (.var 0), (.var 1), (.lam (.lam (.var 0))), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13705
def r13706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))
theorem reject13706 : ¬ Reader r13706 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.lam (.lam (.var 0))), (.var 1), (.var 0), (.lam (.lam (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13706
def r13707 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))
theorem reject13707 : ¬ Reader r13707 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.var 0) (.lam (.lam (.var 0)))), (.var 1), (.app (.var 0) (.lam (.lam (.var 0)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13707
def r13708 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))) (.var 1)) (.var 2))))
theorem reject13708 : ¬ Reader r13708 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))) [(.lam (.lam (.var 0)))] [(.var 0), (.var 1), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13708
def r13709 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))
theorem reject13709 : ¬ Reader r13709 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 0))), (.var 0), (.var 1), (.lam (.lam (.var 0))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13709
def r13710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))
theorem reject13710 : ¬ Reader r13710 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.lam (.var 0))), (.var 1), (.var 0), (.lam (.lam (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13710
def r13711 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))
theorem reject13711 : ¬ Reader r13711 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 1), (.var 0), (.var 1), (.var 0), (.lam (.lam (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13711
def r13712 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))
theorem reject13712 : ¬ Reader r13712 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.var 1), (.var 0), (.var 1), (.lam (.lam (.var 0))), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13712
def r13713 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))))
theorem reject13713 : ¬ Reader r13713 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))) [(.var 1), (.app (.var 0) (.lam (.lam (.lam (.var 0))))), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13713
def r13714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1)))))
theorem reject13714 : ¬ Reader r13714 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))) [(.lam (.lam (.lam (.var 0)))), (.var 1), (.var 0), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0)) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13714
def r13715 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0))))))))
theorem reject13715 : ¬ Reader r13715 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))) [(.var 0), (.var 1), (.lam (.lam (.lam (.var 0)))), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13715
def r13716 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1)))))
theorem reject13716 : ¬ Reader r13716 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1))))) [(.var 1), (.lam (.lam (.lam (.var 0)))), (.var 0), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1))))) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1))))) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0))) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13716
def r13717 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0))))))))
theorem reject13717 : ¬ Reader r13717 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))) [(.var 1), (.var 0), (.lam (.lam (.lam (.var 0)))), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13717
def r13718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2)))))
theorem reject13718 : ¬ Reader r13718 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2))))) [(.app (.var 0) (.lam (.lam (.lam (.var 0))))), (.var 1), (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2))))) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 2))))) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1))) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13718
def r13719 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2)))))
theorem reject13719 : ¬ Reader r13719 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))) [(.lam (.lam (.lam (.var 0)))), (.var 0), (.var 1), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1)) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13719
def r13720 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2)))))
theorem reject13720 : ¬ Reader r13720 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2))))) [(.var 0), (.lam (.lam (.lam (.var 0)))), (.var 1), (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2))))) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2)))) (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2))))) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13720
def r13721 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))
theorem reject13721 : ¬ Reader r13721 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) [(.var 1), (.var 0)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13721
def r13722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))
theorem reject13722 : ¬ Reader r13722 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) [(.var 0), (.var 1)] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13722
def r13723 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0)))))))
theorem reject13723 : ¬ Reader r13723 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0))))))) [(.var 1), (.var 0), (.app (.app (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.var 0)) (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.lam (.var 0))))))) (.var 1)) (.var 0))) (.var 1)) (.var 0)), (.lam (.lam (.lam (.var 0)))), (.lam (.lam (.lam (.var 0))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13723
def r13724 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0)))))))
theorem reject13724 : ¬ Reader r13724 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0))))))) [(.var 0), (.var 1), (.app (.app (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.var 1)) (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0)))))) (.lam (.app (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.lam (.var 0))))))) (.var 0)) (.var 1))) (.var 0)) (.var 1)), (.lam (.lam (.lam (.var 0)))), (.lam (.lam (.lam (.var 0))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13724
def r13725 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))
theorem reject13725 : ¬ Reader r13725 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) [(.var 1), (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) (.var 1)) (.app (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))))) (.var 1))) (.var 1)), (.app (.var 0) (.lam (.lam (.lam (.var 0))))), (.app (.var 0) (.lam (.lam (.lam (.var 0)))))] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject13725
end Blc.HandlerLet.Slice43Main0376
