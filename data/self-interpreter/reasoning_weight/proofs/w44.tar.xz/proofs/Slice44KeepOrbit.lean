import Blc.SelfintRootLetBinaryOrbit
namespace Blc.Slice44KeepOrbit
open Term SelfintWireCost SelfintClass SelfintLowerBound SelfintSourceCost SelfintFloor SelfintNestedLets WeakHeadClock
open SelfintRootLetPowers (keep reader_betas)
open SelfintRootLetOrbit (count_fn)
def idT : Term := .lam (.var 0)
def grow (x : Term) : Term := .lam (.app (.app (.app (.var 0) idT) (keep (shift 1 0 x))) (.var 0))
def H : Term := .lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) idT) (.lam (.var 2))) (.var 0))))
theorem hstep (x : Term) : weakStep (.app H x)=some (.app x (grow x)) := by
 simp [H,weakStep,contract,substDec,keep,grow,idT,shift]
theorem gstep (x y : Term) : weakStep (.app (grow x) y)=some (.app (.app (.app y idT) (keep x)) y) := by
 simp [grow,idT,keep,weakStep,contract,substDec,shift_shift0]
 exact substDec_shift0 1 2 _ x (by decide)
theorem kstep (x y : Term) : weakStep (.app (keep x) y)=some x := by simp [keep,weakStep,contract,substDec_shift]
theorem istep (x : Term) : weakStep (.app idT x)=some x := by simp [idT,weakStep,contract,substDec]
inductive Orb : Term → Prop where
 | h : Orb H
 | ident : Orb idT
 | g {x} : Orb x → Orb (grow x)
 | k {x} : Orb x → Orb (keep x)
 | a {f a} : Orb f → Orb a → Orb (.app f a)
theorem orbitClosed (h : Orb t) : Closed t := by
 induction h with
 | h | ident => decide
 | g h hx =>
   simp only [grow,keep,shift_closed 1 0 hx,Closed,FreeUnder]
   exact ⟨⟨by decide, freeUnder_mono (by decide : 0≤2) hx⟩,by decide⟩
 | k h hx =>
   simp only [keep,shift_closed 1 0 hx,Closed,FreeUnder]
   exact freeUnder_mono (by decide : 0≤1) hx
 | a hf ha ihf iha => exact ⟨ihf,iha⟩
theorem closedStep (h : Orb t) (hs : weakStep t = some u) : Orb u := by
 induction h generalizing u with
 | h | g | k | ident => simp [H,grow,keep,idT,weakStep] at hs
 | @a f a hf ha ihf iha =>
   cases hf with
   | h => rw [hstep] at hs; cases hs; exact .a ha (.g ha)
   | ident => rw [istep] at hs; cases hs; exact ha
   | g hx => rw [gstep] at hs; cases hs; exact .a (.a (.a ha .ident) (.k hx)) ha
   | k hx => rw [kstep] at hs; cases hs; exact hx
   | a => simp only [weakStep,Option.map_eq_some_iff] at hs; obtain ⟨v,hv,rfl⟩ := hs; exact .a (ihf hv) ha

inductive Mixed : Term → Prop where
 | pure {t} : Orb t → Mixed t
 | rigid {t} : Rigid t → Mixed t
 | app {f a} : Mixed f → Rigid a → Mixed (.app f a)
theorem mixStep (h : Mixed t) (hs : weakStep t=some u) : Mixed u := by
 induction h generalizing u with
 | pure h => exact .pure (closedStep h hs)
 | rigid h => rw [rigid_stop h] at hs; contradiction
 | @app f a hf ha ih =>
   cases hf with
   | pure hor =>
     cases hor with
     | h => rw [hstep] at hs; cases hs; exact .rigid (.app _ ha)
     | ident => rw [istep] at hs; cases hs; exact .rigid ha
     | g hx => rw [gstep] at hs; cases hs; exact .rigid (.app _ (.app _ (.app _ ha)))
     | k hx => rw [kstep] at hs; cases hs; exact .pure hx
     | a => simp only [weakStep,Option.map_eq_some_iff] at hs; obtain ⟨v,hv,rfl⟩ := hs; exact .app (ih hv) ha
   | rigid h => rw [rigid_stop (Rigid.app a h)] at hs; contradiction
   | app => simp only [weakStep,Option.map_eq_some_iff] at hs; obtain ⟨v,hv,rfl⟩ := hs; exact .app (ih hv) ha
theorem endpoint {t n} (ht : Mixed t) (hc : Count t n) :
    ∃ u, Betas t u ∧ Mixed u ∧ weakStep u=none := by
 induction hc with
 | stop h => exact ⟨_,.refl _,ht,h⟩
 | step h hc ih =>
   obtain ⟨u,hu,hm,hs⟩ := ih (mixStep ht h)
   exact ⟨_,.head (weakStep_beta h) hu,hm,hs⟩
theorem rejectMixed {t : Term} (ht : Mixed t) (v : Nat) : ¬ Reader (.app t (.var v)) := by
 intro hr
 obtain ⟨n,hn⟩ := hasNormalForm_count ⟨_,hr.zero_red,zeroOut_normal⟩
 obtain ⟨_,_,hm⟩ := count_fn n hn
 obtain ⟨_,_,htc⟩ := count_fn _ hm
 obtain ⟨u,hu,hm,hs⟩ := endpoint ht htc
 have hr' := reader_betas hr (betas_appL (.var v) hu)
 cases hm with
 | pure h =>
   by_cases hv : v=0
   · have h1 := reader_j hr'
     have hz := occ_of_freeUnder _ 0 1 (orbitClosed h) (by decide)
     simp [occ,hv,hz] at h1
   · have h0 := reader_c hr'
     have hz := occ_of_freeUnder _ 0 0 (orbitClosed h) (by decide)
     simp [occ,hv,hz] at h0
 | rigid h => exact reader_not_rigid hr' (.app _ h)
 | app hf ha => exact reader_not_rigid hr' (.app _ (weakStep_none_rigid hs (fun h => h)))
def r15068 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))) (.var 1)) (.var 0))
theorem reject15068 : ¬ Reader r15068 := by
 intro hr
 apply rejectMixed (.app (.pure (.a .h .h)) (.var _)) _
 exact hr.beta (.appL _ (.appL _ (.beta _ _)))
#print axioms reject15068
def r15069 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 0)))))) (.var 0)) (.var 1))
theorem reject15069 : ¬ Reader r15069 := by
 intro hr
 apply rejectMixed (.app (.pure (.a .h .h)) (.var _)) _
 exact hr.beta (.appL _ (.appL _ (.beta _ _)))
#print axioms reject15069
end Blc.Slice44KeepOrbit
