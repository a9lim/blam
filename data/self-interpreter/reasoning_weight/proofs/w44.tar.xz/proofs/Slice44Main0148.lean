import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0148
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r4997 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject4997 : ¬ Reader r4997 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))) [(.lam (.app (.app (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0)))) (.var 1)) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 0)))))), (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject4997
def r4998 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject4998 : ¬ Reader r4998 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 1, 1], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject4998
def r4999 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject4999 : ¬ Reader r4999 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject4999
def r5000 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5000 : ¬ Reader r5000 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5000
def r5001 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5001 : ¬ Reader r5001 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5001
def r5002 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5002 : ¬ Reader r5002 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5002
def r5003 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5003 : ¬ Reader r5003 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5003
def r5004 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5004 : ¬ Reader r5004 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 0))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 0))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5004
def r5005 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5005 : ¬ Reader r5005 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5005
def r5006 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5006 : ¬ Reader r5006 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2)))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5006
def r5007 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5007 : ¬ Reader r5007 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5007
def r5008 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5008 : ¬ Reader r5008 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5008
def r5009 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5009 : ¬ Reader r5009 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5009
def r5010 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5010 : ¬ Reader r5010 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5010
def r5011 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5011 : ¬ Reader r5011 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 1, 1], [1, 1]] [[1, 2], [1, 1], [1], [1, 1, 2]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))) [(.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 0)), (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 0))), (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject5011
def r5012 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5012 : ¬ Reader r5012 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 1, 1], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 0)))), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject5012
def r5013 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5013 : ¬ Reader r5013 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5013
def r5014 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5014 : ¬ Reader r5014 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1))) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2))) (.var 0)) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2))) (.var 0)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5014
def r5015 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5015 : ¬ Reader r5015 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))))) [(.lam (.app (.var 0) (.lam (.var 1)))), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5015
def r5016 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5016 : ¬ Reader r5016 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 2)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5016
def r5017 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5017 : ¬ Reader r5017 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 2)) (.var 0))))) [(.var 0), (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 2)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5017
def r5018 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5018 : ¬ Reader r5018 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1))))))))) [(.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5018
def r5019 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5019 : ¬ Reader r5019 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2)))))) [(.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5019
def r5020 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5020 : ¬ Reader r5020 := by
  exact replay_loop true [] 4 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1)))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.lam (.var 1))))))) (.var 0)) (.var 0)), (.lam (.app (.var 0) (.lam (.var 1))))] [(.lam (.app (.var 0) (.lam (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5020
def r5021 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5021 : ¬ Reader r5021 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.lam (.app (.var 0) (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5021
def r5022 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5022 : ¬ Reader r5022 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.lam (.app (.var 0) (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5022
def r5023 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5023 : ¬ Reader r5023 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))))), (.lam (.app (.var 0) (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5023
def r5024 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5024 : ¬ Reader r5024 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.var 0), (.lam (.app (.var 0) (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5024
def r5025 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5025 : ¬ Reader r5025 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 1, 1], [1, 1]] [[1, 2], [1, 1], [1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))) [(.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 1)))), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject5025
def r5026 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5026 : ¬ Reader r5026 := by
  exact replay_loop true [] 4 3 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))) (.var 1))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))) (.var 2)))))) [(.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))) (.var 2)))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5026
def r5027 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5027 : ¬ Reader r5027 := by
  exact replay_loop true [] 4 2 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 1))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1)))))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 2)))) (.lam (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5027
def r5028 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5028 : ¬ Reader r5028 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 1, 1], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject5028
def r5029 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5029 : ¬ Reader r5029 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5029
def r5030 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5030 : ¬ Reader r5030 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5030
def r5031 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5031 : ¬ Reader r5031 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 0)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 0)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5031
def r5032 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5032 : ¬ Reader r5032 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 0)) (.var 2))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 0)) (.var 2)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5032
def r5033 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))
theorem reject5033 : ¬ Reader r5033 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 2))))) [(.lam (.app (.var 0) (.lam (.var 1)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5033
def r5034 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject5034 : ¬ Reader r5034 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.lam (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.lam (.app (.var 0) (.var 0))))) (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5034
def r5035 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject5035 : ¬ Reader r5035 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5035
def r5036 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject5036 : ¬ Reader r5036 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) [(.var 0)] [(.lam (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject5036
end Blc.HandlerLet.Slice44Main0148
