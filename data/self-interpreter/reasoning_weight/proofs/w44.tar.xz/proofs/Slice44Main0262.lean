import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0262
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r9521 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9521 : ¬ Reader r9521 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9521
def r9522 : Term := (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject9522 : ¬ Reader r9522 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9522
def r9523 : Term := (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1))))) (.var 1))
theorem reject9523 : ¬ Reader r9523 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9523
def r9524 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject9524 : ¬ Reader r9524 := by
  exact replay_loop true [] 3 3 (.app (.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))))) (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) [(.app (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9524
def r9525 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))) (.var 1))
theorem reject9525 : ¬ Reader r9525 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[0],[5],[],[],[]] [[],[],[],[],[],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.var 1 [0]) [7]) (.lam 5 (.var 1 [6]) [5]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.app (.var 1 [0]) (.var 0 [5]) [0]) [7]) (.var 0 [5]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9525
def r9526 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))) (.var 1))
theorem reject9526 : ¬ Reader r9526 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 1, 2], [1, 1, 1, 1]] [[1, 1], [1, 1, 1, 2], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject9526
def r9527 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))) (.var 1))
theorem reject9527 : ¬ Reader r9527 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9527
def r9528 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0))))) (.var 1))
theorem reject9528 : ¬ Reader r9528 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))) [(.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.var 0)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9528
def r9529 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))) (.var 1))
theorem reject9529 : ¬ Reader r9529 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[5],[0],[5],[],[],[]] [[],[],[],[],[],[6],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.var 1 [0]) [7]) (.lam 5 (.var 1 [6]) [5]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [5]) (.var 0 [5]) [6]) (.app (.var 1 [0]) (.var 1 [0]) [0]) [7]) (.var 0 [5]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9529
def r9530 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))) (.var 1))
theorem reject9530 : ¬ Reader r9530 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9530
def r9531 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))) (.var 1))
theorem reject9531 : ¬ Reader r9531 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9531
def r9532 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject9532 : ¬ Reader r9532 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))) [(.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9532
def r9533 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 1))))) (.var 1))
theorem reject9533 : ¬ Reader r9533 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 1)))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9533
def r9534 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 1))
theorem reject9534 : ¬ Reader r9534 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) [(.lam (.var 1)), (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.var 1))) (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9534
def r9535 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))) (.var 1))
theorem reject9535 : ¬ Reader r9535 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.app (.lam (.var 1)) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.app (.lam (.var 1)) (.lam (.var 1))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.app (.lam (.var 1)) (.lam (.var 1)))) (.app (.app (.lam (.var 1)) (.lam (.var 1))) (.app (.lam (.var 1)) (.lam (.var 1)))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.app (.lam (.var 1)) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9535
def r9536 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 1))
theorem reject9536 : ¬ Reader r9536 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))) [(.app (.lam (.var 1)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9536
def r9537 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject9537 : ¬ Reader r9537 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9537
def r9538 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))) (.var 1))
theorem reject9538 : ¬ Reader r9538 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9538 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9538
def r9539 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))) (.var 1))
theorem reject9539 : ¬ Reader r9539 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9539 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9539
def r9540 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))) (.var 1))
theorem reject9540 : ¬ Reader r9540 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9540 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9540
def r9541 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))) (.var 1))
theorem reject9541 : ¬ Reader r9541 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9541 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9541
def r9542 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))) (.var 1))
theorem reject9542 : ¬ Reader r9542 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9542 Z) = some (spine (BodyLetSpecial.templateState (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9542
def r9543 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))) (.var 1))
theorem reject9543 : ¬ Reader r9543 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9543 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9543
def r9544 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))) (.var 1))
theorem reject9544 : ¬ Reader r9544 := by
 exact SelfintRound6ReaderBinary.rigid_typed_not_reader (e := SelfintRound6ReaderBinary.rigidEnv) (.app (kf := .pending) (ka := .rigid) (.app (kf := .pending) (ka := .clear) (.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.var _ _ (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.lam (by decide +kernel) (fun | .rigid => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.var _ _ (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) (.lam (by decide +kernel) (fun | .rigid => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.rigidApp (.rigidApp (.app (kf := .pending) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .rigid) (.var _ _ (by decide +kernel)) (.rigidApp (.var _ _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .pending => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .pending) (ka := .clear) (.app (kf := .pending) (ka := .clear) (.app (kf := .clear) (ka := .pending) (.var _ _ (by decide +kernel)) (.app (kf := .pending) (ka := .pending) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.lam (by decide +kernel) (fun | .rigid => ((.rigidApp (.rigidApp (.rigidApp (.var _ _ (by decide +kernel))))) : SelfintRound6ReaderBinary.Typed _ _ .rigid).weaken _ (by decide +kernel) | .pending => ((.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .pending) (.app (kf := .pending) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .pending).weaken _ (by decide +kernel) | .clear => ((.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.app (kf := .clear) (ka := .clear) (.var _ _ (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel)) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) : SelfintRound6ReaderBinary.Typed _ _ .clear).weaken _ (by decide +kernel))) (by decide +kernel)) (.var _ _ (by decide +kernel)) (by decide +kernel))
#print axioms reject9544
def r9545 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject9545 : ¬ Reader r9545 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0))))) [(.lam (.var 1)), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.var 0))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9545
def r9546 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject9546 : ¬ Reader r9546 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))))))] [(.app (.lam (.var 1)) (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9546
def r9547 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))) (.var 1))
theorem reject9547 : ¬ Reader r9547 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))) (.lam (.var 1))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))) (.lam (.var 1)))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))) (.lam (.var 1))) (.lam (.var 1))), (.lam (.var 1))] [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))), (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9547
def r9548 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9548 : ¬ Reader r9548 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[6],[0,5],[6],[],[],[]] [[],[],[],[],[],[0],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.lam 5 (.var 2 [0]) [5]) [7]) (.var 0 [6]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [6]) (.app (.var 1 [0,5]) (.var 0 [6]) [0]) [7]) (.var 0 [6]) []) (.var 1 [0,5]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9548
def r9549 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9549 : ¬ Reader r9549 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[],[5,7],[6],[],[],[]] [[],[],[],[],[],[0],[7],[],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.lam 5 (.var 2 [0]) [5]) [7]) (.var 0 [6]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [6]) (.app (.var 0 [6]) (.var 1 [5,7]) [7]) [7]) (.var 0 [6]) []) (.var 1 [5,7]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9549
def r9550 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1))))) (.var 1))
theorem reject9550 : ¬ Reader r9550 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 1)))), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9550
def r9551 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1))))) (.var 1))
theorem reject9551 : ¬ Reader r9551 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1)))), (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 1))))] [(.lam (.var 1)), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9551
def r9552 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))) (.var 1))
theorem reject9552 : ¬ Reader r9552 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))) (.lam (.app (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9552
def r9553 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))) (.var 1))
theorem reject9553 : ¬ Reader r9553 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 1))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 1)))) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 2)))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 2))))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 1)))) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))) (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9553
def r9554 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 1))))))) (.var 1))
theorem reject9554 : ¬ Reader r9554 := by
  exact replay_absent false [] 6 0 (by decide +kernel) (by decide +kernel)
#print axioms reject9554
def r9555 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 1))))))) (.var 1))
theorem reject9555 : ¬ Reader r9555 := by
  exact replay_absent false [] 6 0 (by decide +kernel) (by decide +kernel)
#print axioms reject9555
def r9556 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject9556 : ¬ Reader r9556 := by
  exact replay_loop true [] 5 5 (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 0)) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 1)) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 1))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 0)) (.var 0)), (.app (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 1)) (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 1)))) (.var 0))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.var 0)) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.var 1)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9556
def r9557 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1))))))) (.var 1))
theorem reject9557 : ¬ Reader r9557 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1))))))) [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 1))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9557
def r9558 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject9558 : ¬ Reader r9558 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1], [1, 1], [1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] [[1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.var 3))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject9558
def r9559 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))) (.var 1))
theorem reject9559 : ¬ Reader r9559 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))) [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))] [(.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9559
def r9560 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject9560 : ¬ Reader r9560 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))) [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))] [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 1) (.var 2)))))) (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9560
end Blc.HandlerLet.Slice44Main0262
