import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0238
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r8567 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject8567 : ¬ Reader r8567 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3))))))) [(.lam (.lam (.var 2))), (.lam (.app (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4))))))) (.lam (.lam (.var 3)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8567
def r8568 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject8568 : ¬ Reader r8568 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))) [(.lam (.var 1)), (.lam (.lam (.app (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))) (.lam (.var 3)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8568
def r8569 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1))
theorem reject8569 : ¬ Reader r8569 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 1))))) [(.var 0), (.lam (.lam (.lam (.app (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 4)))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.app (.var 0) (.var 0)) (.var 4))))) (.var 3)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8569
def r8570 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2)))))) (.var 1))
theorem reject8570 : ¬ Reader r8570 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1], [1, 1, 1, 1], [1, 1, 1, 1, 2, 1], [1, 1, 1, 1, 2, 1, 0, 0], [1, 1, 1, 1, 2], [1, 1, 1, 1]] [[1, 1, 1], [1, 1, 1, 2, 1], [1, 1, 1, 2], [1, 1, 1, 1, 1], [1, 1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2)))))) (.lam (.var 1))) [(.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 4))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 4)))))))) (.lam (.var 1))), (.lam (.var 1))] [(.app (.app (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 4)))))))) (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8570
def r8571 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8571 : ¬ Reader r8571 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1, 1, 2], [1, 1, 1, 1, 1, 2, 0, 1], [1, 1, 1, 1, 1]] [[1, 1, 1], [1, 1, 1, 1, 2], [1, 1, 1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3)))))) (.lam (.lam (.var 2)))) [(.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 4))))))), (.lam (.lam (.var 2))), (.lam (.lam (.var 2)))] [(.app (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 4))))))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8571
def r8572 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject8572 : ¬ Reader r8572 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1, 1, 2], [1, 1, 1, 1, 1, 2, 0, 1], [1, 1, 1, 1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.var 3)))))) (.lam (.var 1))) [(.lam (.var 1))] [(.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 4))))))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8572
def r8573 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1)))) (.var 1))
theorem reject8573 : ¬ Reader r8573 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 1)))) [(.lam (.lam (.lam (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 4))) (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.app (.var 0) (.var 0))) (.var 4))))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8573
def r8574 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.lam (.var 2)))))) (.var 1))
theorem reject8574 : ¬ Reader r8574 := by
 exact mixed_reduct true [[1, 1, 2, 0, 2, 1], [1, 1, 2, 0, 2, 1], [1, 1, 2, 0, 2]] [] (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject8574
def r8575 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 2)))) (.var 1))))) (.var 1))
theorem reject8575 : ¬ Reader r8575 := by
 exact mixed_reduct true [[1, 1, 2, 0, 2, 1], [1, 1, 2, 0, 2, 1], [1, 1, 2, 0, 2]] [] (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject8575
def r8576 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject8576 : ¬ Reader r8576 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.var 3)))), (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 3))))), (.lam (.lam (.lam (.var 3)))), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 3))))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8576
def r8577 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.lam (.lam (.lam (.var 3)))))))) (.var 1))
theorem reject8577 : ¬ Reader r8577 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))), (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 4) (.lam (.lam (.lam (.var 3))))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8577
def r8578 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject8578 : ¬ Reader r8578 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 3))))), (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.var 4))))))) (.lam (.lam (.lam (.var 3))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8578
def r8579 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.lam (.lam (.var 3))))))) (.var 1))
theorem reject8579 : ¬ Reader r8579 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.var 0), (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))), (.var 0), (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 4)) (.lam (.lam (.lam (.var 3))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8579
def r8580 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 2))) (.lam (.lam (.var 2)))))) (.var 1))
theorem reject8580 : ¬ Reader r8580 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 1)), (.lam (.lam (.lam (.app (.var 0) (.var 0))))), (.lam (.var 1)), (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 4))) (.lam (.lam (.var 2))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8580
def r8581 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 3)))) (.lam (.var 1))))) (.var 1))
theorem reject8581 : ¬ Reader r8581 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 2))), (.lam (.lam (.app (.var 0) (.var 0)))), (.lam (.lam (.var 2))), (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 4)))) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8581
def r8582 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 4))))) (.var 0)))) (.var 1))
theorem reject8582 : ¬ Reader r8582 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.var 3)))), (.lam (.app (.var 0) (.var 0))), (.lam (.lam (.lam (.var 3)))), (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 4))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8582
def r8583 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.var 2))) (.var 0)))) (.var 1))
theorem reject8583 : ¬ Reader r8583 := by
  exact replay_loop true [] 12 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.var 2)))))) (.lam (.var 4))) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8583
def r8584 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0)))) (.var 1))
theorem reject8584 : ¬ Reader r8584 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8584
def r8585 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)))) (.var 1))
theorem reject8585 : ¬ Reader r8585 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))) (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8585
def r8586 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject8586 : ¬ Reader r8586 := by
  exact replay_loop true [] 5 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))), (.lam (.lam (.lam (.var 3)))), (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.var 0)))), (.lam (.lam (.lam (.var 3)))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8586
def r8587 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject8587 : ¬ Reader r8587 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.app (.var 0) (.var 0))), (.lam (.lam (.lam (.var 3)))), (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.var 4)))))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8587
def r8588 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject8588 : ¬ Reader r8588 := by
  exact replay_loop true [] 1 8 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.var 1)))))) (.var 0)) (.lam (.var 2))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8588
def r8589 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2))))))) (.var 0)) (.var 1)))) (.var 1))
theorem reject8589 : ¬ Reader r8589 := by
  exact replay_loop true [] 9 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2))))))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2))))))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8589
def r8590 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8590 : ¬ Reader r8590 := by
  exact replay_loop true [] 7 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8590
def r8591 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8591 : ¬ Reader r8591 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.app (.var 0) (.var 0)))), (.lam (.lam (.var 2))), (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.var 4)))))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8591
def r8592 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8592 : ¬ Reader r8592 := by
  exact replay_loop true [] 7 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.lam (.app (.var 0) (.var 0))), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8592
def r8593 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))) (.lam (.var 2))))) (.var 1))
theorem reject8593 : ¬ Reader r8593 := by
  exact replay_loop true [] 9 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8593
def r8594 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.var 1))
theorem reject8594 : ¬ Reader r8594 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.app (.var 0) (.var 0))))), (.lam (.var 1)), (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 2)))) (.lam (.var 4)))))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8594
def r8595 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.lam (.app (.var 0) (.var 0)))))) (.var 1))
theorem reject8595 : ¬ Reader r8595 := by
  exact replay_loop true [] 9 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.var 1)), (.lam (.app (.var 0) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8595
def r8596 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))) (.var 1)))) (.var 1))
theorem reject8596 : ¬ Reader r8596 := by
  exact replay_absent true [] 11 1 (by decide +kernel) (by decide +kernel)
#print axioms reject8596
def r8597 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1)))) (.var 1))
theorem reject8597 : ¬ Reader r8597 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2], [1, 1, 1, 2, 1], [1, 1, 1, 2, 1, 1], [1, 1, 1, 2, 1], [1, 1, 1, 2], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[1, 1, 2], [1, 1, 2, 1, 1], [1, 1, 2, 1], [1, 1, 2], [1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1)))) (.var 0)) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8597
def r8598 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 3))))) (.var 1)))) (.var 1))
theorem reject8598 : ¬ Reader r8598 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))), (.var 0), (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.var 3))))) (.var 4)))))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8598
def r8599 : Term := (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject8599 : ¬ Reader r8599 := by
  exact replay_loop true [] 3 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.var 3)))), (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.var 0) (.var 0)))), (.lam (.lam (.lam (.var 3)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8599
def r8600 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject8600 : ¬ Reader r8600 := by
  exact replay_loop true [] 2 1 (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) [] [(.lam (.lam (.lam (.var 3)))), (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8600
def r8601 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))))) (.var 1))
theorem reject8601 : ¬ Reader r8601 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))) [(.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8601
def r8602 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))) (.var 1))
theorem reject8602 : ¬ Reader r8602 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 2], [1, 1, 2, 2, 0], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0, 2], [1, 1, 2, 0], [1, 1, 1, 2], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 4))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject8602
def r8603 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject8603 : ¬ Reader r8603 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))) [(.lam (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))))) (.lam (.var 2))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 4))) (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8603
def r8604 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject8604 : ¬ Reader r8604 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 2)) (.var 0)))))) [(.lam (.lam (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 4)) (.var 0))))) (.var 2)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.app (.var 0) (.var 4)) (.var 0))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8604
def r8605 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject8605 : ¬ Reader r8605 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 2))))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject8605
def r8606 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))) (.var 1))
theorem reject8606 : ¬ Reader r8606 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2, 1], [1, 1, 2, 1, 0], [1, 1], [1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1, 2, 0, 1, 0, 0], [1, 1, 1, 2, 0], [1, 1, 1, 1, 1], [1, 1, 1, 1, 1, 0, 0], [1, 1, 1, 1]] [[2, 0, 1], [1, 1], [1], [1, 2, 0, 1], [1, 2, 0], [1, 1, 1], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))))) [(.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 5)) (.lam (.var 2))))))))))] [(.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 4)) (.lam (.var 1))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8606
end Blc.HandlerLet.Slice44Main0238
