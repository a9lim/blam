import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0242
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r8727 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.var 1) (.lam (.lam (.var 1))))))) (.var 1))
theorem reject8727 : ¬ Reader r8727 := by
 exact mixed_reduct true [[1, 1]] [[1, 2], [1, 2, 1], [1, 2]] (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.var 1) (.lam (.lam (.var 1)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.app (.var 1) (.lam (.lam (.var 1))))))) [(.app (.var 0) (.lam (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8727
def r8728 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.var 2))))) (.var 1))
theorem reject8728 : ¬ Reader r8728 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 0)))))) (.lam (.var 2))))) [(.lam (.lam (.var 0))), (.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8728
def r8729 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.var 1))))))) (.var 1)))) (.var 1))
theorem reject8729 : ¬ Reader r8729 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.var 1))))))) (.var 1))) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.var 1))))))) (.var 1)))) [(.lam (.lam (.lam (.var 1)))), (.var 0), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8729
def r8730 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8730 : ¬ Reader r8730 := by
 exact mixed_reduct true [[1, 1]] [[1, 1], [1, 1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1], [1], [1], [1, 1, 2], [1, 1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2))), (.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8730
def r8731 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8731 : ¬ Reader r8731 := by
 exact mixed_reduct true [[1, 1]] [[1, 2], [1, 2, 1, 1], [1, 2, 1], [1, 2], [1, 1], [1, 1, 1, 2], [1, 1, 1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.var 3))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.var 3)))))) [(.lam (.lam (.var 2))), (.lam (.lam (.var 2))), (.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8731
def r8732 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.var 2))))) (.var 1))
theorem reject8732 : ¬ Reader r8732 := by
 exact mixed_reduct true [[1, 1]] [[1, 2], [1, 2, 1, 1], [1, 2, 1], [1, 2], [1, 1], [1, 1, 1, 2], [1, 1, 1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 1))))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.lam (.var 1))), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8732
def r8733 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 2))))) (.app (.var 0) (.lam (.var 1)))) (.var 1)))) (.var 1))
theorem reject8733 : ¬ Reader r8733 := by
  exact replay_absent true [] 9 1 (by decide +kernel) (by decide +kernel)
#print axioms reject8733
def r8734 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.lam (.var 2)))))) (.var 1)))) (.var 1))
theorem reject8734 : ¬ Reader r8734 := by
 exact mixed_reduct true [[1, 1]] [[1, 2], [1, 2, 1, 1], [1, 2, 1], [1, 2], [1, 1], [1, 1, 1, 2], [1, 1, 1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.lam (.var 2)))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.lam (.var 2)))))) (.var 1)))) [(.var 0), (.lam (.lam (.lam (.lam (.var 2))))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8734
def r8735 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8735 : ¬ Reader r8735 := by
  exact replay_loop true [] 8 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 4))))))) [(.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.lam (.var 1))) (.lam (.lam (.var 5))))))), (.lam (.lam (.var 2)))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8735
def r8736 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8736 : ¬ Reader r8736 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.lam (.lam (.var 4))))))) [(.lam (.var 0)), (.lam (.lam (.var 2)))] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 0))) (.lam (.lam (.var 3))))), (.lam (.var 0)), (.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8736
def r8737 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject8737 : ¬ Reader r8737 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 1)))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 1)))) (.lam (.var 3)))))) [(.lam (.lam (.var 1))), (.lam (.var 1))] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 1)))) (.lam (.var 2)))), (.lam (.lam (.var 1))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8737
def r8738 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 2))))) (.var 1)))) (.var 1))
theorem reject8738 : ¬ Reader r8738 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 2))))) (.var 1))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 2))))) (.var 2))))) [(.lam (.lam (.lam (.var 2)))), (.var 0)] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 2))))) (.var 1))), (.lam (.lam (.lam (.var 2)))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8738
def r8739 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 2))))))) (.var 1))
theorem reject8739 : ¬ Reader r8739 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 2)))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 2)))))))) [(.var 0), (.lam (.lam (.lam (.var 2))))] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 2)))))), (.var 0), (.lam (.lam (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8739
def r8740 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 1)))))) (.var 1))
theorem reject8740 : ¬ Reader r8740 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 1))))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 3))) (.lam (.lam (.var 1))))))) [(.lam (.var 1)), (.lam (.lam (.var 1)))] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.var 2))) (.lam (.lam (.var 1))))), (.lam (.var 1)), (.lam (.lam (.var 1))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8740
def r8741 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 0))))) (.var 1))
theorem reject8741 : ¬ Reader r8741 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 0)))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 4)))) (.lam (.var 0)))))) [(.lam (.lam (.var 2))), (.lam (.var 0))] [(.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 0)))), (.lam (.lam (.var 2))), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8741
def r8742 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))) (.var 1))
theorem reject8742 : ¬ Reader r8742 := by
  exact replay_loop true [] 1 8 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8742
def r8743 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.var 2))))) (.var 1))
theorem reject8743 : ¬ Reader r8743 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0], [1, 1, 1, 2, 0, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1, 2, 0]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 0))))) (.lam (.var 3)))))) [(.lam (.var 1))] [(.lam (.lam (.var 2))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8743
def r8744 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 0)))) (.lam (.var 2))))) (.var 1))
theorem reject8744 : ¬ Reader r8744 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 0)))) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.var 0)))) (.lam (.var 2))))) [(.lam (.lam (.var 0))), (.lam (.var 1)), (.lam (.lam (.var 0))), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8744
def r8745 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 1)))) (.var 1))
theorem reject8745 : ¬ Reader r8745 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0], [1, 1, 1, 2, 0, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1, 2, 0]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.lam (.var 1)))))) (.var 2))))) [(.var 0)] [(.lam (.lam (.lam (.var 1)))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8745
def r8746 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.var 1))))) (.var 1)))) (.var 1))
theorem reject8746 : ¬ Reader r8746 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.var 1))))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.var 1))))) (.var 1)))) [(.lam (.lam (.lam (.var 1)))), (.var 0), (.lam (.lam (.lam (.var 1)))), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8746
def r8747 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.lam (.lam (.lam (.var 1))))))) (.var 1))
theorem reject8747 : ¬ Reader r8747 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.lam (.lam (.lam (.var 1)))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.lam (.lam (.lam (.var 1))))))) [(.var 0), (.lam (.lam (.lam (.var 1)))), (.var 0), (.lam (.lam (.lam (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8747
def r8748 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))) (.lam (.lam (.var 0)))))) (.var 1))
theorem reject8748 : ¬ Reader r8748 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))) (.lam (.lam (.var 0))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))) (.lam (.lam (.var 0)))))) [(.lam (.var 1)), (.lam (.lam (.var 0))), (.lam (.var 1)), (.lam (.lam (.var 0)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8748
def r8749 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.lam (.var 0)))) (.var 1)))) (.var 1))
theorem reject8749 : ¬ Reader r8749 := by
 exact mixed_reduct true [[1, 1]] [[1, 2, 1], [1, 2, 1, 1], [1, 2, 1], [1, 2]] (.app (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.lam (.var 0)))) (.var 1))) (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.lam (.var 0)))) (.var 1)))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8749
def r8750 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 0))) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject8750 : ¬ Reader r8750 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 0))) (.var 0)) (.lam (.var 4))))))) [(.lam (.var 1))] [(.lam (.var 0)), (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8750
def r8751 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)))) (.var 1))
theorem reject8751 : ¬ Reader r8751 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.var 1)))) (.var 0)) (.var 3)))))) [(.var 0)] [(.lam (.lam (.var 1))), (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8751
def r8752 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1)))) (.var 1))
theorem reject8752 : ¬ Reader r8752 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 1], [1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1, 1], [1, 1, 1], [1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8752
def r8753 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.var 0))) (.var 1)))) (.var 1))
theorem reject8753 : ¬ Reader r8753 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2], [1, 1, 2, 1, 1], [1, 1, 2, 1], [1, 1, 2]] (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.var 0))) (.var 1))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.var 0))) (.var 1)))) [(.lam (.var 0)), (.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8753
def r8754 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1)) (.lam (.var 0))))) (.var 1))
theorem reject8754 : ¬ Reader r8754 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 2], [1, 1, 2, 1, 1], [1, 1, 2, 1], [1, 1, 2]] (.app (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1)) (.lam (.var 0)))) (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.var 1)) (.lam (.var 0))))) [(.var 0), (.lam (.var 0))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8754
def r8755 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) (.var 1))
theorem reject8755 : ¬ Reader r8755 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.app (.var 1) (.lam (.var 0))))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.app (.var 1) (.lam (.var 0)))))) [(.app (.var 0) (.lam (.var 0)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8755
def r8756 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))))) (.var 1))
theorem reject8756 : ¬ Reader r8756 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))))) [(.lam (.lam (.lam (.var 3)))), (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))))) (.lam (.lam (.lam (.var 3))))) (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 4)))))))) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.var 3)))))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8756
def r8757 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2)))))) (.var 1))
theorem reject8757 : ¬ Reader r8757 := by
 exact mixed_reduct true [[1, 1]] [[1, 1, 1, 2, 1], [1, 1, 1, 2, 1], [1, 1, 1, 2]] (.app (.app (.app (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2)))))) (.lam (.var 0))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject8757
def r8758 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject8758 : ¬ Reader r8758 := by
 exact mixed_reduct true [[1, 1]] [[2], [2, 1], [2], [1], [1, 2], [1, 1]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 3)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.lam (.lam (.var 3))))))) [(.var 0)] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8758
def r8759 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0)))) (.var 1))
theorem reject8759 : ¬ Reader r8759 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 4))) (.var 0)))))) [] [(.lam (.var 1)), (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 0))), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8759
def r8760 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4))))))) (.var 1))
theorem reject8760 : ¬ Reader r8760 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4))))))) [(.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4))))))) (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 4)))))))), (.lam (.lam (.lam (.var 3)))), (.lam (.lam (.lam (.var 3))))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8760
def r8761 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3)))))) (.var 1))
theorem reject8761 : ¬ Reader r8761 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 4))))))) [(.lam (.lam (.var 2)))] [(.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.lam (.lam (.var 3))))), (.lam (.lam (.var 2))), (.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8761
def r8762 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.var 2))))) (.var 1))
theorem reject8762 : ¬ Reader r8762 := by
 exact mixed_reduct true [[1, 1]] [[1, 2], [1, 2, 1], [1, 2]] (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.var 2))))) [(.lam (.var 1))] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8762
def r8763 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.var 1)))) (.var 1))
theorem reject8763 : ¬ Reader r8763 := by
  exact replay_loop true [] 1 5 (.app (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.var 1))) (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 3))))) (.var 0)) (.var 1)))) [(.var 0)] [(.lam (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject8763
def r8764 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject8764 : ¬ Reader r8764 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 1], [1, 1, 2, 2, 0], [1, 1, 2, 1], [1, 1, 1]] (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))))) (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4)))))))))) [(.lam (.var 1)), (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4))))))))) (.lam (.var 1))) (.lam (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.app (.var 1) (.lam (.var 5))))))))) (.lam (.var 2)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8764
def r8765 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.app (.var 0) (.lam (.var 2)))))) (.var 1))
theorem reject8765 : ¬ Reader r8765 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 2], [1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4))))) (.app (.var 0) (.lam (.var 3))))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))) (.app (.var 0) (.lam (.var 2)))))) [(.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3))))) (.app (.var 0) (.lam (.var 2)))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8765
def r8766 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.app (.var 0) (.var 1))))) (.var 1))
theorem reject8766 : ¬ Reader r8766 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 2], [1, 1, 2, 0], [1, 1]] [[1, 2, 0], [1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.lam (.app (.var 1) (.var 3))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.lam (.app (.var 1) (.var 3))))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.lam (.app (.var 1) (.var 3))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject8766
end Blc.HandlerLet.Slice44Main0242
