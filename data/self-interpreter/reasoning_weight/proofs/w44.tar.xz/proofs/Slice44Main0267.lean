import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0267
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r9721 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2))))))) (.var 1))
theorem reject9721 : ¬ Reader r9721 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2, 0], [1, 1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.app (.var 1) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject9721
def r9722 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 0))))) (.var 1))
theorem reject9722 : ¬ Reader r9722 := by
 exact mixed_reduct true [] [[1, 1, 1], [1, 1, 1, 0, 1, 2, 0]] (.app (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 0))))) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject9722
def r9723 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.var 1))
theorem reject9723 : ¬ Reader r9723 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9723
def r9724 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.var 1))
theorem reject9724 : ¬ Reader r9724 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9724
def r9725 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9725 : ¬ Reader r9725 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9725
def r9726 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9726 : ¬ Reader r9726 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9726
def r9727 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9727 : ¬ Reader r9727 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9727
def r9728 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 1))
theorem reject9728 : ¬ Reader r9728 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9728
def r9729 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9729 : ¬ Reader r9729 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9729
def r9730 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9730 : ¬ Reader r9730 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9730
def r9731 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9731 : ¬ Reader r9731 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9731
def r9732 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9732 : ¬ Reader r9732 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9732
def r9733 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9733 : ¬ Reader r9733 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9733
def r9734 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9734 : ¬ Reader r9734 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9734
def r9735 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9735 : ¬ Reader r9735 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9735
def r9736 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9736 : ¬ Reader r9736 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9736
def r9737 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9737 : ¬ Reader r9737 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9737
def r9738 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9738 : ¬ Reader r9738 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9738
def r9739 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9739 : ¬ Reader r9739 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9739
def r9740 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9740 : ¬ Reader r9740 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9740
def r9741 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9741 : ¬ Reader r9741 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9741
def r9742 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9742 : ¬ Reader r9742 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9742
def r9743 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9743 : ¬ Reader r9743 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9743
def r9744 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9744 : ¬ Reader r9744 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9744
def r9745 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9745 : ¬ Reader r9745 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9745
def r9746 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9746 : ¬ Reader r9746 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9746
def r9747 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9747 : ¬ Reader r9747 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9747
def r9748 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9748 : ¬ Reader r9748 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9748
def r9749 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1))
theorem reject9749 : ¬ Reader r9749 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9749
def r9750 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.var 1))
theorem reject9750 : ¬ Reader r9750 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 1)) (.var 0))))))) (.var 1)) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9750
def r9751 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0))))) (.var 1))
theorem reject9751 : ¬ Reader r9751 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 1)) (.var 0))))))) (.var 1)) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9751
def r9752 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2))))) (.var 1))
theorem reject9752 : ¬ Reader r9752 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9752
def r9753 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 0))))) (.var 1))
theorem reject9753 : ¬ Reader r9753 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9753 Z) = some (spine (BodyLetSpecial.templateState (.lam (.lam (.app (.var 3) (.var 2)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9753
def r9754 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 0))))) (.var 1))
theorem reject9754 : ¬ Reader r9754 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9754 Z) = some (spine (BodyLetSpecial.templateState (.lam (.lam (.app (.var 2) (.var 3)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9754
def r9755 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.var 1))
theorem reject9755 : ¬ Reader r9755 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9755
def r9756 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))) (.var 1))
theorem reject9756 : ¬ Reader r9756 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9756
def r9757 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))) (.var 1))
theorem reject9757 : ¬ Reader r9757 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9757
def r9758 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 1)))))) (.var 1))
theorem reject9758 : ¬ Reader r9758 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9758
def r9759 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.var 2)))))) (.var 1))
theorem reject9759 : ¬ Reader r9759 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9759
def r9760 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 0))))))) (.var 1))
theorem reject9760 : ¬ Reader r9760 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9760
end Blc.HandlerLet.Slice44Main0267
