import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0180
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r6269 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject6269 : ¬ Reader r6269 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 1))))) (.lam (.app (.var 1) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6269
def r6270 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.lam (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject6270 : ¬ Reader r6270 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 3))))) (.lam (.app (.var 1) (.var 1)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6270
def r6271 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3)))) (.app (.var 0) (.lam (.var 1)))))) (.var 1))
theorem reject6271 : ¬ Reader r6271 := by
  exact replay_absent true [] 4 1 (by decide +kernel) (by decide +kernel)
#print axioms reject6271
def r6272 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3))))))))) (.var 1))
theorem reject6272 : ¬ Reader r6272 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 5) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 9) (.lam (.var 3)))))))))))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 5) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 9) (.lam (.var 3))))))))))))))))))) [(.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 8) (.lam (.var 3))))))))))))))))] [(.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 5) (.lam (.var 3))))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6272
def r6273 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 4))))))))) (.var 1))
theorem reject6273 : ¬ Reader r6273 := by
  exact replay_absent true [] 5 1 (by decide +kernel) (by decide +kernel)
#print axioms reject6273
def r6274 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4))))))))) (.var 1))
theorem reject6274 : ¬ Reader r6274 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 8)))))))) (.lam (.var 5)))))) (.lam (.var 3)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 8)))))))) (.lam (.var 5)))))) (.lam (.var 3))))))) [(.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 7)))))))) (.lam (.var 4)))))) (.lam (.var 2))))] [(.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 5)))))))) (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6274
def r6275 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 3))))))) (.var 1))
theorem reject6275 : ¬ Reader r6275 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[],[]] [[],[],[],[],[],[],[],[],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6,7]) (.lam 6 (.app (.app (.var 0 [6,7]) (.lam 7 (.app (.var 2 [5,6,7]) (.var 1 [6,7]) []) [7]) []) (.lam 8 (.var 3 [0]) [8]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6275
def r6276 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3))))))) (.var 1))
theorem reject6276 : ¬ Reader r6276 := by
  exact replay_loop true [] 2 7 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 3)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 5))))))))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.var 1)), (.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6276
def r6277 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3))))))) (.var 1))
theorem reject6277 : ¬ Reader r6277 := by
  exact replay_loop true [] 6 5 (.app (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 5)))))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2)))) (.lam (.app (.app (.lam (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 5)))))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 3)))) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))) [(.lam (.var 1)), (.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6277
def r6278 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 2))))))))) (.var 1))
theorem reject6278 : ¬ Reader r6278 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[],[]] [[],[],[],[],[],[],[],[0],[6],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.app (.var 3 [0]) (.lam 8 (.var 2 [6]) [8]) [0]) [7]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6278
def r6279 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 4))))))))) (.var 1))
theorem reject6279 : ¬ Reader r6279 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,8],[6,8],[],[6,8],[],[],[]] [[],[],[],[],[0],[0],[0],[0],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) [0]) [4]) (.lam 5 (.app (.var 0 [5,6,8]) (.lam 6 (.app (.app (.var 1 [5,6,8]) (.var 0 [6,8]) [0]) (.lam 7 (.app (.var 1 [6,8]) (.lam 8 (.var 4 [0]) [8]) [0]) [7]) [0]) [6]) [0]) [5]) [0]) (.var 1 [1]) [0]) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6279
def r6280 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2))))))))) (.var 1))
theorem reject6280 : ¬ Reader r6280 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.lam (.var 2))))))))) (.lam (.app (.var 2) (.lam (.var 2))))))) [(.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 5) (.lam (.var 2))))))))))), (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 7) (.lam (.var 2))))))))) (.lam (.app (.var 5) (.lam (.var 2))))))) (.lam (.app (.var 4) (.lam (.var 2)))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6280
def r6281 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4))))))))) (.var 1))
theorem reject6281 : ¬ Reader r6281 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 5))))))))) (.lam (.app (.var 1) (.lam (.var 3))))))) [(.lam (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 5)))))))) (.lam (.var 2)))), (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 7))))))))) (.lam (.app (.var 1) (.lam (.var 5))))))) (.lam (.app (.var 1) (.lam (.var 4)))))) (.lam (.var 2))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6281
def r6282 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4))))))))) (.var 1))
theorem reject6282 : ¬ Reader r6282 := by
  exact replay_loop true [] 8 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.lam (.var 1))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6282
def r6283 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.lam (.var 1))))) (.var 1))
theorem reject6283 : ¬ Reader r6283 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)) [] [(.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 4))))) (.lam (.var 1))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6283
def r6284 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))) (.var 0)))) (.var 1))
theorem reject6284 : ¬ Reader r6284 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.lam (.var 1))) [] [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4)))))) (.var 0))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6284
def r6285 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 2))))) (.var 1))
theorem reject6285 : ¬ Reader r6285 := by
  exact replay_loop true [] 10 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 2)))) (.app (.app (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 6)))) (.app (.var 1) (.var 1))))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 6)))) (.app (.var 1) (.var 1))))) (.app (.var 1) (.var 1)))))) (.app (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 6)))) (.app (.var 1) (.var 1))))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))) (.lam (.var 6)))) (.app (.var 1) (.var 1))))) (.app (.var 1) (.var 1)))))))) [(.lam (.var 1))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6285
def r6286 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 2))))) (.var 1))
theorem reject6286 : ¬ Reader r6286 := by
  exact replay_loop true [] 7 8 (.app (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 6)))))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 2))))) (.app (.app (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 6)))))))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.var 4)))))))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6286
def r6287 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))) (.lam (.var 2))))) (.var 1))
theorem reject6287 : ¬ Reader r6287 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))) (.lam (.var 3))) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))) (.lam (.var 3))) (.var 1))))) (.lam (.var 1))) [(.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))) (.lam (.var 3))) (.var 1))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject6287
def r6288 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.var 2))))) (.var 1))
theorem reject6288 : ¬ Reader r6288 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.var 4))))) (.var 1))))) [(.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))) (.lam (.var 2))))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6288
def r6289 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.var 2))))) (.var 1))
theorem reject6289 : ¬ Reader r6289 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.var 6)))))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.var 6))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.lam (.var 4)))))))) [] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6289
def r6290 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))) (.var 1)))) (.var 1))
theorem reject6290 : ¬ Reader r6290 := by
 exact Rootcert2Flow.reject [[1, 1]] [[],[],[],[],[8],[9],[0],[11],[5,10],[7],[9],[],[],[],[]] [[],[],[],[],[],[6],[],[9],[],[10],[6],[7],[],[14],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [8]) (.lam 5 (.lam 6 (.app (.var 2 [8]) (.app (.var 1 [9]) (.lam 7 (.var 2 [9]) [7]) [10]) []) [6]) [5]) []) (.var 1 [0]) []) [4]) (.lam 8 (.app (.app (.var 0 [5,10]) (.lam 9 (.lam 10 (.app (.var 2 [5,10]) (.app (.var 1 [7]) (.lam 11 (.var 2 [7]) [11]) [9]) [6]) [10]) [9]) [6]) (.var 1 [0]) []) [8]) []) (.var 1 [1]) []) (.lam 12 (.app (.app (.var 0 []) (.lam 13 (.lam 14 (.var 1 []) [14]) [13]) []) (.var 4 [3]) []) [12]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6290
def r6291 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))) (.var 1)))) (.var 1))
theorem reject6291 : ¬ Reader r6291 := by
 exact mixed_reduct true [[1, 1], [1, 1], [1, 1, 1, 2, 0, 0, 1], [1, 1, 1], [1, 1, 1, 1, 2, 0, 0, 1], [1, 1, 1, 1, 2, 0, 0]] [[1, 0, 1, 1, 2, 0, 0, 1], [1, 0, 1, 1, 2, 0, 0], []] (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))) (.var 2)) (.lam (.var 2))))) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))) (.var 2)) (.lam (.var 2)))))) (.var 0)) [(.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 2)))))) (.var 3)) (.lam (.var 2))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject6291
def r6292 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))) (.var 1)))) (.var 1))
theorem reject6292 : ¬ Reader r6292 := by
  exact replay_loop true [] 2 5 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))) (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))) (.var 3)))) (.lam (.var 2)))))) [(.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))) (.var 2))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6292
def r6293 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.var 1)))) (.var 1))
theorem reject6293 : ¬ Reader r6293 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.var 7))))))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.var 7)))))))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))) (.var 5))))))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6293
def r6294 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 1)))) (.var 1))
theorem reject6294 : ¬ Reader r6294 := by
  exact replay_loop true [] 2 9 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 3))))))) (.var 4))))))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6294
def r6295 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))) (.var 0)))) (.var 1))
theorem reject6295 : ¬ Reader r6295 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6295
def r6296 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))) (.var 0)))) (.var 1))
theorem reject6296 : ¬ Reader r6296 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 1)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6296
def r6297 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))) (.var 0)))) (.var 1))
theorem reject6297 : ¬ Reader r6297 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 4)))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6297
def r6298 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))) (.var 0)))) (.var 1))
theorem reject6298 : ¬ Reader r6298 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 1))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6298
def r6299 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))) (.var 0)))) (.var 1))
theorem reject6299 : ¬ Reader r6299 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 1))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6299
def r6300 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.var 0)))) (.var 1))
theorem reject6300 : ¬ Reader r6300 := by
  exact replay_loop true [] 1 2 (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 4))))) (.var 0))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6300
def r6301 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 3))))))) (.var 1))
theorem reject6301 : ¬ Reader r6301 := by
  exact replay_loop true [] 6 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))) (.var 0)) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6301
def r6302 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6302 : ¬ Reader r6302 := by
  exact replay_loop true [] 4 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.app (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.app (.var 1) (.var 1))))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6302
def r6303 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6303 : ¬ Reader r6303 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject6303
def r6304 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6304 : ¬ Reader r6304 := by
  exact replay_absent true [] 6 1 (by decide +kernel) (by decide +kernel)
#print axioms reject6304
def r6305 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6305 : ¬ Reader r6305 := by
  exact replay_loop true [] 1 3 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.var 1)) (.var 1))))) [(.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.var 1)) (.var 1))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6305
def r6306 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6306 : ¬ Reader r6306 := by
  exact replay_loop true [] 6 1 (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) [(.lam (.var 1))] [(.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6306
def r6307 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) (.var 1))
theorem reject6307 : ¬ Reader r6307 := by
  exact replay_loop true [] 4 2 (.app (.app (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject6307
def r6308 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))) (.var 1))
theorem reject6308 : ¬ Reader r6308 := by
 exact mixed_reduct true [[1, 1], [1, 1, 2, 0, 0], [1, 1]] [[1, 1, 1, 0, 1, 2, 0], [1, 1, 1, 0, 1, 1], [1, 1]] (.app (.app (.app (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.var 2)))) (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.var 2)))) (.var 3)))))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject6308
end Blc.HandlerLet.Slice44Main0180
