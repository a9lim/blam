import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0260
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r9441 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 1))
theorem reject9441 : ¬ Reader r9441 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9441
def r9442 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0))))) (.var 1))
theorem reject9442 : ¬ Reader r9442 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9442 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9442
def r9443 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))) (.var 1))
theorem reject9443 : ¬ Reader r9443 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1))))) [(.lam (.app (.var 0) (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9443
def r9444 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))) (.var 1))
theorem reject9444 : ¬ Reader r9444 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,6],[5,7],[0,6],[],[],[]] [[],[],[],[],[],[6],[],[6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.var 0 [5,7]) (.var 1 [0,6]) [6]) (.lam 7 (.app (.var 1 [5,7]) (.app (.var 1 [5,7]) (.var 0 [0,6]) [6]) [6]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9444
def r9445 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))) (.var 1))
theorem reject9445 : ¬ Reader r9445 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5,7],[0],[],[],[]] [[],[],[],[],[],[6],[],[6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.var 0 [5,7]) (.var 1 [0]) [6]) (.lam 7 (.app (.var 1 [5,7]) (.app (.var 0 [0]) (.var 1 [5,7]) [0]) [6]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9445
def r9446 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))) (.var 1))
theorem reject9446 : ¬ Reader r9446 := by
  exact replay_loop true [] 1 5 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))) [(.lam (.app (.app (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))))) (.var 0)) (.lam (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9446
def r9447 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 1))
theorem reject9447 : ¬ Reader r9447 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6,7],[0,5,6,7],[0,5,6,7],[],[],[]] [[],[],[],[],[0],[6],[0],[0,6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) [0]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 0 [0,5,6,7]) (.var 0 [0,5,6,7]) [0,6]) (.lam 7 (.app (.var 1 [0,5,6,7]) (.app (.var 2 [0,5,6,7]) (.var 0 [0,5,6,7]) [0,6]) [0,6]) [7]) [0]) [6]) [5]) [0]) (.var 1 [1]) [0]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9447
def r9448 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 1))
theorem reject9448 : ¬ Reader r9448 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,5,6,7],[0,5,6,7],[0,5,6,7],[],[],[]] [[],[],[],[],[0],[6],[0],[0,6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) [0]) [4]) (.lam 5 (.lam 6 (.app (.app (.var 0 [0,5,6,7]) (.var 0 [0,5,6,7]) [0,6]) (.lam 7 (.app (.var 1 [0,5,6,7]) (.app (.var 0 [0,5,6,7]) (.var 2 [0,5,6,7]) [0,6]) [0,6]) [7]) [0]) [6]) [5]) [0]) (.var 1 [1]) [0]) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) [0]) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9448
def r9449 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 1))
theorem reject9449 : ¬ Reader r9449 := by
  exact replay_loop true [] 7 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) [(.lam (.app (.var 0) (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 1)) (.var 1))))] [(.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9449
def r9450 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.var 1))
theorem reject9450 : ¬ Reader r9450 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9450 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9450
def r9451 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.var 1))
theorem reject9451 : ¬ Reader r9451 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9451 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9451
def r9452 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.var 1))
theorem reject9452 : ¬ Reader r9452 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9452 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9452
def r9453 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.var 1))
theorem reject9453 : ¬ Reader r9453 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9453 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9453
def r9454 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.var 1))
theorem reject9454 : ¬ Reader r9454 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9454 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9454
def r9455 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.var 1))
theorem reject9455 : ¬ Reader r9455 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9455 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9455
def r9456 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.var 1))
theorem reject9456 : ¬ Reader r9456 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9456 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9456
def r9457 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.var 1))
theorem reject9457 : ¬ Reader r9457 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9457 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9457
def r9458 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.var 1))
theorem reject9458 : ¬ Reader r9458 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9458 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9458
def r9459 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.var 1))
theorem reject9459 : ¬ Reader r9459 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9459 Z) = some (spine (BodyLetSpecial.templateState (.lam (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9459
def r9460 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject9460 : ¬ Reader r9460 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9460
def r9461 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 2)))))) (.var 1))
theorem reject9461 : ¬ Reader r9461 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9461
def r9462 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1))
theorem reject9462 : ¬ Reader r9462 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9462
def r9463 : Term := (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 1) (.var 1))) (.var 2))))) (.var 1))
theorem reject9463 : ¬ Reader r9463 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9463
def r9464 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))) (.var 1))
theorem reject9464 : ¬ Reader r9464 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.var 0 [5]) (.var 1 [0,7]) [6]) (.app (.app (.var 0 [5]) (.lam 7 (.var 2 [0,7]) [7]) [6]) (.var 0 [5]) []) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9464
def r9465 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 1))
theorem reject9465 : ¬ Reader r9465 := by
  exact replay_loop true [] 1 4 (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))) [(.lam (.lam (.var 2))), (.app (.app (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.var 1))) (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9465
def r9466 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 1))))))) (.var 1))
theorem reject9466 : ¬ Reader r9466 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 1], [1, 1, 1, 0, 2, 2], [1, 1]] [[2], [1], []] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 2)))))))) [(.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 1)))))) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))] [(.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 1))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject9466
def r9467 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))) (.var 1))
theorem reject9467 : ¬ Reader r9467 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))) (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))) (.app (.var 0) (.lam (.var 1))))) [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))) (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.lam (.var 2))))))] [(.app (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))) (.app (.var 0) (.lam (.var 1)))) (.app (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9467
def r9468 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))) (.var 1))
theorem reject9468 : ¬ Reader r9468 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))) [(.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9468
def r9469 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))) (.var 1))
theorem reject9469 : ¬ Reader r9469 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))) (.lam (.var 1)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9469
def r9470 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject9470 : ¬ Reader r9470 := by
 exact mixed_reduct true [[1, 1], [1, 1, 1], [1, 1], [1, 1, 2], [1, 1, 1, 1], [1, 1, 1], [1, 1, 1, 2], [1, 1, 1, 1, 1]] [[], [1, 1], [1], [1, 2], [1, 1, 1]] (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))) [(.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))] [(.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 1)))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject9470
def r9471 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 1))
theorem reject9471 : ¬ Reader r9471 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[5],[],[],[]] [[],[],[],[],[],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.lam 7 (.var 2 [0,7]) [7]) [6]) (.var 0 [5]) []) (.app (.var 1 [0,7]) (.var 0 [5]) [0,7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9471
def r9472 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 1))
theorem reject9472 : ¬ Reader r9472 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[0,7],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.lam 7 (.var 2 [0,7]) [7]) [6]) (.var 0 [5]) []) (.app (.var 0 [5]) (.var 1 [0,7]) [6]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9472
def r9473 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject9473 : ¬ Reader r9473 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[0],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 1 [0]) (.var 0 [5]) [0]) [6]) (.var 0 [5]) []) (.lam 7 (.var 2 [0]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9473
def r9474 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject9474 : ¬ Reader r9474 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,6],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[0,6],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 0 [5]) (.var 1 [0,6]) [6]) [6]) (.var 0 [5]) []) (.lam 7 (.var 2 [0,6]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9474
def r9475 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))) (.var 1))
theorem reject9475 : ¬ Reader r9475 := by
  exact replay_loop true [] 5 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2))))) (.var 0)) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2))))) (.var 0))) [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2))))) (.var 0)) (.var 0)), (.lam (.var 1))] [(.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))), (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 2)))))), (.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9475
def r9476 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)) (.lam (.var 1)))))) (.var 1))
theorem reject9476 : ¬ Reader r9476 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0],[5],[],[],[],[]] [[],[],[],[],[],[6],[],[5],[],[10],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.app (.var 1 [0]) (.var 1 [0]) [0]) [6]) (.var 0 [5]) []) (.lam 7 (.var 1 [5]) [7]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9476
def r9477 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject9477 : ¬ Reader r9477 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))) [(.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))))] [(.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9477
def r9478 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))) (.var 1))
theorem reject9478 : ¬ Reader r9478 := by
  exact replay_loop true [] 8 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))) (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))) [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))), (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))] [(.lam (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))), (.app (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))), (.app (.var 0) (.var 0)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9478
def r9479 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1)))))) (.var 1))
theorem reject9479 : ¬ Reader r9479 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1))))) (.var 0)) (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1)))))) [(.var 0), (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 1))))))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9479
def r9480 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 0))))) (.var 1))
theorem reject9480 : ¬ Reader r9480 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9480 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9480
end Blc.HandlerLet.Slice44Main0260
