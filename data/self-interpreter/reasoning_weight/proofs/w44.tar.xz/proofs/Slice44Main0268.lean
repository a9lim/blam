import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0268
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r9761 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9761 : ¬ Reader r9761 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9761
def r9762 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9762 : ¬ Reader r9762 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9762
def r9763 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 2))))) (.var 1))
theorem reject9763 : ¬ Reader r9763 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9763
def r9764 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))) (.var 1))
theorem reject9764 : ¬ Reader r9764 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9764
def r9765 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))) (.var 1))
theorem reject9765 : ¬ Reader r9765 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9765
def r9766 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 1))))) (.var 1))
theorem reject9766 : ¬ Reader r9766 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9766
def r9767 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 1))))) (.var 1))
theorem reject9767 : ¬ Reader r9767 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9767
def r9768 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 1))))) (.var 1))
theorem reject9768 : ¬ Reader r9768 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9768
def r9769 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))) (.var 1))
theorem reject9769 : ¬ Reader r9769 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9769
def r9770 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 2))))) (.var 1))
theorem reject9770 : ¬ Reader r9770 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9770
def r9771 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 0)))))) (.var 1))
theorem reject9771 : ¬ Reader r9771 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9771
def r9772 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 2))))) (.var 1))
theorem reject9772 : ¬ Reader r9772 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9772
def r9773 : Term := (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 0)))))) (.var 1))
theorem reject9773 : ¬ Reader r9773 := by
  exact replay_absent true [] 3 1 (by decide +kernel) (by decide +kernel)
#print axioms reject9773
def r9774 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))) (.var 1))
theorem reject9774 : ¬ Reader r9774 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9774 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9774
def r9775 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))) (.var 1))
theorem reject9775 : ¬ Reader r9775 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9775 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9775
def r9776 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))) (.var 1))
theorem reject9776 : ¬ Reader r9776 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9776
def r9777 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))) (.var 1))
theorem reject9777 : ¬ Reader r9777 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[],[],[],[],[]] [[],[],[],[],[],[6],[],[8],[0,7],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.lam 7 (.lam 8 (.var 3 [0,7]) [8]) [7]) [6]) (.var 0 [5]) []) (.var 2 [0]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9777
def r9778 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject9778 : ¬ Reader r9778 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))) [(.lam (.lam (.var 2)))] [(.lam (.var 1)), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9778
def r9779 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))) (.var 1))
theorem reject9779 : ¬ Reader r9779 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[0,7],[5],[],[],[],[],[]] [[],[],[],[],[],[6],[],[0,7],[0],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [5]) (.var 1 [0]) [6]) (.var 0 [5]) []) [4]) (.lam 5 (.lam 6 (.app (.app (.app (.var 0 [5]) (.lam 7 (.var 2 [0,7]) [7]) [6]) (.var 0 [5]) []) (.lam 8 (.var 3 [0]) [8]) []) [6]) [5]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9779
def r9780 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9780 : ¬ Reader r9780 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1)))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))) [(.lam (.lam (.var 2)))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9780
def r9781 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))) (.var 1))
theorem reject9781 : ¬ Reader r9781 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4)))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))) [(.lam (.lam (.var 2)))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9781
def r9782 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject9782 : ¬ Reader r9782 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[0],[0,8],[5],[],[],[],[]] [[],[],[],[],[],[6],[7],[],[0,8],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.var 1 [0]) [7]) (.lam 5 (.var 1 [6]) [5]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [5]) (.var 2 [0]) [6]) (.lam 8 (.var 2 [0,8]) [8]) [7]) (.var 0 [5]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9782
def r9783 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))) (.var 1))
theorem reject9783 : ¬ Reader r9783 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9783
def r9784 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))) (.var 1))
theorem reject9784 : ¬ Reader r9784 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9784
def r9785 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))) (.var 1))
theorem reject9785 : ¬ Reader r9785 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9785
def r9786 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))) (.var 1))
theorem reject9786 : ¬ Reader r9786 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9786 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9786
def r9787 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))) (.var 1))
theorem reject9787 : ¬ Reader r9787 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9787 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9787
def r9788 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.var 1))
theorem reject9788 : ¬ Reader r9788 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))) [(.lam (.var 1))] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9788
def r9789 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))) (.var 1))
theorem reject9789 : ¬ Reader r9789 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[6],[],[5,8],[6],[],[],[],[]] [[],[],[],[],[],[0],[7],[],[5,8],[],[11],[]] (.app (.app (.app (.lam 4 (.app (.app (.var 0 [6]) (.lam 5 (.var 2 [0]) [5]) [7]) (.var 0 [6]) []) [4]) (.lam 6 (.lam 7 (.app (.app (.app (.var 0 [6]) (.lam 8 (.var 2 [5,8]) [8]) [7]) (.var 0 [6]) []) (.var 2 [0]) []) [7]) [6]) []) (.var 1 [1]) []) (.lam 9 (.app (.app (.var 0 []) (.lam 10 (.lam 11 (.var 1 []) [11]) [10]) []) (.var 4 [3]) []) [9]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9789
def r9790 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))) (.var 1))
theorem reject9790 : ¬ Reader r9790 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9790
def r9791 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))) (.var 1))
theorem reject9791 : ¬ Reader r9791 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))) (.lam (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))) [(.lam (.var 1))] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9791
def r9792 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject9792 : ¬ Reader r9792 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.var 0)) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))) (.var 1)))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9792
def r9793 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))) (.var 1))
theorem reject9793 : ¬ Reader r9793 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9793 Z) = some (spine (BodyLetSpecial.templateState (.lam (.var 2)) (.lam (.app (.var 1) (.var 1)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9793
def r9794 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.var 1))
theorem reject9794 : ¬ Reader r9794 := by
  exact replay_loop true [] 1 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9794
def r9795 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.var 1))
theorem reject9795 : ¬ Reader r9795 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9795
def r9796 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 1))
theorem reject9796 : ¬ Reader r9796 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9796 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9796
def r9797 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 1))
theorem reject9797 : ¬ Reader r9797 := by
 intro hr
 have he : betaSteps [[1, 1]] (.app r9797 Z) = some (spine (BodyLetSpecial.templateState (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))]) := by decide
 have hn := betas_preserve_nf (betaSteps_sound _ he) hr.zero_red zeroOut_normal
 exact BodyLetSpecial.template_no_nf _ _ _ ⟨_,hn,zeroOut_normal⟩
#print axioms reject9797
def r9798 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.var 1))
theorem reject9798 : ¬ Reader r9798 := by
  exact replay_loop true [] 3 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))) (.var 0)) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) [(.var 0)] [(.lam (.lam (.var 2))), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9798
def r9799 : Term := (.app (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.var 1))
theorem reject9799 : ¬ Reader r9799 := by
  exact replay_loop true [] 1 2 (.app (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9799
def r9800 : Term := (.app (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 3)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1))
theorem reject9800 : ¬ Reader r9800 := by
  exact replay_loop true [] 4 3 (.app (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.var 1))) (.lam (.app (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.var 2))))) [] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject9800
end Blc.HandlerLet.Slice44Main0268
