import Flow
import Extras
import Recursor
import Lark
import Owl
import Strict
import Blc.SelfintRootLetPending
import Blc.SelfintRound8ReaderTwoLambda
namespace Blc.HandlerLet.Slice44Main0352
open Term SelfintClass SelfintLowerBound SelfintStreamSpecializer SelfintSourceCost
set_option maxRecDepth 20000
set_option maxHeartbeats 6000000
def r12399 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.var 0)) (.var 1))
theorem reject12399 : ¬ Reader r12399 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))))))) (.var 0)) (.lam (.var 2))))) [(.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))), (.lam (.var 1)), (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 5))))))) (.var 0)) (.lam (.var 3))))) (.var 0)) (.lam (.var 2)))), (.lam (.var 1))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12399
def r12400 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.var 1)) (.var 0))
theorem reject12400 : ¬ Reader r12400 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.var 2))))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))) (.lam (.var 2)))), (.lam (.var 1))] [(.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))), (.lam (.var 1)), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12400
def r12401 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.var 0)) (.var 1))
theorem reject12401 : ¬ Reader r12401 := by
  exact replay_loop true [] 4 1 (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.var 2)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 5))))))) (.lam (.var 3))))) (.lam (.var 2))))) [(.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))) (.lam (.var 2)))), (.lam (.var 1))] [(.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))), (.lam (.var 1)), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12401
def r12402 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.var 1)) (.var 0))
theorem reject12402 : ¬ Reader r12402 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[]] [[],[],[],[],[],[],[],[6],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.var 1 [6]) [7]) []) (.var 2 [0]) []) [6]) []) [5]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12402
def r12403 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))) (.var 0)) (.var 1))
theorem reject12403 : ¬ Reader r12403 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6],[6],[],[],[],[]] [[],[],[],[],[],[],[],[6],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.var 0 [5,6]) (.lam 6 (.app (.app (.app (.var 1 [5,6]) (.var 0 [6]) []) (.lam 7 (.var 1 [6]) [7]) []) (.var 2 [0]) []) [6]) []) [5]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12403
def r12404 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.var 1)) (.var 0))
theorem reject12404 : ¬ Reader r12404 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))) (.lam (.var 1))) (.var 1)))) [(.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))), (.var 0), (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 5)))))) (.lam (.var 1))) (.var 3)))) (.lam (.var 1))) (.var 2)))), (.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12404
def r12405 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.var 0)) (.var 1))
theorem reject12405 : ¬ Reader r12405 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))) (.lam (.var 1))) (.var 1)))) [(.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))), (.var 0), (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 5)))))) (.lam (.var 1))) (.var 3)))) (.lam (.var 1))) (.var 2)))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12405
def r12406 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.var 1)) (.var 0))
theorem reject12406 : ¬ Reader r12406 := by
  exact replay_loop true [] 1 11 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) [(.var 0), (.var 0), (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))) (.var 1))), (.var 0), (.var 0), (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))), (.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12406
def r12407 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.var 0)) (.var 1))
theorem reject12407 : ¬ Reader r12407 := by
  exact replay_loop true [] 1 11 (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))) [(.var 0), (.var 0), (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))) (.var 1))), (.var 0), (.var 0), (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))), (.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12407
def r12408 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 1)))) (.var 1)) (.var 0))
theorem reject12408 : ¬ Reader r12408 := by
  exact replay_loop true [] 6 5 (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 3))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 3))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 1) (.var 1)))))) [(.var 0)] [(.var 0), (.var 0), (.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12408
def r12409 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 1)))) (.var 0)) (.var 1))
theorem reject12409 : ¬ Reader r12409 := by
  exact replay_loop true [] 6 5 (.app (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 3))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))) (.var 3))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.var 1) (.var 1)))))) [(.var 0)] [(.var 0), (.var 0), (.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12409
def r12410 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))) (.var 1)))) (.var 1)) (.var 0))
theorem reject12410 : ¬ Reader r12410 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[]] [[],[],[],[],[],[],[],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6,7]) (.lam 6 (.app (.var 0 [6,7]) (.lam 7 (.app (.var 2 [5,6,7]) (.var 1 [6,7]) []) [7]) []) [6]) []) (.var 1 [0]) []) [5]) []) (.var 1 [1]) []) (.var 0 [0]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12410
def r12411 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))) (.var 1)))) (.var 0)) (.var 1))
theorem reject12411 : ¬ Reader r12411 := by
 exact Rootcert2Flow.reject [] [[],[],[],[],[5],[5,6,7],[6,7],[6,7],[],[],[]] [[],[],[],[],[],[],[],[],[],[10],[]] (.app (.app (.app (.app (.lam 4 (.app (.var 0 [5]) (.var 0 [5]) []) [4]) (.lam 5 (.app (.app (.var 0 [5,6,7]) (.lam 6 (.app (.var 0 [6,7]) (.lam 7 (.app (.var 2 [5,6,7]) (.var 1 [6,7]) []) [7]) []) [6]) []) (.var 1 [0]) []) [5]) []) (.var 0 [0]) []) (.var 1 [1]) []) (.lam 8 (.app (.app (.var 0 []) (.lam 9 (.lam 10 (.var 1 []) [10]) [9]) []) (.var 4 [3]) []) [8]) []) (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12411
def r12412 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 1)))) (.var 1)) (.var 0))
theorem reject12412 : ¬ Reader r12412 := by
  exact replay_loop true [] 2 7 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 3)))))))) [(.var 0), (.var 0)] [(.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12412
def r12413 : Term := (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 1)))) (.var 0)) (.var 1))
theorem reject12413 : ¬ Reader r12413 := by
  exact replay_loop true [] 2 7 (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))) (.var 3)))))))) [(.var 0), (.var 0)] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12413
def r12414 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12414 : ¬ Reader r12414 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1, 2], [1, 1, 1, 2, 0], [1, 1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject12414
def r12415 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12415 : ¬ Reader r12415 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1, 2], [1, 1, 1, 2, 0], [1, 1, 1]] [[1, 1, 1, 2, 0], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.app (.var 3) (.var 1)))))))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject12415
def r12416 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12416 : ¬ Reader r12416 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1, 2, 2], [1, 1, 1, 2, 2, 0], [1, 1, 1, 2], [1, 1, 1, 2, 0], [1, 1, 1]] [[1, 1, 1, 2, 0, 2], [1, 1, 1, 2, 0], [1, 1, 1, 1, 2], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject12416
def r12417 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12417 : ¬ Reader r12417 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1], [1, 1, 1], [1, 1, 1, 2, 2], [1, 1, 1, 2, 2, 0], [1, 1, 1, 2], [1, 1, 1, 2, 0], [1, 1, 1]] [[1, 1, 1, 2, 0, 2], [1, 1, 1, 2, 0], [1, 1, 1, 1, 2], [1, 1, 1, 1]] (.app (.app (.app (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.app (.var 1) (.var 3)))))))) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))) [] [] (by decide +kernel) (by decide +kernel)
#print axioms reject12417
def r12418 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12418 : ¬ Reader r12418 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))) [(.lam (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0))))) (.var 1)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0)))))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12418
def r12419 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12419 : ¬ Reader r12419 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 2)) (.var 0)))))) [(.lam (.app (.app (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0))))) (.var 1)) (.lam (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.app (.var 0) (.var 3)) (.var 0)))))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12419
def r12420 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12420 : ¬ Reader r12420 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))) [(.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12420
def r12421 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12421 : ¬ Reader r12421 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[1, 1, 2, 0], [1, 1, 1]] (.app (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))) (.var 0)) [(.var 0)] [(.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12421
def r12422 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12422 : ¬ Reader r12422 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[2], [1], [], [2]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2)))))) [(.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0)))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12422
def r12423 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12423 : ¬ Reader r12423 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[2], [1], [], [2]] (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 2)))))) [(.app (.app (.var 0) (.lam (.var 1))) (.app (.var 0) (.var 0)))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12423
def r12424 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12424 : ¬ Reader r12424 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12424
def r12425 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12425 : ¬ Reader r12425 := by
 exact mixed_reduct true [[1, 1, 1], [1, 1, 1, 2, 0, 1], [1, 1, 1]] [[1, 2, 0], [1, 1]] (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))) [(.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel)
#print axioms reject12425
def r12426 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12426 : ¬ Reader r12426 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12426
def r12427 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12427 : ¬ Reader r12427 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 1)))))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12427
def r12428 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12428 : ¬ Reader r12428 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2))) (.var 0))))) [] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12428
def r12429 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12429 : ¬ Reader r12429 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 1))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 2))) (.var 0))))) [] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12429
def r12430 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12430 : ¬ Reader r12430 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.lam (.app (.var 0) (.lam (.var 1))))] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12430
def r12431 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12431 : ¬ Reader r12431 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 1)))))))) [(.lam (.app (.var 0) (.lam (.var 1))))] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12431
def r12432 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12432 : ¬ Reader r12432 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12432
def r12433 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12433 : ¬ Reader r12433 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 0)) (.var 2))))) [(.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12433
def r12434 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 1)) (.var 0))
theorem reject12434 : ¬ Reader r12434 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12434
def r12435 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))
theorem reject12435 : ¬ Reader r12435 := by
  exact replay_loop true [] 2 2 (.app (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 1))) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1))))) (.var 0)) (.var 2))))) [(.var 0)] [(.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12435
def r12436 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1)) (.var 0))
theorem reject12436 : ¬ Reader r12436 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.var 1)))))) [(.var 0)] [(.var 0), (.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12436
def r12437 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 0)) (.var 1))
theorem reject12437 : ¬ Reader r12437 := by
  exact replay_loop true [] 2 3 (.app (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.var 1))))) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.app (.var 1) (.var 1)))))) [(.var 0)] [(.var 0), (.var 0), (.var 1), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12437
def r12438 : Term := (.app (.app (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1)) (.var 0))
theorem reject12438 : ¬ Reader r12438 := by
  exact replay_loop true [] 1 4 (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))) [(.var 0)] [(.var 1), (.var 0), (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 4)))] (by decide +kernel) (by decide +kernel) (by decide +kernel)
#print axioms reject12438
end Blc.HandlerLet.Slice44Main0352
